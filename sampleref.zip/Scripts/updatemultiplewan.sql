with custWan as (
select distinct customerid,ndc,wholesaleraccountnumber
from  (
select CustomerId,Ndc,WholesalerAccountNumber, dateyear,datemonth,
cast(cast(DateYear as nvarchar(4)) + '' + RIGHT('00'+cast(DateMonth as nvarchar(2)),2) as int) as dateandmonth from dbo.SalesTotalMonthly) query 
where query.dateandmonth >= cast(cast(year(dateadd(day, -90, GETDATE())) as nvarchar(4)) + '' +
 RIGHT('00'+cast(month(dateadd(day, -90, GETDATE())) as nvarchar(2)),2) as int)

/*select c.customerid,st.ndc,st.wholesaleraccountnumber
from customer c join SalesTotals st  on c.customerid = st.customerid
group by c.customerid,st.wholesaleraccountnumber,st.ndc*/
), 
WanAgg as (select a.customerid,a.ndc,STRING_AGG(a.wholesaleraccountnumber,',') WITHIN GROUP ( ORDER BY a.customerid ASC) as wholesaleraccountnumber
 from custWan a
group by a.customerid,a.ndc)

select 
                   ROW_NUMBER() OVER (
                   ORDER BY npp.[NationalPricePredictionGuid]
                   ) NPPId
                 , npp.[NationalPricePredictionId]
                 , npp.[NationalPricePredictionGuid]
                 , npp.[RecordSyncDate]
                 , npp.[IsActive]
                 , case when pis.IsShort is not null then pis.IsShort else 0 end as 'IsShort'
                 , npp.[Ndc]
                 , phi.ItemId
                 , phi.ItemDescription
                 , npp.[PriceDate]
                 , npp.[RunDate]
                 , npp.[TrainDate]
                 , npp.[WacUnitPrice]
                 , npp.[PeriodFirstIdentified]
                 --facility price info
                 , cip.CpSupplierID 'CpSupplierId'
                 , s.SupplierName 'Wholesaler'
                 , c.ClientId
                 , c.CustomerId
                 , c.Premier_Relation as PremierRelation
                 , dbo.fn_FacilityName(c.CustomerName, c.AccountNumber, c.Dea) 'FacilityName'
                 , dbo.fn_DivisionName(c.DivisionName, c.DivisionId) 'Division'
                 , cip.PriceAmount 'UnitPrice'
                 , pl.PriceListDescription 'AccountType'
                 , sum(isNull(st.[1YearUsageQty], 0)) 'YearQty'
                 , cast(sum(isnull(st.[1YearUsageQty], 0))as decimal (18,2))/4  'QuarterQty'
                 , cast(sum(isnull(st.[1YearUsageQty], 0))as decimal (18,2))/4 * cip.PriceAmount 'QuarterCost'
                 , sc.StorageConditionDescription
                 , gpid.GpiCodeSegment + ' - ' + replace(gpid.GpiName,'*','') 'GpiDrugGroup'
                 -- verification current month
                 , npp.[Month0ProbabilityOfIncrease]
                 , npp.[Month0PredictedWacUnitPrice]
                 
                 -- month 1
                 , npp.[Month1ProbabilityOfIncrease]
                 , npp.[Month1PredictedWacUnitPrice]
                 , npp.[Month1PercentIncrease]
                 , npp.[Month1Period]
                 , dbo.fn_IncreaseMoneyByPercent(cip.PriceAmount, npp.Month1PercentIncrease) 'Month1PredictedUnitPrice'
                 , cast(sum(isnull(st.[1YearUsageQty], 0))as decimal (18,2))/4 * cast((cip.PriceAmount + (cip.PriceAmount * npp.Month1PercentIncrease)) as decimal(18, 2)) 'Month1PredictedQuarterCost'
                 , cast(sum(isnull(st.[1YearUsageQty], 0))as decimal (18,2))/4 * (cast((cip.PriceAmount + (cip.PriceAmount * npp.Month1PercentIncrease)) as decimal(18, 2)) - cip.PriceAmount) 'Month1PredictedQuarterSavings'
                 
                 --month 2
                 , npp.[Month2ProbabilityOfIncrease]
                 , npp.[Month2PredictedWacUnitPrice]
                 , npp.[Month2PercentIncrease]
                 , npp.[Month2Period]
                 , dbo.fn_IncreaseMoneyByPercent(cip.PriceAmount, npp.Month2PercentIncrease) 'Month2PredictedUnitPrice'
                 , cast(sum(isnull(st.[1YearUsageQty], 0))as decimal (18,2))/4 * cast((cip.PriceAmount + (cip.PriceAmount * npp.Month2PercentIncrease)) as decimal(18, 2)) 'Month2PredictedQuarterCost'
                 , cast(sum(isnull(st.[1YearUsageQty], 0))as decimal (18,2))/4 * (cast((cip.PriceAmount + (cip.PriceAmount * npp.Month2PercentIncrease)) as decimal(18, 2)) - cip.PriceAmount) 'Month2PredictedQuarterSavings'
                 
                 --month 3
                 , npp.[Month3ProbabilityOfIncrease]
                 , npp.[Month3PredictedWacUnitPrice]
                 , npp.[Month3PercentIncrease]
                 , npp.[Month3Period]
                 , dbo.fn_IncreaseMoneyByPercent(cip.PriceAmount, npp.Month3PercentIncrease) 'Month3PredictedUnitPrice'
                 , cast(sum(isnull(st.[1YearUsageQty], 0))as decimal (18,2))/4 * cast((cip.PriceAmount + (cip.PriceAmount * npp.Month3PercentIncrease)) as decimal(18, 2)) 'Month3PredictedQuarterCost'
                 , cast(sum(isnull(st.[1YearUsageQty], 0))as decimal (18,2))/4 * (cast((cip.PriceAmount + (cip.PriceAmount * npp.Month3PercentIncrease)) as decimal(18, 2)) - cip.PriceAmount) 'Month3PredictedQuarterSavings'
                 , wa.wholesalerAccountNumber
                from [Predictive].[NationalPricePrediction] npp
                join PharmacyItem phi on phi.Ndc = npp.Ndc
                join CustomerItem ci on npp.Ndc = ci.Ndc
                join CustomerItemPricing cip on ci.Ndc = cip.Ndc
                                                and ci.ClientId = cip.ClientId
                join Supplier s on cip.CpSupplierID = s.SupplierId
                join Customer c on c.CustomerId = cip.CustomerId
                                   and c.ClientId = cip.ClientId
                join WanAgg wa on c.customerid = wa.customerid and wa.ndc = phi.ndc
                -- join to PriceList and PriceTypeGroup to use description to link purchases and prices  
                join PriceList pl on pl.PriceListId = cip.PriceListId
                join PriceTypeGroup ptg on ptg.PriceTypeGroupDescription = pl.PriceListDescription
                join SalesTotals st on npp.NDC = st.ndc
                                       and st.ClientId = ci.ClientId
                                       and st.CustomerId = cip.CustomerId
                                       and st.PriceTypeGroupId = ptg.PriceTypeGroupId
                                       and st.SupplierId = cip.CpSupplierID
                join ItemMaster.WkGpiDescriptions gpid on substring(phi.GPI, 1, 2) = substring(gpid.GpiCodeSegment, 1, 2)
                -- left join to PharmacyItemShortage to determine if Ndc has shortages
                left join
                (   select pisg.Ndc
                            , case when pisg.Ndc is null then 0 else 1 end as IsShort
                    from PharmacyItemShortage pisg
                    where pisg.Ndc is not null
                            and pisg.Status != 'R'
                    group by pisg.Ndc) pis on pis.Ndc = npp.Ndc
                    join ItemMaster.StorageCondition sc on sc.storageConditionId = phi.storageConditionId
            where npp.IsActive = 1
                and c.status = 'A'
                and st.[1YearUsageQty] > 0
                and c.ClientId = 6
                and gpid.GPIRecordTypeId > 0
				and gpid.Status = 'A'
                and substring(phi.GPI, 1, 2) = gpid.GpiCodeSegment
                -- todo: We should evaluate how we handle BuyInExclusions
                and not exists 
                (   select bie.ItemId
                    from App.BuyInExclusion bie
                    where bie.ItemId = phi.ItemId
                          and (bie.CustomerId is null or bie.CustomerId = c.customerid)
                          and bie.ClientId = c.ClientId
                          and (bie.ExclusionEndDate > getdate() or bie.ExclusionEndDate is null))
            -- we need to group because SalesTotals groups by WAN, and that will cause duplicates since WAN is not 
            -- everything is going to be included in the grouping *except* for sales total 1 year usage, which will be summed
            group by npp.ndc
                    , st.PriceTypeGroupId
                    , st.SupplierId
                    , cip.CpSupplierID
                    , s.SupplierName
                    , c.ClientId
                    , c.CustomerId
                    , npp.NationalPricePredictionGuid
                    , npp.[NationalPricePredictionId]
                    , npp.[RecordSyncDate]
                    , npp.[IsActive]
                    , pis.IsShort
                    , phi.ItemId
                    , phi.ItemDescription
                    , npp.[PriceDate]
                    , npp.[RunDate]
                    , npp.[TrainDate]
                    , npp.[WacUnitPrice]
                    , npp.[PeriodFirstIdentified]
                    , c.Premier_Relation
                    , c.CustomerName
                    , c.AccountNumber
                    , c.Dea
                    , c.DivisionName
                    , c.DivisionId
                    , cip.PriceAmount
                    , pl.PriceListDescription 
                    , sc.StorageConditionDescription
                    , npp.[Month0ProbabilityOfIncrease]
                    , npp.[Month0PredictedWacUnitPrice]
                    , npp.[Month1ProbabilityOfIncrease]
                    , npp.[Month1PredictedWacUnitPrice]
                    , npp.[Month1PercentIncrease]
                    , npp.[Month1Period]
                    , npp.[Month2ProbabilityOfIncrease]
                    , npp.[Month2PredictedWacUnitPrice]
                    , npp.[Month2PercentIncrease]
                    , npp.[Month2Period]
                    , npp.[Month3ProbabilityOfIncrease]
                    , npp.[Month3PredictedWacUnitPrice]
                    , npp.[Month3PercentIncrease]
                    , npp.[Month3Period]
                    , gpid.GpiCodeSegment + ' - ' + replace(gpid.GpiName,'*','')
					, wa.wholesalerAccountNumber

            order by Ndc

/*
      select top 100
      *,
      month(transactiondate),
      year(transactiondate)  ,
      day(transactiondate) 
      from dbo.salestotalmonthly where YEAR >= year(dateadd(day, -240, GETDATE()))
      and datemonth >= month(dateadd(day, -240, GETDATE()))

      select * from dbo.salestotalmonthly
select distinct datemonth,dateyear from (
(select customerid,ndc,wholesaleraccountnumber,datemonth,dateyear,dateandmonth,
cast(cast(year(dateadd(day, -240, GETDATE())) as nvarchar(4)) + '' +
 RIGHT('00'+cast(month(dateadd(day, -240, GETDATE())) as nvarchar(2)),2) as int) as deriveddateandmonth from  (
select CustomerId,Ndc,WholesalerAccountNumber, dateyear,datemonth,
cast(cast(DateYear as nvarchar(4)) + '' + RIGHT('00'+cast(DateMonth as nvarchar(2)),2) as int) as dateandmonth from dbo.SalesTotalMonthly) query 
where query.dateandmonth >= cast(cast(year(dateadd(day, -240, GETDATE())) as nvarchar(4)) + '' +
 RIGHT('00'+cast(month(dateadd(day, -240, GETDATE())) as nvarchar(2)),2) as int))) b
order by b.DateYear,b.DateMonth

 select 
      distinct dateyear,datemonth
      from dbo.salestotalmonthly where Dateyear >= year(dateadd(day, -240, GETDATE()))
      and datemonth >= month(dateadd(day, -240, GETDATE()))



          declare  @Past90 date = dateadd(day, -240, GETDATE()); select @past90;

      select top 100 * from dbo.sales     */