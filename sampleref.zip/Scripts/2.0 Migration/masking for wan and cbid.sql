truncate table xrefwanload;
truncate table xrefcbidload;

with distinctWan
as (select distinct WholesalerAccountNumber from Sales where clientid = 1)
   , xrefWan
as (select 'WAN-' + cast(row_number() over (order by WholesalerAccountNumber asc) as varchar(25)) as Maskwan
         , WholesalerAccountNumber
    from distinctWan) 
insert into dbo.xrefwanload
		(Maskedwan ,
		WholesalerAccountNumber) 
 select Maskwan,
 		WholesalerAccountNumber 
 		from xrefwan;
 	
 	
with distinctCbid
as (select distinct WholesalerCBID from Sales where clientid = 1)
   , xrefCbid
as ((select 'CBID-' + cast(row_number() over (order by WholesalerCBID asc) as varchar(25)) as maskcbid
          , WholesalerCBID
     from distinctCbid))
insert into dbo.xrefcbidload
		(Maskedcbid ,
		WholesalerCBID) 
 select maskcbid,
 		WholesalerCBID 
 		from xrefCbid;

update sa 
set sa.WholesalerAccountNumber = wa.maskedwan
from dbo.sales sa join xrefwanload wa on sa.WholesalerAccountNumber = wa.WholesalerAccountNumber
where sa.ClientId = 1;
    
update sa 
set sa.WholesalerCBID = wa.Maskedcbid
from dbo.sales sa join xrefcbidload wa on sa.WholesalerCBID = wa.WholesalerCBID   
where sa.ClientId = 1;
 	
delete from dbo.SalesTotals where ClientId = 1;
delete from dbo.SalesTotalMonthly where clientid =1;
exec [DailyMaintinance].[RebuildSalesTotal];

select * from dbo.sales where clientid = 1;

truncate table dbo.SalesTotals;
exec [DailyMaintinance].[RebuildSalesTotal];
truncate table dbo.SalesTotalMonthly;


select * from dbo.SalesTotals

snippiselect count(*) from dbo.sales

select clientid, count(clientid) from raw.PremierCustomerList
group by clientid

select clientid,count(clientid) from dbo.Customer
group by ClientId


