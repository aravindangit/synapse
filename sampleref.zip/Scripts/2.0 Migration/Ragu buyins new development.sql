WITH LatestPuchaseDate
AS (
    SELECT customerid
        , WholesalerAccountNumber
        , Ndc
        , Max(TransactionDate) AS Latestpurchasedate
    FROM dbo.Sales
    GROUP BY customerid
        , WholesalerAccountNumber
        , Ndc
    ),
custWan
AS (
    SELECT l.customerid
        , l.ndc
        , l.wholesaleraccountnumber
        , l.Latestpurchasedate
        , s.qty  
        , s.unitprice
    FROM LatestPuchaseDate l
    JOIN sales s
       ON s.CustomerId = l.CustomerId
            AND s.WholesalerAccountNumber = l.WholesalerAccountNumber
            AND s.ndc = l.Ndc
            AND s.transactiondate = l.Latestpurchasedate
    ) 
    , WanAgg
AS (
    SELECT a.customerid
    , a.ndc
    , STRING_AGG(cast(a.Latestpurchasedate as datetime), ',') WITHIN GROUP (ORDER BY a.customerid ASC) AS Latestpurchasedate
    , STRING_AGG(a.wholesaleraccountnumber, ',') WITHIN GROUP (ORDER BY a.customerid ASC) AS wholesaleraccountnumber
    , STRING_AGG(a.qty, ',') WITHIN GROUP (ORDER BY a.customerid ASC) AS quantity
    , STRING_AGG(a.unitprice, ',') WITHIN GROUP (ORDER BY a.customerid ASC) AS unitprice
    FROM custWan a
    GROUP BY a.customerid
        , a.ndc
    )
SELECT *
FROM WanAgg    -- where ndc in ('00904662361','00002143380')


/*WITH LatestPuchaseDate
AS (
    SELECT customerid
        , WholesalerAccountNumber
        , Ndc
        , Max(TransactionDate) AS Latestpurchasedate
    FROM dbo.Sales
    GROUP BY customerid
        , WholesalerAccountNumber
        , Ndc
    )
    , LatestData
AS (
    SELECT l.customerid
        , l.WholesalerAccountNumber
        , l.Ndc
        , l.Latestpurchasedate
        , s.qty
        , s.unitprice
    FROM dbo.sales s
    JOIN LatestPuchaseDate l
        ON s.CustomerId = l.CustomerId
            AND s.WholesalerAccountNumber = l.WholesalerAccountNumber
            AND s.ndc = l.Ndc
            AND s.transactiondate = l.Latestpurchasedate
    )
SELECT *
FROM latestdata
WHERE ndc = '00000430102'

select * from 

 
SELECT ColumnID, Column1, value  --Do not change 'value' name. Leave it as it is.
FROM tbl_Sample  
CROSS APPLY STRING_SPLIT(Tags, ','); --'Tags' is the name of column containing comma separated values */



;with custWan as (
                    select c.customerid,st.ndc,st.wholesaleraccountnumber
                    from customer c join SalesTotals st  on c.customerid = st.customerid
                    group by c.customerid,st.wholesaleraccountnumber,st.ndc
                    ), 
                    WanAgg as (select a.customerid,a.ndc,STRING_AGG(a.wholesaleraccountnumber,',') WITHIN GROUP ( ORDER BY a.customerid ASC) as wholesaleraccountnumber
                        from custWan a
                    group by a.customerid,a.ndc)
                    select * from WanAgg where  ndc in ('00904662361','00002143380')



select * from dbo.sales where ndc = '00904662361' and wholesaleraccountnumber = '00000000000000399543'
order by transactiondate DESC

truncate table dbo.testingshortage
select * into dbo.testingshortage1 from RawFda.FDAShortage


;with custWan as (
                    select c.customerid,st.ndc,st.wholesaleraccountnumber
                    from customer c join SalesTotals st  on c.customerid = st.customerid
                    group by c.customerid,st.wholesaleraccountnumber,st.ndc
                    ), 
        WanAgg as (select a.customerid,a.ndc,STRING_AGG(cast(a.wholesaleraccountnumber as datetime),',') WITHIN GROUP ( ORDER BY a.customerid ASC) as wholesaleraccountnumber
                        from custWan a
                    group by a.customerid,a.ndc) select * from WanAgg