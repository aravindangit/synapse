(select CustomerId  from dbo.Customer c 
WHERE accountnumber  IN ('PA5036','NJ5062','809162','NJ5061','809161',
'655027','NU2044','PA2196','781393','PA2586','743695','PA5025','730437',
'PA1151','PA1152','742292','PA2033','691507','PA0025',
--'PA2108',
'619908'))

delete from dbo.Customer 
WHERE accountnumber not IN ('PA5036',
'NJ5062','809162',
'NJ5061','809161',
'655027','NU2044',
'PA2196','781393',
'PA2586','743695',
'PA5025',
'730437',
'PA1151',
'PA1152',
'742292',
'PA2033',
'691507',
'PA0025',
--'PA2108',
'619908')

select * from dbo.customer where CustomerId in (2,11,20,26,28,50,51,70,78,85,90,98,114,133,140)  



delete from dbo.customer where CustomerId not in (2,11,20,26,28,50,51,70,78,85,90,98,114,133,140)  

(2,11,20,26,28,50,51,70,78,85,90,98,114,133,140)      
|98       
|114     
|133      
|140    


dbo.SalesArchive
|CustomerId|CustomerUId                         |ClientId|DataSourceId|AccountNumber|CustomerOrganizationId|OrganizationNumber|OrganizationName     |CustomerName                                  |PriceList       |AddrLine1                   |AddrLine2|City         |State|Zip       |ParentCustomerId|CotId|CustomImportCode|GlDept|Status|DateImported           |DateChanged            |CustomerPatientCareAreaId|CustomerBusinessTypeId|CustomerPurchaseTypeId|CustomerSpecialtyTypeId|CustomerRegionId|DeaLicenseNum|DeaLicenseExpiration|StateLicenseNum|StateLicenseExpiration|HinNum|GlnNum|340bId|340bType|HierarchyNum|HierarchyName|CustomerHrsaNumber|BusinessType|PatientCareArea|ClassOfTrade|BockingData|Notes|SysStartTime           |SysEndTime             |DEA      |Premier_Relation|SPC             |DivisionName|DivisionId|
|----------|------------------------------------|--------|------------|-------------|----------------------|------------------|---------------------|----------------------------------------------|----------------|----------------------------|---------|-------------|-----|----------|----------------|-----|----------------|------|------|-----------------------|-----------------------|-------------------------|----------------------|----------------------|-----------------------|----------------|-------------|--------------------|---------------|----------------------|------|------|------|--------|------------|-------------|------------------|------------|---------------|------------|-----------|-----|-----------------------|-----------------------|---------|----------------|----------------|------------|----------|
|2         |AE190455-8623-ED11-B494-002248322A77|9       |            |730437       |9                     |PA5036            |TJUH SYSTEM -  PA5036|ARIA HEALTH - FRANKFORD CAMPUS                |UNK,340B,WAC,GPO|4900 FRANKFORD AVE          |         |PHILADELPHIA |PA   |19124-2618|                |     |                |      |A     |2022-08-24 08:25:35.800|2022-09-21 10:08:25.870|                         |                      |                      |                       |                |             |                    |               |                      |      |      |      |        |            |             |                  |            |               |            |           |     |2022-09-21 10:08:26.000|9999-12-31 23:59:59.000|AF2340317|OLM             |ACUTE - PHARMACY|            |          |
|11        |B7190455-8623-ED11-B494-002248322A77|9       |            |781393       |7                     |PA5036            |TJUH SYSTEM -  PA5036|ABINGTON HOSPITAL LANSDALE                    |GPO,UNK         |100 MEDICAL CAMPUS DR       |         |LANSDALE     |PA   |19446-1259|                |     |                |      |A     |2022-08-24 08:25:35.800|2022-09-21 10:08:25.870|                         |                      |                      |                       |                |             |                    |               |                      |      |      |      |        |            |             |                  |            |               |            |           |     |2022-09-21 10:08:26.000|9999-12-31 23:59:59.000|FL1203809|OLM             |ACUTE - PHARMACY|            |          |
|20        |C0190455-8623-ED11-B494-002248322A77|9       |            |691507       |11                    |PA5036            |TJUH SYSTEM -  PA5036|EINSTEIN MEDICAL CENTER - MONTGOMERY          |UNK,340B,WAC,GPO|559 W GERMANTOWN PIKE       |         |EAST NORRITON|PA   |19403-4250|                |     |                |      |A     |2022-08-24 08:25:35.800|2022-09-21 10:08:25.870|                         |                      |                      |                       |                |             |                    |               |                      |      |      |      |        |            |             |                  |            |               |            |           |     |2022-09-21 10:08:26.000|9999-12-31 23:59:59.000|FE3408184|OLM             |ACUTE - PHARMACY|            |          |
|26        |C6190455-8623-ED11-B494-002248322A77|9       |            |PA0025       |11                    |PA5036            |TJUH SYSTEM -  PA5036|EINSTEIN MEDICAL CENTER                       |340B,UNK,GPO,WAC|5501 OLD YORK RD STE 2      |         |PHILADELPHIA |PA   |19141-3018|                |     |                |      |A     |2022-08-24 08:25:35.800|2022-09-21 10:08:25.870|                         |                      |                      |                       |                |             |                    |               |                      |      |      |      |        |            |             |                  |            |               |            |           |     |2022-09-21 10:08:26.000|9999-12-31 23:59:59.000|AE2409046|OLM             |ACUTE - PHARMACY|            |          |
|28        |C8190455-8623-ED11-B494-002248322A77|9       |            |619908       |13                    |PA5036            |TJUH SYSTEM -  PA5036|MAGEE REHABILITATION HOSPITAL                 |GPO,UNK         |1513 RACE ST                |         |PHILADELPHIA |PA   |19102-1177|                |     |                |      |A     |2022-08-24 08:25:35.800|2022-09-21 10:08:25.870|                         |                      |                      |                       |                |             |                    |               |                      |      |      |      |        |            |             |                  |            |               |            |           |     |2022-09-21 10:08:26.000|9999-12-31 23:59:59.000|AM6387597|OLM             |ACUTE - PHARMACY|            |          |
|50        |DE190455-8623-ED11-B494-002248322A77|9       |            |NU2044       |8                     |PA5036            |TJUH SYSTEM -  PA5036|JEFFERSON WASHINGTON TOWNSHIP HOSPITAL        |340B,UNK,GPO,WAC|435 HURFFVILLE CROSS KEYS RD|         |TURNERSVILLE |NJ   |08012-2453|                |     |                |      |A     |2022-08-24 08:25:35.800|2022-09-21 10:08:25.870|                         |                      |                      |                       |                |             |                    |               |                      |      |      |      |        |            |             |                  |            |               |            |           |     |2022-09-21 10:08:26.000|9999-12-31 23:59:59.000|AJ1035143|OLM             |ACUTE - PHARMACY|            |          |
|51        |DF190455-8623-ED11-B494-002248322A77|9       |            |PA5025       |13                    |PA5036            |TJUH SYSTEM -  PA5036|METHODIST HOSPITAL DIVISION - THOMAS JEFFERSON|WAC,340B,GPO,UNK|2301 S BROAD ST             |         |PHILADELPHIA |PA   |19148-3594|                |     |                |      |A     |2022-08-24 08:25:35.800|2022-09-21 10:08:25.870|                         |                      |                      |                       |                |             |                    |               |                      |      |      |      |        |            |             |                  |            |               |            |           |     |2022-09-21 10:08:26.000|9999-12-31 23:59:59.000|BM5266639|OLM             |ACUTE - PHARMACY|            |          |
|70        |F2190455-8623-ED11-B494-002248322A77|9       |            |PA5036       |1                     |PA5036            |TJUH SYSTEM -  PA5036|TJUH SYSTEM                                   |340B,GPO        |925 CHESTNUT ST STE 110     |         |PHILADELPHIA |PA   |19107-4201|                |     |                |      |A     |2022-08-24 08:25:35.800|2022-09-21 10:08:25.870|                         |                      |                      |                       |                |             |                    |               |                      |      |      |      |        |            |             |                  |            |               |            |           |     |2022-09-21 10:08:26.000|9999-12-31 23:59:59.000|         |OLM             |ACUTE - PHARMACY|            |          |
|78        |FA190455-8623-ED11-B494-002248322A77|9       |            |PA2196       |14                    |PA5036            |TJUH SYSTEM -  PA5036|THOMAS JEFFERSON UNIVERSITY HOSPITAL          |340B,UNK,GPO,WAC|111 S 11TH ST               |         |PHILADELPHIA |PA   |19107-5084|                |     |                |      |A     |2022-08-24 08:25:35.800|2022-09-21 10:08:25.870|                         |                      |                      |                       |                |             |                    |               |                      |      |      |      |        |            |             |                  |            |               |            |           |     |2022-09-21 10:08:26.000|9999-12-31 23:59:59.000|BT6398235|OLM             |ACUTE - PHARMACY|            |          |
|85        |011A0455-8623-ED11-B494-002248322A77|9       |            |809162       |8                     |PA5036            |TJUH SYSTEM -  PA5036|JEFFERSON CHERRY HILL HOSPITAL                |WAC,340B,GPO,UNK|2201 CHAPEL AVE W           |         |CHERRY HILL  |NJ   |08002-2048|                |     |                |      |A     |2022-08-24 08:25:35.800|2022-09-21 10:08:25.870|                         |                      |                      |                       |                |             |                    |               |                      |      |      |      |        |            |             |                  |            |               |            |           |     |2022-09-21 10:08:26.000|9999-12-31 23:59:59.000|AJ1060730|OLM             |ACUTE - PHARMACY|            |          |
|90        |061A0455-8623-ED11-B494-002248322A77|9       |            |PA2586       |13                    |PA5036            |TJUH SYSTEM -  PA5036|JEFFERSON HOSPITAL FOR NEUROSCIENCE           |340B,WAC,GPO    |900 WALNUT ST               |         |PHILADELPHIA |PA   |19107-5191|                |     |                |      |A     |2022-08-24 08:25:35.800|2022-09-21 10:08:25.870|                         |                      |                      |                       |                |             |                    |               |                      |      |      |      |        |            |             |                  |            |               |            |           |     |2022-09-21 10:08:26.000|9999-12-31 23:59:59.000|BT7130266|OLM             |ACUTE - PHARMACY|            |          |
|98        |0E1A0455-8623-ED11-B494-002248322A77|9       |            |743695       |7                     |PA5036            |TJUH SYSTEM -  PA5036|ABINGTON HOSPITAL                             |UNK,GPO         |1200 OLD YORK RD            |         |ABINGTON     |PA   |19001-3788|                |     |                |      |A     |2022-08-24 08:25:35.800|2022-09-21 10:08:25.870|                         |                      |                      |                       |                |             |                    |               |                      |      |      |      |        |            |             |                  |            |               |            |           |     |2022-09-21 10:08:26.000|9999-12-31 23:59:59.000|AA0589448|OLM             |ACUTE - PHARMACY|            |          |
|114       |1E1A0455-8623-ED11-B494-002248322A77|9       |            |PA1151       |9                     |PA5036            |TJUH SYSTEM -  PA5036|ARIA HEALTH - BUCKS CAMPUS                    |WAC,GPO,340B,UNK|380 OXFORD VALLEY RD        |         |LANGHORNE    |PA   |19047-8304|                |     |                |      |A     |2022-08-24 08:25:35.800|2022-09-21 10:08:25.870|                         |                      |                      |                       |                |             |                    |               |                      |      |      |      |        |            |             |                  |            |               |            |           |     |2022-09-21 10:08:26.000|9999-12-31 23:59:59.000|BF6249444|OLM             |ACUTE - PHARMACY|            |          |
|133       |311A0455-8623-ED11-B494-002248322A77|9       |            |PA1152       |9                     |PA5036            |TJUH SYSTEM -  PA5036|ARIA HEALTH - TORRESDALE CAMPUS               |340B,UNK,GPO,WAC|10800 KNIGHTS RD            |         |PHILADELPHIA |PA   |19114-4299|                |     |                |      |A     |2022-08-24 08:25:35.800|2022-09-21 10:08:25.870|                         |                      |                      |                       |                |             |                    |               |                      |      |      |      |        |            |             |                  |            |               |            |           |     |2022-09-21 10:08:26.000|9999-12-31 23:59:59.000|AF7481702|OLM             |ACUTE - PHARMACY|            |          |
|140       |381A0455-8623-ED11-B494-002248322A77|9       |            |809161       |8                     |PA5036            |TJUH SYSTEM -  PA5036|JEFFERSON STRATFORD HOSPITAL                  |340B,GPO,UNK,WAC|18 E LAUREL RD              |         |STRATFORD    |NJ   |08084-1327|                |     |                |      |A     |2022-08-24 08:25:35.800|2022-09-21 10:08:25.870|                         |                      |                      |                       |                |             |                    |               |                      |      |      |      |        |            |             |                  |            |               |            |           |     |2022-09-21 10:08:26.000|9999-12-31 23:59:59.000|AJ1544229|OLM             |ACUTE - PHARMACY|            |          |




delete from dbo.SalesArchive 
where CustomerId not in 
(select CustomerId  from dbo.Customer c 
WHERE accountnumber  IN ('PA5036','NJ5062','809162','NJ5061','809161',
'655027','NU2044','PA2196','781393','PA2586','743695','PA5025','730437',
'PA1151','PA1152','742292','PA2033','691507','PA0025',
--'PA2108',
'619908'))
delete from dbo.SalesTotalMonthly 
where CustomerId not in 
(select CustomerId  from dbo.Customer c 
WHERE accountnumber  IN ('PA5036','NJ5062','809162','NJ5061','809161',
'655027','NU2044','PA2196','781393','PA2586','743695','PA5025','730437',
'PA1151','PA1152','742292','PA2033','691507','PA0025',
--'PA2108',
'619908'))
delete from dbo.SalesTotals 
where CustomerId not in 
(select CustomerId  from dbo.Customer c 
WHERE accountnumber  IN ('PA5036','NJ5062','809162','NJ5061','809161',
'655027','NU2044','PA2196','781393','PA2586','743695','PA5025','730437',
'PA1151','PA1152','742292','PA2033','691507','PA0025',
--'PA2108',
'619908'))
delete from dbo.CustomerItemPricing 
where CustomerId not in 
(select CustomerId  from dbo.Customer c 
WHERE accountnumber  IN ('PA5036','NJ5062','809162','NJ5061','809161',
'655027','NU2044','PA2196','781393','PA2586','743695','PA5025','730437',
'PA1151','PA1152','742292','PA2033','691507','PA0025',
--'PA2108',
'619908'))
delete from dbo.CustomerItemPricingHistoryMonthly 
where CustomerId not in 
(select CustomerId  from dbo.Customer c 
WHERE accountnumber  IN ('PA5036','NJ5062','809162','NJ5061','809161',
'655027','NU2044','PA2196','781393','PA2586','743695','PA5025','730437',
'PA1151','PA1152','742292','PA2033','691507','PA0025',
--'PA2108',
'619908'))
delete from dbo.CustomerPriceList 
where CustomerId not in 
(select CustomerId  from dbo.Customer c 
WHERE accountnumber  IN ('PA5036','NJ5062','809162','NJ5061','809161',
'655027','NU2044','PA2196','781393','PA2586','743695','PA5025','730437',
'PA1151','PA1152','742292','PA2033','691507','PA0025',
--'PA2108',
'619908'))

delete from dbo.Sales  
where CustomerId not in 
(select CustomerId  from dbo.Customer c 
WHERE accountnumber  IN ('PA5036','NJ5062','809162','NJ5061','809161',
'655027','NU2044','PA2196','781393','PA2586','743695','PA5025','730437',
'PA1151','PA1152','742292','PA2033','691507','PA0025',
--'PA2108',
'619908'))

delete from dbo.customer 
WHERE accountnumber not IN ('PA5036','NJ5062','809162','NJ5061','809161',
'655027','NU2044','PA2196','781393','PA2586','743695','PA5025','730437',
'PA1151','PA1152','742292','PA2033','691507','PA0025',
--'PA2108',
'619908')
where CustomerId not in (2,11,20,26,28,50,51,70,78,85,90,98,114,133,140) 


select distinct customerid from dbo.sales





