select clientid,count(*) from customer
group by clientid

select distinct a.clientid, a.Account, a.CustomerName, a.Address1 'Address1',
    a.Address2 'Address2',
    a.city, a.state, a.zipcode,
    string_agg(a.WholesalerAccountAttribute,',') as WholesalerAccountAttribute
from (select distinct s.clientid, s.Account, 'Unknown - ' + s.Account CustomerName,
        s.Address1, s.Address2, s.city, s.state, s.zipcode, s.WholesalerAccountAttribute
    from [Raw].sales s
       -- inner join [dbo].[ImportFileIDMapping] ifm
      --  on s.[DataSource] = ifm.[ClientImportCode] and s.WholesalerAccountAttribute is not null
        left join [dbo].[Customer] c
        on s.[Account] = c.[AccountNumber]
            and s.ClientId = c.ClientId
    where s.[DataSource] = 'PremierWholesaleInvoice' and s.WholesalerAccountAttribute is not null ) a
group by clientid, Account, Address1, Address2, city, state, zipcode, CustomerName

select top 100000
    *
from raw.Sales
select sum(a.total)
from
    (select clientid, count(*) as total
    from raw.Sales
    group by clientid) a
    --rollup by clientid

    select top 1000  * from raw.sales

    select * from calendar c where c.ClientId is not null







-----------------------------------------------------------------------
merge [dbo].[Customer] AS tar
USING (select distinct a.clientid, a.Account, a.CustomerName, a.Address1 'Address1',
        a.Address2 'Address2',
        a.city, a.state, a.zipcode,
        string_agg(a.WholesalerAccountAttribute,',') as WholesalerAccountAttribute
        from (select distinct s.clientid, s.Account, 'Unknown - ' + s.Account CustomerName,
                s.Address1, s.Address2, s.city, s.state, s.zipcode, s.WholesalerAccountAttribute
            from [Raw].sales s
            --    inner join [dbo].[ImportFileIDMapping] ifm
            --    on s.[DataSource] = ifm.[ClientImportCode] and s.WholesalerAccountAttribute is not null
                left join [dbo].[Customer] c
                on s.[Account] = c.[AccountNumber]
                    and s.ClientId = c.ClientId
            where s.[DataSource] = 'PremierWholesaleInvoice' and  s.WholesalerAccountAttribute is not null
	) a
    group by clientid, Account, Address1, Address2, city, state, zipcode, CustomerName) AS src
		ON --tar.[OrganizationNumber] = src.[HealthSystemID] and
        tar.Clientid = src.clientid and 
		tar.AccountNumber = src.Account
		WHEN MATCHED 
		     AND (((tar.AddrLine1 is null and src.Address1 is not null) or tar.AddrLine1 != src.Address1)
        or ((tar.AddrLine2 is null and src.Address2 is not null) or tar.AddrLine2 != src.Address2)
        or ((tar.city is null and src.city is not null) or src.city != tar.city)
        or ((tar.state is null and src.state is not null) or tar.state != src.state)
        or ((tar.zip is null and src.zipcode is not null) or src.zipcode != tar.zip)
        or ((tar.PriceList is null and src.WholesalerAccountAttribute is not null) or src.WholesalerAccountAttribute != tar.PriceList))
		    THEN
		   UPDATE SET
			  tar.AddrLine1 = src.Address1,
			  tar.AddrLine2 = src.Address2,
			  tar.city = src.city,
			  tar.state = src.state,
			  tar.PriceList = src.WholesalerAccountAttribute,
			  tar.zip = src.zipcode,
			  tar.DateChanged = getdate()
		WHEN NOT MATCHED THEN
		   INSERT
		   (
				ClientId,
				AccountNumber,
				--[OrganizationNumber],
				CustomerName,
				AddrLine1,
				AddrLine2,
				city,
				state,
				zip,
				PriceList
		   )
		   VALUES
		   (
				src.ClientId,
				src.Account,
				--src.[HealthSystemID],
				src.CustomerName,
				src.Address1,
				src.Address2,
				src.city,
				src.state,
				src.zipcode,
				src.WholesalerAccountAttribute
		   );
--sales load

insert into [dbo].[Sales]
        ([ClientId],
        [CustomerId],
        [SupplierId],
        [SupplierName],
        [ItemId],
        [TransactionDate],
        [Ndc],
        [ItemDescription],
        [OrderNumber],
        [LineNumber],
        [OrderType],
        [Qty],
        [QtyOrdered],
        [UnitCost],
        [UnitPrice],
        [UOM],
        [InvoiceNumber],
        [WholesalerAccountNumber],
        [WholesalerCBID],
        [CostofDistribution],
        [PriceTypeGroupId],
        [Address1],
        [Address2],
        [City],
        [State],
        [ZipCode],
        [QuarterDate],
        [ImportedDate],
        [DataSourceId],
        [ProcessPipelineId],
        [RepackagedFlag],
        [OrderDate],
        [ReasonCodeDesc])
    select s.[ClientId],
        c.[CustomerId],
       -- su.SupplierId SupplierId,
       -- su.SupplierName SupplierName,
        pi.ItemId,
        s.[TransactionDate],
        s.[Ndc],
        s.[ItemDescription],
        s.[OrderNumber],
        s.[LineNumber],
        s.[OrderType],
        s.[Qty],
        s.[QtyOrdered],
        s.[UnitCost],
        s.[UnitPrice],
        s.[UOM],
        s.[InvoiceNumber],
        s.[WholesalerAccountNumber],
        s.[ChargeBackContractNumber],
        s.[Markup/Markdown],
        ptx.[PriceTypeGroupId],
        s.[Address1],
        s.[Address2],
        s.[City],
        s.[State],
        s.[ZipCode],
       -- format(ca.FirstDateOfQuarter,'yyyyMMdd') QuarterDate,
        FORMAT(DATEADD(qq, DATEDIFF(qq, 0, s.TransactionDate), 0),'yyyyMMdd') QuarterDate,
        s.[ImportedDate],
        17 as [DataSourceId],
        s.[ProcessPipelineId],
        case when s.OrderType in ('CPAK Return', 'DOD Order', 'DOD Return', 'Order CPAK') then 1 else 0 end RepackagedFlag,
        s.[OrderDate],
        s.[ReasonCodeDesc]
    from [Raw].[Sales] s
    --    inner join [dbo].[ImportFileIDMapping] ifm
     --   on s.[DataSource] = ifm.[ClientImportCode]
        inner join [dbo].[Customer] c
        on s.[Account] = c.[AccountNumber]
            and s.ClientId = c.ClientId
        left join [dbo].[PharmacyItem] pi
        on s.ndc = pi.Ndc
      /*  inner join Calendar ca
        on ifm.[ClientId] = ca.ClientId
            and s.TransactionDate = ca.CalendarDate   */
        left join Mapping.[PriceTypeGroupXref] ptx
       -- on c.ClientId = ptx.clientid
            on s.WholesalerAccountAttribute = ptx.[ClientPriceTypeCode]
        left join supplier su
        on s.Wholesaler = su.SupplierName
    where su.SupplierTypeId= 2 and su.MfrId is null and s.[DataSource] = 'PremierWholesaleInvoice'

    select * from supplier
select count(*) from raw.Sales

select count(Clientid) ,clientid from raw.sales group by Clientid
select count(Clientid) ,clientid from raw.PurchaseOrders group by Clientid