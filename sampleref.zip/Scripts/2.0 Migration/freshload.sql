select top 10 * from Customer
order by customerid asc

select distinct customerid from dbo.Sales
order by customerid asc

delete from Customer;

truncate table dbo.CustomerPriceList;
truncate table dbo.SalesTotalMonthly;
truncate table dbo.SalesTotals;
truncate table dbo.CustomerItemPricing;
truncate table dbo.CustomerItemPricingHistoryMonthly;
delete from dbo.Customer;
delete from dbo.CustomerOrganization;

select * from CustomerOrganization

select * from Customer
select * from CustomerOrganization


dbcc checkident ('dbo.Customer', reseed, 0);