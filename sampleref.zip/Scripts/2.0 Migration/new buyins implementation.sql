WITH LatestPuchaseDate
AS (
    SELECT customerid
        , WholesalerAccountNumber  --00000000000000622942
        , Ndc
        , FORMAT(Max(TransactionDate), 'MM/dd/yyyy') AS Latestpurchasedate
    FROM dbo.Sales
    WHERE qty > 0
     --   AND ndc = '64764030020'
    GROUP BY customerid
        , WholesalerAccountNumber
        , Ndc
        --    ,InvoiceNumber
    ),
    maxinvoice as ( select customerid, wholesaleraccountnumber,ndc,max(InvoiceNumber) as latestinvoice from dbo.Sales
    WHERE qty > 0
       -- AND ndc = '64764030020'
    GROUP BY customerid
        , WholesalerAccountNumber
        , Ndc),
custWan
AS (
    SELECT l.customerid
        , l.ndc
        , l.wholesaleraccountnumber
        , l.Latestpurchasedate
        , s.qty
        , s.unitprice
     --   , s.InvoiceNumber
    --    , ROW_NUMBER() OVER(partition by s.customerid,s.ndc,s.WholesalerAccountNumber,s.InvoiceNumber
    --      ORDER BY InvoiceNumber desc) AS rowlines
    FROM LatestPuchaseDate l
    JOIN sales s
        ON s.CustomerId = l.CustomerId
            AND s.WholesalerAccountNumber = l.WholesalerAccountNumber
            AND s.ndc = l.Ndc
            AND s.transactiondate = l.Latestpurchasedate
            join maxinvoice m on 
            s.CustomerId = l.CustomerId
            AND s.WholesalerAccountNumber = m.WholesalerAccountNumber
            AND s.ndc = m.Ndc
          --  AND s.transactiondate = m.Latestpurchasedate   
            and s.InvoiceNumber = m.latestinvoice
            where s.qty > 0
    ),
/*SELECT *
FROM custwan
WHERE ndc = '64764030020' */
WanAgg AS (
        SELECT a.customerid
            , a.ndc
            , STRING_AGG(a.Latestpurchasedate, ',') WITHIN
        GROUP (
                ORDER BY a.customerid ASC
                ) AS Latestpurchasedate
            , STRING_AGG(a.wholesaleraccountnumber, ',') WITHIN
        GROUP (
                ORDER BY a.customerid ASC
                ) AS wholesaleraccountnumber
            , STRING_AGG(a.qty, ',') WITHIN
        GROUP (
                ORDER BY a.customerid ASC
                ) AS quantity
            , STRING_AGG(a.unitprice, ',') WITHIN
        GROUP (
                ORDER BY a.customerid ASC
                ) AS unitprice
        FROM custWan a
        GROUP BY a.customerid
            , a.ndc
        ) select * from wanagg where ndc = '64764030020'
