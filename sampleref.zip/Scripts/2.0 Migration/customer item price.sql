with Prices AS 
(
  Select 
       -- wi.clientid as individualclientid,
        wi.Cliendid as individualclientid,
        FacilityID, 
        Wholesaler, 
		WholesalerPurchaseType, 
		su.[SupplierId] 'SupplierId', 
		--CASE WholesalerPurchaseType  
		--	WHEN 'Premier Contract' THEN 3  
		--	WHEN 'Wholesaler Contract' THEN 3  
		--	WHEN 'Other Contract' THEN 3  
		--	WHEN 'Private Contract' THEN 3  
		--	WHEN 'Non Contract' THEN 3  
		--	WHEN 'DSH' THEN 2  
		--	WHEN '340B' THEN 2  
		--	WHEN 'WAC' THEN 11  	
		--	ELSE null
		--END 'PriceListId',
		p.PriceListId as PriceListId,
		Ndc, 
		InvoiceDate, 
		InvoicePrice, 
		wi.Wholesaler 'DistributorAccountNo'
from [Premier].[WholesalerInvoices] wi
		inner join supplier su
	on wi.Wholesaler = su.SupplierName
			left join PriceList p on p.PriceListDescription=coalesce(wi.WholesalerAccountAttribute,'UNK')
 where su.SupplierTypeId= 2 and su.MfrId is null and ndc != '0'),
PriceRank AS (
select  individualclientid,
        FacilityID, 
        Wholesaler, 
		SupplierId,
		WholesalerPurchaseType, 
		Ndc, 
		InvoiceDate, 
		InvoicePrice,
		PriceListId,
		rank() over (partition by individualclientid,FacilityID, SupplierId, PriceListId, Ndc order by InvoiceDate desc) rnk,
		DistributorAccountNo
from Prices)

select *  from PriceRank where individualclientid = 5
PriceCodes as ( 
select 
       individualclientid,
       FacilityID, 
       Wholesaler,
	   SupplierId,
	   WholesalerPurchaseType,
	   Ndc,
	   InvoiceDate,
	   InvoicePrice,
	   PriceListId,
	   ROW_NUMBER() over (partition by individualclientid,SupplierId, FacilityID, Ndc, PriceListId order by InvoiceDate desc) Seq,
	   DistributorAccountNo
from PriceRank
where rnk = 1)

select --@clientid 'clientid', 
       pc.individualclientid 'clientid',
	   SupplierId 'CpSupplierID',
	   c.CustomerId 'CustomerId',	    
	   pc.Ndc 'NDC',
	   pi.itemid 'ItemId',
	   pc.InvoicePrice 'PriceAmount',
	   InvoiceDate 'PriceStartDate',
	   PriceListId,
	   17 'DataSourceId',
	   DistributorAccountNo
--into #temp_Premier_Pricing
from PriceCodes pc
	inner join customer c
		on c.ClientId = pc.individualclientid
		and pc.FacilityID = c.AccountNumber
	inner join [dbo].[PharmacyItem] pi
		on pc.ndc = pi.ndc
where seq = 1
-- select count(*),clientid
-- from intermediatenew
-- group by clientid


---existing change



