drop table if exists #customers 

select distinct PriceTypeGroupId  from dbo.sales where WholesalerAccountNumber = '860683'

select  distinct PriceTypeGroupId  from dbo.SalesTotalMonthly where WholesalerAccountNumber = '860683'

select top 1000 * from dbo.CustomerItemPricing
 
;WITH Customer_PriceList AS
            (SELECT DISTINCT cip.CustomerId, pl.PriceListDescription ,
            CONCAT_WS(' - ',c.CustomerName,c.AccountNumber,c.DEA) AS 'Facility'
            FROM CustomerItemPricing cip join PriceList pl on pl.PriceListId = cip.PriceListId
            join customer c on c.CustomerId=cip.CustomerId and c.status = 'A')

			select distinct pl.CustomerId, pl.Facility                        
			            ,sr.SupplierName as 'Wholesaler'	            
						,s.WholesalerAccountNumber as 'WAN' 
                        ,pl.PriceListDescription as 'AccountType'
                        ,sr.SupplierId 
            into #customers
            from   SalesTotalMonthly s
					join Supplier sr on s.SupplierId = sr.SupplierId                    		           
			        join Customer_PriceList pl on pl.CustomerId=s.CustomerId
                    where 1=1 and  s.ClientId = (SELECT clientid FROM client)
	              

            select   
                     ROW_NUMBER() OVER ( ORDER BY CustomerId) Id,
                     CustomerId,
                     Facility,
			         Wholesaler,	            
				     WAN,
                     AccountType,
                     wc.TotalCount SearchResultCount,
                     SupplierId
		             from #customers	
                     join (select count(1) TotalCount from #customers where 1 = 1  ) wc on 1 = 1
                     where 1 = 1 and WAN = '860683'
                     
          /*  order by 	            
	            case when @sortColumn = 'Facility' and @sortDirection = 'asc' then Facility end,
	            case when @sortColumn = 'Facility' and @sortDirection = 'desc' then Facility end desc,
				case when @sortColumn = 'Wholesaler' and @sortDirection = 'asc' then Wholesaler end,
	            case when @sortColumn = 'Wholesaler' and @sortDirection = 'desc' then Wholesaler end desc,
                case when @sortColumn = 'WAN' and @sortDirection = 'asc' then WAN end,
	            case when @sortColumn = 'WAN' and @sortDirection = 'desc' then WAN end desc
            offset @pageNumber * @pageSize rows --Param
            fetch next @pageSize rows only;";*/