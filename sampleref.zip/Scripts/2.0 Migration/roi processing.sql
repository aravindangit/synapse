with Roienddate as (
select ndc,ROI_Start_Date,roi_end_date,clientid
from dbo.ROI_Tracking),
roisales as(
select sum(qty * UnitCost) as dollarvalue,sa.ndc from dbo.sales as sa
join Roienddate as ra on sa.ndc=ra.ndc and sa.clientid = ra.clientid
where sa.transactiondate >= ra.ROI_Start_Date and sa.transactiondate <= ra.ROI_end_Date 
group by sa.ndc)
select * from roisales



----------------------------------------------------------------------------------------



with Roienddate as (
select ndc,ROI_Start_Date,roi_end_date
from dbo.ROI_information),
roisales as(
select sum(qty * UnitCost) as dollarvalue,sa.ndc from dbo.sales as sa
join Roienddate as ra on sa.ndc=ra.ndc 
where sa.transactiondate >= ra.ROI_Start_Date and sa.transactiondate <= ra.ROI_end_Date 
group by sa.ndc)
select * from roisales

select sum(qty * unitcost) as dollarvalue,sa.ndc from dbo.sales sa
join dbo.ROI_information as ra on sa.ndc = ra.ndc
where  sa.transactiondate >= ra.ROI_Start_Date and sa.transactiondate <= ra.ROI_end_Date and sa.ndc = '65757040103'
group by sa.ndc