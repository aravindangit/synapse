--736714
/*select distinct PriceTypeGroupId  from dbo.sales where WholesalerAccountNumber = '736714'

select distinct OrderType  from  dbo.sales where WholesalerAccountNumber = '736714'

select distinct a.wholesaleraccountnumber,b.pricelistdescription
from dbo.sales a join dbo.PriceList b on a.PriceTypeGroupId = b.pricelistid
where a.WholesalerAccountNumber = 'FPA00658B'

select * from PriceList pl */

-- sqldbCogRxProdStLukes.dbo.sales_buyins_passthru definition

-- Drop table

-- DROP TABLE sqldbCogRxProdStLukes.dbo.sales_buyins_passthru;
select * from BuyinsAggregation

CREATE TABLE dbo.BuyinsAggregation (
	customerid int NOT NULL,
	ndc varchar(11) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	Latestpurchasedate nvarchar(2000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	wholesaleraccountnumber varchar(8000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	quantity nvarchar(2000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	unitprice nvarchar(2000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	last_updated_date DATETIME DEFAULT GETDATE() NULL
);
 CREATE NONCLUSTERED INDEX BuyinsAggregation_customerid_IDX ON dbo.BuyinsAggregation (  customerid ASC  , ndc ASC  )  
	 WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
	 ON [PRIMARY ] ;

WITH LatestPuchaseDate
                    AS (
                        SELECT customerid
                            , WholesalerAccountNumber  --00000000000000622942
                            , Ndc
                            , FORMAT(Max(TransactionDate), 'MM/dd/yyyy') AS Latestpurchasedate
                        FROM dbo.Sales
                        WHERE qty > 0
                        --    AND ndc = '64764030020'
                        GROUP BY customerid
                            , WholesalerAccountNumber
                            , Ndc
                        ),
                    custWan
                    AS (
                        SELECT l.customerid
                            , l.ndc
                            , l.wholesaleraccountnumber
                            , l.Latestpurchasedate
                            , s.qty
                            , s.unitprice
                            , s.InvoiceNumber
                           , ROW_NUMBER() OVER(partition by s.customerid,s.ndc,s.WholesalerAccountNumber
                              ORDER BY InvoiceNumber desc,qty desc) AS rowlines
                        FROM LatestPuchaseDate l
                        JOIN sales s
                            ON s.CustomerId = l.CustomerId
                                AND s.WholesalerAccountNumber = l.WholesalerAccountNumber
                                AND s.ndc = l.Ndc
                                AND s.transactiondate = l.Latestpurchasedate
                                where s.qty > 0  
                        ),
                    WanAgg AS (
                            SELECT a.customerid
                                , a.ndc
                                , STRING_AGG(a.Latestpurchasedate, ',') WITHIN
                            GROUP (
                                    ORDER BY a.customerid ASC
                                    ) AS Latestpurchasedate
                                , STRING_AGG(a.wholesaleraccountnumber, ',') WITHIN
                            GROUP (
                                    ORDER BY a.customerid ASC
                                    ) AS wholesaleraccountnumber
                                , STRING_AGG(a.qty, ',') WITHIN
                            GROUP (
                                    ORDER BY a.customerid ASC
                                    ) AS quantity
                                , STRING_AGG(a.unitprice, ',') WITHIN
                            GROUP (
                                    ORDER BY a.customerid ASC
                                    ) AS unitprice
                            FROM custWan a
                            where a.rowlines = 1
                            GROUP BY a.customerid
                                , a.ndc
                            ) insert into dbo.BuyinsAggregation(
                            customerid ,ndc,Latestpurchasedate , wholesaleraccountnumber ,
							quantity ,	unitprice )
							select customerid ,ndc,Latestpurchasedate , wholesaleraccountnumber ,
							quantity ,	unitprice from wanagg
                            
                            /*SELECT * INTO dbo.sales_buyins_passthru FROM wanagg
                            
                            select * from dbo.sales_buyins_passthru
                            
                            customerid,ndc,lastpurc*/
							
                            