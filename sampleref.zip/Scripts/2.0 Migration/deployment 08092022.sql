

CREATE TABLE dbo.IPD_Patent (
	[Brand Drug Name] nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Generic Name] nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Brand Company] nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Therapeutic Area] nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[US Brand Sales ($bln)] nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Orange Book Patents] nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Pediatric Exclusivity] nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Patent Comments] nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Related Litigation Comments] nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Paragraph IV Certification] nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[First ANDA Filer(s)] nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Other ANDA Filer(s)] nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[DMF Filers] nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Litigation Status] nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[30-Month Stay Expirations] nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Earliest Possible Generic Entrants(s)] nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Triggering Event] nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Earliest Possible Launch] nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Earliest Launch Probability] nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Expected Outlook for Generic Entry] nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Comments on Generic Entry] nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Estimated LOE] nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
);


CREATE TABLE App.BuyInResolved (
	BuyInResolvedId int IDENTITY(1,1) NOT NULL,
	ClientId int NOT NULL,
	Ndc char(11) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	WholesalerSupplierId int NOT NULL,
	CustomerId int NOT NULL,
	UserAddedId int NOT NULL,
	DateAdded datetime NOT NULL,
	DivisionID varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Status varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	AccountType varchar(3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_BuyInResolved PRIMARY KEY (BuyInResolvedId)
);