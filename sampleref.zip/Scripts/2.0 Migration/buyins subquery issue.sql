;WITH LatestPuchaseDate
                    AS (
                        SELECT customerid
                            , WholesalerAccountNumber  --00000000000000622942
                            , Ndc
                            , FORMAT(Max(TransactionDate), 'MM/dd/yyyy') AS Latestpurchasedate
							, PriceTypeGroupId
                        FROM dbo.Sales
                        WHERE qty > 0
                        --    AND ndc = '64764030020'
                        GROUP BY customerid
                            , WholesalerAccountNumber
                            , Ndc
							, PriceTypeGroupId
                        ),
                    custWan
                    AS (
                        SELECT l.customerid
                            , l.ndc
                            , l.wholesaleraccountnumber
                            , l.Latestpurchasedate
                            , s.qty
                            , s.unitprice
                            , s.InvoiceNumber
							, pl.PriceTypeGroupDescription
                           , ROW_NUMBER() OVER(partition by s.customerid,s.ndc,s.WholesalerAccountNumber,s.PriceTypeGroupId
                              ORDER BY InvoiceNumber desc,qty desc) AS rowlines
                        FROM LatestPuchaseDate l

                        JOIN sales s
                            ON s.CustomerId = l.CustomerId
                                AND s.WholesalerAccountNumber = l.WholesalerAccountNumber
                                AND s.ndc = l.Ndc
                                AND s.transactiondate = l.Latestpurchasedate
								AND s.PriceTypeGroupId = l.PriceTypeGroupId
								--join PriceList pl on pl.PriceListId = s.PriceTypeGroupId
								join PriceTypeGroup pl on pl.PriceTypeGroupId = s.PriceTypeGroupId
                                where s.qty > 0  
                        ),



                    WanAgg AS (
                            SELECT a.customerid
                                , a.ndc
								, a.PriceTypeGroupDescription
                                , STRING_AGG(a.Latestpurchasedate, ',') WITHIN
                            GROUP (
                                    ORDER BY a.customerid ASC
                                    ) AS Latestpurchasedate
                                , STRING_AGG(a.wholesaleraccountnumber, ',') WITHIN
                            GROUP (
                                    ORDER BY a.customerid ASC
                                    ) AS wholesaleraccountnumber
                                , STRING_AGG(a.qty, ',') WITHIN
                            GROUP (
                                    ORDER BY a.customerid ASC
                                    ) AS quantity
                                , STRING_AGG(a.unitprice, ',') WITHIN
                            GROUP (
                                    ORDER BY a.customerid ASC
                                    ) AS unitprice
                            FROM custWan a
                            where a.rowlines = 1
                            GROUP BY a.customerid
                                , a.ndc
								,a.PriceTypeGroupDescription
                            ) --select * into dbo.salesWanAgg from wanagg*/
                                

                select 
                   ROW_NUMBER() OVER (
                   ORDER BY npp.[NationalPricePredictionGuid]
                   ) NPPId
                 , npp.[NationalPricePredictionId]
                 , npp.[NationalPricePredictionGuid]
                 , npp.[RecordSyncDate]
                 , npp.[IsActive]
                 , case when pis.IsShort is not null then pis.IsShort else 0 end as 'IsShort'
                 , npp.[Ndc]
                 , phi.ItemId
                 , phi.ItemDescription
                 , npp.[PriceDate]
                 , npp.[RunDate]
                 , npp.[TrainDate]
                 , npp.[WacUnitPrice]
                 , npp.[PeriodFirstIdentified]
                 --facility price info
                 , cip.CpSupplierID 'CpSupplierId'
                 , s.SupplierName 'Wholesaler'
                 , c.ClientId
                 , c.CustomerId
                 , c.Premier_Relation as PremierRelation
                 , dbo.fn_FacilityName(c.CustomerName, c.AccountNumber, c.Dea) 'FacilityName'
                 , dbo.fn_DivisionName(c.DivisionName, c.DivisionId) 'Division'
                 , cip.PriceAmount 'UnitPrice'
                 , ptg.PriceTypeGroupDescription 'AccountType'
                 , sum(isNull(st.[1YearUsageQty], 0)) 'YearQty'
                 , cast(sum(isnull(st.[1YearUsageQty], 0))as decimal (18,2))/4  'QuarterQty'
                 , cast(sum(isnull(st.[1YearUsageQty], 0))as decimal (18,2))/4 * cip.PriceAmount 'QuarterCost'
                 , sc.StorageConditionDescription
                 , gpid.GpiCodeSegment + ' - ' + replace(gpid.GpiName,'*','') 'GpiDrugGroup'
                -- , case when IPD.[Brand Drug Name] is null then 0 else 1 end as 'Potential_Generic'
                 -- verification current month
                 , npp.[Month0ProbabilityOfIncrease]
                 , npp.[Month0PredictedWacUnitPrice]
                 
                 -- month 1
                 , npp.[Month1ProbabilityOfIncrease]
                 , npp.[Month1PredictedWacUnitPrice]
                 , npp.[Month1PercentIncrease]
                 , npp.[Month1Period]
                 , dbo.fn_IncreaseMoneyByPercent(cip.PriceAmount, npp.Month1PercentIncrease) 'Month1PredictedUnitPrice'
                 , cast(sum(isnull(st.[1YearUsageQty], 0))as decimal (18,2))/4 * cast((cip.PriceAmount + (cip.PriceAmount * npp.Month1PercentIncrease)) as decimal(18, 2)) 'Month1PredictedQuarterCost'
                 , cast(sum(isnull(st.[1YearUsageQty], 0))as decimal (18,2))/4 * (cast((cip.PriceAmount + (cip.PriceAmount * npp.Month1PercentIncrease)) as decimal(18, 2)) - cip.PriceAmount) 'Month1PredictedQuarterSavings'
                 
                 --month 2
                 , npp.[Month2ProbabilityOfIncrease]
                 , npp.[Month2PredictedWacUnitPrice]
                 , npp.[Month2PercentIncrease]
                 , npp.[Month2Period]
                 , dbo.fn_IncreaseMoneyByPercent(cip.PriceAmount, npp.Month2PercentIncrease) 'Month2PredictedUnitPrice'
                 , cast(sum(isnull(st.[1YearUsageQty], 0))as decimal (18,2))/4 * cast((cip.PriceAmount + (cip.PriceAmount * npp.Month2PercentIncrease)) as decimal(18, 2)) 'Month2PredictedQuarterCost'
                 , cast(sum(isnull(st.[1YearUsageQty], 0))as decimal (18,2))/4 * (cast((cip.PriceAmount + (cip.PriceAmount * npp.Month2PercentIncrease)) as decimal(18, 2)) - cip.PriceAmount) 'Month2PredictedQuarterSavings'
                 
                 --month 3
                 , npp.[Month3ProbabilityOfIncrease]
                 , npp.[Month3PredictedWacUnitPrice]
                 , npp.[Month3PercentIncrease]
                 , npp.[Month3Period]
                 , dbo.fn_IncreaseMoneyByPercent(cip.PriceAmount, npp.Month3PercentIncrease) 'Month3PredictedUnitPrice'
                 , cast(sum(isnull(st.[1YearUsageQty], 0))as decimal (18,2))/4 * cast((cip.PriceAmount + (cip.PriceAmount * npp.Month3PercentIncrease)) as decimal(18, 2)) 'Month3PredictedQuarterCost'
                 , cast(sum(isnull(st.[1YearUsageQty], 0))as decimal (18,2))/4 * (cast((cip.PriceAmount + (cip.PriceAmount * npp.Month3PercentIncrease)) as decimal(18, 2)) - cip.PriceAmount) 'Month3PredictedQuarterSavings'                 
                 , wa.wholesalerAccountNumber
                 , c.DivisionId 
                 , ISNULL(BR.STATUS,'Not Reviewed') AS BRSTATUS
                 , wa.Latestpurchasedate
                 , wa.quantity
				 , wa.unitprice AS UtPrice                

                from [Predictive].[NationalPricePrediction] npp
                join PharmacyItem phi on phi.Ndc = npp.Ndc
                join CustomerItem ci on npp.Ndc = ci.Ndc
                join CustomerItemPricing cip on ci.Ndc = cip.Ndc
                                                and ci.ClientId = cip.ClientId
                join Supplier s on cip.CpSupplierID = s.SupplierId
                join Customer c on c.CustomerId = cip.CustomerId
                                   and c.ClientId = cip.ClientId                
                -- join to PriceList and PriceTypeGroup to use description to link purchases and prices  
                join PriceList pl on pl.PriceListId = cip.PriceListId				
                join PriceTypeGroup ptg on ptg.PriceTypeGroupDescription = pl.PriceListDescription
				join wanagg wa on c.customerid = wa.customerid and wa.ndc = phi.ndc AND wa.PriceTypeGroupDescription = pl.PriceListDescription
                join SalesTotals st on npp.NDC = st.ndc
                                       and st.ClientId = ci.ClientId
                                       and st.CustomerId = cip.CustomerId
                                       and st.PriceTypeGroupId = ptg.PriceTypeGroupId
                                       and st.SupplierId = cip.CpSupplierID
                join ItemMaster.WkGpiDescriptions gpid on substring(phi.GPI, 1, 2) = substring(gpid.GpiCodeSegment, 1, 2)
               -- left join [dbo].[IPD_Patent] IPD on phi.DrugName = IPD.[Brand Drug Name]
                left join App.BuyInResolved BR on BR.Ndc = npp.Ndc and BR.CustomerId = C.CustomerID --and BR.DivisionId = C.DivisionId
				AND BR.WHOLESALERSUPPLIERID = ST.SUPPLIERID AND BR.AccountType = pl.PriceListDescription
              --  AND BR.USERADDEDID=@userId
                -- left join to PharmacyItemShortage to determine if Ndc has shortages
                left join
                (   select pisg.Ndc
                            , case when pisg.Ndc is null then 0 else 1 end as IsShort
                    from PharmacyItemShortage pisg
                    where pisg.Ndc is not null
                            and pisg.Status != 'R'
                    group by pisg.Ndc) pis on pis.Ndc = npp.Ndc
                    join ItemMaster.StorageCondition sc on sc.storageConditionId = phi.storageConditionId
            where npp.IsActive = 1
                and c.status = 'A'
                and st.[1YearUsageQty] > 0
                and c.ClientId = (select ClientId from client)
                and gpid.GPIRecordTypeId > 0
				and gpid.Status = 'A'
                and substring(phi.GPI, 1, 2) = gpid.GpiCodeSegment
                -- todo: We should evaluate how we handle BuyInExclusions
                and not exists 
                (   select bie.ItemId
                    from App.BuyInExclusion bie
                    where bie.ItemId = phi.ItemId
                          and (bie.CustomerId is null or bie.CustomerId = c.customerid)
                          and bie.ClientId = c.ClientId
                          and (bie.ExclusionEndDate > getdate() or bie.ExclusionEndDate is null))
            -- we need to group because SalesTotals groups by WAN, and that will cause duplicates since WAN is not 
            -- everything is going to be included in the grouping *except* for sales total 1 year usage, which will be summed
            group by npp.ndc
                    , st.PriceTypeGroupId
                    , st.SupplierId
                    , cip.CpSupplierID
                    , s.SupplierName
                    , c.ClientId
                    , c.CustomerId
                    , npp.NationalPricePredictionGuid
                    , npp.[NationalPricePredictionId]
                    , npp.[RecordSyncDate]
                    , npp.[IsActive]
                    , pis.IsShort
                    , phi.ItemId
                    , phi.ItemDescription
                    , npp.[PriceDate]
                    , npp.[RunDate]
                    , npp.[TrainDate]
                    , npp.[WacUnitPrice]
                    , npp.[PeriodFirstIdentified]
                    , c.Premier_Relation
                    , c.CustomerName
                    , c.AccountNumber
                    , c.Dea
                    , c.DivisionName
                    , c.DivisionId
                    , cip.PriceAmount
                    , ptg.PriceTypeGroupDescription 
                    , sc.StorageConditionDescription
                    , npp.[Month0ProbabilityOfIncrease]
                    , npp.[Month0PredictedWacUnitPrice]
                    , npp.[Month1ProbabilityOfIncrease]
                    , npp.[Month1PredictedWacUnitPrice]
                    , npp.[Month1PercentIncrease]
                    , npp.[Month1Period]
                    , npp.[Month2ProbabilityOfIncrease]
                    , npp.[Month2PredictedWacUnitPrice]
                    , npp.[Month2PercentIncrease]
                    , npp.[Month2Period]
                    , npp.[Month3ProbabilityOfIncrease]
                    , npp.[Month3PredictedWacUnitPrice]
                    , npp.[Month3PercentIncrease]
                    , npp.[Month3Period]
                    , gpid.GpiCodeSegment + ' - ' + replace(gpid.GpiName,'*','')
                    , c.DivisionId
                    , wa.wholesalerAccountNumber
                    ,c.DivisionId
                    , BR.STATUS
                    , wa.Latestpurchasedate 
                    , wa.quantity
				    , wa.unitprice 
                  --  , IPD.[Brand Drug Name]

				---  having  wa.wholesalerAccountNumber like '%FCA01277A%'

            order by Ndc

/*
			go

			--00006302602
			--1408
		 --   GPO   --- 3
			--42
			--100092142,100092404,100097012

			--SELECT distinct PriceTypeGroupId FROM SALES WHERE WholesalerAccountNumber='100097012' and SupplierId=42 and CustomerId=1408  
			
			----SELECT * FROM PriceTypeGroup



			GO
			--00006302604
			--1452
			--51
			--340B - 2
			--768077,768078,768080

			--SELECT distinct PriceTypeGroupId FROM SALES WHERE WholesalerAccountNumber='768080' and SupplierId=51 and CustomerId=1452  


			GO

			


			GO

			--959787,813326,597910
			--00517065001
			--1
			--1451
			--340B - 2


			--SELECT distinct PriceTypeGroupId FROM SALES WHERE WholesalerAccountNumber='597910' and SupplierId=1 and CustomerId=1451


			go

			--FCA01455B,FCA01457B,FCA02570B
			--13533080020
			--4
			--1451

			--340B- 2
			--SELECT distinct PriceTypeGroupId FROM SALES WHERE WholesalerAccountNumber='FCA02570B' and SupplierId=4 and CustomerId=1451

			GO

			--FCA01277A
			--63833038702
			--4
			--1496
			--WAC - 1

			--SELECT distinct PriceTypeGroupId FROM SALES WHERE WholesalerAccountNumber='FCA01277A' and SupplierId=4 and CustomerId=1496

			---SELECT *  FROM SALES WHERE WholesalerAccountNumber='FCA01277A' and SupplierId=4 and CustomerId=1496 and ndc='63833038702'


			--SELECT * FROM PriceTypeGroup
			--SELECT * FROM PriceList*/