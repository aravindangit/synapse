
select * from raw.Drug_shortage_alerts
---initially the data is loaded into RawFda.FDAShortage
--step1 -->ndc 70860065210 drug status is current

select top 1000 * from RawFda.FDAShortage where RawShortageId = 281 

select top 10000 * from RawFda.FDAShortage where status = 'Resolved'
order by RawShortageId asc
--step2-->10 digit and 11 digit format in [RawFda].[FDAShortageNDC]

select distinct status from RawFda.FDAShortage

select  top 10000 * from rawashp.ASHPShortage

select * from dbo.PharmacyItemShortage where   ndc = '70860065210'

9d6a9d56-404b-eb11-a607-281878557c5c

--step3-->last one day changes

SELECT max(AddedDateTime),min(AddedDateTime) FROM [RawFda].[FDAShortageNDC] where ndc like '%70860%' and  isActive = 1

--'70860065210'

--step4-->duplicate pharmacy items shortages

select top 1000 * from [Fda].[FDAShortage] where ndc  = '70860-0652-10'
select top 1000 * from [Fda].[FDAShortage] where FDAShortageId = 281

select * from dbo.PharmacyItem pi2 where ndc = '70860065210'


select  [dbo].[FormatNdc](ndc) 'NDC',
		 GenericName,
		 [DateofUpdate],
		 [RelatedInfoLink],
		 [DateDiscontinued],
		 [Status],
		 [ReasonforShortage],
		 [AvailabilityInformation],
		 [FDAShortageUID],
		 [InitialPostingDate],
		 [AddedDateTime]
 from [Fda].[FDAShortage] where ndc = '70860065210'


 SELECT pis.Id
                 , pis.ItemId
                 , pis.Ndc
                 , pis.Source
                 , pis.STATUS
                 , pi.ItemDescription
                 , pis.UpdatedDate
                 , affectedNdcs.Ndcs AffectedNdcs
                 , availableNdcs.AvailableNdcs
                 , pis.ExternalLink
                 , pis.Reasons
                 , pis.EstimatedResupply
            FROM PharmacyItemShortage pis
                 JOIN PharmacyItem pi ON pis.ItemId = pi.ItemId
                 LEFT JOIN (
                    SELECT pisg.ExternalId
                         , STUFF(
                            (
                                --split each NDC by pipe, with optional description after tilda
                                SELECT N'|' + CASE
                                                  WHEN pii.ItemId IS NOT NULL
                                                  THEN dbo.FormatNdc(pisi.Ndc) + '~' + pii.ItemDescription
                                                  ELSE dbo.FormatNdc(pisi.Ndc)
                                              END Ndc
                                FROM PharmacyItemShortage pisi
                                     LEFT JOIN PharmacyItem pii ON pisi.Ndc = pii.Ndc
                                WHERE pisi.ExternalId = pisg.ExternalId
                                ORDER BY pii.ItemDescription FOR XML PATH(N''), TYPE
                            ).value(N'.[1]', N'nvarchar(max)'), 1, 1, N'') Ndcs
                    FROM PharmacyItemShortage pisg
                    GROUP BY pisg.ExternalId
                ) affectedNdcs ON pis.ExternalId = affectedNdcs.ExternalId
                 LEFT JOIN (
                    SELECT pisg.Ndc
                         , STUFF((
                        --split each NDC by pipe, with optional description after tilda
                        SELECT N'|' + CASE
                                          WHEN pia.ItemId IS NOT NULL
                                          THEN dbo.FormatNdc(pissa.Value) + '~' + pia.ItemDescription
                                          ELSE dbo.FormatNdc(pissa.Value)
                                      END Ndc
                        FROM PharmacyItemShortage pisa
                             CROSS APPLY STRING_SPLIT(pisa.AvailableNdcs, ',') AS pissa
                             LEFT JOIN PharmacyItem pia ON pia.Ndc = dbo.FormatNdc(pissa.Value)
                        WHERE pisg.Ndc = pisa.Ndc
                        ORDER BY pia.ItemDescription FOR XML PATH(N''), TYPE
                    ).value(N'.[1]', N'nvarchar(max)'), 1, 1, N'') AvailableNdcs
                    FROM PharmacyItemShortage pisg
                    GROUP BY pisg.Ndc
                ) availableNdcs ON pis.Ndc = availableNdcs.Ndc
            WHERE pis.Ndc = @ndc; --Param




		  select distinct [GenericName]
						  ,[CompanyName]
						  ,[ContactInfo]
						  ,[Presentation]
						  ,[TypeofUpdate]
						  ,[DateofUpdate]
						  ,[AvailabilityInformation]
						  ,[RelatedInformation]
						  ,[ResolvedNote]
						  ,[ReasonforShortage]
						  ,[TherapeuticCategory]
						  ,[Status]
						  ,[ChangeDate]
						  ,[DateDiscontinued]
						  ,[InitialPostingDate]
						  ,[GenericNameNote]
						  ,[GenericNameLink]
						  ,[CompanyInfoLink]
						  ,[AvailabilityLink]
						  ,[RelatedInfoLink]
						  ,[ResolvedNoteLink]
						  ,[DiscontinuedNoteLink]
						  ,[NDC]
						  ,ndc.[PipelineRunId]
			from [RawFda].[FDAShortageNDC] ndc
			inner join [RawFda].[FDAShortage] s on s.[RawShortageId] = ndc.[RawShortageId]
			where ndc.PipelineRunId = 'ba87c585-49fc-444b-967b-93b81c42995b'
				and ndc.isImported = 0
				and s.[DateofUpdate] >= '09/06/2022'

				select top 5000 * from  [RawFda].[FDAShortage] where RawShortageId = 305371
				select top 5000 * from [RawFda].[FDAShortageNDC] where RawShortageId = 305371

				select  * from  [RawFda].[FDAShortage] order by AddedDateTime asc

				select * from PharmacyItem where ndc  = '70860065210'


                select * from [RawASHP].[ASHPShortageAvailableProduct]  

                select * from [dbo].[ASHPShortageAffectedProduct] 
                where affectedProductNDC = '70860-0652-10'
                select * from [dbo].[ASHPShortage] where ASHPShortageId = 262


                select * from [RawASHP].[ASHPShortage]

                select * from [dbo].[ASHPShortage]

                select * from dbo.PharmacyItemShortage where ndc  = '70860065210' and source = 'FDA' -- actual S

                update dbo.PharmacyItemShortage set status = 'R' where ndc  = '70860065210' and source = 'FDA'
                 select * from dbo.PharmacyItemShortage where ndc  = '70860065210' and source = 'FDA'

                 select ndc,status,count(*), min(updateddate),max(updateddate) from dbo.PharmacyItemShortage
                 where status = 'R' --and year(max(updateddate)) = 2019
                 group by ndc,status
                 having year(max(updateddate)) = 2019
                 where status = 'R'


                select * from dbo.PharmacyItemShortage where ndc  = '70860065210'