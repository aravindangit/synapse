
select * from raw.Drug_shortage_alerts

ItemMasterSync
-- CogRxDemo.Raw.Drug_shortage_alerts definition

-- Drop table

-- DROP TABLE CogRxDemo.Raw.Drug_shortage_alerts;
drop table History.Drug_shortage_alerts_History; 
---------------------------------------------------------History table------
CREATE TABLE History.Drug_shortage_alerts_History (
	DrugName varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Route varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ShortageSource varchar(10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Rank] float NULL,
	Date_Scored datetime NULL,
    Last_updated datetime NULL
);
---------------------------------------------------------Actual table table------
CREATE TABLE dbo.Drug_shortage_alerts (
	DrugName varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Route varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ShortageSource varchar(10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Rank] float NULL,
	Date_Scored datetime NULL,
    Last_updated datetime NULL
);
--------actual to history-----
INSERT INTO History.Drug_shortage_alerts_History
(
    DrugName ,
	[Route] ,
	ShortageSource,
	[Rank] ,
	Date_Scored ,
    Last_updated
)
SELECT DrugName
    , [Route]
    , ShortageSource
    , rank_isInjectable_incrInjNS_byRoute as [Rank]
    , Date_Scored
    , GETDATE()
FROM dbo.Drug_shortage_alerts

--------raw to actual
INSERT INTO dbo.Drug_shortage_alerts
(
    DrugName ,
	[Route] ,
	ShortageSource,
	[Rank] ,
	Date_Scored ,
    Last_updated
)
SELECT DrugName
    , [Route]
    , ShortageSource
    , rank_isInjectable_incrInjNS_byRoute as [Rank]
    , Date_Scored
    , GETDATE()
FROM raw.Drug_shortage_alerts

------------

select * from history.Drug_shortage_alerts_History



INSERT INTO History.Drug_shortage_alerts_History (
      DrugName
    , [Route]
    , ShortageSource
    , [Rank]
    , Date_Scored
    , Last_updated
    )
SELECT m.actiontype
    , m.DrugName
    , m.[Route]
    , m.ShortageSource
    , m.[Rank]
    , m.Date_Scored
    , GETDATE() AS updated
    from raw.Drug_shortage_alerts
FROM (
    MERGE dbo.ROI_information AS Target
    USING raw.ROI_information AS Source
        ON Source.ndc = Target.ndc
            -- For Inserts
    WHEN NOT MATCHED BY Target
        THEN
            INSERT (
                Ndc
                , ROI_Track_Date
                , ROI_Start_Date
                , ROI_End_Date
                )
            VALUES (
                Source.Ndc
                , Source.ROI_Track_Date
                , Source.ROI_Start_Date
                , Source.ROI_End_Date
                )
                -- For Updates
    WHEN MATCHED
        AND (
            Target.ROI_Track_Date != Source.ROI_Track_Date
            OR (
                Source.ROI_Track_Date IS NULL
                AND Target.ROI_Track_Date IS NOT NULL
                )
            OR (
                Source.ROI_Track_Date IS NOT NULL
                AND Target.ROI_Track_Date IS NULL
                )
            OR Target.ROI_Start_Date != Source.ROI_Start_Date
            OR (
                Source.ROI_Start_Date IS NULL
                AND Target.ROI_Start_Date IS NOT NULL
                )
            OR (
                Source.ROI_Start_Date IS NOT NULL
                AND Target.ROI_Start_Date IS NULL
                )
            OR Target.ROI_End_Date != Source.ROI_End_Date
            OR (
                Source.ROI_End_Date IS NULL
                AND Target.ROI_End_Date IS NOT NULL
                )
            OR (
                Source.ROI_End_Date IS NOT NULL
                AND Target.ROI_End_Date IS NULL
                )
            )
        THEN
            UPDATE
            SET Target.ROI_Track_Date = Source.ROI_Track_Date
                , Target.ROI_Start_Date = Source.ROI_Start_Date
                , Target.ROI_End_Date = source.ROI_End_Date
    --WHEN NOT MATCHED BY Source THEN
    --    DELETE
    OUTPUT CASE 
            WHEN $ACTION = 'UPDATE'
                THEN 'UPDATED'
            WHEN $ACTION = 'INSERT'
                THEN 'INSERTED'
            ELSE $ACTION
            END AS ActionType
        , CASE 
            WHEN $ACTION = 'INSERT'
                THEN inserted.Ndc
            ELSE deleted.Ndc
            END AS Ndc
        , CASE 
            WHEN $ACTION = 'INSERT'
                THEN inserted.ROI_Track_Date
            ELSE deleted.ROI_Track_Date
            END AS ROI_Track_Date
        , CASE 
            WHEN $ACTION = 'INSERT'
                THEN inserted.ROI_Start_Date
            ELSE deleted.ROI_Start_Date
            END AS ROI_Start_Date
        , CASE 
            WHEN $ACTION = 'INSERT'
                THEN inserted.ROI_End_Date
            ELSE deleted.ROI_End_Date
            END AS ROI_End_Date
    ) AS m;
    
   
END