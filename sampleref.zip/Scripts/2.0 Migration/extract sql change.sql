--LATEST QUERY
--WHOLESALER INVOICES CHANGES
with DemoCustomers as (
SELECT a.*,
1 as clientid
from
	[Premier].[WholesalerInvoices] a
	join dbo.clientidlookup c on a.FacilityDirectParentID = c.healthsystem 
where
	([HealthSystemID] = 'NY5011'
		and [FacilityDirectParentID] = 'NY0024')
	and [FacilityID] in ('NY5073', 'NY5029', 'NY2179')
),
IndirectCustomers as (
select a.*,c.clientid
from
[Premier].[WholesalerInvoices] a
	join dbo.clientidlookup c on a.FacilityDirectParentID = c.healthsystem  --facility direct parentid join
where
 ([HealthSystemID] in ('NY5011','CO5012')
   and [FacilityDirectParentID] IN  ('NY0024','838509'))),
DirectCustomers as (
select a.*,c.clientid
from
[Premier].[WholesalerInvoices] a
	join dbo.clientidlookup c on a.HealthSystemID = c.healthsystem   --healthsystem join
where [HealthSystemID] in  ('CO5012','PA0023','MN2013','743692','WI0013')),
DistinctDirectParent as (
select * from DemoCustomers
union all
select * from IndirectCustomers
union all
select * from DirectCustomers)
select  [Id],
[HealthSystemID],
case when clientid = 1 then 'NC9999'
     else FacilityDirectParentID 
     end as FacilityDirectParentID,
case 
	when clientid = 1 and FacilityID = 'NY5073' THEN 'NC9999'
	when clientid = 1 and FacilityID = 'NY5029' THEN 'NC8888'
	when clientid = 1 and FacilityID = 'NY2179' THEN 'NC7777'
	else FacilityID
end as FacilityID,
--[FacilityDirectParentID],
--[FacilityID],
case 
	when clientid = 1  THEN '13034 Ballantyne Corporate Pl'
	else [FacilityAddress1]
end as [FacilityAddress1],
[FacilityAddress2],
case 
	when clientid = 1  THEN 'Charlotte'
	else [FacilityCity]
end as [FacilityCity],
case 
	when clientid = 1  THEN 'NC'
	else [FacilityState]
end as [FacilityState],
--[FacilityState],
case 
	when clientid = 1  THEN '28277'
	else [FacilityZipCode]
end as [FacilityZipCode],
--[FacilityZipCode],
[NDC],
[ItemId],
[BrandName],
[GenericName],
[LabelName],
[WholesalerPurchaseType],
[WholesalerLoadPrice],
[Supplier],
[InvoiceDate],
[InvoiceNumber],
[InvoicePrice],
[Wholesaler],
[DistributionCenterName],
[WholesalerAccountNumber],
[WholesalerAccountName],
[LineNumberfromInvoice],
[ContractLeadName],
[ServiceProviderClass],
[ShipMethod],
[ShippingDate],
[WholesalerPkgQty],
[WholesalerOrderLineNumber],
[WholesalerCatalogNumber],
[UnitofMeasure],
[WholesalerAccountAttribute],
[ChargeBackContractNumber],
[Markup/Markdown],
[PremierAwardStatus],
[PremierContractNumber],
[TotalUnits],
[TotalSpend],
[QuantityOrdered],
[AddedDate],
[ProcessPipelineId],
[OriginalFileName],
[AdlPath],
[ReasonCodeDesc],
[OrderDate],
[clientid]
 from DistinctDirectParent
where clientid = 1