SELECT top 1000 * from premier.WholesalerInvoices wi 
--84412135
select count(*) from premier.WholesalerInvoices wi 
--health system

select HealthSystemID,FacilityDirectParentID,Secret from SyncControl.PremierCustomerSync;

select HealthSystemID ,count(*)
from
	premier.WholesalerInvoices
where
	[HealthSystemID] in (
'CO5012',
'PA0023',
'MN2013',
'743692',
'NY5011',
'WI0013')
group by HealthSystemID 
--CO5012
--NY5011

=================================================================================================
|PremierCustomerSyncId|DataFactory                 |HealthSystemID|FacilityDirectParentID|Secret                        |DatasetInvoiceCode     |DatasetPoCode     |Status|
|---------------------|----------------------------|--------------|----------------------|------------------------------|-----------------------|------------------|------|
|1                    |adf-Premier-DataReceive-prod|CO5012        |                      |Secret-CogRX-DB-CommonSpirit  |PremierWholesaleInvoice|PremierWholesalePO|A     |
|2                    |adf-Premier-DataReceive-prod|PA0023        |                      |Secret-CogRX-DB-stluke        |PremierWholesaleInvoice|PremierWholesalePO|A     |
|3                    |adf-Premier-DataReceive-prod|NY5011        |NY0024                |Secret-CogRX-DB-northwell     |PremierWholesaleInvoice|PremierWholesalePO|A     |
|4                    |adf-Premier-DataReceive-prod|MN2013        |                      |Secret-CogRX-DB-Fairview      |PremierWholesaleInvoice|PremierWholesalePO|A     |
|5                    |adf-Premier-DataReceive-prod|743692        |                      |Secret-CogRX-DB-upmc          |PremierWholesaleInvoice|PremierWholesalePO|A     |
|6                    |adf-Premier-DataReceive-prod|NY5011        |NY5073                |Secret-CogRX-DB-Demo          |PremierWholesaleInvoice|PremierWholesalePO|I     |
|7                    |adf-Premier-DataReceive-prod|WI0013        |                      |Secret-CogRX-DB-AdvocateAurora|PremierWholesaleInvoice|PremierWholesalePO|A     |
|8                    |adf-Premier-DataReceive-prod|CO5012        |838509                |Secret-CogRX-DB-Centura       |PremierWholesaleInvoice|PremierWholesalePO|A     |

=================================================================================================
select * from raw.PremierCustomerList pcl 

--northwell
--HIERARCHY REPORT PULL
SELECT COUNT(*),[Health System ID] FROM
(select *
from [Raw].[PremierCustomerList]
where ([Health System ID] in ('NY5011','CO5012')
    and [Facility Direct Parent ID] IN  ('NY0024','838509'))
    or [Facility ID] IN  ('NY0024','838509')
union ALL
select *
from [Raw].[PremierCustomerList]
where [Health System ID] in  ('CO5012','PA0023','MN2013','743692','WI0013')) X
GROUP BY X.[Health System ID]

--WHOLESALER INVOICE PULL
SELECT COUNT(*),[HealthSystemID] FROM
(
select *
from [Premier].[WholesalerInvoices]
where ([HealthSystemID] in ('NY5011','CO5012')
   and [FacilityDirectParentID] IN  ('NY0024','838509'))
union ALL
select *
from [Premier].[WholesalerInvoices]
where [HealthSystemID] in  ('CO5012','PA0023','MN2013','743692','WI0013')) X
GROUP BY X.[HealthSystemID]


--OUTPUT OF WHOLESALER INVOICE PULL
|         |HealthSystemID|
|---------|--------------|
|870,982  |743692        |
|3,394,604|CO5012        |
|1,556,914|MN2013        |
|524,913  |NY5011        |
|271,036  |PA0023        |
|1,910,197|WI0013        |
---PREMIER HIERARCHY MERGE PROCESS

select distinct fm.ClientId, 
                       [Facility Direct Parent ID] 'OrganizationNumber', 
					   [Facility Direct Parent] 'OrganizationName' ,
					   1 'IsActive'
		from [Raw].[PremierCustomerList] pcl
			inner join [dbo].[ImportFileIDMapping] fm
				on pcl.[Health System ID] = fm.ClientImportCode
		where [Health System ID] is not null

SELECT * FROM DBO.ImportFileIDMapping ifi 

select HealthSystemID,COUNT(*)
from [Premier].[WholesalerInvoices]
where [HealthSystemID] in  ('CO5012','PA0023','MN2013','743692','WI0013')
GROUP BY HealthSystemID 

--GROUP BY [Health System ID]
select * from calendar where clientid is  null

SELECT COUNT(*) FROM Customer c 
create table dbo.clientidlookup
add

CREATE TABLE dbo.clientidlookup (
    healthsytem varchar(50),
    clientid int)
    
 INSERT INTO clientidlookup (healthsytem,clientid) VALUES ('CO5012',1);
 INSERT INTO clientidlookup (healthsytem,clientid) VALUES ('PA0023',2);
 INSERT INTO clientidlookup (healthsytem,clientid) VALUES ('MN2013',3);
 INSERT INTO clientidlookup (healthsytem,clientid) VALUES ('743692',4);
 INSERT INTO clientidlookup (healthsytem,clientid) VALUES ('NY5011',5);
 INSERT INTO clientidlookup (healthsytem,clientid) VALUES ('WI0013',6);


743692	868075
CO5012	2993580
MN2013	1551343
NY5011	4245622
PA0023	270161
WI0013	1903518

select A.*,b.* from premier.WholesalerInvoices a join clientidlookup b on a.HealthSystemID = b.healthsytem
with ctenew as (
select a.*,b.* from premier.WholesalerInvoices a join clientidlookup b on a.HealthSystemID = b.healthsytem)
select count(*),clientid from ctenew group by clientid

   /* LastName varchar(255),
    FirstName varchar(255),
    Address varchar(255),
    City varchar(255)*/
);

--QUARTER DATE ELIMINATION
SELECT TOP 100 TransactionDate ,QuarterDate ,* FROM DBO.SALES

SELECT DISTINCT QUARTERDATE FROM DBO.SALES
SELECT TRANSACTIONDATE,
QUARTERDATE, 
FORMAT(DATEADD(qq, DATEDIFF(qq, 0, TRANSACTIONDATE), 0),'yyyyMMdd') AS FQUARTER,
DATEADD(qq, DATEDIFF(qq, 0, TRANSACTIONDATE), 0) AS CALCULATEDQDATE
FROM DBO.SALES

select * from Mapping.PriceTypeGroupXref




=======================================================
--[Integrations].[MergeAquisitionCost_Premier] 'PremierWholesaleInvoice'



declare @clientid int = (select clientid from [ImportFileIDMapping] where [ClientImportCode] = 'PremierWholesaleInvoice');
declare @DataSourceId int = (select DataSourceId from [ImportFileIDMapping] where [ClientImportCode] = 'PremierWholesaleInvoice');

Drop table if exists #temp_Premier_Pricing;

with Prices AS 
(
  Select top 5000 FacilityID, 
        Wholesaler, 
		WholesalerPurchaseType, 
		su.[SupplierId] 'SupplierId', 
		p.PriceListId as PriceListId,
		Ndc, 
		InvoiceDate, 
		InvoicePrice, 
		wi.Wholesaler 'DistributorAccountNo'
from [Premier].[WholesalerInvoices] wi
		inner join supplier su
	on wi.Wholesaler = su.SupplierName
			left join PriceList p on p.PriceListDescription=coalesce(wi.WholesalerAccountAttribute,'UNK')
 where su.SupplierTypeId= 2 and su.MfrId is null and ndc != '0') ,
PriceRank AS (
select FacilityID, 
        Wholesaler, 
		SupplierId,
		WholesalerPurchaseType, 
		Ndc, 
		InvoiceDate, 
		InvoicePrice,
		PriceListId,
		rank() over (partition by FacilityID, SupplierId, PriceListId, Ndc order by InvoiceDate desc) rnk,
		DistributorAccountNo
from Prices) ,
PriceCodes as ( 
select FacilityID, 
       Wholesaler,
	   SupplierId,
	   WholesalerPurchaseType,
	   Ndc,
	   InvoiceDate,
	   InvoicePrice,
	   PriceListId,
	   ROW_NUMBER() over (partition by SupplierId, FacilityID, Ndc, PriceListId order by InvoiceDate desc) Seq,
	   DistributorAccountNo
from PriceRank
where rnk = 1) select * from pricecodes
select @clientid 'clientid', 
	   SupplierId 'CpSupplierID',
	   c.CustomerId 'CustomerId',	    
	   pc.Ndc 'NDC',
	   pi.itemid 'ItemId',
	   pc.InvoicePrice 'PriceAmount',
	   InvoiceDate 'PriceStartDate',
	   PriceListId,
	   @DataSourceId 'DataSourceId',
	   DistributorAccountNo
--into #temp_Premier_Pricing
from PriceCodes pc
	inner join customer c
		on c.ClientId = @clientid
		and pc.FacilityID = c.AccountNumber
	inner join [dbo].[PharmacyItem] pi
		on pc.ndc = pi.ndc
where seq = 1;


--customer merge process fix;
---------------------------------
select distinct fm.ClientId 'clientid', 
					pcl.[Facility ID] 'AccountNumber', 
					pcl.[Facility Name] 'CustomerName', 
					pcl.[Facility AddrLine1] 'Address1', 
					pcl.[Facility AddrLine2] 'Address2', 
 					pcl.[Facility City]      'City',
					pcl.[Facility State]     'State', 
					pcl.[Facility Zip]       'Zip',
					pcl.[Facility DEA]       'DEA',
					pcl.[Premier_Relation]       'Premier_Relation',
					pcl.[SPC]       'SPC',
					pcl.[Division Name]       'Division Name',
					pcl.[DivisionId]       'DivisionId',
					co.CustomerOrganizationId 'CustomerOrganizationId', 
					case when fm.ClientImportCode='NY5011' or fm.ClientId = 8  then pcl.[Facility Direct Parent ID] else pcl.[Health System ID] end 'OrganizationNumber',
					case when fm.ClientImportCode='NY5011' or fm.ClientId = 8  then pcl.[Facility Direct Parent] else pcl.[Health System] end 'OrganizationName'
					--case when pcl.[Facility Direct Parent ID] is not null then pcl.[Facility Direct Parent ID] else pcl.[Health System ID] end 'OrganizationNumber',
					--case when  pcl.[Facility Direct Parent] is not null then pcl.[Facility Direct Parent] else pcl.[Health System] end 'OrganizationName'
                    from [Raw].[PremierCustomerList] pcl
						inner join [dbo].[ImportFileIDMapping] fm
							on pcl.[Health System ID] = fm.ClientImportCode
						inner join CustomerOrganization co
							on pcl.[Facility Direct Parent ID] = co.[OrganizationNumber]
							
							select clientid from client
-----------------------------DEMO MASKING PROCESS--------------	
DROP TABLE IF EXISTS #TEMPCUST					
SELECT *
INTO #TEMPCUST
FROM [RAW].[PREMIERCUSTOMERLIST]
WHERE ([HEALTH SYSTEM ID] = 'NY5011'
    AND [FACILITY DIRECT PARENT ID] = 'NY0024')
    AND [FACILITY ID] IN ('NY5073', 'NY5029', 'NY2179')
    
update #TEMPCUST 
        set [Facility ID] = 'NC7777',
            [Facility Name] = 'Hope Hospital',
            [Facility DEA] = 'ZZ9876543', 
            [Facility Direct Parent ID] = 'NC9999',
            [Facility Direct Parent] = 'Top Notch Health System',
            [Facility AddrLine1] = '13034 Ballantyne Corporate Pl',
            [Facility AddrLine2] = null,
            [Facility City] = 'Charlotte',
            [Facility State] = 'NC',
            [Facility Zip] = '28277'
where [Facility ID] = 'NY2179' or  [Facility Name] = 'North Shore University Hospital' or [Facility DEA] = 'AN0768917' 
     or [Facility ID] = 'NC7777' or  [Facility Name] = 'Hope Hospital' or [Facility DEA] = 'ZZ9876543';

SELECT * FROM #TEMPCUST;

--DEMO MASKING WHOLESALER INVOICE--
DROP TABLE IF EXISTS #TEMPSALES
SELECT  *
INTO #TEMPSALES
FROM [PREMIER].[WHOLESALERINVOICES]
WHERE ([HEALTHSYSTEMID] = 'NY5011' 
   AND [FACILITYDIRECTPARENTID] = 'NY0024')   ---NC9999
   AND [FACILITYID] IN ('NY5073', 'NY5029', 'NY2179')
   
   
 -- SELECT * FROM CUSTOMER  
 --  SUMMARY OF DEMO CUSTOMERS
 --  HEALTHSYSTEMID, --ONLY ONE
 --  FACILITYDIRECTPARENTID --ONLY ONE
 --  FACILITYID--ONLY THREE
   
UPDATE #TEMPSALES
SET FACILITYID = 
				     case 
						 when FACILITYID = 'NY5073' THEN 'NC9999'
						 when FACILITYID = 'NY5029' THEN 'NC8888'
						 when FACILITYID = 'NY2179' THEN 'NC7777'
				     end

SELECT * FROM #TEMPSALES

declare @clientId int = 2;

with SuppliersWithSpend as 

(   select phi.MfrId
    from SalesTotals st
    join PharmacyItem phi on phi.Ndc = st.Ndc
    where st.ClientId = 2
    and [1YearUsageQty] > 0
    group by phi.MfrId 
)

select mfr.MfrName 'SupplierName'
    , s.SupplierId
    ,spend.mfrid
    , case when spend.MfrId is null then 1 else 0 end 'HasSpend'
from Manufacturer mfr
join Supplier s on s.MfrId = mfr.MfrId
left join SuppliersWithSpend spend on spend.MfrId = mfr.MfrId