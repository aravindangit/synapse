--select * into stage.premiercustomerlistbkp from stage.premiercustomerlist
--NEW HIERARCHY PROCESS START
truncate table stage.premiercustomerlist;
with DemoCustomers as (
select a.*,c.clientid  from raw.democustomerlist a
			left join dbo.clientidlookup c on a.[Facility Direct Parent ID] = c.healthsystem 
),
IndirectCustomers as (
select a.*,c.clientid
from
	[Raw].[PremierCustomerList] a
	   left join dbo.clientidlookup c on a.[Facility Direct Parent ID] = c.healthsystem
where
	([Health System ID] in ('NY5011', 'CO5012')
and [Facility Direct Parent ID] IN ('NY0024', '838509'))
or  [Facility ID] IN ('NY0024', '838509')),
DirectCustomers as (
select a.*,c.clientid
from [Raw].[PremierCustomerList] a
		left join dbo.clientidlookup c on a.[Health System ID]  = c.healthsystem
where [Health System ID] in  ('CO5012','PA0023','MN2013','743692','WI0013')),
DistinctDirectParent as (
select * from DemoCustomers
union 
select * from IndirectCustomers
union 
select * from DirectCustomers)
--SELECT * FROM DistinctDirectParent
insert into STAGE.PremierCustomerList
(	[Health System] ,
	[Health System ID] ,
	[Facility Direct Parent] ,
	[Facility Direct Parent ID] ,
	[Facility Name] ,
	[Facility ID] ,
	[ImportedDate] ,
	[Facility AddrLine1] ,
	[Facility AddrLine2] ,
	[Facility City] ,
	[Facility State],
	[Facility Zip] ,
	[Facility DEA] ,
	[Premier_Relation] ,
	[SPC] ,
	[Division Name] ,
	[DivisionId] ,
    [Clientid] )
(select 
	[Health System] ,
	[Health System ID] ,
	[Facility Direct Parent] ,
	[Facility Direct Parent ID] ,
	[Facility Name] ,
	[Facility ID] ,
	[ImportedDate] ,
	[Facility AddrLine1] ,
	[Facility AddrLine2] ,
	[Facility City] ,
	[Facility State],
	[Facility Zip] ,
	[Facility DEA] ,
	[Premier_Relation] ,
	[SPC] ,
	[Division Name] ,
	[DivisionId] ,
    [Clientid] from DistinctDirectParent WHERE clientid IS NOT NULL)

--NEW HIERARCHY PROCESS END 






/* CENTURA - 8  -- 838509
AA - 7 - WI0013
COMMONSPIRIT -2  -- CO5012
PRODDEMO -1  -- NC9999
NORTHWELL - 4  -- NY004
FAIRVIEW - 3  -- MN2013
STLUKES - 5  -- PA0023
UPMC - 6  -- 743692 */


select * into raw.democustomerlist from [Raw].[PremierCustomerList] 
where ([Health System ID] = 'NY5011'     
and [Facility Direct Parent ID] = 'NY0024')    
and [Facility ID] in ('NY5073', 'NY5029', 'NY2179')

select * from raw.democustomerlist
--LOADING HIERARCHY DATA
select *
from [Raw].[PremierCustomerList]
where ([Health System ID] in ('NY5011','CO5012')
    and [Facility Direct Parent ID] IN  ('NY0024','838509'))
    or [Facility ID] IN  ('NY0024','838509')
union all
select * from raw.democustomerlist
union all
select *
from [Raw].[PremierCustomerList]
where [Health System ID] in  ('CO5012','PA0023','MN2013','743692','WI0013')

 
set FacilityID = 
				     case 
						 when FacilityID = 'NC9999' THEN 'NY5073'
						 when FacilityID = 'NC8888' THEN 'NY5029'
						 when FacilityID = 'NC7777' THEN 'NY2179'
				     end
-- MASKING THE WHOLESALER INVOICES FOR DEMO REGION AND LOADING INTO 
-- DEMOWHOLESALERINVOICES TABLE AND LATER UNIONED  FOR LOADING INTO MEMBER DATABASE			     
SELECT
	Id,
	HealthSystemID,
	FacilityDirectParentID,
	case 
						 when FacilityID = 'NY5073' THEN 'NC9999'
						 when FacilityID = 'NY5029' THEN 'NC8888'
						 when FacilityID = 'NY2179' THEN 'NC7777'
				     end as FacilityID,
	--FacilityID,
	FacilityAddress1,
	FacilityAddress2,
	FacilityCity,
	FacilityState,
	FacilityZipCode,
	NDC,
	ItemId,
	BrandName,
	GenericName,
	LabelName,
	WholesalerPurchaseType,
	WholesalerLoadPrice,
	Supplier,
	InvoiceDate,
	InvoiceNumber,
	InvoicePrice,
	Wholesaler,
	DistributionCenterName,
	WholesalerAccountNumber,
	WholesalerAccountName,
	LineNumberfromInvoice,
	ContractLeadName,
	ServiceProviderClass,
	ShipMethod,
	ShippingDate,
	WholesalerPkgQty,
	WholesalerOrderLineNumber,
	WholesalerCatalogNumber,
	UnitofMeasure,
	WholesalerAccountAttribute,
	ChargeBackContractNumber,
	[Markup/Markdown],
	PremierAwardStatus,
	PremierContractNumber,
	TotalUnits,
	TotalSpend,
	QuantityOrdered,
	AddedDate,
	ProcessPipelineId,
	OriginalFileName,
	AdlPath,
	OrderDate,
	ReasonCodeDesc
--select * into premier.demowholesalerinvoices
from
	[Premier].[WholesalerInvoices]
where
	([HealthSystemID] = 'NY5011'
		and [FacilityDirectParentID] = 'NY0024')
	and [FacilityID] in ('NY5073', 'NY5029', 'NY2179')


--CREATION OF STAGING TABLES
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE SCHEMA STAGE;
GO
CREATE TABLE [STAGE].[PremierCustomerList](
	[Health System] ,
	[Health System ID] ,
	[Facility Direct Parent] ,
	[Facility Direct Parent ID] ,
	[Facility Name] ,
	[Facility ID] ,
	[ImportedDate] [datetime] NULL,
	[Facility AddrLine1] [varchar](200) NULL,
	[Facility AddrLine2] [varchar](100) NULL,
	[Facility City] [varchar](50) NULL,
	[Facility State] [varchar](10) NULL,
	[Facility Zip] [varchar](30) NULL,
	[Facility DEA] ,
	[Premier_Relation] [varchar](25) NULL,
	[SPC] ,
	[Division Name] ,
	[DivisionId] ,
    [Clientid] INT NOT NULL
)
GO
SET IDENTITY_INSERT DBO.CLIENT ON
INSERT INTO sqldbCogRxDevAppCombined.dbo.Client (clientid,Name,ImportCode,LicenseId,Primary340bSupplierId,PrimaryWacSupplierId,PrimaryOtherSupplierId,ShowDivision) VALUES
	 (8,N'CENTURA',NULL,NULL,NULL,NULL,NULL,0),
	 (7,N'AA',NULL,NULL,NULL,NULL,NULL,0),
	 (2,N'COMMONSPIRIT',NULL,NULL,NULL,NULL,NULL,1),
	 (1,N'PROD DEMO',NULL,NULL,NULL,NULL,NULL,0),
	 (4,N'NORTHWELL',NULL,NULL,NULL,NULL,NULL,0),
	 (3,N'FAIRVIEW',NULL,NULL,NULL,NULL,NULL,0),
	 (5,N'ST LUKES',NULL,NULL,NULL,NULL,NULL,0),
	 (6,N'UPMC',NULL,NULL,NULL,NULL,NULL,0);

SET IDENTITY_INSERT DBO.CLIENT OFF;


select * from dbo.CustomerOrganization
select * from dbo.Customer
select * from Client

merge [dbo].[CustomerOrganization] AS tar
USING (select distinct pcl.ClientId, 
                       [Facility Direct Parent ID] 'OrganizationNumber', 
					   [Facility Direct Parent] 'OrganizationName' ,
					   1 'IsActive'
		from [Raw].[PremierCustomerList] pcl
		--	inner join [dbo].[ImportFileIDMapping] fm
			--	on pcl.[Health System ID] = fm.ClientImportCode
		where [Health System ID] is not null and [Facility Direct Parent ID] <> '0') AS src
		ON tar.[ClientId] = src.[ClientId]
		and tar.OrganizationNumber = src.OrganizationNumber
		WHEN MATCHED 
		     AND (tar.OrganizationName != src.OrganizationName
		       or (src.OrganizationName is null and tar.OrganizationName is not null)
			   or (src.OrganizationName is not null and tar.OrganizationName is null))
		    THEN
		   UPDATE SET
			  tar.OrganizationName = src.OrganizationName,
			  tar.DateChanged = getdate()
		WHEN NOT MATCHED THEN
		   INSERT
		   (
				ClientId,
				OrganizationNumber,
				OrganizationName,
				IsActive
		   )
		   VALUES
		   (
				src.ClientId,
				src.OrganizationNumber,
				src.OrganizationName,
				src.IsActive
		   );


select distinct pcl.Clientid 'clientid', 
					pcl.[Facility ID] 'AccountNumber', 
					pcl.[Facility Name] 'CustomerName', 
					pcl.[Facility AddrLine1] 'Address1', 
					pcl.[Facility AddrLine2] 'Address2', 
 					pcl.[Facility City]      'City',
					pcl.[Facility State]     'State', 
					pcl.[Facility Zip]       'Zip',
					pcl.[Facility DEA]       'DEA',
					pcl.[Premier_Relation]       'Premier_Relation',
					pcl.[SPC]       'SPC',
					pcl.[Division Name]       'Division Name',
					pcl.[DivisionId]       'DivisionId',
					co.CustomerOrganizationId 'CustomerOrganizationId', 
					CASE 
						WHEN pcl.Clientid IN (8,4,1) then
							pcl.[Health System ID]
						ELSE
							pcl.[Facility Direct Parent ID]
						END AS 'OrganizationNumber', 
					CASE 
						WHEN pcl.clientid IN (8,4,1) then
							pcl.[Facility Direct Parent]
						ELSE
							pcl.[Health System]
						END AS 'OrganizationNumber', 
					pcl.[Facility Direct Parent] 'OrganizationName'
                    from [Raw].[PremierCustomerList] 
						inner join CustomerOrganization co
							on 
							CASE 
								WHEN PCL.[Health System ID] in  ('CO5012','PA0023','MN2013','743692','WI0013')
									THEN 
									pcl.[Health System ID] 
								ELSE
									pcl.[Facility Direct Parent ID] 
							END

							= co.[OrganizationNumber] 

							


				SELECT * FROM RAW.PremierCustomerList WHERE [Health System ID] = 'WI0013'

				select * from raw.PremierCustomerList



				

select distinct pcl.Clientid 'clientid', 
					pcl.[Facility ID] 'AccountNumber', 
					pcl.[Facility Name] 'CustomerName', 
					pcl.[Facility AddrLine1] 'Address1', 
					pcl.[Facility AddrLine2] 'Address2', 
 					pcl.[Facility City]      'City',
					pcl.[Facility State]     'State', 
					pcl.[Facility Zip]       'Zip',
					pcl.[Facility DEA]       'DEA',
					pcl.[Premier_Relation]       'Premier_Relation',
					pcl.[SPC]       'SPC',
					pcl.[Division Name]       'Division Name',
					pcl.[DivisionId]       'DivisionId',
					co.CustomerOrganizationId 'CustomerOrganizationId', 
					CASE 
						WHEN pcl.Clientid IN (8,4,1) then
							pcl.[Health System ID]
						ELSE
							pcl.[Facility Direct Parent ID]
						END AS 'OrganizationNumber', 
					CASE 
						WHEN pcl.clientid IN (8,4,1) then
							pcl.[Facility Direct Parent]
						ELSE
							pcl.[Health System]
						END AS 'OrganizationNumber', 
					pcl.[Facility Direct Parent] 'OrganizationName'
                    from [Raw].[PremierCustomerList] pcl
						inner join CustomerOrganization co
							on 
							(CASE 
								WHEN PCL.[Health System ID] in  ('CO5012','PA0023','MN2013','743692','WI0013')
									THEN 
									pcl.[Health System ID] 
								ELSE
									pcl.[Facility Direct Parent ID] 
							END) = co.[OrganizationNumber] 
							
							
--joining facility parent direct id and client id						
with custorganization as (
select count(b.clientid) as countid,b.clientid, 'withclientid' as status from (
select distinct pcl.Clientid 'clientid', 
					pcl.[Facility ID] 'AccountNumber', 
					pcl.[Facility Name] 'CustomerName', 
					pcl.[Facility AddrLine1] 'Address1', 
					pcl.[Facility AddrLine2] 'Address2', 
 					pcl.[Facility City]      'City',
					pcl.[Facility State]     'State', 
					pcl.[Facility Zip]       'Zip',
					pcl.[Facility DEA]       'DEA',
					pcl.[Premier_Relation]       'Premier_Relation',
					pcl.[SPC]       'SPC',
					pcl.[Division Name]       'Division Name',
					pcl.[DivisionId]       'DivisionId',
					co.CustomerOrganizationId 'CustomerOrganizationId', 
					CASE 
						WHEN pcl.Clientid IN (8,4,1) then
							pcl.[Health System ID]
						ELSE
							pcl.[Facility Direct Parent ID]
						END AS 'OrganizationNumber', 
					CASE 
						WHEN pcl.clientid IN (8,4,1) then
							pcl.[Facility Direct Parent]
						ELSE
							pcl.[Health System]
						END AS 'OrganizationName'
				--	pcl.[Facility Direct Parent] 'OrganizationName'
                    from [Raw].[PremierCustomerList] pcl
						inner join CustomerOrganization co
							on pcl.[Facility Direct Parent ID] 
							= co.[OrganizationNumber] and pcl.Clientid = co.clientid) as b 
						group by b.clientid

union all
--joining facility parent direct id and without client id						

select count(b.clientid) as countid,b.clientid,'withoutclientid' as status from (
select distinct pcl.Clientid 'clientid', 
					pcl.[Facility ID] 'AccountNumber', 
					pcl.[Facility Name] 'CustomerName', 
					pcl.[Facility AddrLine1] 'Address1', 
					pcl.[Facility AddrLine2] 'Address2', 
 					pcl.[Facility City]      'City',
					pcl.[Facility State]     'State', 
					pcl.[Facility Zip]       'Zip',
					pcl.[Facility DEA]       'DEA',
					pcl.[Premier_Relation]       'Premier_Relation',
					pcl.[SPC]       'SPC',
					pcl.[Division Name]       'Division Name',
					pcl.[DivisionId]       'DivisionId',
					co.CustomerOrganizationId 'CustomerOrganizationId', 
					CASE 
						WHEN pcl.Clientid IN (8,4,1) then
							pcl.[Health System ID]
						ELSE
							pcl.[Facility Direct Parent ID]
						END AS 'OrganizationNumber', 
					CASE 
						WHEN pcl.clientid IN (8,4,1) then
							pcl.[Facility Direct Parent]
						ELSE
							pcl.[Health System]
						END AS 'OrganizationName'
				--	pcl.[Facility Direct Parent] 'OrganizationName'
                    from [Raw].[PremierCustomerList] pcl
						inner join CustomerOrganization co
							on pcl.[Facility Direct Parent ID] 
							= co.[OrganizationNumber] ) as b 
						group by b.clientid)
select * from custorganization
order by clientid

select * from Customer

--customer table load
--Changes are made in the select query, set statement in update and insert statement.
merge [dbo].[Customer] AS tar
USING (select distinct pcl.ClientId 'clientid', 
					pcl.[Facility ID] 'AccountNumber', 
					pcl.[Facility Name] 'CustomerName', 
					pcl.[Facility AddrLine1] 'Address1', 
					pcl.[Facility AddrLine2] 'Address2', 
 					pcl.[Facility City]      'City',
					pcl.[Facility State]     'State', 
					pcl.[Facility Zip]       'Zip',
					pcl.[Facility DEA]       'DEA',
					pcl.[Premier_Relation]       'Premier_Relation',
					pcl.[SPC]       'SPC',
					pcl.[Division Name]       'Division Name',
					pcl.[DivisionId]       'DivisionId',
					co.CustomerOrganizationId 'CustomerOrganizationId', 
                    CASE 
						WHEN pcl.Clientid IN (8,4,1) then
							pcl.[Health System ID]
						ELSE
							pcl.[Facility Direct Parent ID]
						END AS 'OrganizationNumber', 
					CASE 
						WHEN pcl.clientid IN (8,4,1) then
							pcl.[Facility Direct Parent]
						ELSE
							pcl.[Health System]
						END AS 'OrganizationName'
					--pcl.[Facility Direct Parent ID] 'OrganizationNumber', 
					--pcl.[Facility Direct Parent] 'OrganizationName',

--updating top parent to org name & ID
					--case when fm.ClientImportCode='NY5011' then pcl.[Facility Direct Parent ID] else pcl.[Health System ID] end 'OrganizationNumber',
					--case when fm.ClientImportCode='NY5011' then pcl.[Facility Direct Parent] else pcl.[Health System] end 'OrganizationName'
					--case when pcl.[Facility Direct Parent ID] is not null then pcl.[Facility Direct Parent ID] else pcl.[Health System ID] end 'OrganizationNumber',
					--case when  pcl.[Facility Direct Parent] is not null then pcl.[Facility Direct Parent] else pcl.[Health System] end 'OrganizationName'
                    from [Raw].[PremierCustomerList] pcl
					--	inner join [dbo].[ImportFileIDMapping] fm
						--	on pcl.[Health System ID] = fm.ClientImportCode
						inner join CustomerOrganization co
							on pcl.[Facility Direct Parent ID] = co.[OrganizationNumber]
                            and pcl.Clientid = co.clientid) AS src
		ON tar.[ClientId] = src.[ClientId]
		and tar.AccountNumber = src.AccountNumber
		WHEN MATCHED 
		     AND (tar.CustomerName != src.CustomerName
		       or (src.CustomerName is null and tar.CustomerName is not null)
			   or (src.CustomerName is not null and tar.CustomerName is null)
			   or tar.CustomerOrganizationId != src.CustomerOrganizationId
		       or (src.CustomerOrganizationId is null and tar.CustomerOrganizationId is not null)
			   or (src.CustomerOrganizationId is not null and tar.CustomerOrganizationId is null)
			   or tar.OrganizationNumber != src.OrganizationNumber
		       or (src.OrganizationNumber is null and tar.OrganizationNumber is not null)
			   or (src.OrganizationNumber is not null and tar.OrganizationNumber is null)
			   or tar.OrganizationName != src.OrganizationName
		       or (src.OrganizationName is null and tar.OrganizationName is not null)
			   or (src.OrganizationName is not null and tar.OrganizationName is null)
			   or tar.AddrLine1 != src.Address1
		       or (src.Address1 is null and tar.AddrLine1 is not null)
			   or (src.Address1 is not null and tar.AddrLine1 is null)
			   or tar.AddrLine2 != src.Address2
		       or (src.Address2 is null and tar.AddrLine2 is not null)
			   or (src.Address2 is not null and tar.AddrLine2 is null)
			   or tar.City != src.City
		       or (src.City is null and tar.City is not null)
			   or (src.City is not null and tar.City is null)
			   or tar.State != src.State
		       or (src.State is null and tar.State is not null)
			   or (src.State is not null and tar.State is null)
			   or tar.Zip != src.Zip
		       or (src.Zip is null and tar.Zip is not null)
			   or (src.Zip is not null and tar.Zip is null)
			   or tar.DEA != src.DEA
		       or (src.DEA is null and tar.DEA is not null)
			   or (src.DEA is not null and tar.DEA is null)
			   or tar.Premier_Relation != src.Premier_Relation
		       or (src.Premier_Relation is null and tar.Premier_Relation is not null)
			   or (src.Premier_Relation is not null and tar.Premier_Relation is null)
			   or tar.SPC != src.SPC
		       or (src.SPC is null and tar.SPC is not null)
			   or (src.SPC is not null and tar.SPC is null)
			     or tar.[DivisionName] != src.[Division Name]
		       or (src.[Division Name] is null and tar.[DivisionName] is not null)
			   or (src.[Division Name] is not null and tar.[DivisionName] is null)
			   or tar.[DivisionId] != src.[DivisionId]
		       or (src.[DivisionId] is null and tar.[DivisionId] is not null)
			   or (src.[DivisionId] is not null and tar.[DivisionId] is null))
		    THEN
		   UPDATE SET
			  tar.CustomerName = src.CustomerName,
			  tar.CustomerOrganizationId = src.CustomerOrganizationId,
			  tar.OrganizationNumber = src.OrganizationNumber,
			  tar.OrganizationName = src.OrganizationName,
			  tar.DateChanged = getdate() ,
			  tar.AddrLine1 = src.Address1 ,
			  tar.AddrLine2 = src.Address2 ,
			  tar.City      = src.City ,
			  tar.State     = src.State ,
			  tar.Zip       = src.Zip  ,
			  tar.DEA       = src.DEA ,
			  tar.Premier_Relation       = src.Premier_Relation ,
			  tar.SPC       = src.SPC ,
			  tar.[DivisionName]       = src.[Division Name],
			  tar.[DivisionId]       = src.[DivisionId]
			  
		WHEN NOT MATCHED THEN
		   INSERT
		   (
				ClientId,
				AccountNumber,
				CustomerName,
				CustomerOrganizationId,
				OrganizationNumber,
				OrganizationName,
				AddrLine1,
				AddrLine2,
				City,
				State,
				Zip,
				DEA,
				Premier_relation,
				SPC,
				[DivisionName],
				DivisionId
		   )
		   VALUES
		   (
				src.ClientId,
				src.AccountNumber,
				src.CustomerName,
				src.CustomerOrganizationId,
				src.OrganizationNumber,
				src.OrganizationName,
				src.Address1 ,
			    src.Address2 ,
			    src.City ,
			    src.State ,
			    src.Zip ,
			    src.DEA ,
			    src.Premier_Relation ,
			    src.SPC ,
			    src.[Division Name],
			    src.[DivisionId]
		   );

		   select ClientId,count(ClientId) from dbo.Customer
		   group by ClientId
		   select clientid,count(clientid) from dbo.CustomerOrganization
		   group by clientid

		   delete  from dbo.customerorganization
		   delete  from dbo.customer
		   select * from Customer

		   select * from dbo.CustomerOrganization
		   select * from dbo.Customer
		 

		 select count(*) from dbo.sales

		 select * from dbo.LeadTimeType