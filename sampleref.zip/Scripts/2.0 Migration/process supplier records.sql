select top 1000 * from raw.PurchaseOrders

select top 1000 * from [dbo].[CustomerSupplier]

--changes to be tested

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER PROCEDURE [Integrations].[MergeSuppierRecordsFromPo]  @DataSource varchar(50)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

Insert into [dbo].[CustomerSupplierHistory]
	(ActionType,              
	 CustomerSupplierId,         
	 clientid,                
	 ClientSupplierRefId,                     
	 Name,                  
	 Status, 
	 DataSourceId,    
	 DateImported,
	 DateChanged)
select m.ActionType,              
	   m.CustomerSupplierId,         
	   m.clientid,                
	   m.ClientSupplierRefId,                     
	   m.Name,                  
	   m.Status,     
	   m.DataSourceId,
	   m.DateImported,
	   m.DateChanged
From
	(MERGE [dbo].[CustomerSupplier] AS tar
		USING (select --ifim.clientid clientid, 
                       po.clientid,
					   po.SupplierId ClientSupplierRefId,
					   po.SupplierName Name,
					   ifim.[DataSourceId] 'DataSourceId'
				from [Raw].[PurchaseOrders] po
				   inner join [dbo].[ImportFileIDMapping] ifim
					  on po.DataSource = ifim.ClientImportCode
				where po.DataSource = @DataSource
				group by po.clientid, 
					   po.SupplierId,
					   po.SupplierName,
					   ifim.[DataSourceId]) AS src
		ON tar.[ClientId] = src.[ClientId]
		 and tar.ClientSupplierRefId = src.ClientSupplierRefId
		WHEN MATCHED 
		     AND (tar.name != src.name
					or (src.name is null and tar.name is not null)
					or (src.name is not null and tar.name is null))
		    THEN
		   UPDATE SET
					tar.name = src.name, 
					tar.DateChanged = getdate()
		WHEN NOT MATCHED THEN
		   INSERT
		   (
				clientid,
				ClientSupplierRefId,
				Name,
				Status,
				DataSourceId
		   )
		   VALUES
		   (
				src.clientid,
				src.ClientSupplierRefId,
				src.Name,
				'A',
				src.DataSourceId
		   )
		OUTPUT
		   CASE WHEN $action = 'UPDATE' Then 'UPDATED'
				WHEN $action = 'INSERT' Then 'INSERTED'
		        ELSE $action End as ActionType,
			CASE WHEN $action = 'INSERT' then inserted.CustomerSupplierId else deleted.CustomerSupplierId end as CustomerSupplierId,
			CASE WHEN $action = 'INSERT' then inserted.ClientId else deleted.ClientId end as ClientId,
			CASE WHEN $action = 'INSERT' then inserted.ClientSupplierRefId else deleted.ClientSupplierRefId end as ClientSupplierRefId,
			CASE WHEN $action = 'INSERT' then inserted.Name else deleted.Name end as Name,
			CASE WHEN $action = 'INSERT' then inserted.Status else deleted.Status end as Status,
			CASE WHEN $action = 'INSERT' then inserted.DataSourceId else deleted.DataSourceId end as DataSourceId,
			CASE WHEN $action = 'INSERT' then inserted.DateImported else deleted.DateImported end as DateImported,
			CASE WHEN $action = 'INSERT' then inserted.DateChanged else deleted.DateChanged end as DateChanged	
			) as M; 


--Log data activity
declare @BeginDate datetime
declare @EndData datetime

select @BeginDate = min([TransactionDate]), @EndData = max([TransactionDate])
from [Raw].[Sales]

exec [Integrations].[LogDataFeed] @DataSource, 'CustSupplier', @BeginDate, @EndData;


END
GO
