select count(*) from dbo.ItemMaster im 

delete from dbo.ItemMaster


select * from ItemMaster

SELECT * FROM sys.sql_expression_dependencies  
WHERE referencing_id = OBJECT_ID(N'dbo.ItemMaster');  

exec  sp_depends 'dbo.ItemMaster'

SELECT  obj.name AS FK_NAME,
    sch.name AS [schema_name],
    tab1.name AS [table],
    col1.name AS [column],
    tab2.name AS [referenced_table],
    col2.name AS [referenced_column]
FROM sys.foreign_key_columns fkc
INNER JOIN sys.objects obj
    ON obj.object_id = fkc.constraint_object_id
INNER JOIN sys.tables tab1
    ON tab1.object_id = fkc.parent_object_id
INNER JOIN sys.schemas sch
    ON tab1.schema_id = sch.schema_id
INNER JOIN sys.columns col1
    ON col1.column_id = parent_column_id AND col1.object_id = tab1.object_id
INNER JOIN sys.tables tab2
    ON tab2.object_id = fkc.referenced_object_id
INNER JOIN sys.columns col2
    ON col2.column_id = referenced_column_id AND col2.object_id = tab2.object_id
    
    
    
    select * from     Watch.NationalShortageWatch
--select * from     dbo.CustomerItemPricingHistoryMonthly
select * from     Watch.ShortageWatch
select * from     dbo.CustomerItemRelationship
select * from     dbo.CustomerItemRelationship
select * from     dbo.CustomerItemSupplier
select * from     Predictive.NDCPricePredictions
select * from     Predictive.NDCPricePredictionsHistory
select * from     dbo.ReimbursementItemPricing
select * from     dbo.CustomerItem
select * from     dbo.CustomerItemLeadTime
select * from     dbo.CustomerSupplierItemLeadTime
select * from     dbo.NationalPharmacyItemPrice
select * from     dbo.NationalPharmacyItemPriceMonthly
select * from     dbo.AspPriceAndLimits
select * from     Predictive.NDCDemandPredictions
select * from     dbo.ChargeCdmNdcXref


DELETE FROM   Watch.NationalShortageWatch
DELETE FROM   dbo.CustomerItemPricingHistoryMonthly
DELETE FROM   Watch.ShortageWatch
DELETE FROM   dbo.CustomerItemRelationship
DELETE FROM   dbo.CustomerItemRelationship
DELETE FROM   dbo.CustomerItemSupplier
DELETE FROM   Predictive.NDCPricePredictions
DELETE FROM   Predictive.NDCPricePredictionsHistory
DELETE FROM   dbo.ReimbursementItemPricing
DELETE FROM   dbo.CustomerItem
DELETE FROM   dbo.CustomerItemLeadTime
DELETE FROM   dbo.CustomerSupplierItemLeadTime
DELETE FROM   dbo.NationalPharmacyItemPrice
DELETE FROM   dbo.NationalPharmacyItemPriceMonthly
DELETE FROM   dbo.AspPriceAndLimits
DELETE FROM   Predictive.NDCDemandPredictions
DELETE FROM   dbo.ChargeCdmNdcXref






--fixing the issue

DBCC CHECKIDENT ('[TestTable]', RESEED, 0); 2320

DBCC CHECKIDENT ("dbo.ManufacturerLabeler", NORESEED)

select * from dbo.ManufacturerLabeler where mfid > 2320


DBCC CHECKIDENT ('dbo.ManufacturerLabeler', RESEED, 0);
DBCC CHECKIDENT ('dbo.Manufacturer', RESEED, 0);
DBCC CHECKIDENT ('dbo.Supplier', RESEED, 0);
DBCC CHECKIDENT ('dbo.ImportFileIDMapping', RESEED, 0);

delete from dbo.DataSource 
delete from dbo.ImportFileIDMapping
delete from dbo.DataFeedLog

select * from  dbo.manufacturer
select * from Supplier
delete from dbo.ManufacturerLabeler
delete  from dbo.Manufacturer
delete from dbo.Supplier
truncate table dbo.SalesTotalMonthly
truncate table dbo.salestotals
truncate table dbo.sales
truncate table dbo.CustomerItemPricing
truncate table dbo.CustomerItemPricingHistoryMonthly
delete from  dbo.ImportFileIDMapping
truncate table dbo.DataFeedLog
truncate table dbo.ManufacturerLabeler
delete from PharmacyItem
delete from ItemMaster.NdcIngredients
delete from ItemMaster.FdaProductApplications
delete from ItemMaster.FdaProductPatent
delete from Fda.RecallV2Ndc
delete from ItemMaster.FdaProductExclusivity
delete from dbo.PharmacyItemShortage

select * from dbo.ImportFileIDMapping

select * from dbo.Manufacturer
select * from dbo.ManufacturerLabeler

delete from dbo.ItemMaster

truncate table dbo.NationalPharmacyItemPrice
truncate table dbo.CustomerSupplierItemLeadTime
truncate table dbo.CustomerItem
truncate table dbo.CustomerItemLeadTime
delete from Watch.NationalShortageWatch
delete from Watch.NationalShortageWatchReason
truncate table dbo.AspPriceAndLimits
delete from Watch.ShortageWatch
delete from Watch.ShortageWatchReason



select ni.ItemUId, im.ItemId, ni.[Ndc], ni.IngredientDrugName, ni.IngredientStrengthValue, ni.IngredientStengthUom
from dbo.ndcingredientsdebugsep ni 
  left join [dbo].[ItemMaster] im 
     on ni.ItemUId = im.ItemUId  where im.itemid is null;



     select * from dbo.ItemMaster

select im.ItemId ItemMasterItemId, im.ItemTypeId, im.ItemCode, im.ItemDescription, 
m.MfrId, im.Gtin, im.DateAdded, im.DateChanged, im.ItemUId, im.DataSourceId 
from dbo.itemmasterdebugsep im left join [dbo].[Manufacturer] m on im.MfrId = m.[ItemMasterMfrId]

select * from dbo.ItemMaster

 
