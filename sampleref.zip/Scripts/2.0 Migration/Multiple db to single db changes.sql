SELECT top 1000 * from premier.WholesalerInvoices wi 
--84412135
select count(*) from premier.WholesalerInvoices wi 
--health system

select HealthSystemID,FacilityDirectParentID,Secret from SyncControl.PremierCustomerSync;

select HealthSystemID ,count(*)
from
	premier.WholesalerInvoices
where
	[HealthSystemID] in (
'CO5012',
'PA0023',
'MN2013',
'743692',
'NY5011',
'WI0013')
group by HealthSystemID 
--CO5012
--NY5011

=================================================================================================
|PremierCustomerSyncId|DataFactory                 |HealthSystemID|FacilityDirectParentID|Secret                        |DatasetInvoiceCode     |DatasetPoCode     |Status|
|---------------------|----------------------------|--------------|----------------------|------------------------------|-----------------------|------------------|------|
|1                    |adf-Premier-DataReceive-prod|CO5012        |                      |Secret-CogRX-DB-CommonSpirit  |PremierWholesaleInvoice|PremierWholesalePO|A     |
|2                    |adf-Premier-DataReceive-prod|PA0023        |                      |Secret-CogRX-DB-stluke        |PremierWholesaleInvoice|PremierWholesalePO|A     |
|3                    |adf-Premier-DataReceive-prod|NY5011        |NY0024                |Secret-CogRX-DB-northwell     |PremierWholesaleInvoice|PremierWholesalePO|A     |
|4                    |adf-Premier-DataReceive-prod|MN2013        |                      |Secret-CogRX-DB-Fairview      |PremierWholesaleInvoice|PremierWholesalePO|A     |
|5                    |adf-Premier-DataReceive-prod|743692        |                      |Secret-CogRX-DB-upmc          |PremierWholesaleInvoice|PremierWholesalePO|A     |
|6                    |adf-Premier-DataReceive-prod|NY5011        |NY5073                |Secret-CogRX-DB-Demo          |PremierWholesaleInvoice|PremierWholesalePO|I     |
|7                    |adf-Premier-DataReceive-prod|WI0013        |                      |Secret-CogRX-DB-AdvocateAurora|PremierWholesaleInvoice|PremierWholesalePO|A     |
|8                    |adf-Premier-DataReceive-prod|CO5012        |838509                |Secret-CogRX-DB-Centura       |PremierWholesaleInvoice|PremierWholesalePO|A     |

=================================================================================================
select * from raw.PremierCustomerList pcl 

--northwell
--HIERARCHY REPORT PULL
SELECT COUNT(*),[Health System ID] FROM
(select *
from [Raw].[PremierCustomerList]
where ([Health System ID] in ('NY5011','CO5012')
    and [Facility Direct Parent ID] IN  ('NY0024','838509'))
    or [Facility ID] IN  ('NY0024','838509')
union ALL
select *
from [Raw].[PremierCustomerList]
where [Health System ID] in  ('CO5012','PA0023','MN2013','743692','WI0013')) X
GROUP BY X.[Health System ID]

--WHOLESALER INVOICE PULL
SELECT COUNT(*),[HealthSystemID] FROM
(
select *
from [Premier].[WholesalerInvoices]
where ([HealthSystemID] in ('NY5011','CO5012')
   and [FacilityDirectParentID] IN  ('NY0024','838509'))
union ALL
select *
from [Premier].[WholesalerInvoices]
where [HealthSystemID] in  ('CO5012','PA0023','MN2013','743692','WI0013')) X
GROUP BY X.[HealthSystemID]


--OUTPUT OF WHOLESALER INVOICE PULL
|         |HealthSystemID|
|---------|--------------|
|870,982  |743692        |
|3,394,604|CO5012        |
|1,556,914|MN2013        |
|524,913  |NY5011        |
|271,036  |PA0023        |
|1,910,197|WI0013        |
---PREMIER HIERARCHY MERGE PROCESS

SELECT * FROM DBO.ImportFileIDMapping ifi 

select HealthSystemID,COUNT(*)
from [Premier].[WholesalerInvoices]
where [HealthSystemID] in  ('CO5012','PA0023','MN2013','743692','WI0013')
GROUP BY HealthSystemID 

--GROUP BY [Health System ID]


SELECT COUNT(*) FROM Customer c 
create table dbo.clientidlookup
add

CREATE TABLE dbo.clientidlookup (
    healthsytem varchar(50),
    clientid int)
    
 INSERT INTO clientidlookup (healthsytem,clientid) VALUES ('CO5012',1);
 INSERT INTO clientidlookup (healthsytem,clientid) VALUES ('PA0023',2);
 INSERT INTO clientidlookup (healthsytem,clientid) VALUES ('MN2013',3);
 INSERT INTO clientidlookup (healthsytem,clientid) VALUES ('743692',4);
 INSERT INTO clientidlookup (healthsytem,clientid) VALUES ('NY5011',5);
 INSERT INTO clientidlookup (healthsytem,clientid) VALUES ('WI0013',6);


743692	868075
CO5012	2993580
MN2013	1551343
NY5011	4245622
PA0023	270161
WI0013	1903518

select A.*,b.* from premier.WholesalerInvoices a join clientidlookup b on a.HealthSystemID = b.healthsytem
with ctenew as (
select a.*,b.* from premier.WholesalerInvoices a join clientidlookup b on a.HealthSystemID = b.healthsytem)
select count(*),clientid from ctenew group by clientid

   /* LastName varchar(255),
    FirstName varchar(255),
    Address varchar(255),
    City varchar(255)*/
);