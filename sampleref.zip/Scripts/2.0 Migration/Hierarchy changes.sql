--CLIENT ID MAPPING
SELECT *
FROM raw.PremierCustomerList

---from dbeaver
SELECT *
FROM CUSTOMER CENTURA - 8 -- 838509
    AA - 7 - WI0013 COMMONSPIRIT - 2 -- CO5012
    PRODDEMO - 1 -- NC9999
    NORTHWELL - 4 -- NY004
    FAIRVIEW - 3 -- MN2013
    STLUKES - 5 -- PA0023
    -- -- UPMC - 6  -- 743692

--LOOKUP TABLE
CREATE TABLE dbo.clientidlookup (
    healthsystem VARCHAR(50)
    , clientid INT
    )

SELECT *
FROM dbo.clientidlookup c

INSERT INTO clientidlookup (
    healthsytem
    , clientid
    )
VALUES (
    'CO5012'
    , 1
    );

INSERT INTO clientidlookup (
    healthsytem
    , clientid
    )
VALUES (
    'PA0023'
    , 2
    );

INSERT INTO clientidlookup (
    healthsytem
    , clientid
    )
VALUES (
    'MN2013'
    , 3
    );

INSERT INTO clientidlookup (
    healthsytem
    , clientid
    )
VALUES (
    '743692'
    , 4
    );

INSERT INTO clientidlookup (
    healthsytem
    , clientid
    )
VALUES (
    'NY5011'
    , 5
    );

INSERT INTO clientidlookup (
    healthsytem
    , clientid
    )
VALUES (
    'WI0013'
    , 6
    );

--NEW HIERARCHY PROCESS
WITH DemoCustomers
AS (
    SELECT a.*
        , c.clientid
    FROM raw.democustomerlist a
    LEFT JOIN dbo.clientidlookup c
        ON a.[Facility Direct Parent ID] = c.healthsystem
    )
    , IndirectCustomers
AS (
    SELECT a.*
        , c.clientid
    FROM [Raw].[PremierCustomerList] a
    LEFT JOIN dbo.clientidlookup c
        ON a.[Facility Direct Parent ID] = c.healthsystem
    WHERE (
            [Health System ID] IN ('NY5011', 'CO5012')
            AND [Facility Direct Parent ID] IN ('NY0024', '838509')
            )
        OR [Facility ID] IN ('NY0024', '838509')
    )
    , DirectCustomers
AS (
    SELECT a.*
        , c.clientid
    FROM [Raw].[PremierCustomerList] a
    LEFT JOIN dbo.clientidlookup c
        ON a.[Health System ID] = c.healthsystem
    WHERE [Health System ID] IN ('CO5012', 'PA0023', 'MN2013', '743692', 'WI0013')
    )
    , DistinctDirectParent
AS (
    SELECT *
    FROM DemoCustomers
    
    UNION
    
    SELECT *
    FROM IndirectCustomers
    
    UNION
    
    SELECT *
    FROM DirectCustomers
    )
SELECT clientid
    , count(clientid)
FROM DistinctDirectParent
GROUP BY clientid

--CLIENTID JOIN VALIDATION COUNT
SELECT COUNT(*)
    , [Health System ID]
FROM (
    SELECT *
    FROM [Raw].[PremierCustomerList]
    WHERE (
            [Health System ID] IN ('NY5011', 'CO5012')
            AND [Facility Direct Parent ID] IN ('NY0024', '838509')
            )
        OR [Facility ID] IN ('NY0024', '838509')
    
    UNION ALL
    
    SELECT *
    FROM [Raw].[PremierCustomerList]
    WHERE [Health System ID] IN ('CO5012', 'PA0023', 'MN2013', '743692', 'WI0013')
    ) X
GROUP BY X.[Health System ID]

SELECT *
INTO raw.democustomerlist
FROM [Raw].[PremierCustomerList]
WHERE (
        [Health System ID] = 'NY5011'
        AND [Facility Direct Parent ID] = 'NY0024'
        )
    AND [Facility ID] IN ('NY5073', 'NY5029', 'NY2179')

SELECT *
FROM raw.democustomerlist

--LOADING HIERARCHY DATA
SELECT *
FROM [Raw].[PremierCustomerList]
WHERE (
        [Health System ID] IN ('NY5011', 'CO5012')
        AND [Facility Direct Parent ID] IN ('NY0024', '838509')
        )
    OR [Facility ID] IN ('NY0024', '838509')

UNION ALL

SELECT *
FROM raw.democustomerlist

UNION ALL

SELECT *
FROM [Raw].[PremierCustomerList]
WHERE [Health System ID] IN ('CO5012', 'PA0023', 'MN2013', '743692', 'WI0013')

SET FacilityID = CASE 
        WHEN FacilityID = 'NC9999'
            THEN 'NY5073'
        WHEN FacilityID = 'NC8888'
            THEN 'NY5029'
        WHEN FacilityID = 'NC7777'
            THEN 'NY2179'
        END

-- MASKING THE WHOLESALER INVOICES FOR DEMO REGION AND LOADING INTO 
-- DEMOWHOLESALERINVOICES TABLE AND LATER UNIONED  FOR LOADING INTO MEMBER DATABASE			     
SELECT Id
    , HealthSystemID
    , FacilityDirectParentID
    , CASE 
        WHEN FacilityID = 'NY5073'
            THEN 'NC9999'
        WHEN FacilityID = 'NY5029'
            THEN 'NC8888'
        WHEN FacilityID = 'NY2179'
            THEN 'NC7777'
        END AS FacilityID
    ,
    --FacilityID,
    FacilityAddress1
    , FacilityAddress2
    , FacilityCity
    , FacilityState
    , FacilityZipCode
    , NDC
    , ItemId
    , BrandName
    , GenericName
    , LabelName
    , WholesalerPurchaseType
    , WholesalerLoadPrice
    , Supplier
    , InvoiceDate
    , InvoiceNumber
    , InvoicePrice
    , Wholesaler
    , DistributionCenterName
    , WholesalerAccountNumber
    , WholesalerAccountName
    , LineNumberfromInvoice
    , ContractLeadName
    , ServiceProviderClass
    , ShipMethod
    , ShippingDate
    , WholesalerPkgQty
    , WholesalerOrderLineNumber
    , WholesalerCatalogNumber
    , UnitofMeasure
    , WholesalerAccountAttribute
    , ChargeBackContractNumber
    , [Markup/Markdown]
    , PremierAwardStatus
    , PremierContractNumber
    , TotalUnits
    , TotalSpend
    , QuantityOrdered
    , AddedDate
    , ProcessPipelineId
    , OriginalFileName
    , AdlPath
    , OrderDate
    , ReasonCodeDesc
--select * into premier.demowholesalerinvoices
FROM [Premier].[WholesalerInvoices]
WHERE (
        [HealthSystemID] = 'NY5011'
        AND [FacilityDirectParentID] = 'NY0024'
        )
    AND [FacilityID] IN ('NY5073', 'NY5029', 'NY2179')

--CREATION OF STAGING TABLES
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE SCHEMA STAGE;
GO

CREATE TABLE [STAGE].[PremierCustomerList] (
    [Health System] [nvarchar](255) NULL
    , [Health System ID] [nvarchar](255) NULL
    , [Facility Direct Parent] [nvarchar](255) NULL
    , [Facility Direct Parent ID] [nvarchar](255) NULL
    , [Facility Name] [nvarchar](255) NULL
    , [Facility ID] [nvarchar](255) NULL
    , [ImportedDate] [datetime] NULL
    , [Facility AddrLine1] [varchar](200) NULL
    , [Facility AddrLine2] [varchar](100) NULL
    , [Facility City] [varchar](50) NULL
    , [Facility State] [varchar](10) NULL
    , [Facility Zip] [varchar](30) NULL
    , [Facility DEA] [nvarchar](255) NULL
    , [Premier_Relation] [varchar](25) NULL
    , [SPC] [nvarchar](255) NULL
    , [Division Name] [nvarchar](255) NULL
    , [DivisionId] [nvarchar](255) NULL
    , [Clientid] INT NOT NULL
    )
GO

SELECT a.[Health System ID]
    , a.clientid
    , a.[Health System]
    , count(*) AS clientcount
FROM raw.PremierCustomerList a
GROUP BY a.clientid
    , a.[Health System ID]
    , a.[Health System]

SELECT *
FROM raw.premiercustomerlist
WHERE clientid = 2

SELECT *
FROM customerorganization


select count(*) from dbo.Sales



select * from premier.WholesalerInvoices

select * from INFORMATION_SCHEMA.COLUMNS where TABLE_SCHEMA = 'premier' and TABLE_NAME = 'WholesalerInvoices'


select top 100 * from premier.WholesalerInvoices


select distinct wholesaler from premier.WholesalerInvoices


select clientid, count(*),min(TransactionDate) as count from dbo.sales
group by ClientId

select min(TransactionDate) from dbo.Sales
 where ClientId = 1