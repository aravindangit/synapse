CREATE TABLE SourceProducts(
    ProductID		INT,
    ProductName		VARCHAR(50),
    Price			DECIMAL(9,2)
)
;
    
INSERT INTO SourceProducts(ProductID,ProductName, Price) VALUES(71,'11Table',100)
INSERT INTO SourceProducts(ProductID,ProductName, Price) VALUES(81,'11Desk',80)
INSERT INTO SourceProducts(ProductID,ProductName, Price) VALUES(91,'11Chair',50)
INSERT INTO SourceProducts(ProductID,ProductName, Price) VALUES(101,'11Computer',300)
;
    
CREATE TABLE TargetProducts(
    ProductID		INT,
    ProductName		VARCHAR(50),
    Price			DECIMAL(9,2)
);

    
INSERT INTO TargetProducts(ProductID,ProductName, Price) VALUES(1,'Table',100)
INSERT INTO TargetProducts(ProductID,ProductName, Price) VALUES(2,'Desk',180)
INSERT INTO TargetProducts(ProductID,ProductName, Price) VALUES(5,'Bed',50)
INSERT INTO TargetProducts(ProductID,ProductName, Price) VALUES(6,'Cupboard',300)
;
    
    
SELECT * FROM SourceProducts
SELECT * FROM TargetProducts


MERGE TargetProducts AS Target
USING SourceProducts AS Source
ON Source.ProductID = Target.ProductID
-- For Inserts
WHEN NOT MATCHED BY Target THEN
        INSERT
	(ProductID,
	ProductName,
	Price)
VALUES (Source.ProductID,
Source.ProductName,
Source.Price)
-- For Updates
WHEN MATCHED
AND (Target.ProductName != Source.ProductName
	or (Source.ProductName is null
		and Target.ProductName is not null)
	or (Source.ProductName is not null
		and Target.ProductName is null)
	or Target.Price != Source.Price
	or (Source.Price is null
		and Target.Price is not null)
	or (Source.Price is not null
		and Target.Price is null))
    THEN
UPDATE
SET
	Target.ProductName = Source.ProductName,
	Target.Price = Source.Price
WHEN NOT MATCHED BY Source THEN
    DELETE
	
	OUTPUT $action,
	DELETED.ProductID AS TargetProductID,
	DELETED.ProductName AS TargetProductName,
	DELETED.Price AS TargetPrice,
	INSERTED.ProductID AS SourceProductID,
	INSERTED.ProductName AS SourceProductName,
	INSERTED.Price AS SourcePrice;
       
       
       select * from SourceProducts sp 
       update dbo.SourceProducts set price = 5577 where ProductID = 1
       select * from SourceProducts sp 
        
       
       
   '''full sample review



CREATE PROCEDURE [Integrations].[MergeCustomerItemRecordsFromPo]  @DataSource varchar(50)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

Insert into [dbo].[CustomerItemHistory]
	(ActionType,              
	 CustomerItemId,
	 ClientId,
	 ItemId,
	 Ndc,
	 Description,
	 ClientItemId,
	 Status,
	 DataSourceId,
	 DateImported,
	DateChanged)
select m.ActionType,              
	   m.CustomerItemId,
	   m.ClientId,
	   m.ItemId,
	   m.Ndc,
	   m.Description,
	   m.ClientItemId,
	   m.Status,
	   m.DataSourceId,
	   m.DateImported,
	   m.DateChanged	
From
	(MERGE [dbo].[CustomerItem] AS tar
		USING (select --ifim.clientid 'clientid', 
                       po.clientid 'clientid' , 
					   po.Ndc 'NDC',
					   pi.itemid 'ItemId',
					   pi.ItemDescription 'Description',
					   po.Ndc 'ClientItemId',
					   ifim.[DataSourceId] 'DataSourceId'
				from [Raw].[PurchaseOrders] po
				   inner join [dbo].[ImportFileIDMapping] ifim
					  on po.DataSource = ifim.ClientImportCode
				   inner join [dbo].[PharmacyItem] pi
					  on po.ndc = pi.ndc
				where po.DataSource = @DataSource
				group by po.clientid, 
					   po.Ndc,
					   pi.itemid,
					   pi.ItemDescription,
					   ifim.[DataSourceId]) AS src
		ON tar.[ClientId] = src.[ClientId]
		 and tar.NDC = src.NDC
		WHEN MATCHED 
		     AND (tar.Description != src.Description
					or (src.Description is null and tar.Description is not null)
					or (src.Description is not null and tar.Description is null)
					or tar.ClientItemId != src.ClientItemId
					or (src.ClientItemId is null and tar.ClientItemId is not null)
					or (src.ClientItemId is not null and tar.ClientItemId is null)
					or tar.DataSourceId != src.DataSourceId
					or (src.DataSourceId is null and tar.DataSourceId is not null)
					or (src.DataSourceId is not null and tar.DataSourceId is null)
					or tar.Status = 'I')
		    THEN
		   UPDATE SET
					tar.Description = src.Description, 
					tar.ClientItemId = src.ClientItemId,
					tar.DataSourceId = src.DataSourceId,
					tar.DateChanged = getdate(),
					tar.Status = 'A'
  		   WHEN NOT MATCHED THEN
		   INSERT
		   (
				clientid,
				NDC,
				ItemId,
				Description,
				ClientItemId,
				Status,
				DataSourceId
		   )
		   VALUES
		   (
				src.clientid,
				src.NDC,
				src.ItemId,
				src.Description,
				src.ClientItemId,
				'A',
				src.DataSourceId
		   )
		OUTPUT
		   CASE WHEN $action = 'UPDATE' Then 'UPDATED'
				WHEN $action = 'INSERT' Then 'INSERTED'
		        ELSE $action End as ActionType,
			CASE WHEN $action = 'INSERT' then inserted.CustomerItemId else deleted.CustomerItemId end as CustomerItemId,
			CASE WHEN $action = 'INSERT' then inserted.ClientId else deleted.ClientId end as ClientId,
			CASE WHEN $action = 'INSERT' then inserted.ItemId else deleted.ItemId end as ItemId,
			CASE WHEN $action = 'INSERT' then inserted.Ndc else deleted.Ndc end as Ndc,
			CASE WHEN $action = 'INSERT' then inserted.Description else deleted.Description end as Description,
			CASE WHEN $action = 'INSERT' then inserted.ClientItemId else deleted.ClientItemId end as ClientItemId,
			CASE WHEN $action = 'INSERT' then inserted.Status else deleted.Status end as Status,
			CASE WHEN $action = 'INSERT' then inserted.DataSourceId else deleted.DataSourceId end as DataSourceId,
			CASE WHEN $action = 'INSERT' then inserted.DateImported else deleted.DateImported end as DateImported,
			CASE WHEN $action = 'INSERT' then inserted.DateChanged else deleted.DateChanged end as DateChanged	
			) as M; 


--Log data activity
declare @BeginDate datetime
declare @EndData datetime

select @BeginDate = min([TransactionDate]), @EndData = max([TransactionDate])
from [Raw].[Sales]

exec [Integrations].[LogDataFeed] @DataSource, 'CustCat', @BeginDate, @EndData;


END

   