select * from dbo.Customer   where status = 'I'

SELECT * FROM DBO.salesWanAgg swa 


select * from sys.syscolumns s 
update c 
set c.DivisionName = c2.DivisionName ,
    c.DivisionId  = c2.DivisionId 
 from dbo.customer c join dbo.customerapr2022 c2
on c.AccountNumber = c2.AccountNumber 


select * from dbo.Customer c 