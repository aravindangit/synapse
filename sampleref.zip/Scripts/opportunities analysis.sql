            SELECT
                    MAX(ndc) as ndc
                    , MAX(ndc_1) as ndc_1
                    , MAX(drugname) as drugname
                    , generic
                    , MAX([desc]) as 'desc'
                    , MAX(desc_1) as desc_1
                    , MAX(supp_0) as supp_0
                    , MAX(supp_1) as supp_1
                    , MAX(sname_0) as sname_0
                    , MAX(sname_1) as sname_1
                    , MAX( mname_0) as mname_0
                    , MAX(mname_1) as mname_1
                    , equ_or_switch
                    , tkey
                    , SUM([340b]) as '340b'
                    , SUM(wac) as 'wac'
                    , SUM(gpo) as 'gpo'
                    , SUM(total) as 'total'
                FROM MV.PriceOppsFinal
                WHERE rundate >= DATEADD(day, -30, GETDATE()) and drugname='Insulin Glargine'
                GROUP BY tkey, generic, equ_or_switch
                HAVING SUM(total) > 5000 AND (SUM([340b]) > 0 OR SUM(gpo) > 0)






SELECT pi.*, df.DosageFormDescription, ps.PackageSizeUomDescription, r.OnHandInventoryQuantity
                FROM pharmacyitem pi
                LEFT JOIN itemmaster.dosageform df ON pi.dosageformid = df.dosageformid
                LEFT JOIN itemmaster.packagesizeuom ps ON pi.packagesizeuomid = ps.packagesizeuomid
                LEFT JOIN clientpharmacyrisk r ON pi.ndc = r.ndc
                WHERE pi.ndc = '49502019675' AND  (r.clientid = 2 OR r.clientid IS NULL)