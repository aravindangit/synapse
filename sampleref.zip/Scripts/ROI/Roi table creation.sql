--Creating Roi table

CREATE TABLE dbo.ROI_Tracking (
    Ndc varchar(11) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
    Division varchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
    Facility varchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
    Wholesaler varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
    WholesalerAccountNumber varchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
    ROI_Track_Date datetime NULL,
    ROI_Start_Date datetime NULL,
    ROI_End_Date datetime NULL,
    Status varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    Estimated_Advance_Purchase_Units int NOT NULL,
    Actual_Quantity int NULL,
    Units_to_Count_for_ROI int null,
    Actual_ROI int null)
	select * from dbo.ROI_Tracking


CREATE TABLE dbo.ROI_Information (
    Ndc varchar(11) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
    ROI_Track_Date datetime NULL,
    ROI_Start_Date datetime NULL,
    ROI_End_Date datetime NULL)

	select * from  dbo.ROI_Information

INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)
VALUES ('00126001661', '4/1/2022', '5/1/2022', '6/16/2022');
select * from  dbo.ROI_Information





	ClientId int NOT NULL,
	CustomerId int NOT NULL,
	SupplierId int NOT NULL,
	ItemId int NULL,
	SupplierName varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	TransactionDate datetime NOT NULL,
	Ndc varchar(11) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	ItemDescription varchar(1000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	OrderNumber varchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	LineNumber int NULL,
	OrderType varchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	Qty int NOT NULL,
	UnitCost money NOT NULL,
	UnitPrice money NOT NULL,
	UOM varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	InvoiceNumber varchar(250) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	WholesalerAccountNumber varchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	WholesalerCBID varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CostofDistribution varchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Address1 varchar(1000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Address2 varchar(1000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	City varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	State varchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ZipCode varchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ImportedDate datetime NULL,
	SalesId int IDENTITY(1,1) NOT NULL,
	PriceTypeGroupId int NULL,
	DataSourceId int NULL,
	QuarterDate varchar(8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ProcessPipelineId varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	RepackagedFlag bit NULL,
	QtyOrdered int NULL,
	OrderDate datetime NULL,
	ReasonCodeDesc varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK__Sales__C952FB325B51AB80 PRIMARY KEY (SalesId)
);


TRUNCATE TABLE ROI_Information
---manual loading---
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('00126001661','2022-04-01','2022-05-01','2022-06-16');
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('00126002292','2022-04-01','2022-05-01','2022-06-16');
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('00126003316','2022-04-01','2022-05-01','2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('00126007061','2022-04-01','2022-05-01','2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('00126007292','2022-04-01','2022-05-01','2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('00126007492','2022-04-01','2022-05-01','2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('00126008802','2022-04-01','2022-05-01','2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('00126016593','2022-04-01','2022-05-01','2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('00126019293','2022-04-01','2022-05-01','2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('00126028666','2022-04-01','2022-05-01','2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('00126028766','2022-04-01','2022-05-01','2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('00126028802','2022-04-01','2022-05-01','2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('00126028992','2022-04-01','2022-05-01','2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('00299382230','2022-02-01','2022-04-01','2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('00299590660','2022-03-01',NULL,'2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('00299598030','2022-02-01','2022-04-01','2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('00299598035','2022-02-01','2022-04-01','2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('24338015020','2022-04-01','2022-05-01','2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('24359050502','2022-02-01',NULL,'2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('24359050901','2022-02-01',NULL,'2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('24359054403','2022-02-01',NULL,'2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('24359055107','2022-03-01',NULL,'2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('24359057502','2022-03-01',NULL,'2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('24359070403','2022-02-01',NULL,'2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('42023010501','2022-04-01',NULL,'2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('42023011925','2022-04-01',NULL,'2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('46122045021','2022-04-01',NULL,'2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('49502080632','2022-04-01',NULL,'2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('49502080693','2022-04-01',NULL,'2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('53436008401','2022-02-01','2022-04-01','2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('53436008404','2022-02-01','2022-04-01','2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('53436008430','2022-02-01','2022-04-01','2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('53436016801','2022-02-01','2022-04-01','2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('53436016830','2022-02-01','2022-04-01','2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('53436025201','2022-02-01','2022-04-01','2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('53436025230','2022-02-01','2022-04-01','2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('54436020002','2022-04-01',NULL,'2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('54436020004','2022-04-01',NULL,'2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('54436025002','2022-04-01',NULL,'2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('54436025004','2022-04-01',NULL,'2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('54436027502','2022-04-01',NULL,'2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('54436027504','2022-04-01',NULL,'2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('55566750102','2022-02-01','2022-06-01','2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('59212056210','2022-04-01',NULL,'2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('59310058020','2022-04-01',NULL,'2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('59338077501','2022-04-01',NULL,'2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('65628007003','2022-04-01','2022-05-01','2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('65628007005','2022-04-01','2022-05-01','2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('65628007010','2022-04-01',NULL,'2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('65628008003','2022-04-01','2022-05-01','2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('65628008005','2022-04-01','2022-05-01','2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('65628008010','2022-04-01',NULL,'2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('65628010102','2022-04-01',NULL,'2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('65628010104','2022-04-01',NULL,'2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('65757040101','2022-02-01','2022-04-01','2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('65757040103','2022-02-01','2022-04-01','2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('65757040201','2022-02-01','2022-04-01','2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('65757040203','2022-02-01','2022-04-01','2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('65757040301','2022-02-01','2022-04-01','2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('65757040303','2022-02-01','2022-04-01','2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('65757040401','2022-02-01','2022-04-01','2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('65757040403','2022-02-01','2022-04-01','2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('65757050003','2022-02-01','2022-04-01','2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('67457022000','2022-04-01',NULL,'2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('67457022005','2022-04-01',NULL,'2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('67457025905','2022-04-01',NULL,'2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('67457058600','2022-04-01',NULL,'2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('67457058605','2022-04-01',NULL,'2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('67979000201','2022-02-01','2022-04-01','2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('69616021103','2022-04-01',NULL,'2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('69616021104','2022-04-01',NULL,'2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('69616021106','2022-04-01',NULL,'2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('69639010201','2022-04-01',NULL,'2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('69639012001','2022-04-01',NULL,'2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('70720072010','2022-04-01',NULL,'2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('70720072210','2022-04-01',NULL,'2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('70720072310','2022-04-01',NULL,'2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('71879013601','2022-04-01',NULL,'2022-06-16')
INSERT INTO ROI_Information (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('71904010001','2022-04-01','2022-05-01','2022-06-16')

SELECT * FROM ROI_Information