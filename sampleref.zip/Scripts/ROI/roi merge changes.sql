/*select * into ROI_target from ROI_Information

select * from roi_source


update roi_source set ROI_Track_Date = GETDATE(), ROI_Start_Date = GETDATE(), ROI_End_Date = GETDATE()
where ndc = '00126001661'
drop table dbo.roi_history;
CREATE TABLE dbo.ROI_history (
    Action varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	Ndc varchar(11) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	ROI_Track_Date datetime NULL,
	ROI_Start_Date datetime NULL,
	ROI_End_Date datetime NULL,
    updated datetime null)*/
   -- select * from dbo.roi_history
   --drop table dbo.roi_Source
   --select * into dbo.roi_Source from dbo.ROI_Information
  -- update roi_source set ROI_Track_Date = GETDATE(), ROI_Start_Date = GETDATE(), ROI_End_Date = GETDATE() where ndc = '00126001661'
  -- update roi_source set  ROI_Start_Date = NULL where ndc = '00126002292'
  --delete roi_source where ndc = '00000000001'
  --INSERT INTO ROI_SOURCE (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('00000000003','2022-04-01','2022-05-01','2022-06-16')  
INSERT INTO dbo.roi_history (
    action
    , Ndc
    , ROI_Track_Date
    , ROI_Start_Date
    , ROI_End_Date
    , updated
    )
SELECT m.actiontype
    , m.Ndc
    , m.ROI_Track_Date
    , m.ROI_Start_Date
    , m.ROI_End_Date
    , GETDATE() AS updated
FROM (
    MERGE ROI_target AS Target
    USING roi_source AS Source
        ON Source.ndc = Target.ndc
            -- For Inserts
    WHEN NOT MATCHED BY Target
        THEN
            INSERT (
                Ndc
                , ROI_Track_Date
                , ROI_Start_Date
                , ROI_End_Date
                )
            VALUES (
                Source.Ndc
                , Source.ROI_Track_Date
                , Source.ROI_Start_Date
                , Source.ROI_End_Date
                )
                -- For Updates
    WHEN MATCHED
        AND (
            Target.ROI_Track_Date != Source.ROI_Track_Date
            OR (
                Source.ROI_Track_Date IS NULL
                AND Target.ROI_Track_Date IS NOT NULL
                )
            OR (
                Source.ROI_Track_Date IS NOT NULL
                AND Target.ROI_Track_Date IS NULL
                )
            OR Target.ROI_Start_Date != Source.ROI_Start_Date
            OR (
                Source.ROI_Start_Date IS NULL
                AND Target.ROI_Start_Date IS NOT NULL
                )
            OR (
                Source.ROI_Start_Date IS NOT NULL
                AND Target.ROI_Start_Date IS NULL
                )
            OR Target.ROI_End_Date != Source.ROI_End_Date
            OR (
                Source.ROI_End_Date IS NULL
                AND Target.ROI_End_Date IS NOT NULL
                )
            OR (
                Source.ROI_End_Date IS NOT NULL
                AND Target.ROI_End_Date IS NULL
                )
            )
        THEN
            UPDATE
            SET Target.ROI_Track_Date = Source.ROI_Track_Date
                , Target.ROI_Start_Date = Source.ROI_Start_Date
                , Target.ROI_End_Date = source.ROI_End_Date
    --WHEN NOT MATCHED BY Source THEN
    --    DELETE
    OUTPUT CASE 
            WHEN $ACTION = 'UPDATE'
                THEN 'UPDATED'
            WHEN $ACTION = 'INSERT'
                THEN 'INSERTED'
            ELSE $ACTION
            END AS ActionType
        , CASE 
            WHEN $ACTION = 'INSERT'
                THEN inserted.Ndc
            ELSE deleted.Ndc
            END AS Ndc
        , CASE 
            WHEN $ACTION = 'INSERT'
                THEN inserted.ROI_Track_Date
            ELSE deleted.ROI_Track_Date
            END AS ROI_Track_Date
        , CASE 
            WHEN $ACTION = 'INSERT'
                THEN inserted.ROI_Start_Date
            ELSE deleted.ROI_Start_Date
            END AS ROI_Start_Date
        , CASE 
            WHEN $ACTION = 'INSERT'
                THEN inserted.ROI_End_Date
            ELSE deleted.ROI_End_Date
            END AS ROI_End_Date
    ) AS m;

            
            select * from roi_history order by updated desc
           -- truncate table ROI_target
           -- select * from ROI_target
    /*
    $action AS Actiontaken,
    DELETED.Ndc AS sourcendc,
	DELETED.ROI_Track_Date AS sourcetrackdate,
	DELETED.ROI_Start_Date AS sourcestartdate,
    DELETED.ROI_End_Date AS sourceenddate,
	INSERTED.Ndc AS sourcendc,
	INSERTED.ROI_Track_Date AS sourcetrackdate,
	INSERTED.ROI_Start_Date AS sourcestartdate, 
    INSERTED.ROI_End_Date AS sourceenddate)
    AS m;*/
  
--update dbo.roi_source set 

--TRUNCATE TABLE ROI_SOURCE
--TRUNCATE TABLE ROI_TARGET
 --  INSERT INTO ROI_SOURCE (Ndc, ROI_Track_Date, ROI_Start_Date, ROI_End_Date)  values  ('00000000001','2022-04-01','2022-05-01','2022-06-16')    
   /* 
       select * from SourceProducts sp 
       update dbo.SourceProducts set price = 5577 where ProductID = 1
       select * from SourceProducts sp 
        
       
       
   '''full sample review



CREATE PROCEDURE [Integrations].[MergeCustomerItemRecordsFromPo]  @DataSource varchar(50)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

Insert into [dbo].[CustomerItemHistory]
	(ActionType,              
	 CustomerItemId,
	 ClientId,
	 ItemId,
	 Ndc,
	 Description,
	 ClientItemId,
	 Status,
	 DataSourceId,
	 DateImported,
	DateChanged)
select m.ActionType,              
	   m.CustomerItemId,
	   m.ClientId,
	   m.ItemId,
	   m.Ndc,
	   m.Description,
	   m.ClientItemId,
	   m.Status,
	   m.DataSourceId,
	   m.DateImported,
	   m.DateChanged	
From
	(MERGE [dbo].[CustomerItem] AS tar
		USING (select --ifim.clientid 'clientid', 
                       po.clientid 'clientid' , 
					   po.Ndc 'NDC',
					   pi.itemid 'ItemId',
					   pi.ItemDescription 'Description',
					   po.Ndc 'ClientItemId',
					   ifim.[DataSourceId] 'DataSourceId'
				from [Raw].[PurchaseOrders] po
				   inner join [dbo].[ImportFileIDMapping] ifim
					  on po.DataSource = ifim.ClientImportCode
				   inner join [dbo].[PharmacyItem] pi
					  on po.ndc = pi.ndc
				where po.DataSource = @DataSource
				group by po.clientid, 
					   po.Ndc,
					   pi.itemid,
					   pi.ItemDescription,
					   ifim.[DataSourceId]) AS src
		ON tar.[ClientId] = src.[ClientId]
		 and tar.NDC = src.NDC
		WHEN MATCHED 
		     AND (tar.Description != src.Description
					or (src.Description is null and tar.Description is not null)
					or (src.Description is not null and tar.Description is null)
					or tar.ClientItemId != src.ClientItemId
					or (src.ClientItemId is null and tar.ClientItemId is not null)
					or (src.ClientItemId is not null and tar.ClientItemId is null)
					or tar.DataSourceId != src.DataSourceId
					or (src.DataSourceId is null and tar.DataSourceId is not null)
					or (src.DataSourceId is not null and tar.DataSourceId is null)
					or tar.Status = 'I')
		    THEN
		   UPDATE SET
					tar.Description = src.Description, 
					tar.ClientItemId = src.ClientItemId,
					tar.DataSourceId = src.DataSourceId,
					tar.DateChanged = getdate(),
					tar.Status = 'A'
  		   WHEN NOT MATCHED THEN
		   INSERT
		   (
				clientid,
				NDC,
				ItemId,
				Description,
				ClientItemId,
				Status,
				DataSourceId
		   )
		   VALUES
		   (
				src.clientid,
				src.NDC,
				src.ItemId,
				src.Description,
				src.ClientItemId,
				'A',
				src.DataSourceId
		   )
		OUTPUT
		   CASE WHEN $action = 'UPDATE' Then 'UPDATED'
				WHEN $action = 'INSERT' Then 'INSERTED'
		        ELSE $action End as ActionType,
			CASE WHEN $action = 'INSERT' then inserted.CustomerItemId else deleted.CustomerItemId end as CustomerItemId,
			CASE WHEN $action = 'INSERT' then inserted.ClientId else deleted.ClientId end as ClientId,
			CASE WHEN $action = 'INSERT' then inserted.ItemId else deleted.ItemId end as ItemId,
			CASE WHEN $action = 'INSERT' then inserted.Ndc else deleted.Ndc end as Ndc,
			CASE WHEN $action = 'INSERT' then inserted.Description else deleted.Description end as Description,
			CASE WHEN $action = 'INSERT' then inserted.ClientItemId else deleted.ClientItemId end as ClientItemId,
			CASE WHEN $action = 'INSERT' then inserted.Status else deleted.Status end as Status,
			CASE WHEN $action = 'INSERT' then inserted.DataSourceId else deleted.DataSourceId end as DataSourceId,
			CASE WHEN $action = 'INSERT' then inserted.DateImported else deleted.DateImported end as DateImported,
			CASE WHEN $action = 'INSERT' then inserted.DateChanged else deleted.DateChanged end as DateChanged	
			) as M; 


--Log data activity
declare @BeginDate datetime
declare @EndData datetime

select @BeginDate = min([TransactionDate]), @EndData = max([TransactionDate])
from [Raw].[Sales]

exec [Integrations].[LogDataFeed] @DataSource, 'CustCat', @BeginDate, @EndData;


END
*/

   