 

CREATE PROCEDURE [dbo].[ROI_Merge_Process] 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

INSERT INTO dbo.roi_history (
    action
    , Ndc
    , ROI_Start_Date
    , ROI_End_Date
    , ROI_Check_Date
    , updated
    )
SELECT m.actiontype
    , m.Ndc
    , m.ROI_Start_Date
    , m.ROI_End_Date
    , m.ROI_Check_Date
    , GETDATE() AS updated
FROM (
    MERGE dbo.ROI_information AS Target
    USING raw.ROI_information AS Source
        ON Source.ndc = Target.ndc
            -- For Inserts
    WHEN NOT MATCHED BY Target
        THEN
            INSERT (
                  Ndc
                , ROI_Check_Date
                , ROI_Start_Date
                , ROI_End_Date
                )
            VALUES (
                Source.Ndc
                , Source.ROI_Check_Date
                , Source.ROI_Start_Date
                , Source.ROI_End_Date
                )
                -- For Updates
    WHEN MATCHED
        AND (
            Target.ROI_Check_Date != Source.ROI_Check_Date
            OR (
                Source.ROI_Check_Date IS NULL
                AND Target.ROI_Check_Date IS NOT NULL
                )
            OR (
                Source.ROI_Check_Date IS NOT NULL
                AND Target.ROI_Check_Date IS NULL
                )
            OR Target.ROI_Start_Date != Source.ROI_Start_Date
            OR (
                Source.ROI_Start_Date IS NULL
                AND Target.ROI_Start_Date IS NOT NULL
                )
            OR (
                Source.ROI_Start_Date IS NOT NULL
                AND Target.ROI_Start_Date IS NULL
                )
            OR Target.ROI_End_Date != Source.ROI_End_Date
            OR (
                Source.ROI_End_Date IS NULL
                AND Target.ROI_End_Date IS NOT NULL
                )
            OR (
                Source.ROI_End_Date IS NOT NULL
                AND Target.ROI_End_Date IS NULL
                )
            )
        THEN
            UPDATE
            SET   Target.ROI_Check_Date = Source.ROI_Check_Date
                , Target.ROI_Start_Date = Source.ROI_Start_Date
                , Target.ROI_End_Date = source.ROI_End_Date
    --WHEN NOT MATCHED BY Source THEN
    --    DELETE
    OUTPUT CASE 
            WHEN $ACTION = 'UPDATE'
                THEN 'UPDATED'
            WHEN $ACTION = 'INSERT'
                THEN 'INSERTED'
            ELSE $ACTION
            END AS ActionType
        , CASE 
            WHEN $ACTION = 'INSERT'
                THEN inserted.Ndc
            ELSE deleted.Ndc
            END AS Ndc
        , CASE 
            WHEN $ACTION = 'INSERT'
                THEN inserted.ROI_Check_Date
            ELSE deleted.ROI_Check_Date
            END AS ROI_Check_Date
        , CASE 
            WHEN $ACTION = 'INSERT'
                THEN inserted.ROI_Start_Date
            ELSE deleted.ROI_Start_Date
            END AS ROI_Start_Date
        , CASE 
            WHEN $ACTION = 'INSERT'
                THEN inserted.ROI_End_Date
            ELSE deleted.ROI_End_Date
            END AS ROI_End_Date
    ) AS m;

END


   