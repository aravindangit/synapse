


select top 100 * from  [Premier].WholesalerInvoices
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Premier].[WholesalerInvoices](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[HealthSystemID] [varchar](50) NULL,
	[FacilityDirectParentID] [varchar](50) NULL,
	[FacilityID] [varchar](50) NULL,
	[FacilityAddress1] [varchar](250) NULL,
	[FacilityAddress2] [varchar](250) NULL,
	[FacilityCity] [varchar](75) NULL,
	[FacilityState] [char](2) NULL,
	[FacilityZipCode] [varchar](50) NULL,
	[NDC] [varchar](11) NULL,
	[ItemId] [int] NULL,
	[BrandName] [varchar](75) NULL,
	[GenericName] [varchar](75) NULL,
	[LabelName] [varchar](75) NULL,
	[WholesalerPurchaseType] [varchar](75) NULL,
	[WholesalerLoadPrice] [money] NULL,
	[Supplier] [varchar](250) NULL,
	[InvoiceDate] [datetime] NULL,
	[InvoiceNumber] [varchar](25) NULL,
	[InvoicePrice] [money] NULL,
	[Wholesaler] [varchar](75) NULL,
	[DistributionCenterName] [varchar](75) NULL,
	[WholesalerAccountNumber] [varchar](25) NULL,
	[WholesalerAccountName] [varchar](75) NULL,
	[LineNumberfromInvoice] [varchar](25) NULL,
	[ContractLeadName] [varchar](75) NULL,
	[ServiceProviderClass] [varchar](75) NULL,
	[ShipMethod] [char](1) NULL,
	[ShippingDate] [datetime] NULL,
	[WholesalerPkgQty] [int] NULL,
	[WholesalerOrderLineNumber] [varchar](25) NULL,
	[WholesalerCatalogNumber] [varchar](25) NULL,
	[UnitofMeasure] [varchar](25) NULL,
	[WholesalerAccountAttribute] [varchar](25) NULL,
	[ChargeBackContractNumber] [varchar](50) NULL,
	[Markup/Markdown] [varchar](25) NULL,
	[PremierAwardStatus] [varchar](25) NULL,
	[PremierContractNumber] [varchar](25) NULL,
	[TotalUnits] [int] NULL,
	[TotalSpend] [money] NULL,
	[QuantityOrdered] [int] NULL,
	[AddedDate] [datetime] NULL,
	[ProcessPipelineId] [varchar](50) NULL,
	[OriginalFileName] [varchar](250) NULL,
	[AdlPath] [varchar](250) NULL,
	[ReasonCodeDesc] [varchar](100) NULL,
	[OrderDate] [datetime] NULL,
	[Source] [varchar](100) NULL,
	[Price Start Date] [varchar](25) NULL,
	[Price End Date] [varchar](25) NULL,
	[Price Pkg] [money] NULL,
	[Program Name] [varchar](100) NULL,
	[Tier Desc] [varchar](100) NULL,
	[Rx Product Pricing Cbid] [varchar](100) NULL
) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [idx_PremierWholesalerInvoices_InvoiceDate] ON [Premier].[WholesalerInvoices]
(
	[InvoiceDate] ASC
)
INCLUDE([HealthSystemID],[FacilityCity],[FacilityState],[NDC],[Supplier],[TotalUnits],[TotalSpend],[QuantityOrdered]) WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
CREATE NONCLUSTERED INDEX [idx_PremierWholesalerInvoices_NDC] ON [Premier].[WholesalerInvoices]
(
	[NDC] ASC
)
INCLUDE([HealthSystemID],[FacilityCity],[FacilityState],[WholesalerLoadPrice],[Supplier],[InvoiceDate],[InvoicePrice],[ShippingDate],[TotalUnits],[QuantityOrdered]) WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
CREATE NONCLUSTERED INDEX [IX_Premier_WholesalerInvoices_HealthSystemID] ON [Premier].[WholesalerInvoices]
(
	[HealthSystemID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
ALTER TABLE [Premier].[WholesalerInvoices] ADD  CONSTRAINT [DF_WholesalerInvoices_AddedDate]  DEFAULT (getdate()) FOR [AddedDate]
GO
