select top 100 * from premier.WholesalerInvoices

select * from customer apr2022

update cus 
set cus.divisionname = bkp.divisionname,
    cus.divisionid = bkp.divisionid
    from dbo.customer cus join dbo.customerapr2022 bkp on cus.AccountNumber = bkp.AccountNumber


    select top 100000 * from dbo.sales where PriceEndDate is not null