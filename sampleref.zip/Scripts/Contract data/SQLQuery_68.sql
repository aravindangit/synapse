SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [Premier].[LoadInvoiceAndPO]  @DatasetInvoice varchar(50), @DatasetPO varchar(50), @PipelineId varchar(50)

--[Premier].[LoadInvoiceAndPO_temp]  'PremierWholesaleInvoice', 'PremierWholesalePO', 'd2e85f2d-5a34-437b-9943-f7329e59fbc1'
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

declare @MinDate datetime = (select min([InvoiceDate]) from [Premier].[WholesalerInvoices])

truncate table [Raw].[Sales]
truncate table [Raw].[PurchaseOrders]


INSERT INTO [Raw].[Sales]
           ([DataSource]
           ,[TransactionDate]
           ,[Ndc]
           ,[ItemDescription]
		   ,[HealthSystemID]
           ,[Account]
		   ,[AccountParent]
           ,[OrderNumber]
           ,[LineNumber]
           ,[OrderType]
           ,[Qty]
		   ,[QtyOrdered]
           ,[UnitCost]
           ,[UnitPrice]
		   ,[UOM]
           ,[InvoiceNumber]
		   ,[Address1]
		   ,[Address2]
		   ,[City]
		   ,[State]
		   ,[ZipCode]
		   ,[Wholesaler]
		   ,[WholesalerAccountAttribute]
		   ,[WholesalerAccountNumber]
		   ,[ChargeBackContractNumber]
		   ,[Markup/Markdown]
           ,[ImportedDate]
           ,[ProcessPipelineId]
           ,[OrderDate]
           ,[ReasonCodeDesc]
           ,[PremierContractNumber]
           ,[Source] 
           , [PriceStartDate] 
           ,[PriceEndDate] 
            ,[PricePkg] 
            ,[Program Name] 
            ,[TierDesc] 
            ,[RxProductPricingCbid] )
(SELECT @DatasetInvoice 'DataSource',
      [InvoiceDate] 'TransactionDate',
      [NDC],
      isnull([BrandName],'n') + ' ' + isnull([GenericName],'n') + ' ' + isnull([LabelName],'n') 'Item Description',
      [HealthSystemID] 'HealthSystemID',
	  [FacilityID] 'Account',  --lookup from customer,
	  [FacilityDirectParentID] 'AccountParent',
      [InvoiceNumber] 'OrderNumber',
      [LineNumberfromInvoice] 'LineNumber',
	  [WholesalerPurchaseType] 'OrderType', --what is this
      [TotalUnits] 'Qty',
	  [QuantityOrdered] 'QtyOrdered',
	  [InvoicePrice] 'UnitCost',
      [InvoicePrice] 'UnitPrice',
	  [UnitofMeasure] 'UOM',
	  [InvoiceNumber] 'InvoiceNumber',
	  [FacilityAddress1] 'Address1',
	  [FacilityAddress2] 'Address2',
	  [FacilityCity] 'City',
	  [FacilityState] 'State',
	  [FacilityZipCode] 'ZipCode',
	  [Wholesaler] 'Wholesaler',
	  coalesce([WholesalerAccountAttribute],'UNK') 'WholesalerAccountAttribute',
	  [WholesalerAccountNumber] 'WholesalerAccountNumber',
	  [ChargeBackContractNumber] 'ChargeBackContractNumber',
	  [Markup/Markdown] 'Markup/Markdown',
	  [AddedDate] 'ImportedDate',
	  @PipelineId,
	  [OrderDate],
	  [ReasonCodeDesc],
	  [PremierContractNumber],
    [Source] 'Source',
	[Price Start Date] 'PriceStartDate',
	[Price End Date] 'PriceEndDate',
	[Price Pkg] 'PricePkg',
	[Program Name] 'Program Name' ,
	[Tier Desc] 'TierDesc',
	[Rx Product Pricing Cbid] 'RxProductPricingCbid'
  FROM [Premier].[WholesalerInvoices] 
  where ndc != '0')


INSERT INTO [Raw].[PurchaseOrders]
           ([DataSource]
           ,[ApprovalDateTime]
           ,[Ndc]
           ,[PurchaseOrderNumber]
           ,[LineNumber]
           ,[PriceList]
           ,[PurchaseOrderStatus]
           ,[LineStatus]
           ,[InvoiceNumber]
		   ,[SupplierId]
           ,[SupplierName]
           ,[ReceivedDateTime]
           ,[UnitPrice]
           ,[ExtendedPrice]
           ,[CurrentQuantityOrdered]
           ,[OriginalQuantityOrdered]
           ,[QuantityReceived]
           ,[QuantityOutstanding]
           ,[QuantityCancelled]
           ,[TotalQuantityBilled]
           ,[ImportedDate]
           ,[ClosedDateTime]
           ,[PipelineId]
           ,[ReportedDate])
(SELECT @DatasetPO 'DataSource',
	  [InvoiceDate] 'ApprovalDateTime',
      [NDC],
	  [InvoiceNumber] 'PurchaseOrderNumber',
	  [LineNumberfromInvoice] 'LineNumber',
	  [WholesalerPurchaseType] 'PriceList',
	  'CLOSED' 'PurchaseOrderStatus',
	  'CLOSED' 'LineStatus',
	  [InvoiceNumber] 'InvoiceNumber',
	  case when Wholesaler = ' ' then 'Not provided' else Wholesaler end 'SupplierId',
	  case when Wholesaler = ' ' then 'Not provided' else Wholesaler end 'SuplierName',
	  [ShippingDate] 'ReceivedDateTime',
	  [InvoicePrice] 'UnitPrice',
	  [TotalSpend] 'ExtendedPrice',
	  [QuantityOrdered] 'CurrentQuantityOrdered',
	  [QuantityOrdered] 'OriginalQuantityOrdered',
	  [TotalUnits] 'QuantityReceived',
	  case when [QuantityOrdered] = 0 and [TotalUnits] < 0 then 0 else [QuantityOrdered] - [TotalUnits] end 'QuantityOutstanding',
	  0 'QuantityCancelled',
	  [TotalUnits] 'TotalQuantityBilled',
	  [AddedDate] 'ImportedDate',
	  [InvoiceDate] 'ClosedDateTime',
	  @PipelineId 'PipelineId',
	  [AddedDate] 'ReportedDate'
  FROM [Premier].[WholesalerInvoices]
    where ndc != '0')

END
GO
