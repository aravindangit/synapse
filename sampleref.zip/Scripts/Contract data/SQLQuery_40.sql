INSERT INTO SyncControl.MemberCustomerSync (
    [Member_Environment]
    , [Member_azure_sql_url]
    , [Member_azure_db]
    , [Member_Tenant]
    , [Member_Service_Principal]
    , [Member_Secret]
    , [Status]
    )
    values('AAH'
    , 'sqlcogrxprodcommonspirit.database.windows.net'
    , 'sqldbCogRxProdAdvocateAurora'
    , 'b110eddf-23ae-457c-a6f3-734d592b2847'
    , '7aee9959-dc91-4e83-b0fc-51e0ff91adbb'
    , 'Secret-Cogrx-Client-Databases'
    , 'A')

    select * from SyncControl.MemberCustomerSync

   update SyncControl.MemberCustomerSync 
   set status = 'I'
   where Member_Environment = 'AAH'
