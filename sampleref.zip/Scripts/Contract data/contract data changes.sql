[Source] string	,
[Price Start Date] string,
[Price End Date] string,
[Price Pkg] string,
[Program Name] string,
[Tier Desc] string,
[Rx Product Pricing Cbid] string


select top 100 * from premier.WholesalerInvoices order by AddedDate desc

s
select top 100  * from premier.WholesalerInvoices

--changing national wholesaler db
alter table premier.WholesalerInvoices
add 
[Source] varchar(100) null	,
[Price Start Date] varchar(25) null,
[Price End Date] varchar(25) null,
[Price Pkg] [money] NULL,
[Program Name] varchar(100) null,
[Tier Desc] varchar(100) null,
[Rx Product Pricing Cbid] varchar(100) null



--changing client db
alter table premier.WholesalerInvoices
add 
[Source] varchar(100) null	,
[Price Start Date] varchar(25) null,
[Price End Date] varchar(25) null,
[Price Pkg] [money] NULL,
[Program Name] varchar(100) null,
[Tier Desc] varchar(100) null,
[Rx Product Pricing Cbid] varchar(100) null



alter table raw.sales
add 
[Source] varchar(100) null	,
[PriceStartDate] [datetime] NULL,
[PriceEndDate] [datetime] NULL,
[PricePkg] [money] NULL,
[Program Name] varchar(100) null,
[TierDesc] varchar(100) null,
[RxProductPricingCbid] varchar(100) null

select top 100 * from dbo.sales
alter table dbo.sales
add 
[Source] varchar(100) null	,
[PriceStartDate] [datetime] NULL,
[PriceEndDate] [datetime] NULL,
[PricePkg] [money] NULL,
[Program Name] varchar(100) null,
[TierDesc] varchar(100) null,
[RxProductPricingCbid] varchar(100) null

-- changing following sp [Premier].[LoadInvoiceAndPO]

--changing following sp [Integrations].[InsertSalesRecordsUsingPremier]
select * from SyncControl.MemberCustomerSync


select * from Predictive.drug_shortage_alerts_detection