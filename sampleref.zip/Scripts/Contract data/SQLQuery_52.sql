SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [Integrations].[MergeWoltersKluwerAspItemPrice] 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from interfering with SELECT statements.
	SET NOCOUNT ON;


declare @iDataSource int = 10;

MERGE [dbo].[AspPriceAndLimits] AS tar
	USING (select p.ndc, 
				   p.ItemId, 
				   m.QuarterDate,
				   m.revisiondate,
				   m.HcpcsCode,
				   m.shortdescription HCPCSDescription,
				   m.HcpcsCodeDosage,
				   cast((m.paymentlimit / 1.06) as decimal(13,6)) AspUnitPrice,
				   m.paymentlimit,
				   m.IndependentEsrdLimit,
				   m.VaccineLimit,
				   m.DMEInfusionLimit,
				   m.BloodLimit,
				   m.PackageSize,
				   m.PackageQuantity,
				   m.BillableUnitsPerPackage,
				   m.BillableUnitsPer11DigitNDC,
				   @iDataSource DataSourceId
			from [rawWK].[pb2mcaf_MediSpanCustomizedFile] m
				inner join [dbo].[PharmacyItem] p
					on m.MediSpanDrugIdentifier = p.Ndc) AS src
	ON tar.NDC = src.NDC
   and tar.HcpcsCode = src.HcpcsCode
   and tar.QuarterDate = src.QuarterDate
   --and tar.RevisionDate = src.RevisionDate
	WHEN MATCHED 
			AND (tar.ItemId != src.ItemId
			 or (src.ItemId is null and tar.ItemId is not null)
		 	 or (src.ItemId is not null and tar.ItemId is null)
			 or tar.RevisionDate != src.RevisionDate
			 or (src.RevisionDate is null and tar.RevisionDate is not null)
			 or (src.RevisionDate is not null and tar.RevisionDate is null)
			 or tar.HCPCSDescription != src.HCPCSDescription
			 or (src.HCPCSDescription is null and tar.HCPCSDescription is not null)
			 or (src.HCPCSDescription is not null and tar.HCPCSDescription is null)
			 or tar.HcpcsCodeDosage != src.HcpcsCodeDosage
			 or (src.HcpcsCodeDosage is null and tar.HcpcsCodeDosage is not null)
			 or (src.HcpcsCodeDosage is not null and tar.HcpcsCodeDosage is null)
			 or tar.AspUnitPrice != src.AspUnitPrice
			 or (src.AspUnitPrice is null and tar.AspUnitPrice is not null)
			 or (src.AspUnitPrice is not null and tar.AspUnitPrice is null)
			 or tar.paymentlimit != src.paymentlimit
			 or (src.paymentlimit is null and tar.paymentlimit is not null)
			 or (src.paymentlimit is not null and tar.paymentlimit is null)
			 or tar.IndependentEsrdLimit != src.IndependentEsrdLimit
			 or (src.IndependentEsrdLimit is null and tar.IndependentEsrdLimit is not null)
			 or (src.IndependentEsrdLimit is not null and tar.IndependentEsrdLimit is null)
			 or tar.VaccineLimit != src.VaccineLimit
			 or (src.VaccineLimit is null and tar.VaccineLimit is not null)
			 or (src.VaccineLimit is not null and tar.VaccineLimit is null)
			 or tar.DMEInfusionLimit != src.DMEInfusionLimit
			 or (src.DMEInfusionLimit is null and tar.DMEInfusionLimit is not null)
			 or (src.DMEInfusionLimit is not null and tar.DMEInfusionLimit is null)
			 or tar.BloodLimit != src.BloodLimit
			 or (src.BloodLimit is null and tar.BloodLimit is not null)
			 or (src.BloodLimit is not null and tar.BloodLimit is null)
			 or tar.PackageSize != src.PackageSize
			 or (src.PackageSize is null and tar.PackageSize is not null)
			 or (src.PackageSize is not null and tar.PackageSize is null)
			 or tar.PackageQuantity != src.PackageQuantity
			 or (src.PackageQuantity is null and tar.PackageQuantity is not null)
			 or (src.PackageQuantity is not null and tar.PackageQuantity is null)
			 or tar.BillableUnitsPerPackage != src.BillableUnitsPerPackage
			 or (src.BillableUnitsPerPackage is null and tar.BillableUnitsPerPackage is not null)
			 or (src.BillableUnitsPerPackage is not null and tar.BillableUnitsPerPackage is null)
			 or tar.BillableUnitsPer11DigitNDC != src.BillableUnitsPer11DigitNDC
			 or (src.BillableUnitsPer11DigitNDC is null and tar.BillableUnitsPer11DigitNDC is not null)
			 or (src.BillableUnitsPer11DigitNDC is not null and tar.BillableUnitsPer11DigitNDC is null)
			 or tar.DataSourceId != src.DataSourceId)
		THEN
		UPDATE SET
			tar.ItemId = src.ItemId,
			tar.HCPCSDescription = src.HCPCSDescription,
			tar.HcpcsCodeDosage = src.HcpcsCodeDosage,
			tar.AspUnitPrice = src.AspUnitPrice,
			tar.paymentlimit = src.paymentlimit,
			tar.IndependentEsrdLimit = src.IndependentEsrdLimit,
			tar.VaccineLimit = src.VaccineLimit,
			tar.DMEInfusionLimit = src.DMEInfusionLimit,
			tar.BloodLimit = src.BloodLimit,
			tar.PackageSize = src.PackageSize,
			tar.PackageQuantity = src.PackageQuantity,
			tar.BillableUnitsPerPackage = src.BillableUnitsPerPackage,
			tar.BillableUnitsPer11DigitNDC = src.BillableUnitsPer11DigitNDC,
			tar.DataSourceId = src.DataSourceId,
			tar.DateChanged = getdate()
	WHEN NOT MATCHED THEN
		INSERT
		(  ndc, 
		   ItemId, 
		   QuarterDate,
		   revisiondate,
		   HcpcsCode,
		   HCPCSDescription,
		   HcpcsCodeDosage,
		   AspUnitPrice,
		   paymentlimit,
		   IndependentEsrdLimit,
		   VaccineLimit,
		   DMEInfusionLimit,
		   BloodLimit,
		   PackageSize,
		   PackageQuantity,
		   BillableUnitsPerPackage,
		   BillableUnitsPer11DigitNDC,
		   DataSourceId
		)
		VALUES
		(  src.ndc, 
		   src.ItemId, 
		   src.QuarterDate,
		   src.revisiondate,
		   src.HcpcsCode,
		   src.HCPCSDescription,
		   src.HcpcsCodeDosage,
		   src.AspUnitPrice,
		   src.paymentlimit,
		   src.IndependentEsrdLimit,
		   src.VaccineLimit,
		   src.DMEInfusionLimit,
		   src.BloodLimit,
		   src.PackageSize,
		   src.PackageQuantity,
		   src.BillableUnitsPerPackage,
		   src.BillableUnitsPer11DigitNDC,
		   src.DataSourceId
		);


update [AspPriceAndLimits]
	set IsCurrentRecords = 0,
	    DateChanged = getdate()
where IsCurrentRecords = 1;


update ap
	set ap.IsCurrentRecords = 1,
	    ap.DateChanged = getdate()
from [AspPriceAndLimits] ap
	inner join (select ndc, HcpcsCode, max(QuarterDate) MaxQrtDate
				from [AspPriceAndLimits]
				group by ndc, HcpcsCode) m
	on ap.ndc = m.ndc
   and ap.HcpcsCode = m.HcpcsCode
   and ap.QuarterDate = m.MaxQrtDate;


With LatestNotesCte as (
select HcpcsCode,QuarterDate, notes from  (
    SELECT hcpcscode
        , quarterdate
        , notes AS notes
        , ROW_NUMBER() OVER(partition by hcpcscode,quarterdate order by revisiondate desc) as rownum
    FROM [rawWK].[pb2lmn_PaymentAllowanceLimitNotesFile]) AS A WHERE A.ROWNUM = 1)
update apl
set apl.HcpcsNotes = bpl.notes 
FROM dbo.AspPriceAndLimits apl
JOIN LatestNotesCte bpl
    ON apl.HcpcsCode = bpl.HcpcsCode
        AND apl.QuarterDate = bpl.QuarterDate;

update [dbo].[AspPriceAndLimits]
set aspunitprice = cast((paymentlimit / 1.08) as decimal(13,6)), 
isbiosimilar = 1
where HcpcsNotes = '8% of reference add-on applied';


--Log data activity
declare @BeginDate datetime
declare @EndData datetime
declare @PipelineRunId varchar(50)

exec [Integrations].[LogDataFeed] 'WoltersKluwerASPItemPrice', 'WoltersKluwerFeed', @BeginDate, @EndData, @PipelineRunId;

END
GO
