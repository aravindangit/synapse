--create table [#tempMemberCustomerSync] (
--[Member_Environment] [varchar] (250) NULL,
--[Member_azure_sql_url] [varchar] (250) NULL,
--[Member_azure_db] [varchar] (50) NULL,
--[Member_Tenant] [varchar] (50) NULL,
--[Member_Service_Principal] [varchar] (250) NULL,
--[Member_Secret] [varchar] (50) NULL,
--[Status] [char] (1) NULL);


insert into [SyncControl.tempMemberCustomerSync] ([Member_Environment],[Member_azure_sql_url],[Member_azure_db],[Member_Tenant],[Member_Service_Principal],[Member_Secret],[Status])
select 'AAH','sqlcogrxprodcommonspirit.database.windows.net','sqldbCogRxProdAdvocateAurora','b110eddf-23ae-457c-a6f3-734d592b2847','7aee9959-dc91-4e83-b0fc-51e0ff91adbb','Secret-Cogrx-Client-Databases','A' 