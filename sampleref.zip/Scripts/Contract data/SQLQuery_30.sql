SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO





-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
ALTER PROCEDURE [Premier].[ArchiveWholesalerInvoices] @MinInvoiceDate datetime
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

/*insert into [Premier].[WholesalerInvoicesArchive]
([HealthSystemID]
      ,[FacilityDirectParentID]
      ,[FacilityID]
      ,[FacilityAddress1]
      ,[FacilityAddress2]
      ,[FacilityCity]
      ,[FacilityState]
      ,[FacilityZipCode]
      ,[NDC]
      ,[ItemId]
      ,[BrandName]
      ,[GenericName]
      ,[LabelName]
      ,[WholesalerPurchaseType]
      ,[WholesalerLoadPrice]
      ,[Supplier]
      ,[InvoiceDate]
      ,[InvoiceNumber]
      ,[InvoicePrice]
      ,[Wholesaler]
      ,[DistributionCenterName]
      ,[WholesalerAccountNumber]
      ,[WholesalerAccountName]
      ,[LineNumberfromInvoice]
      ,[ContractLeadName]
      ,[ServiceProviderClass]
      ,[ShipMethod]
      ,[ShippingDate]
      ,[WholesalerPkgQty]
      ,[WholesalerOrderLineNumber]
      ,[WholesalerCatalogNumber]
      ,[UnitofMeasure]
      ,[WholesalerAccountAttribute]
      ,[ChargeBackContractNumber]
      ,[Markup/Markdown]
      ,[PremierAwardStatus]
      ,[PremierContractNumber]
      ,[TotalUnits]
      ,[TotalSpend]
      ,[QuantityOrdered]
      ,[AddedDate]
      ,[ProcessPipelineId]
      ,[OriginalFileName]
      ,[AdlPath]
      ,[ReasonCodeDesc]
      ,[OrderDate])
select [HealthSystemID]
      ,[FacilityDirectParentID]
      ,[FacilityID]
      ,[FacilityAddress1]
      ,[FacilityAddress2]
      ,[FacilityCity]
      ,[FacilityState]
      ,[FacilityZipCode]
      ,[NDC]
      ,[ItemId]
      ,[BrandName]
      ,[GenericName]
      ,[LabelName]
      ,[WholesalerPurchaseType]
      ,[WholesalerLoadPrice]
      ,[Supplier]
      ,[InvoiceDate]
      ,[InvoiceNumber]
      ,[InvoicePrice]
      ,[Wholesaler]
      ,[DistributionCenterName]
      ,[WholesalerAccountNumber]
      ,[WholesalerAccountName]
      ,[LineNumberfromInvoice]
      ,[ContractLeadName]
      ,[ServiceProviderClass]
      ,[ShipMethod]
      ,[ShippingDate]
      ,[WholesalerPkgQty]
      ,[WholesalerOrderLineNumber]
      ,[WholesalerCatalogNumber]
      ,[UnitofMeasure]
      ,[WholesalerAccountAttribute]
      ,[ChargeBackContractNumber]
      ,[Markup/Markdown]
      ,[PremierAwardStatus]
      ,[PremierContractNumber]
      ,[TotalUnits]
      ,[TotalSpend]
      ,[QuantityOrdered]
      ,[AddedDate]
      ,[ProcessPipelineId]
      ,[OriginalFileName]
      ,[AdlPath]
      ,[ReasonCodeDesc]
      ,[OrderDate]
from [Premier].[WholesalerInvoices]
where [InvoiceDate] < @MinInvoiceDate*/


truncate table [Premier].[WholesalerInvoices]

END
GO
