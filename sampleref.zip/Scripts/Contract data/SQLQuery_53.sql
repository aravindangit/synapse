SELECT TOP (1000) [Member_Environment]
      ,[Member_azure_sql_url]
      ,[Member_azure_db]
      ,[Member_Tenant]
      ,[Member_Service_Principal]
      ,[Member_Secret]
      ,[Status]
  FROM [SyncControl].[MemberCustomerSync]

  select * from SyncControl.PremierCustomerSyncNewSp