

select * from dbo.roi_tracking