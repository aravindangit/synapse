SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

create PROCEDURE [DailyMaintinance].[UpdatingRoiActualQty]
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;
-- updating quantity

-- updating quantity
    WITH Ndcwithenddate
    AS (
        SELECT NDC
            , ROI_Start_Date
            , Roi_end_date
        FROM dbo.ROI_information i
        WHERE i.roi_end_date IS NOT NULL
        )
        , RoiSales
    AS (
        SELECT sum(qty) AS ActualQuanitycalculated
           -- , sum(qty * UnitCost) AS dollarvalue
            , sa.ndc
            , sa.clientid
        FROM dbo.sales AS sa
        JOIN Ndcwithenddate AS ra
            ON sa.ndc = ra.ndc
        WHERE sa.transactiondate >= ra.ROI_Start_Date
            AND sa.transactiondate <= ra.ROI_end_Date
        GROUP BY sa.ndc
            , sa.clientid
        )
    UPDATE track
    SET track.Actual_Quantity = s.ActualQuanitycalculated
     --   track.Status = 'Pending ROI',
      --  track.Actual_Percentage_Increase = s.Actual_Percentage_Increase
    FROM dbo.ROI_tracking track
    JOIN RoiSales s
        ON track.ndc = s.ndc
            AND track.clientid = s.clientid;

-- updating status, Actual percentage increase and ROI end date

WITH Ndcwithenddate
    AS (
        SELECT NDC
            , ROI_Start_Date
            , Roi_end_date
            , Actual_Percentage_Increase
        FROM dbo.ROI_information i
        WHERE i.roi_end_date IS NOT NULL
        )
    UPDATE r
    SET r.Status = 'Pending',
        r.Actual_Percentage_Increase = s.Actual_Percentage_Increase,
        r.ROI_End_Date  = s.ROI_End_Date
    FROM dbo.ROI_tracking r
    JOIN Ndcwithenddate s
        ON r.ndc = s.ndc;
           -- AND r.clientid = s.clientid;

  --resetting the buyins status

  WITH Ndcwithenddatestatus
    AS (
        SELECT NDC
        FROM dbo.ROI_tracking i
        WHERE i.status = 'Pending'
        )
    UPDATE r
    SET status = 'Not Reviewed'
    FROM app.BuyInResolved r
    JOIN Ndcwithenddatestatus s
        ON r.ndc = s.ndc;

  --updating the status to complete for dropped prediction

  WITH droppedprediction
    AS (
        SELECT NDC
        FROM dbo.roi_dropped_prediction i
        )
    UPDATE r
    SET status = 'Completed', Actual_ROI = 0
    FROM dbo.ROI_Tracking r
    JOIN droppedprediction s
        ON r.ndc = s.ndc
    where r.[Status] = 'In Process';
        
END
GO
