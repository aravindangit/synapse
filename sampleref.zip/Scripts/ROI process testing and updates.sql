--select * from raw.roi_information ri 
-- updating quantity
    WITH Ndcwithenddate
    AS (
        SELECT NDC
            , ROI_Start_Date
            , Roi_end_date
        FROM dbo.ROI_information i
        WHERE i.roi_end_date IS NOT NULL
        )
        , RoiSales
    AS (
        SELECT sum(qty) AS ActualQuanitycalculated
           -- , sum(qty * UnitCost) AS dollarvalue
            , sa.ndc
            , sa.clientid
        FROM dbo.sales AS sa
        JOIN Ndcwithenddate AS ra
            ON sa.ndc = ra.ndc
        WHERE sa.transactiondate >= ra.ROI_Start_Date
            AND sa.transactiondate <= ra.ROI_end_Date
        GROUP BY sa.ndc
            , sa.clientid
        )
    UPDATE track
    SET track.Actual_Quantity = s.ActualQuanitycalculated
     --   track.Status = 'Pending ROI',
      --  track.Actual_Percentage_Increase = s.Actual_Percentage_Increase
    FROM dbo.ROI_tracking track
    JOIN RoiSales s
        ON track.ndc = s.ndc
            AND track.clientid = s.clientid;

-- updating status

WITH Ndcwithenddate
    AS (
        SELECT NDC
            , ROI_Start_Date
            , Roi_end_date
            , Actual_Percentage_Increase
        FROM dbo.ROI_information i
        WHERE i.roi_end_date IS NOT NULL
        )
    UPDATE r
    SET r.Status = 'Pending ROI',
        r.Actual_Percentage_Increase = s.Actual_Percentage_Increase
    FROM dbo.ROI_tracking r
    JOIN Ndcwithenddate s
        ON r.ndc = s.ndc
           -- AND r.clientid = s.clientid;

select * from dbo.ROI_Tracking rt 



update

select * from dbo.ROI_Information ri 

update dbo.ROI_Information 
set Actual_Percentage_Increase =  0.019998839476957242,
    ROI_End_Date = GETDATE() 
where ndc in (
'15370025030',
'68727074505',
'70720095036',
'59310061031'
)



select * from dbo.ROI_Information ri 
where ri.ndc in (
'64764030020',
'63833038602',
'64764030020',
'64764030020',
'00006302604',
'66887000301',
'64764030020',
'63833038702',
'63833038602',
'63833038702',
'63833038602',
'63833038702',
'63833038702',
'63833038602',
'13533080024',
'63833038702',
'63833038602',
'59310061031',
'63833038702',
'63833061702',
'63833038602',
'63833038602',
'13533080024',
'63833038602',
'64764030020',
'66887000301',
'63833038602',
'66887000301',
'63833038602',
'13533080024',
'00517065001',
'64764030020',
'63833038702',
'63833038602',
'68727074505',
'64764030020',
'63833038702',
'49230064551',
'00006302602',
'63833038702',
'59310061031',
'64764030020',
'64764030020',
'64764030020',
'70720095036',
'00006302602',
'13533080071',
'63833038602',
'13533080071',
'63833038602',
'00517065001',
'63833061602',
'68025004430',
'59310061031',
'63833061702',
'63833038602',
'13533080020',
'13533080071',
'63833038602',
'13533080024',
'63833038602',
'68025005930',
'15370025030',
'59310061031',
'68025006530',
'13533080020',
'68982085004',
'00006302602',
'00006302604',
'00006302604',
'00006302602',
'59310061031',
'13533080024',
'13533080071',
'68025006730',
'46287002004',
'13533080012',
'13533080024',
'13533080020',
'13533080020',
'13533080071',
'68025006630',
'13533080020',
'68982085002',
'00517065001',
'13533080024',
'13533080012',
'68025006530',
'15370025030',
'13533080071',
'63833061502',
'68025006630'
)

