/* These queries are used to generate the CogRx National Shortages Top 20 GPI by Unit */

-- currently manually run. select each query seperately, run, and copy results into the exel template.

/* This is the main export for top 20 GPI by units */

--start by grabbing the summary
with top20 as (
    select top 20 GpiName from [NationalPriceDisruptions].[ResultsGpi]  order by MissingUnits desc
        ),
        NdcsOrderQty as (select Ndc, sum(TotalUnits) NdcsFilled, sum(QuantityOrdered) NdcsOrdered from NationalPriceDisruptions.RawInvoices ri join top20 on top20.GpiName = ri.GpiName group by Ndc )
-- get the GPI and NDC data
select 
         Gpi.GpiName
        --,Gpi.HealthSystemId
        ,Gpi.Gpi10
        ,Gpi.Inc_Days GpiLines  
        ,Gpi.MissingDollars GpiMissingDollars --spend impact
        ,Gpi.MissingUnits GpiMissingUnits   --missing units
        ,Gpi.HsCount GpiHealthSystemsAffected -- systems affected
        --,Gpi.HsMax GpiHsMax   --todo: determine what this actually is
        --,Gpi.IncPerDay GpiIncPerDay
        --,Gpi.IncPerDay_NoTop 
        --,Gpi.Spread
        ,Gpi.Filled GpiFilledUnits
        --,Gpi.ContractCount
        --,Gpi.GeneratedDate
        --,Gpi.SyncDate
       --,Ndc.*
        ,Ndc.Ndc
        ,Ndc.DrugStrength
        ,Ndc.Inc_Days   NdcLines
	    ,Ndc.MissingDollars NdcMissingDollars
        --,NdcsOrderQty.NdcsOrdered 'NdcOrderedUnits'
        ,NdcsOrderQty.NdcsFilled 'NdcFilledUnits'
	    ,Ndc.MissingUnits NdcMissingUnits
	    ,Ndc.HsCount NdcHealthSystemsAffected
	    ,pi.Manufacturer Supplier
	    ,pi.ItemDescription
	    ,nat.WacPackagePrice as 'WacPrice'
        ,Ndc.AvgPrice AvgInvoicePrice
        
  FROM [NationalPriceDisruptions].[ResultsGpi] Gpi
    join top20 t on t.GpiName = Gpi.GpiName
    join NationalPriceDisruptions.ResultsNdc Ndc on Gpi.GpiName= Ndc.GpiName
    JOIN dbo.PharmacyItem pi ON Ndc.Ndc = pi.Ndc
    JOIN dbo.NationalPharmacyItemPriceCurrent nat ON Ndc.Ndc = nat.Ndc
    join NdcsOrderQty NdcsOrderQty on NdcsOrderQty.Ndc = Ndc.Ndc
  
 order by Gpi.MissingUnits desc;
  --order by Gpi.Inc_Days desc;

/* This is the state sheet for the top 20 export */

--given the top 20 drugs, what's the state information for each of them?
--per Kelly: Thanks. Let�s leave what you provided exactly how it is, and create a separate export with just 3 columns: GpiName, State, and State Invoice Lines (ie Propofol, NY, 1072). 
-- So 20 problem drugs x 50 states = 1000 rows.

with top20 as (
    select top 20 GpiName from [NationalPriceDisruptions].[ResultsGpi]  order by MissingUnits desc
    )
--select top 10 * from NationalPriceDisruption

   SELECT  t.GpiName
        ,states.FacilityState
		,SUM(states.Inc_Days) as Lines
		,SUM(states.MissingUnits) as MissingUnits
		,SUM(states.MissingDollars) as MissingDollars
		--,ROW_NUMBER() OVER(ORDER BY SUM(states.Inc_Days) DESC) as rownumber
	FROM NationalPriceDisruptions.[IncidentsGpiMfr] states
    join top20 t on t.GpiName = states.GpiName
	--WHERE GpiName = 'Pantoprazole Sodium'
	GROUP BY t.GpiName, states.FacilityState
    ORDER BY t.GpiName, states.FacilityState
    --SUM(states.Inc_Days) DESC
    
    
    -----tweaking sql------------------------------------------------------------------------------

    with top20 as (
    select top 20 GpiName from [NationalPriceDisruptions].[ResultsGpi]  order by MissingUnits desc
        ),
        NdcsOrderQty as (select Ndc, sum(TotalUnits) NdcsFilled, sum(QuantityOrdered) NdcsOrdered from NationalPriceDisruptions.RawInvoices ri join top20 on top20.GpiName = ri.GpiName group by Ndc )
-- get the GPI and NDC data
select 
         Gpi.GpiName
        --,Gpi.HealthSystemId
        ,Gpi.Gpi10
        ,Gpi.Inc_Days GpiLines  
        ,Gpi.MissingDollars GpiMissingDollars --spend impact
        ,Gpi.MissingUnits GpiMissingUnits   --missing units
        ,Gpi.HsCount GpiHealthSystemsAffected -- systems affected
        --,Gpi.HsMax GpiHsMax   --todo: determine what this actually is
        --,Gpi.IncPerDay GpiIncPerDay
        --,Gpi.IncPerDay_NoTop 
        --,Gpi.Spread
        ,Gpi.Filled GpiFilledUnits
        --,Gpi.ContractCount
        --,Gpi.GeneratedDate
        --,Gpi.SyncDate
       --,Ndc.*
        ,Ndc.Ndc
        ,Ndc.DrugStrength
        ,Ndc.Inc_Days   NdcLines
	    ,Ndc.MissingDollars NdcMissingDollars
        --,NdcsOrderQty.NdcsOrdered 'NdcOrderedUnits'
        ,NdcsOrderQty.NdcsFilled 'NdcFilledUnits'
	    ,Ndc.MissingUnits NdcMissingUnits
	    ,Ndc.HsCount NdcHealthSystemsAffected
	    ,pi.Manufacturer Supplier
	    ,pi.ItemDescription
	    ,nat.WacPackagePrice as 'WacPrice'
        ,Ndc.AvgPrice AvgInvoicePrice
        
  FROM [NationalPriceDisruptions].[ResultsGpi] Gpi
    join top20 t on t.GpiName = Gpi.GpiName
    join NationalPriceDisruptions.ResultsNdc Ndc on Gpi.GpiName= Ndc.GpiName
    JOIN dbo.PharmacyItem pi ON Ndc.Ndc = pi.Ndc
    JOIN dbo.NationalPharmacyItemPriceCurrent nat ON Ndc.Ndc = nat.Ndc
   join NdcsOrderQty NdcsOrderQty on NdcsOrderQty.Ndc = Ndc.Ndc
    where Gpi.GpiName = 'Pantoprazole Sodium'
  
 order by Gpi.MissingUnits desc;
  --order by Gpi.Inc_Days desc;
    -----tweaking sql------------------------------------------------------------------------------------


select top 10 * from dbo.NdcsOrderQty

select
	GpiName,
	sum(TotalUnits) NdcsFilled,
	sum(QuantityOrdered) NdcsOrdered
from
	NationalPriceDisruptions.RawInvoices ri
	where ri.GpiName in (select top 20 GpiName from [NationalPriceDisruptions].[ResultsGpi]  order by MissingUnits desc)
--join top20 on-
--	top20.GpiName = ri.GpiName
group by
	GpiName
	
	select count(*) from dbo.PharmacyItem 
    select count(*) from dbo.NationalPharmacyItemPriceCurrent
    
  select  ndc  from NationalPriceDisruptions.RawInvoices where GpiName = 'Pantoprazole Sodium' group by ndc