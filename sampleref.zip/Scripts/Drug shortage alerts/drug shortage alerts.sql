

declare @Rawlatestdate datetime = (select max([Date_Scored]) from [raw].[Drug_shortage_alerts])
select @Rawlatestdate

declare @dbolatestdate datetime = (select min([Date_Scored]) from [dbo].[Drug_shortage_alerts])
select @dbolatestdate

IF @Rawlatestdate > @dbolatestdate
    BEGIN
        INSERT INTO History.Drug_shortage_alerts_History
                (
                    DrugName ,
                    [Route] ,
                    ShortageSource,
                    [Rank] ,
                    Date_Scored ,
                    isInjectable,
                    Last_updated
                )
                SELECT DrugName
                    , [Route]
                    , ShortageSource
                    , [Rank]
                    , Date_Scored
                    , isInjectable
                    , GETDATE()
                FROM dbo.Drug_shortage_alerts;

                TRUNCATE table dbo.Drug_shortage_alerts;

                INSERT INTO dbo.Drug_shortage_alerts
                (
                    DrugName ,
                    [Route] ,
                    ShortageSource,
                    [Rank] ,
                    Date_Scored ,
                    isInjectable,
                    Last_updated
                )
                SELECT DrugName
                    , [Route]
                    , ShortageSource
                    , rank_isInjectable_incrInjNS_byRoute as [Rank]
                    , Date_Scored
                    , isInjectable
                    , GETDATE()
                FROM raw.Drug_shortage_alerts;

                UPDATE dbo.Drug_shortage_alerts
                SET ShortageSource = 'Premier Alert'
                WHERE ShortageSource = 'None';
    END

    
   
END




CREATE PROCEDURE dbo.Drug_shortage_alerts_Merge_Process
AS
BEGIN


INSERT INTO History.Drug_shortage_alerts_History
(
    DrugName ,
	[Route] ,
	ShortageSource,
	[Rank] ,
	Date_Scored ,
    isInjectable,
    Last_updated
)
SELECT DrugName
    , [Route]
    , ShortageSource
    , [Rank]
    , Date_Scored
    , isInjectable
    , GETDATE()
FROM dbo.Drug_shortage_alerts;

truncate table dbo.Drug_shortage_alerts;

INSERT INTO dbo.Drug_shortage_alerts
(
    DrugName ,
	[Route] ,
	ShortageSource,
	[Rank] ,
	Date_Scored ,
    isInjectable,
    Last_updated
)
SELECT DrugName
    , [Route]
    , ShortageSource
    , rank_isInjectable_incrInjNS_byRoute as [Rank]
    , Date_Scored
    , isInjectable
    , GETDATE()
FROM raw.Drug_shortage_alerts;

UPDATE dbo.Drug_shortage_alerts
SET ShortageSource = 'Premier Alert'
WHERE ShortageSource = 'None';
    
   
END