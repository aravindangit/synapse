
declare @clientid int = (select clientid from [ImportFileIDMapping] where [ClientImportCode] = @DataSource);


select DataSourceId from [ImportFileIDMapping] where [ClientImportCode] = 'GPO'


SELECT * FROM [ImportFileIDMapping]

Drop table if exists #temp_Premier_Pricing;


select min([InvoiceDate]) from [Premier].[WholesalerInvoices]

select * from dbo.PurchaseOrder po 

select * from dbo.DataFeedLog dfl 

select * 

from [Raw].sales s
					inner join [dbo].[ImportFileIDMapping] ifm
     on s.[DataSource] = ifm.[ClientImportCode]
     
     
     
     
     
     
     
     