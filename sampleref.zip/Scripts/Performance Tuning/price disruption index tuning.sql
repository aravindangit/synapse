CREATE PROCEDURE NationalPriceDisruptions.RawDisableIndex
AS
BEGIN
     --Disabling the index while loading wholesaler data to the app databases
	SET NOCOUNT ON;
	
	ALTER INDEX ALL ON [NationalPriceDisruptions].[RawInvoices] DISABLE;

END

CREATE PROCEDURE NationalPriceDisruptions.RawRebuildIndex
AS
BEGIN
     --Disabling the index while loading wholesaler data to the app databases
	SET NOCOUNT ON;
	
	ALTER INDEX ALL ON [NationalPriceDisruptions].[RawInvoices] REBUILD;

END