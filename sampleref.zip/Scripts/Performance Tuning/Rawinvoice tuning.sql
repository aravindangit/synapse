select * into PriceDisruptions.PerfRawInvoices from PriceDisruptions.RawInvoices ri 

--creating index for perfrawinvoices

 CREATE NONCLUSTERED INDEX idx_PerfrawInvoices_NDC ON PriceDisruptions.PerfRawInvoices (  Ndc ASC  )  
	 INCLUDE ( HealthSystemId , IsGenericDrug , PricingKey ) 
	 WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
	 ON [PRIMARY ] 
	 
--disabling INDEX 
ALTER INDEX idx_PerfrawInvoices_NDC
ON PriceDisruptions.PerfRawInvoices
DISABLE;


--checking indexes
select * from sys.indexes
where object_id = (select object_id from sys.objects where name = 'PerfRawInvoices')

--deleting data for fresh load
DELETE [PriceDisruptions].[PerfRawInvoices];

--tuncating the table

select top 100 * from PriceDisruptions.PerfRawInvoices pri 

select top 100 * from PriceDisruptions.RawInvoices pri 

truncate table [PriceDisruptions].[PerfRawInvoices];


--rebuild indeex
ALTER INDEX idx_PerfrawInvoices_NDC
ON PriceDisruptions.PerfRawInvoices
REBUILD;


DECLARE @StartDate datetime, @EndDate datetime

SET @StartDate = getdate()

CREATE SCHEMA Performance;

 
insert into [PriceDisruptions].[PerfRawInvoices]
           ([Ndc]
           ,[QuantityOrdered]
           ,[InvoicePrice]
           ,[TotalSpend]
           ,[TotalUnits]
           ,[ContractNumber]
           ,[HealthSystemId]
           ,[FacilityState]
           ,[FMonth]
           ,[Manufacturer]
           ,[DrugName]
           ,[PricingKey]
           ,[IsGenericDrug]
           ,[DrugStrength]
           ,[DrugId]
           ,[Wac]
           ,[GpiName]
           ,[InvoiceDateString]
           ,[D_Wholesaler]
           ,[DaysAgo]
           ,[PotentialSpend]
           ,[FillRate]
           ,[MissingDollars]
           ,[MissingUnits]
           ,[Equ_MaxWac]
           ,[AvgPrice])
SELECT
       i.[Ndc]
      ,i.[QuantityOrdered]
      ,i.[InvoicePrice]
      ,i.[TotalSpend]
      ,i.[TotalUnits]
      ,i.[ContractNumber]
      ,i.[HealthSystemId]
      ,i.[FacilityState]
      ,i.[FMonth]
      ,i.[Manufacturer]
      ,i.[DrugName]
      ,i.[PricingKey]
      ,i.[IsGenericDrug]
      ,i.[DrugStrength]
      ,i.[DrugId]
      ,i.[Wac]
      ,i.[GpiName]
      ,i.[InvoiceDateString]
      ,i.[D_Wholesaler]
      ,i.[DaysAgo]
	, i.quantityordered * i.invoiceprice as PotentialSpend
	, CASE WHEN quantityordered != 0 THEN CAST(i.totalunits AS DECIMAL(8,2))/CAST(quantityordered AS DECIMAL(8,2)) ELSE CAST(0 AS DECIMAL(8,2)) END AS FillRate
	, (i.quantityordered * i.invoiceprice) - i.TotalSpend AS MissingDollars
	, i.quantityordered - i.totalunits AS MissingUnits
	, pk.equ_maxwac
	, ap.avgprice
FROM [PriceDisruptions].[Transform] i
	LEFT JOIN [PriceDisruptions].[AvgPrices] ap 
		ON i.ndc = ap.ndc
	LEFT JOIN [PriceDisruptions].[WacPricekey] pk 
		ON i.pricingkey = pk.pricingkey 
	   AND i.isgenericdrug = pk.isgenericdrug;



 

--SET @EndDate = getdate()

 

--SELECT datediff(ms,@StartDate, @EndDate) AS 'Milliseconds'