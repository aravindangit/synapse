 CREATE NONCLUSTERED INDEX IX_FILLRATE ON PriceDisruptions.PerfRawInvoices (  GpiName ASC  )  
	 INCLUDE ( InvoiceDateString , QuantityOrdered , TotalUnits ) 
	 WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
	 ON [PRIMARY ] 

 CREATE NONCLUSTERED INDEX IX_FILL_DS ON PriceDisruptions.PerfRawInvoices (  DrugStrength ASC  , GpiName ASC  )  
	 INCLUDE ( InvoiceDateString , QuantityOrdered , TotalUnits ) 
	 WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
	 ON [PRIMARY ] 

 CREATE NONCLUSTERED INDEX IX_FILL_MFR ON PriceDisruptions.PerfRawInvoices (  Manufacturer ASC  , GpiName ASC  )  
	 INCLUDE ( InvoiceDateString , QuantityOrdered , TotalUnits ) 
	 WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
	 ON [PRIMARY ] 

 CREATE NONCLUSTERED INDEX IX_FILL_STATE ON PriceDisruptions.PerfRawInvoices (  FacilityState ASC  , GpiName ASC  )  
	 INCLUDE ( InvoiceDateString , Manufacturer , QuantityOrdered , TotalUnits ) 
	 WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
	 ON [PRIMARY ] 

 CREATE NONCLUSTERED INDEX idx_RawInvoices_NDC ON PriceDisruptions.PerfRawInvoices (  Ndc ASC  )  
	 INCLUDE ( HealthSystemId , IsGenericDrug , PricingKey ) 
	 WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
	 ON [PRIMARY ] 
	 
	
ALTER INDEX ALL ON PriceDisruptions.PerfRawInvoices
DISABLE;

--checking indexes
select * from sys.indexes
where object_id = (select top 1 object_id from sys.objects where name = 'sales')


select * from sys.indexes
where object_id = (select top 1 object_id from sys.objects where name = 'PURCHASEORDER')


PK_PurchaseOrders

ALTER index PK_PurchaseOrders ON [dbo].[PURCHASEORDER] REBUILD;

select * from sys.objects where name = 'sales'
--set STATISTICS io on
ALTER INDEX IX_Sales_TransactionDate ON [dbo].[Sales] REBUILD;
ALTER INDEX PK__Sales__C952FB325B51AB80 ON [dbo].[Sales] REBUILD;

ALTER INDEX ALL ON dbo.PurchaseOrder 
DISABLE;

ALTER index PK_PurchaseOrders ON [dbo].[PURCHASEORDER] REBUILD;
ALTER INDEX IX_PurchaseOrder_closeddate ON [dbo].[PURCHASEORDER] REBUILD;


update dbo.PurchaseOrder set ExtendedPrice = 1 where PurchaseOrderId = 10968886
select * from dbo.PurchaseOrder  where PurchaseOrderId = 10968886
DELETE from dbo.PurchaseOrder where PurchaseOrderId = 10968886 
ALTER INDEX ALL ON dbo.PurchaseOrder 
disable;

ALTER INDEX ALL ON PriceDisruptions.PerfRawInvoices
REBUILD;


select * from PriceDisruptions.PerfRawInvoices pri 
DELETE [PriceDisruptions].[PerfRawInvoices];




ALTER INDEX PK__Sales__C952FB325B51AB80 ON [dbo].[Sales] REBUILD;

ALTER index PK_PurchaseOrders ON [dbo].[PURCHASEORDER] REBUILD;


--checking indexes
select * from sys.indexes
where object_id = (select top 1 object_id from sys.objects where name = 'sales')


select * from sys.indexes
where object_id = (select top 1 object_id from sys.objects where name = 'PURCHASEORDER')


ALTER INDEX ALL ON [dbo].[Sales] REBUILD;
ALTER INDEX ALL ON [dbo].[PurchaseOrder] REBUILD;




-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [Premier].[ClearPoAndInvoices]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

declare @MinDate datetime = (select min([InvoiceDate]) from [Premier].[WholesalerInvoices])

ALTER INDEX ALL ON [dbo].[Sales] DISABLE;

ALTER INDEX PK__Sales__C952FB325B51AB80 ON [dbo].[Sales] REBUILD;

ALTER INDEX IX_Sales_TransactionDate ON [dbo].[Sales] REBUILD;

delete [dbo].[Sales] where TransactionDate > = @MinDate

ALTER INDEX ALL ON [dbo].[Sales] REBUILD;

ALTER INDEX ALL ON [dbo].[PurchaseOrder] DISABLE;

ALTER index PK_PurchaseOrders ON [dbo].[PurchaseOrder] REBUILD;

ALTER INDEX IX_PurchaseOrder_closeddate ON [dbo].[PurchaseOrder] REBUILD;

delete [dbo].[PurchaseOrder] where ClosedDateTime > = @MinDate

ALTER INDEX ALL ON [dbo].[PurchaseOrder] REBUILD;

END

