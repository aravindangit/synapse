SELECT PurchaseOrderId, clientid, Ndc, ItemId, PurchaseOrderNumber, CustomerSupplierId, LineNumber, Buyer, ApprovalDateTime, ReceivedDateTime, ClosedDateTime, ReceiptNumber, PriceList, PurchaseOrderStatus, LineStatus, SupplierId, SupplierName, SupplierSite, Routing, UnitPrice, ExtendedPrice, CurrentQuantityOrdered, OriginalQuantityOrdered, QuantityReceived, QuantityOutstanding, QuantityCancelled, TotalQuantityBilled, ReceiptTransactionCount, DataSourceId, PriceTypeGroupId, Is340B, DateImported, DateChanged
FROM sqldbCogRxProdCommonSpirit.dbo.PurchaseOrder;


declare @MinDate datetime = (select min([InvoiceDate]) from [Premier].[WholesalerInvoices])
select @MinDate
delete [dbo].[PurchaseOrderbkp08172021] where ClosedDateTime > = '2020-08-01'

2020-08-01 00:00:00
select count(*) from [dbo].[PurchaseOrderbkp08172021] where ClosedDateTime > = '2020-08-01'

ALTER INDEX ALL ON [dbo].[PurchaseOrderbkp08172021]
DISABLE;

select * from sys.indexes
where object_id = (select object_id from sys.objects where name = 'PurchaseOrderbkp08172021')

alter index IX_PurchaseOrder_closeddate on [dbo].[PurchaseOrderbkp08172021] rebuild;
delete [dbo].[PurchaseOrderbkp08172021] where ClosedDateTime > = @MinDate



select @MinDate

/*delete [dbo].[Sales] where TransactionDate > = @MinDate

delete [dbo].[PurchaseOrder] where ClosedDateTime > = @MinDate*/

select * into dbo.PurchaseOrderbkp08172021 from [dbo].[PurchaseOrder]
--select count(*) from dbo.PurchaseOrder po 

select * from dbo.PurchaseOrderbkp08172021


     CREATE NONCLUSTERED INDEX IX_PO_ApprovalDate1 ON dbo.PurchaseOrderbkp08172021 (  ApprovalDateTime ASC  , QuantityReceived ASC  )  
	 INCLUDE ( CustomerSupplierId , ItemId , Ndc , PurchaseOrderNumber ) 
	 WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
	 ON [PRIMARY ] 
	 CREATE NONCLUSTERED INDEX IX_PurchaseOrder_Agg_PO_Line1 ON dbo.PurchaseOrderbkp08172021 (  clientid ASC  , SupplierName ASC  , Ndc ASC  , PurchaseOrderNumber ASC  , LineNumber ASC  , ApprovalDateTime ASC  )  
	 INCLUDE ( ItemId , ReceivedDateTime ) 
	 WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
	 ON [PRIMARY ] 
	  CREATE NONCLUSTERED INDEX IX_PurchaseOrder_ItemId1 ON dbo.PurchaseOrderbkp08172021 (  ItemId ASC  )  
	 INCLUDE ( ApprovalDateTime ) 
	 WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
	 ON [PRIMARY ] 
	  CREATE NONCLUSTERED INDEX IX_PurchaseOrder_Merge1 ON dbo.PurchaseOrderbkp08172021 (  clientid ASC  , Ndc ASC  , PurchaseOrderNumber ASC  , LineNumber ASC  , ReceiptNumber ASC  , Routing ASC  )  
	 WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
	 ON [PRIMARY ] 
	  CREATE NONCLUSTERED INDEX IX_PurchaseOrder_Ndc1 ON dbo.PurchaseOrderbkp08172021 (  Ndc ASC  )  
	 WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
	 ON [PRIMARY ] 
	  CREATE NONCLUSTERED INDEX IX_PurchaseOrder_clientid1 ON dbo.PurchaseOrderbkp08172021 (  clientid ASC  )  
	 WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
	 ON [PRIMARY ] 
	 
	 --close date time
	 
	 CREATE NONCLUSTERED INDEX IX_PurchaseOrder_closeddate ON dbo.PurchaseOrderbkp08172021 (  ClosedDateTime ASC  )  
	-- INCLUDE ( ApprovalDateTime ) 
	 WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
	 ON [PRIMARY ] 
	 
	 
	 select * from dbo.PurchaseOrderbkp08172021
