select * from customerbkp where CustomerId > 3




select * into customersink from dbo.Customer c where CustomerId is null
select top 100 * from dbo.sales

, "63323-0494-05", "00143-9785-10"
select * from dbo.pharmacyitemshortage where ndc  = '63323049405'

select top 100 * from raw.Sales s 
select * from ImportFileIDMapping
/*declare @clientid int = (select clientid from [ImportFileIDMapping] 
where [ClientImportCode] = 'PremierWholesaleInvoice');*/
declare @clientid int = 5;

SELECT * FROM customer
with Prices AS 
(
  Select FacilityID, 
        Wholesaler, 
		WholesalerPurchaseType, 
		su.[SupplierId] 'SupplierId', 
		--CASE WholesalerPurchaseType  
		--	WHEN 'Premier Contract' THEN 3  
		--	WHEN 'Wholesaler Contract' THEN 3  
		--	WHEN 'Other Contract' THEN 3  
		--	WHEN 'Private Contract' THEN 3  
		--	WHEN 'Non Contract' THEN 3  
		--	WHEN 'DSH' THEN 2  
		--	WHEN '340B' THEN 2  
		--	WHEN 'WAC' THEN 11  	
		--	ELSE null
		--END 'PriceListId',
		p.PriceListId as PriceListId,
		Ndc, 
		InvoiceDate, 
		InvoicePrice, 
		wi.Wholesaler 'DistributorAccountNo'
from [Premier].[WholesalerInvoices] wi
		inner join supplier su
	on wi.Wholesaler = su.SupplierName
			left join PriceList p on p.PriceListDescription=coalesce(wi.WholesalerAccountAttribute,'UNK')
 where su.SupplierTypeId= 2 and su.MfrId is null and ndc != '0'),
PriceRank AS (
select FacilityID, 
        Wholesaler, 
		SupplierId,
		WholesalerPurchaseType, 
		Ndc, 
		InvoiceDate, 
		InvoicePrice,
		PriceListId,
		rank() over (partition by FacilityID, SupplierId, PriceListId, Ndc order by InvoiceDate desc) rnk,
		DistributorAccountNo
from Prices),
PriceCodes as ( 
select FacilityID, 
       Wholesaler,
	   SupplierId,
	   WholesalerPurchaseType,
	   Ndc,
	   InvoiceDate,
	   InvoicePrice,
	   PriceListId,
	   ROW_NUMBER() over (partition by SupplierId, FacilityID, Ndc, PriceListId order by InvoiceDate desc) Seq,
	   DistributorAccountNo
from PriceRank
where rnk = 1)
select @clientid 'clientid', 
	   SupplierId 'CpSupplierID',
	   c.CustomerId 'CustomerId',	    
	   pc.Ndc 'NDC',
	   pi.itemid 'ItemId',
	   pc.InvoicePrice 'PriceAmount',
	   InvoiceDate 'PriceStartDate',
	   PriceListId,
	   17 'DataSourceId',
	   DistributorAccountNo
--into #temp_Premier_Pricing
from PriceCodes pc
	inner join customer c
		on c.ClientId = @clientid
		and pc.FacilityID = c.AccountNumber
	inner join [dbo].[PharmacyItem] pi
		on pc.ndc = pi.ndc
where seq = 1;

select * from dbo.LeadTimeType


INSERT INTO dbo.LeadTimeType (Name,LeadTimeTypeUId) VALUES
	 (N'All Purchases 12 Month',NULL),
	 (N'All Purchases 1 Month',NULL),
	 (N'Non-340B Purchases 12 Month',NULL),
	 (N'Non-340B Purchases 1 Month',NULL),
	 (N'Ony 340B Purchases 12 Month',NULL),
	 (N'Ony 340B Purchases 1 Month',NULL),
	 (N'All Purchases 3 Month',NULL),
	 (N'Non-340B Purchases 3 Month',NULL),
	 (N'Ony 340B Purchases 3 Month',NULL);
	
	
	select * from [MV].[OrganizationSummary]
	
	
	
	with activecustomers as (select distinct customerid from dbo.sales)
	select a.customerid,count(*)
	from customer a left join activecustomers c 
	on a.customerid = c.customerid
	where c.customerid is null
	group by a.CustomerId 
	
	
	
	
	select * from CustomerPriceList where ClientId = 5
	
	
	select * from NationalPharmacyItemPriceCurrent
