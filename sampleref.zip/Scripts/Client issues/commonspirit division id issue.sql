DivisionId as varchar(20) to dbo.Customer
DivsionId is nullable


with EntityCrossRef as (
select [Facility Name] as [Name], [Facility ID] as Id into #templookup from raw.PremierCustomerList)

select * from #templookup

select c.*, xref.Id from  raw.PremierCustomerList c 

join EntityCrossRef xref on c.[Division Name] = xref.Name

select distinct fm.ClientId 'clientid', 
					pcl.[Facility ID] 'AccountNumber', 
					pcl.[Facility Name] 'CustomerName', 
					pcl.[Facility AddrLine1] 'Address1', 
					pcl.[Facility AddrLine2] 'Address2', 
 					pcl.[Facility City]      'City',
					pcl.[Facility State]     'State', 
					pcl.[Facility Zip]       'Zip',
					pcl.[Facility DEA]       'DEA',
					pcl.[Premier_Relation]       'Premier_Relation',
					pcl.[SPC]       'SPC',
					pcl.[Division Name]       'Division Name',
					lk.[Facility ID] 'Division Id',
					co.CustomerOrganizationId 'CustomerOrganizationId', 
					--pcl.[Facility Direct Parent ID] 'OrganizationNumber', 
					--pcl.[Facility Direct Parent] 'OrganizationName',

--updating top parent to org name & ID
					case when fm.ClientImportCode='NY5011' then pcl.[Facility Direct Parent ID] else pcl.[Health System ID] end 'OrganizationNumber',
					case when fm.ClientImportCode='NY5011' then pcl.[Facility Direct Parent] else pcl.[Health System] end 'OrganizationName'
					from [Raw].[PremierCustomerList] pcl
						inner join [dbo].[ImportFileIDMapping] fm
							on pcl.[Health System ID] = fm.ClientImportCode
							inner JOIN #templookup as lk
							on pc1.[Division Name]  = lk.Name
						inner join CustomerOrganization co
							on pcl.[Facility Direct Parent ID] = co.[OrganizationNumber]
							) AS src
		ON tar.[ClientId] = src.[ClientId]
		and tar.AccountNumber = src.AccountNumber
		WHEN MATCHED 
		     AND (tar.CustomerName != src.CustomerName
		       or (src.CustomerName is null and tar.CustomerName is not null)
			   or (src.CustomerName is not null and tar.CustomerName is null)
			   or tar.CustomerOrganizationId != src.CustomerOrganizationId
		       or (src.CustomerOrganizationId is null and tar.CustomerOrganizationId is not null)
			   or (src.CustomerOrganizationId is not null and tar.CustomerOrganizationId is null)
			   or tar.OrganizationNumber != src.OrganizationNumber
		       or (src.OrganizationNumber is null and tar.OrganizationNumber is not null)
			   or (src.OrganizationNumber is not null and tar.OrganizationNumber is null)
			   or tar.OrganizationName != src.OrganizationName
		       or (src.OrganizationName is null and tar.OrganizationName is not null)
			   or (src.OrganizationName is not null and tar.OrganizationName is null)
			   or tar.AddrLine1 != src.Address1
		       or (src.Address1 is null and tar.AddrLine1 is not null)
			   or (src.Address1 is not null and tar.AddrLine1 is null)
			   or tar.AddrLine2 != src.Address2
		       or (src.Address2 is null and tar.AddrLine2 is not null)
			   or (src.Address2 is not null and tar.AddrLine2 is null)
			   or tar.City != src.City
		       or (src.City is null and tar.City is not null)
			   or (src.City is not null and tar.City is null)
			   or tar.State != src.State
		       or (src.State is null and tar.State is not null)
			   or (src.State is not null and tar.State is null)
			   or tar.Zip != src.Zip
		       or (src.Zip is null and tar.Zip is not null)
			   or (src.Zip is not null and tar.Zip is null)
			   or tar.DEA != src.DEA
		       or (src.DEA is null and tar.DEA is not null)
			   or (src.DEA is not null and tar.DEA is null)
			   or tar.Premier_Relation != src.Premier_Relation
		       or (src.Premier_Relation is null and tar.Premier_Relation is not null)
			   or (src.Premier_Relation is not null and tar.Premier_Relation is null)
			   or tar.SPC != src.SPC
		       or (src.SPC is null and tar.SPC is not null)
			   or (src.SPC is not null and tar.SPC is null)
			     or tar.[DivisionName] != src.[Division Name]
		       or (src.[Division Name] is null and tar.[DivisionName] is not null)
			   or (src.[Division Name] is not null and tar.[DivisionName] is null))
		    THEN
		   UPDATE SET
			  tar.CustomerName = src.CustomerName,
			  tar.CustomerOrganizationId = src.CustomerOrganizationId,
			  tar.OrganizationNumber = src.OrganizationNumber,
			  tar.OrganizationName = src.OrganizationName,
			  tar.DateChanged = getdate() ,
			  tar.AddrLine1 = src.Address1 ,
			  tar.AddrLine2 = src.Address2 ,
			  tar.City      = src.City ,
			  tar.State     = src.State ,
			  tar.Zip       = src.Zip  ,
			  tar.DEA       = src.DEA ,
			  tar.Premier_Relation       = src.Premier_Relation ,
			  tar.SPC       = src.SPC ,
			  tar.[DivisionName]       = src.[Division Name]
			  
		WHEN NOT MATCHED THEN
		   INSERT
		   (
				ClientId,
				AccountNumber,
				CustomerName,
				CustomerOrganizationId,
				OrganizationNumber,
				OrganizationName,
				AddrLine1,
				AddrLine2,
				City,
				State,
				Zip,
				DEA,
				Premier_relation,
				SPC,
				[DivisionName]
		   )
		   VALUES
		   (
				src.ClientId,
				src.AccountNumber,
				src.CustomerName,
				src.CustomerOrganizationId,
				src.OrganizationNumber,
				src.OrganizationName,
				src.Address1 ,
			    src.Address2 ,
			    src.City ,
			    src.State ,
			    src.Zip ,
			    src.DEA ,
			    src.Premier_Relation ,
			    src.SPC ,
			    src.[Division Name]
		   );
		   ==================================================================================
		   
		   
--drop table #templook



--DROP TABLE IF EXISTS #templookup

select [Facility Name] as [Name], [Facility ID] as Id into #templookup from raw.PremierCustomerList		   
		   
select * from #templookup	

/*(SELECT AVG(E2.SALARY)
FROM EMP E2
WHERE E2.DEPTNO = E1.DEPTNO)
AS DEPT_AVG_SAL*/
		   
select distinct fm.ClientId 'clientid', 
					pcl.[Facility ID] 'AccountNumber', 
					pcl.[Facility Name] 'CustomerName', 
					pcl.[Division Name]       'Division Name',
					pcl.[Facility AddrLine1] 'Address1', 
					pcl.[Facility AddrLine2] 'Address2', 
 					pcl.[Facility City]      'City',
					pcl.[Facility State]     'State', 
					pcl.[Facility Zip]       'Zip',
					pcl.[Facility DEA]       'DEA',
					pcl.[Premier_Relation]       'Premier_Relation',
					pcl.[SPC]       'SPC',					
			--		lk.[Id] 'Division Id',
					isnull((select lk.[id] from 
					#templookup as lk where lk.Name =  pcl.[Division Name] ),'') as 'Division Id' ,
					co.CustomerOrganizationId 'CustomerOrganizationId', 
					--pcl.[Facility Direct Parent ID] 'OrganizationNumber', 
					--pcl.[Facility Direct Parent] 'OrganizationName',

--updating top parent to org name & ID
					case when fm.ClientImportCode='NY5011' then pcl.[Facility Direct Parent ID] else pcl.[Health System ID] end 'OrganizationNumber',
					case when fm.ClientImportCode='NY5011' then pcl.[Facility Direct Parent] else pcl.[Health System] end 'OrganizationName'
					from [Raw].[PremierCustomerList] pcl
				--	inner join #templookup as lk
					--		on pcl.[Division Name]  = lk.Name
						inner join [dbo].[ImportFileIDMapping] fm
							on pcl.[Health System ID] = fm.ClientImportCode
					--		
						inner join CustomerOrganization co
							on pcl.[Facility Direct Parent ID] = co.[OrganizationNumber]	
							
							
						--	select * from Customer c 
						--	select DivisionId from customer
							
							
							alter table dbo.Customer 
						add DivisionId  varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL;
							
							
							
							select * from dbo.sales
							select * from PharmacyItemAhfs pia 
							
							select * from premier.WholesalerInvoices wi 
							
							select * into dbo.customerdivid from dbo.customer
							select * from dbo.customerdivid