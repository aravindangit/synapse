select distinct TABLE_SCHEMA , TABLE_NAME  from INFORMATION_SCHEMA.COLUMNS where COLUMN_NAME like '%dose%'



select * from dbo.NationalPharmacyItemPriceCurrent
select * from dbo.PharmacyItem
select * from dbo.PharmacyItemAttributes
select * from dbo.ProductImport
select * from HcpBi.vw_ItemMasterDetail
select * from ItemMaster.UnitDose
select * from Raw.AcquisitionCost
select * from Validation.McKesson-2019
select * from Validation.McKesson-2020