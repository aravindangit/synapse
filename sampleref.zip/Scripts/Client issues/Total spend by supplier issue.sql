
--select * from Supplier where SupplierName = '19 and Pacific'
				select 
					c.CustomerId
					, c.CustomerName
					, sum([30DayUsageExtPrice]) as TotalCost30Day
					, sum([60DayUsageExtPrice]) as TotalCost60Day
					, sum([90DayUsageExtPrice]) as TotalCost90Day
					, sum([1YearUsageExtPrice]) as TotalCost
				from SalesTotals st							
						join dbo.Customer c on c.CustomerId = st.CustomerId and c.ClientId = st.ClientId
				        join PharmacyItem pi on st.ItemId = pi.ItemId and st.ClientId = 1 --Param
				        join Supplier sup on pi.MfrId = sup.MfrId and sup.SupplierId = 2614 --Param
				group by c.CustomerId, c.CustomerName
				order by c.CustomerName;
				
	declare @clientId int = 6,@supplierId int = 1893;
	
			
			
			
			
			
            SELECT
				 clientId AS ClientId
            	,supplierid AS SupplierId
            	,y_transactionyear AS Y_TransactionYear
            	,y_cost AS Y_Cost
            	,y_qty AS Y_Qty
            	,r_cost AS R_Cost
            	,r_costrank AS R_CostRank
            	,r_qty AS R_Qty
            	,r_qtyrank AS R_QtyRank
            	,r_totalcount AS R_TotalCount
            	,c_items AS C_Items
            	,c_contracted AS C_Contracted
            	,c_purchased AS C_Qty
            	,c_purchasedoncontract AS C_QtyOnContract
            	,c_spend AS C_Spend
            	,c_spendoncontract AS C_SpendOnContract
            FROM MV.SupplierSummary 
            WHERE clientid = @clientId 
            AND supplierid = @supplierId
            select 
                 year(s.TransactionDate) TransactionYear
	            ,sum(s.UnitCost * s.Qty) Cost	           
            from Sales s
	            join PharmacyItem pi on pi.ItemId = s.ItemId
	            join Supplier sup on sup.MfrId = pi.MfrId	            
            where s.ClientId = @clientId --Param	            
	            and year(s.TransactionDate) >= year(getdate()) - 4
            group by year(s.TransactionDate)	            
            order by year(s.TransactionDate)
            select 
				case when Rank > 5 then null else Ndc end as Ndc,
				case when Rank > 5 then 'Other' else Description end as Description,
				SUM(Cost) as Cost 
            from (
	            select pi.ItemId
		            ,pi.Ndc
		            ,pi.ItemDescription Description
		            ,sum(s.UnitCost * s.Qty) Cost
		            ,dense_rank() over (order by sum(s.UnitCost * s.Qty) desc) Rank
	            from Sales s
		            join PharmacyItem pi on pi.ItemId = s.ItemId
		            join Supplier sup on sup.MfrId = pi.MfrId
	            where s.ClientId = @clientId --Param
		            and sup.SupplierId = @supplierId
		            and s.TransactionDate >= dateadd(month, -12, getdate())
	            group by pi.ItemId
		            ,pi.Ndc
		            ,pi.ItemDescription
            ) q
            group by 
				case when Rank > 5 then null else Ndc end,
				case when Rank > 5 then 'Other' else Description end 
				order by sum(Cost) desc
            select top 5 
                 p.pricetypegroupdescription as PriceList
	            ,sum(s.UnitCost * s.Qty) Cost
				from Sales s
	            join Customer c on s.CustomerId = c.CustomerId
	            join PharmacyItem pi on pi.ItemId = s.ItemId
	            join Supplier sup on sup.MfrId = pi.MfrId
				left join pricetypegroup p on p.pricetypegroupid=s.pricetypegroupid
            where s.ClientId = @clientId --Param
	            and sup.SupplierId = @supplierId --Param
	            and s.TransactionDate >= dateadd(month, -12, getdate())
            group by p.pricetypegroupdescription
            order by sum(s.UnitCost * s.Qty) desc 
            select 
                 (q.PercentIncrease1 + q.PercentIncrease2) / 2 AveragePriceIncreaseAmount
	            ,q.ItemChangeCount
	            ,q.ItemCount
	            ,(q.ItemChangeCount / convert(decimal, q.ItemCount)) * 100 ItemChangePercentage
            from (
	            select 
                    count(case when 
			            pm1.PackagePrice != pm2.PackagePrice or pm1.PackagePrice != pm3.PackagePrice then 1
			            else null
		            end) ItemChangeCount
		            ,count(distinct pi.ItemId) ItemCount
		            ,case when sum(pm1.PackagePrice) != 0 then 
			            ((sum(pm2.PackagePrice) - sum(pm1.PackagePrice)) / sum(pm1.PackagePrice)) * 100
			            else 0 
		            end PercentIncrease1
		            ,case when sum(pm1.PackagePrice) != 0 then 
			            ((sum(pm3.PackagePrice) - sum(pm2.PackagePrice)) / sum(pm2.PackagePrice)) * 100
			            else 0
		            end PercentIncrease2
	            from PharmacyItem pi
		            join Supplier s on pi.MfrId = s.MfrId
		            join NationalPharmacyItemPriceMonthly pm1 on pm1.ItemId = pi.ItemId
			            and pm1.WkPriceCodeId = 5
			            and pm1.PriceDate = convert(datetime, convert(varchar(4), year(getdate()) - 2) + '-01-01')
		            join NationalPharmacyItemPriceMonthly pm2 on pm2.ItemId = pi.ItemId
			            and pm2.WkPriceCodeId = 5
			            and pm2.PriceDate = convert(datetime, convert(varchar(4), year(getdate()) - 1) + '-01-01')
		            join NationalPharmacyItemPriceMonthly pm3 on pm3.ItemId = pi.ItemId
			            and pm3.WkPriceCodeId = 5
			            and pm3.PriceDate = convert(datetime, convert(varchar(4), year(getdate())) + '-01-01')
	            where s.SupplierId = @supplierId --Param
	            group by s.SupplierId
		            ,s.SupplierName
            ) q 
            SELECT
		         pi.ItemDescription as Description
		        ,sum(s.UnitCost * s.Qty) as Cost
		    FROM  Sales s
		            join PharmacyItem pi on pi.ItemId = s.ItemId
		            join Supplier sup on sup.MfrId = pi.MfrId
	            where s.ClientId = @clientId --Param
		            and sup.SupplierId = @supplierId
		            and s.TransactionDate >= dateadd(month, -12, getdate())
	            group by pi.ItemDescription
				ORDER BY SUM(s.UnitCost * s.Qty) DESC
			select 
					c.CustomerId
					, c.CustomerName
					, sum([30DayUsageExtPrice]) as TotalCost30Day
					, sum([60DayUsageExtPrice]) as TotalCost60Day
					, sum([90DayUsageExtPrice]) as TotalCost90Day
					, sum([1YearUsageExtPrice]) as TotalCost
				from SalesTotals st							
						join dbo.Customer c on c.CustomerId = st.CustomerId and c.ClientId = st.ClientId
				        join PharmacyItem pi on st.ItemId = pi.ItemId and st.ClientId = @clientId --Param
				        join Supplier sup on pi.MfrId = sup.MfrId and sup.SupplierId = @supplierId --Param
				group by c.CustomerId, c.CustomerName
				order by c.CustomerName
				
				
				
				
				
				
=======================================================
select 
                 year(s.TransactionDate) TransactionYear
	            ,sum(s.UnitCost * s.Qty) Cost	           
            from Sales s
	            join PharmacyItem pi on pi.ItemId = s.ItemId
	            join Supplier sup on sup.MfrId = pi.MfrId	            
            where s.ClientId = 6 --Param	  
            		and sup.supplierid= 1893         
	            and year(s.TransactionDate) >= year(getdate()) - 4
            group by year(s.TransactionDate)	            
            order by year(s.TransactionDate)