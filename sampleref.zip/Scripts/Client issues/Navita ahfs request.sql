CREATE TABLE NationalWholeSaler.dbo.Pharmacyspend_ahfs (
	ahfs_id varchar(11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ahfs_desc varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ahfs_tier1_id varchar(11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ahfs_tier1_desc varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ahfs_tier2_id varchar(11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ahfs_tier2_desc varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ahfs_tier3_id varchar(11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ahfs_tier3_desc varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	
);


CREATE TABLE NationalWholeSaler.dbo.Pharmacyspend_ahfs (
	ahfs_id varchar(11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ahfs_desc varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ahfs_tier1_id varchar(11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ahfs_tier1_desc varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ahfs_tier1_code text COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ahfs_tier1_abbre varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ahfs_tier2_id varchar(11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ahfs_tier2_desc varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ahfs_tier2_code text COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ahfs_tier2_abbre varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ahfs_tier3_id varchar(11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ahfs_tier3_desc varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ahfs_tier3_code text COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ahfs_tier3_abbre varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
);