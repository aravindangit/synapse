select schema_name(t.schema_id) + '.' + t.name as [table],
       c.column_id,
       c.name as column_name,
       type_name(user_type_id) as data_type,
       max_length,
       precision,
       scale 
from sys.columns c
join sys.tables t
     on t.object_id = c.object_id
where type_name(user_type_id) in ('bigint', 'int', 
      'smallint', 'tinyint', 'decimal', 'numeric',
      'smallmoney', 'money', 'bit', 'float', 'real')
      and schema_name(t.schema_id) = 'raw'
order by [table],
         c.column_id;
         
        
        select top 100 * from raw.Sales s 
        
        
   select count(*) from premier.WholesalerInvoices wi  where HealthSystemID = 'MN2013'      

 --Operation on target Load Invoice and PO into Raw failed: Execution fail against sql server. 
 --Sql error number: 245. Error Message: 
 --Conversion failed when converting the varchar value '1.1' to data type int.  
 select
	cast([LineNumberfromInvoice] as int) 'LineNumber',
	[TotalUnits] 'Qty',
	[QuantityOrdered] 'QtyOrdered',
	[InvoicePrice] 'UnitCost',
	[InvoicePrice] 'UnitPrice'
from
	premier.WholesalerInvoices
where
	HealthSystemID = 'MN2013'
	and ISNUMERIC(LineNumberfromInvoice) <> 1
	and LineNumberfromInvoice is not NULL
   --   where   ISNUMERIC(TotalUnits) <> 1
    --  or  ISNUMERIC(QuantityOrdered) <> 1
	
	
	select count(*)  from [Raw].[Sales]
	
select
	[LineNumberfromInvoice] 'LineNumber',
	[TotalUnits] 'Qty',
	[QuantityOrdered] 'QtyOrdered',
	[InvoicePrice] 'UnitCost',
	[InvoicePrice] 'UnitPrice'
from
	premier.WholesalerInvoices
where LineNumberfromInvoice = '1.1'
ISNUMERIC(LineNumberfromInvoice) <> 1
	and ISNUMERIC(TotalUnits) <> 1
    or  ISNUMERIC(QuantityOrdered) <> 1
    
 --northwell   
    select * from 
	premier.WholesalerInvoices
where LineNumberfromInvoice = '1.1'

--common spirit
 select distinct(LineNumberfromInvoice) from 
	premier.WholesalerInvoices
where LineNumberfromInvoice = '5.1'


TRY_CAST (userID AS INT)

 select
	distinct(TRY_CAST([LineNumberfromInvoice] as int)) 'LineNumber', [LineNumberfromInvoice] as original
from
	premier.WholesalerInvoices
	
	
select
distinct(CONVERT(INT,[LineNumberfromInvoice])) 'LineNumber', 
[LineNumberfromInvoice] as original
from
	premier.WholesalerInvoices WHERE LineNumberfromInvoice IS NOT NULL  
	
	
select
distinct(TRY_PARSE([LineNumberfromInvoice] AS INT)) 'LineNumber', 
[LineNumberfromInvoice] as original
from
	premier.WholesalerInvoices
	
	
	CONVERT(INT, @varchar)
TRY_CAST(

	select
distinct(TRY_CAST([LineNumberfromInvoice] AS INT)) 'LineNumber', 
[LineNumberfromInvoice] as original
from
	premier.WholesalerInvoices
	
	
	select case when [LineNumberfromInvoice] is null then [LineNumberfromInvoice]
				when charinde
				
				
select [LineNumberfromInvoice],count(*) as count 
from premier.WholesalerInvoices where 1=1 group by [LineNumberfromInvoice] 


SELECT case when CHARINDEX('.', LineNumberfromInvoice) >  0 then LineNumberfromInvoice  
else null as linvoice
from premier.WholesalerInvoices




	select
distinct(CAST(CAST(CAST([LineNumberfromInvoice] as numeric) as decimal)as real)) 'LineNumber', 
[LineNumberfromInvoice] as original
from
	premier.WholesalerInvoices
	
	
		select
distinct(CAST(CAST(CAST([LineNumberfromInvoice] as real) as int)as decimal)) 'LineNumber', 
[LineNumberfromInvoice] as original
from
	premier.WholesalerInvoices
	
	
	
	
		select
distinct(CAST(CAST(CAST([LineNumberfromInvoice] as numeric) as decimal)as real)) 'LineNumber', 
[LineNumberfromInvoice] as original
from
	premier.WholesalerInvoices
			