
with FirstCTE as(select * from --[Year],[Month],[Total Spend],[Total Units] from
(SELECT YEAR(transactiondate) [Year1], 
	case when year(transactiondate)= year(GETDATE()) then
�����		concat('Current','-',�DATENAME(MONTH, transactiondate)) 
         else 
        	concat('Previous','-',�DATENAME(MONTH, transactiondate))
         end as [Month],
������SUM(Qty * UnitCost) as [Total Spend]
--	  sum(Unitcost) as [Total Units] 
	  from dbo.sales s join dbo.customer c on s.customerid = c.customerid
where s.customerid = 56 and 
YEAR(s.transactiondate) = year(GETDATE()) 
								or 
								YEAR(s.transactiondate)=(YEAR(GETDATE()) - 1)
GROUP BY YEAR(transactiondate), 
������     DATENAME(MONTH, transactiondate)) AS MontlySalesData
PIVOT( SUM([Total Spend])�� 
����FOR [Month] IN (
		[Current-January],
		[Current-February],
		[Current-March],
		[Current-April],
		[Current-May],
����	[Current-June],
		[Current-July],
		[Current-August],
		[Current-September],
		[Current-October],
		[Current-November],
����	[Current-December],
		[Previous-January],
		[Previous-February],
		[Previous-March],
		[Previous-April],
		[Previous-May],
����	[Previous-June],
		[Previous-July],
		[Previous-August],
		[Previous-September],
		[Previous-October],
		[Previous-November],
����	[Previous-December])) AS pivotname1),
SecondCTE as(select * from --[Year],[Month],[Total Spend],[Total Units] from
(SELECT YEAR(transactiondate) [Year2], 
	case when year(transactiondate)= year(GETDATE()) then
�����		concat('Current1','-',�DATENAME(MONTH, transactiondate)) 
         else 
        	concat('Previous1','-',�DATENAME(MONTH, transactiondate))
         end as [Month],
������SUM(Qty * UnitCost) as [Total Spend]
--	  sum(Unitcost) as [Total Units] 
	  from dbo.sales s join dbo.customer c on s.customerid = c.customerid
where s.customerid = 56 and 
YEAR(s.transactiondate) = year(GETDATE()) 
								or 
								YEAR(s.transactiondate)=(YEAR(GETDATE()) - 1)
GROUP BY YEAR(transactiondate), 
������     DATENAME(MONTH, transactiondate)) AS MontlySalesData
PIVOT( SUM([Total Spend])�� 
����FOR [Month] IN (
		[Current1-January],
		[Current1-February],
		[Current1-March],
		[Current1-April],
		[Current1-May],
����	[Current1-June],
		[Current1-July],
		[Current1-August],
		[Current1-September],
		[Current1-October],
		[Current1-November],
����	[Current1-December],
		[Previous1-January],
		[Previous1-February],
		[Previous1-March],
		[Previous1-April],
		[Previous1-May],
����	[Previous1-June],
		[Previous1-July],
		[Previous1-August],
		[Previous1-September],
		[Previous1-October],
		[Previous1-November],
����	[Previous1-December])) AS pivotname2),
ThirdCTE as(
select * from FirstCTE  cross join SecondCTE where year1 = 2021 and  year2 = 2020 )
--select * from ThirdCTE
,
FourthCTE as(select * from --[Year],[Month],[Total Spend],[Total Units] from
(SELECT YEAR(transactiondate) [Year3], 
	case when year(transactiondate)= year(GETDATE()) then
�����		concat('Current2','-',�DATENAME(MONTH, transactiondate)) 
         else 
        	concat('Previous2','-',�DATENAME(MONTH, transactiondate))
         end as [Month],
��
  	  sum(Qty) as [Total Units] 
	  from dbo.sales s join dbo.customer c on s.customerid = c.customerid
where s.customerid = 56 and 
YEAR(s.transactiondate) = year(GETDATE()) 
								or 
								YEAR(s.transactiondate)=(YEAR(GETDATE()) - 1)
GROUP BY YEAR(transactiondate), 
������     DATENAME(MONTH, transactiondate)) AS MontlySalesData
PIVOT( SUM([Total Units])�� 
����FOR [Month] IN (
		[Current2-January],
		[Current2-February],
		[Current2-March],
		[Current2-April],
		[Current2-May],
����	[Current2-June],
		[Current2-July],
		[Current2-August],
		[Current2-September],
		[Current2-October],
		[Current2-November],
����	[Current2-December],
		[Previous2-January],
		[Previous2-February],
		[Previous2-March],
		[Previous2-April],
		[Previous2-May],
����	[Previous2-June],
		[Previous2-July],
		[Previous2-August],
		[Previous2-September],
		[Previous2-October],
		[Previous2-November],
����	[Previous2-December])) AS pivotname1),
FifthCTE as(select * from --[Year],[Month],[Total Spend],[Total Units] from
(SELECT YEAR(transactiondate) [Year4], 
	case when year(transactiondate)= year(GETDATE()) then
�����		concat('Current3','-',�DATENAME(MONTH, transactiondate)) 
         else 
        	concat('Previous3','-',�DATENAME(MONTH, transactiondate))
         end as [Month],
��
  	  sum(Qty) as [Total Units] 
	  from dbo.sales s join dbo.customer c on s.customerid = c.customerid
where s.customerid = 56 and 
YEAR(s.transactiondate) = year(GETDATE()) 
								or 
								YEAR(s.transactiondate)=(YEAR(GETDATE()) - 1)
GROUP BY YEAR(transactiondate), 
������     DATENAME(MONTH, transactiondate)) AS MontlySalesData
PIVOT( SUM([Total Units])�� 
����FOR [Month] IN (
		[Current3-January],
		[Current3-February],
		[Current3-March],
		[Current3-April],
		[Current3-May],
����	[Current3-June],
		[Current3-July],
		[Current3-August],
		[Current3-September],
		[Current3-October],
		[Current3-November],
����	[Current3-December],
		[Previous3-January],
		[Previous3-February],
		[Previous3-March],
		[Previous3-April],
		[Previous3-May],
����	[Previous3-June],
		[Previous3-July],
		[Previous3-August],
		[Previous3-September],
		[Previous3-October],
		[Previous3-November],
����	[Previous3-December])) AS pivotname5),
SixthCTE as(
select * from FourthCTE  cross join FifthCTE where year3 = 2021 and  year4 = 2020 ),
SeventhCTE as(select * from ThirdCTE cross join  SixthCTE),
EighthCTE as (select [Current-January],
		[Current-February],
		[Current-March],
		[Current-April],
		[Current-May],
����	[Current-June],
		[Current-July],
		[Current-August],
		[Current-September],
		[Current-October],
		[Current-November],
����	[Current-December],
		[Previous1-January],
		[Previous1-February],
		[Previous1-March],
		[Previous1-April],
		[Previous1-May],
����	[Previous1-June],
		[Previous1-July],
		[Previous1-August],
		[Previous1-September],
		[Previous1-October],
		[Previous1-November],
����	[Previous1-December],
		[Current2-January],
		[Current2-February],
		[Current2-March],
		[Current2-April],
		[Current2-May],
����	[Current2-June],
		[Current2-July],
		[Current2-August],
		[Current2-September],
		[Current2-October],
		[Current2-November],
����	[Current2-December],
		[Previous3-January],
		[Previous3-February],
		[Previous3-March],
		[Previous3-April],
		[Previous3-May],
����	[Previous3-June],
		[Previous3-July],
		[Previous3-August],
		[Previous3-September],
		[Previous3-October],
		[Previous3-November],
����	[Previous3-December],
		([Current-January] + 
		[Current-February]+
		[Current-March]+
		[Current-April]+
		[Current-May]+
����	[Current-June]+
		[Current-July]+
		[Current-August]+
		[Current-September]+
		[Current-October]+
		isnull([Current-November],0)+
����	isnull([Current-December],0)) as CurrentyearCost,
([Previous1-January] + [Previous1-February]+
		[Previous1-March]+
		[Previous1-April]+
		[Previous1-May]+
����	[Previous1-June]+
		[Previous1-July]+
		[Previous1-August]+
		[Previous1-September]+
		[Previous1-October]+
		isnull([Previous1-November],0)+
����	isnull([Previous1-December],0)) as PreviousyearCost,
([Current2-January] + [Current2-February]+
		[Current2-March]+
		[Current2-April]+
		[Current2-May]+
����	[Current2-June]+
		[Current2-July]+
		[Current2-August]+
		[Current2-September]+
		[Current2-October]+
		isnull([Current2-November],0)+
����	isnull([Current2-December],0)) as currentunits,
([Previous3-January] + [Previous3-February]+
		[Previous3-March]+
		[Previous3-April]+
		[Previous3-May]+
����	[Previous3-June]+
		[Previous3-July]+
		[Previous3-August]+
		[Previous3-September]+
		[Previous3-October]+
		isnull([Previous3-November],0)+
����	isnull([Previous3-December],0)) as previosyearunits,
--calculating different
		([Current-January] + 
		[Current-February]+
		[Current-March]+
		[Current-April]+
		[Current-May]+
����	[Current-June]+
		[Current-July]+
		[Current-August]+
		[Current-September]+
		[Current-October]+
		isnull([Current-November],0)+
����	isnull([Current-December],0)) -
([Previous1-January] + [Previous1-February]+
		[Previous1-March]+
		[Previous1-April]+
		[Previous1-May]+
����	[Previous1-June]+
		[Previous1-July]+
		[Previous1-August]+
		[Previous1-September]+
		[Previous1-October]+
		isnull([Previous1-November],0)+
����	isnull([Previous1-December],0)) as differencebetweenyear
		
 from SeventhCTE )
 
 select (((CurrentyearCost - PreviousyearCost)/PreviousyearCost)*100) as Percentagecostincrease,
 		(((currentunits - previosyearunits)/previosyearunits)*100) as Percentageunitsincrease,*
 from EighthCTE
 
/* select sum(qty * unitcost),month(TransactionDate),year(TransactionDate) from dbo.sales where CustomerId = 56
 and year(transactiondate) = 2021
 group by  customerid,year(TransactionDate),month(TransactionDate)    
 
 select customerid,sum(qty * unitcost) from dbo.sales where year(transactiondate) = 2021 group by customerid
 
 select * from customer*/
 
 select sum(qty) from dbo.sales where year(transactiondate) = 2021 and customerid =56 group by month(TransactionDate)
  select sum(qty),month(TransactionDate) from dbo.sales 
  where year(transactiondate) = 2020 and customerid =56 group by month(TransactionDate)
