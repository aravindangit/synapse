select distinct
				 s.SupplierId as WholesalerId
	            ,s.SupplierUId as WholesalerUId
	            ,s.SupplierName as WholesalerName
            into #suppliers
            from Supplier s
	            join SupplierType st on s.SupplierTypeId = st.SupplierTypeId
				join SALESTOTALMONTHLY sal on s.SupplierId=sal.SupplierId
				join Customer c on c.CustomerId = sal.CustomerId
				where st.SupplierTypeDescription = 'GPO' and c.Status='A' 