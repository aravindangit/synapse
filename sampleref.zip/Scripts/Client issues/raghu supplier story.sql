
select
s.SupplierId
,s.SupplierUId
,s.SupplierName
,case when st.SupplierTypeDescription ='Manufacturer' then 'Supplier' else st.SupplierTypeDescription end SupplierTypeDescription
into #suppliers
from Supplier s
join SupplierType st on s.SupplierTypeId = st.SupplierTypeId
where st.SupplierTypeDescription <> 'GPO'
%%SEARCH_TERM%% ;with filteredResults as (
select distinct pt.SupplierId
,pt.SupplierUId
,pt.SupplierName
,pt.SupplierTypeDescription
from (
select s.SupplierId
,s.SupplierUId
,s.SupplierName
,s.SupplierTypeDescription
,eat.Description
,eav.Value
from #suppliers s
left join EntityAttributeValue eav on s.SupplierUId = eav.EntityId
left join EntityAttributeType eat on eav.EntityAttributeTypeId = eat.EntityAttributeTypeId
where 1 = 1
***FILTERS***
)
***PIVOT_SQL***
pt
where 1 = 1
***ENTITY_ATTRIBUTE_FILTERS***
)
select s.SupplierId
,s.SupplierUId
,s.SupplierName
,s.SupplierTypeDescription
,tc.SearchResultCount
from filteredResults s
join (select count(1) SearchResultCount from filteredResults) tc on 1 = 1
JOIN salesTotalMonthly s
order by --Param
case when @sortColumn = 'SupplierName' and @sortDirection = 'asc' then s.SupplierName end,
case when @sortColumn = 'SupplierName' and @sortDirection = 'desc' then s.SupplierName end desc,
case when @sortColumn = 'SupplierTypeDescription' and @sortDirection = 'asc' then s.SupplierTypeDescription end,
case when @sortColumn = 'SupplierTypeDescription' and @sortDirection = 'desc' then s.SupplierTypeDescription end desc
offset @pageNumber * @pageSize rows --Param
fetch next @pageSize rows only


select s.ExtendedPrice
from salesTotalMonthly s
join PharmacyItem pi on s.NDC = pi.NDC and s.ClientId = 6
join Supplier sup on pi.MfrId = sup.MfrId and sup.SupplierId = 2518


select s.ExtendedPrice
from salesTotalMonthly s
join PharmacyItem pi on s.NDC = pi.NDC and s.ClientId = 6
join Supplier sup on pi.MfrId = sup.MfrId and sup.SupplierId = 2518 WHERE @PURCHASED = 0


SELECT * FROM salestotalmonthly

select * from Supplier s 







declare @purchased int = 0



select distinct sup.SupplierId
from salesTotalMonthly s
join PharmacyItem pi on s.NDC = pi.NDC and s.ClientId = 6
join Supplier sup on pi.MfrId = sup.MfrId
WHERE (S.DATEYEAR > (YEAR(GETDATE())-1) and S.DATEYEAR >= (MONTH(GETDATE())))
AND (
(@purchased = 0 and S.EXTENDEDPRICE = 0) or (@purchased = 1 and S.EXTENDEDPRICE > 0) )
ORDER BY SUP.SUPPLIERID

select top 100 * from SalesTotalMonthly stm 
select YEAR(GETDATE())-1

DECLARE @LastChangeDate as date
SET @LastChangeDate = GetDate()

select  YEAR(GETDATE())-1 and S.DATEYEAR >= (MONTH(GETDATE())))

select (YEAR(GETDATE())-1)
select @LastChangeDate

==================================================================================================

select dateadd(month,datediff(month,0,getdate())-12,0)
select DATEADD(year,-1,GETDATE())


DECLARE @LastChangeDate as date;
SET @LastChangeDate = DATEADD(year,-1,GETDATE());
with supplierwithspend as (
Select distinct sup.supplierId,
isnull(sum(ROUND((qty * unitprice),0)), 0) as Extendedprice,
'Purchase' as status
from dbo.sales s
join PharmacyItem pi on s.NDC = pi.NDC and s.ClientId = 6
join Supplier sup on pi.MfrId = sup.MfrId
where s.TransactionDate >= @LastChangeDate
group by sup.SupplierId ),
supplierwithoutspend as (
select SupplierId , 'Null' as Extendedprice, 'Not purchased' as status from Supplier where
SupplierId not in (select SupplierId from supplierwithspend))
select * from supplierwithspend
union
select * from supplierwithoutspend



WHERE S.DATEYEAR > 2020 AND (
(@purchased = 0 and S.EXTENDEDPRICE = 0) or (@purchased = 1 and S.EXTENDEDPRICE > 0) )
)

