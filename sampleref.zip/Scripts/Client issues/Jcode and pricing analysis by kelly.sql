SELECT distinct Ndc 
FROM dbo.AspPriceAndLimits where HcpcsCode = 'J1745'



-------------------------------

--FOR EACH department, and pricelist, what are the purchases in the most recent quarter for which there is sales

declare @clientid int = 3
declare @jcode varchar(10) = 'J1745'
 

 SELECT
                         JCode
                        ,ClientId
                        ,QuarterDate
                        ,PriceList
                        ,CustomerId
	                    ,SUM(SalesQty) AS 'SalesQty'
	                    ,SUM(Cost) AS 'Cost'
	                    ,SUM(DispQty) AS 'DispQty'
                    FROM 
                    (
	                    SELECT 
                             ptg.PriceTypeGroupDescription AS 'PriceList'
                            ,c.ClientId
                            ,s.QuarterDate
                            ,c.CustomerId
                            ,s.Qty AS 'SalesQty'
                            ,s.Qty*s.UnitPrice AS 'Cost'
                            ,asp.HcpcsCode AS 'JCode'
                            ,asp.BillableUnitsPer11DigitNDC*s.Qty AS 'DispQty'
	                    FROM Sales s
	                        JOIN Customer c ON s.CustomerId = c.CustomerId AND s.ClientId = c.ClientId
                            JOIN AspPriceAndLimits asp ON asp.Ndc = s.Ndc AND asp.IsCurrentRecords = 1
                            JOIN PriceTypeGroup ptg ON ptg.PriceTypeGroupId = s.PriceTypeGroupId
	                        WHERE s.ClientId = @clientId
	                        and asp.HcpcsCode = @jCode
                    ) TOTALS
                    GROUP BY
                         JCode
                        ,ClientId
                        ,QuarterDate
                        ,PriceList
	                    ,CustomerId