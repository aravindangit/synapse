select    a11.month_id AS month_id,
			a15.ndc ,
               max(a14.month_desc) AS month_desc,
               a11.member_key AS member_key,
               max(a13.member_identity) AS member_identity,
               a12.bus_partner_id AS bus_partner_id,
               max(a12.bus_partner_desc) AS bus_partner_desc,
               a11.invoice_date AS invoice_date,
               a11.invoice_num AS invoice_num,
               a11.invoice_price AS invoice_price,
               Sum(case when a11.matrix_status_key in (0,1,2,4,5,6)  then a11.sales_qty  else 0 end) AS TOTALUNITS,
               Sum(case when a11.matrix_status_key in (0,1,2,4,5,6)  then a11.sales_dollars  else 0 end) AS TOTALSPEND
from      fact_bp_sales_detail_view            a11
join product_rpt a15 --new
  on (a11.product_key = a15.product_key)  --new
               join        bus_partner_source         a12
                 on        (a11.bp_source_id = a12.bp_source_id)
               join        member_view    a13
                 on        (a11.member_key = a13.member_key)
               join        trans_current_month_37_view   a14
                 on        (a11.month_id = a14.month_id)
where    (a11.month_id in (2021410) and a15.ndc= '61958290102'
and a13.member_top_parent_key in (59815)
and a13.member_status in ('ACTIVE', 'TERMINATED'))
group by              a11.month_id,
               a11.member_key,
               a12.bus_partner_id,
               a11.invoice_date,
               a11.invoice_num,
               a11.invoice_price,
               a15.ndc limit 500001
               
               
               
               select distinct(month_id) from  trans_current_month_37_view  

               
               
               
               
               select 
				case when Rank > 5 then null else Ndc end as Ndc,
				case when Rank > 5 then 'Other' else Description end as Description,
				SUM(Cost) as Cost 
            from (
	            select pi.ItemId
		            ,pi.Ndc
		            ,pi.ItemDescription Description
		            ,sum(s.UnitCost * s.Qty) Cost
		            ,dense_rank() over (order by sum(s.UnitCost * s.Qty) desc) Rank
	            from Sales s
		            join PharmacyItem pi on pi.ItemId = s.ItemId
		            join Supplier sup on sup.MfrId = pi.MfrId
	            where s.ClientId = 2 --@clientId --Param
		       --     and sup.SupplierId = @supplierId
		            and s.TransactionDate >= dateadd(month, -12, getdate())
	            group by pi.ItemId
		            ,pi.Ndc
		            ,pi.ItemDescription
            ) q
            group by 
				case when Rank > 5 then null else Ndc end,
				case when Rank > 5 then 'Other' else Description end 
				order by sum(Cost) desc;
				select * from Client c 
			
			select * from dbo.Sales s 
			
			
			
			
			select c.CustomerName, s.SupplierName ,s.ndc,s.TransactionDate ,s.InvoiceNumber ,
			sum(s.UnitCost * s.Qty) as spend, year(TransactionDate) as tyear,MONTH(TransactionDate) as tmonth
			from sales s join customer c on s.CustomerId = c.customerid
			where s.ndc='61958290102'
            and  s.TransactionDate >= dateadd(month, -12, getdate())
            group by s.SupplierName,c.CustomerName,s.ndc,s.TransactionDate ,s.InvoiceNumber,year(TransactionDate),MONTH(TransactionDate)
            order by year(TransactionDate) desc,MONTH(TransactionDate) desc
            
            
            
            
            
            
            select top 100 * from premier.WholesalerInvoices c where c.InvoiceNumber = '3071747194'
            
            
            
            
  ---six months comparision
  select    a11.month_id AS month_id,
			a15.ndc ,
               max(a14.month_desc) AS month_desc,
               a11.member_key AS member_key,
               max(a13.member_identity) AS member_identity,
               a12.bus_partner_id AS bus_partner_id,
               max(a12.bus_partner_desc) AS bus_partner_desc,
               a11.invoice_date AS invoice_date,
               a11.invoice_num AS invoice_num,
               a11.invoice_price AS invoice_price,
               Sum(case when a11.matrix_status_key in (0,1,2,4,5,6)  then a11.sales_qty  else 0 end) AS TOTALUNITS,
               Sum(case when a11.matrix_status_key in (0,1,2,4,5,6)  then a11.sales_dollars  else 0 end) AS TOTALSPEND
from      fact_bp_sales_detail_view            a11
join product_rpt a15 --new
  on (a11.product_key = a15.product_key)  --new
               join        bus_partner_source         a12
                 on        (a11.bp_source_id = a12.bp_source_id)
               join        member_view    a13
                 on        (a11.member_key = a13.member_key)
               join        trans_current_month_37_view   a14
                 on        (a11.month_id = a14.month_id)
where    (a11.month_id in (2021410,2021309,2021308,2021307,2021206,2021205) and a15.ndc= '61958290102'
and a13.member_top_parent_key in (59815)
and a13.member_status in ('ACTIVE', 'TERMINATED'))
group by              a11.month_id,
               a11.member_key,
               a12.bus_partner_id,
               a11.invoice_date,
               a11.invoice_num,
               a11.invoice_price,
               a15.ndc limit 500001
               
               
  select * from dbo.Customer  
  where AccountNumber not in (select [Facility ID] from raw.PremierCustomerList c)
  and DivisionName is null or DivisionId is null
  
 select * from raw.PremierCustomerList  
  where [Facility ID] in (select accountnumber from dbo.Customer c)
 -- and DivisionName is null or DivisionId is null
  
  select * from Customer c 
  
  select 1917 - 1801
  
  '677064'   --[Division Name] is null or DivisionId is null         
               
               select customername,AccountNumber  from dbo.customer 
               where DivisionName is null or DivisionId is null
               
               
               
               
               select * from customer where CustomerName like '%DECATUR%'