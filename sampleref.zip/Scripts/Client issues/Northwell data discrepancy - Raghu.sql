/*select sum(qty * UnitPrice)  from sales where transactiondate >= '2021-08-01' and TransactionDate <= '2021-08-31'
and CustomerId = 12   --- 5163.3600
--select * from Customer c order by CustomerName */

select    a11.member_key AS member_key,
               max(a12.member_identity) AS member_identity,
               a11.invoice_date AS invoice_date,
               a15.ndc,
                a13.bus_partner_id AS bus_partner_id,
       max(a13.bus_partner_desc) AS bus_partner_desc,
               Sum(case when a11.matrix_status_key in (0,1,2,4,5,6)  then a11.sales_dollars  else 0 end) AS TOTALSPEND
from      fact_bp_sales_detail_view            a11
               join        member_view    a12
                 on        (a11.member_key = a12.member_key)
 join product_rpt        a15 on (a11.product_key = a15.product_key)  --added
 join bus_partner_source a13 on (a11.bp_source_id = a13.bp_source_id)
where    (a11.month_id in (2021308, 2021307, 2021206, 2021205, 2021204, 2021103, 2021102, 2021101, 2020412, 2020411, 2020410, 2020309, 2021309)
and a12.member_direct_parent_key in (12103)
and a12.member_status in ('ACTIVE', 'TERMINATED'))
group by              a11.member_key,
				 a13.bus_partner_id,
               a11.invoice_date, 
               a15.ndc limit 500001
               
               
              -- select * from   fact_bp_sales_detail_view  order by 1 desc limit 100
               
               
               
               
                   declare @today date = getdate();
    declare @Past30 date = dateadd(day, -30, @today);
    declare @Past60 date = dateadd(day, -60, @today);
    declare @Past90 date = dateadd(day, -90, @today);
    declare @Past6Months date = dateadd(month, -6, @today);
    declare @Past1Year date = dateadd(year, -1, @today);
    declare @Past2Year date = dateadd(year, -2, @today);
select clientid
             , CustomerId
             , ndc
             , PriceTypeGroupId
             ,TransactionDate 
             , SupplierId
             , max(itemid) itemid
             , isnull(sum(qty), 0) as "1YearUsageQty"
             , isnull(sum(qty * unitprice), 0) as "1YearUsageExtPrice"
             , isnull(sum(QtyOrdered), 0) as "1YearQtyOrdered"
             , count(1) as "1YearUsageTransactionCount"
             , @Past1Year as "1YearAsOfDate"
        from dbo.sales
        where transactiondate >= @Past1Year
              and [RepackagedFlag] = 0
        group by clientid
               , CustomerId
               , ndc
               ,TransactionDate
               , PriceTypeGroupId
               , SupplierId
