SELECT
                 e.BuyInExclusionId
	            ,e.ItemId
	            ,p.Ndc
	            ,p.ItemDescription
                ,CASE
					WHEN CHARINDEX('Unknown - ', cm.CustomerName) > 0 THEN cm.CustomerName	
                    WHEN cm.DEA IS NULL THEN cm.CustomerName + ' - ' + cm.AccountNumber
					ELSE cm.CustomerName + ' - ' + cm.AccountNumber + ' - ' + cm.DEA 
					END AS Facility
                ,e.DateAdded
				,e.ExclusionEndDate
                ,CASE
                    WHEN e.ExclusionEndDate IS NULL OR e.ExclusionEndDate > GETDATE() 
                    THEN 1
                    ELSE 0
                END AS IsActive,
            userCreated.DisplayName AS CreatedBy,
            userUpdated.DisplayName AS UpdatedBy,            
            e.UpdatedOn AS UpdatedOn,
            e.ExclusionReason,
            e.ExclusionDuration,
            dbo.fn_DivisionName(cm.DivisionName, cm.DivisionId) 'Division'
            FROM App.BuyInExclusion e
				inner join dbo.PharmacyItem p
					ON e.ItemId = p.ItemId
            left join Customer cm on cm.customerid = e.customerid
            left join App.UserData userCreated on e.UserAddedUserDataId = userCreated.UserDataId
            left join App.UserData userUpdated on e.UserChangedUserDataId = userUpdated.UserDataId
			WHERE e.ClientId = @clientId and cm.status = 'A'
            ORDER BY IsActive desc, e.ExclusionEndDate desc, e.DateAdded desc";