select  distinct PriceTypeGroupId  from dbo.Sales s 
select count(*) from dbo.Sales s where PriceTypeGroupId is not NULL 
--change1
select * from [dbo].[ImportFileIDMapping]

select * from dbo.SalesTotalMonthly stm 
select * from dbo.SalesTotals st 

select * from dbo.CustomerItemPricing cip 
--change2
select * from Mapping.[PriceTypeGroupXref] 

select ClientId,PriceTypeGroupId,ClientPriceTypeCode from Mapping.[PriceTypeGroupXref] ptg 


select * from Mapping.[PriceTypeGroupXref]
INSERT INTO Mapping.[PriceTypeGroupXref] (ClientId,PriceTypeGroupId,ClientPriceTypeCode) VALUES
	 (8,1,N'WAC'),
	 (8,3,N'Wholesaler Contract'),
	 (8,3,N'Premier Contract'),
	 (8,2,N'340B'),
	 (8,3,N'Other Contract'),
	 (8,3,N'Private Contract'),
	 (8,2,N'DSH'),
	 (8,3,N'Non Contract'),
	 (8,3,N'GPO'),
	 (8,4,N'UNK');


INSERT INTO Mapping.[PriceTypeGroupXref] (ClientId,PriceTypeGroupId,ClientPriceTypeCode,DateAdded,DateChanged,SysStartTime,SysEndTime) VALUES
	 (8,1,N'WAC''9999-12-31 23:59:59.000'),
	 (8,3,N'Wholesaler Contract','2020-12-24 18:21:58.820','2020-12-24 18:21:58.820','2022-02-18 23:48:16.000','9999-12-31 23:59:59.000'),
	 (8,3,N'Premier Contract','2020-12-24 18:21:58.820','2020-12-24 18:21:58.820','2022-02-18 23:48:16.000','9999-12-31 23:59:59.000'),
	 (8,2,N'340B','2020-12-24 18:21:58.820','2020-12-24 18:21:58.820','2022-02-18 23:48:16.000','9999-12-31 23:59:59.000'),
	 (8,3,N'Other Contract','2020-12-24 18:21:58.820','2020-12-24 18:21:58.820','2022-02-18 23:48:16.000','9999-12-31 23:59:59.000'),
	 (8,3,N'Private Contract','2020-12-24 18:21:58.820','2020-12-24 18:21:58.820','2022-02-18 23:48:16.000','9999-12-31 23:59:59.000'),
	 (8,2,N'DSH','2020-12-24 18:21:58.820','2020-12-24 18:21:58.820','2022-02-18 23:48:16.000','9999-12-31 23:59:59.000'),
	 (8,3,N'Non Contract','2020-12-24 18:21:58.820','2020-12-24 18:21:58.820','2022-02-18 23:48:16.000','9999-12-31 23:59:59.000'),
	 (8,3,N'GPO','2021-03-15 08:25:15.147','2021-03-15 08:25:15.147','2022-02-18 23:48:16.000','9999-12-31 23:59:59.000'),
	 (8,4,N'UNK','2021-05-26 18:23:32.257','2021-05-26 18:23:32.257','2022-02-18 23:48:16.000','9999-12-31 23:59:59.000');

select * from dbo.DataSource ds 

INSERT INTO [dbo].[ImportFileIDMapping] (ClientImportCode,Description,ClientId,ClientSupplierId,CpSupplierID,CustomerId,PriceListId,DataSourceId,PayerId,ReimbursementTypeId,ImportFileFrequencyTypeId,ImportFileMapUId,MPBFlag) VALUES
	 (N'PremierWholesaleInvoice',N'PremierWholesaleInvoice',8,NULL,1,NULL,NULL,17,NULL,NULL,1,N'2BA70072-09C4-4905-92F8-444804DAD413',NULL),
	 (N'PremierWholesalePO',N'PremierWholesalePO',8,NULL,1,NULL,NULL,17,NULL,NULL,1,N'05903B9A-E45D-4000-B633-AE7AEA7176E3',NULL),
	 (N'CO5012',N'Premier Health System Id',8,NULL,NULL,NULL,NULL,17,NULL,NULL,NULL,N'BC0F82F6-5BE3-4F0A-A21E-A8B934AD9243',NULL);*/
	

select * from dbo.Customer c 
	
	
	select top 100 ifm.[ClientId],
	   c.[CustomerId],
	--   su.SupplierId SupplierId,
	--   su.SupplierName SupplierName,
	--   pi.ItemId,
       s.[TransactionDate],
       s.[Ndc],
       s.[ItemDescription],
       s.[OrderNumber],
       s.[LineNumber],
       s.[OrderType],
       s.[Qty],
	   s.[QtyOrdered],
      s.[UnitCost],
 s.[UnitPrice],
       s.[UOM],
       s.[InvoiceNumber],
	   s.[WholesalerAccountNumber],
	   s.[ChargeBackContractNumber],
	   s.[Markup/Markdown],
--	   ptx.[PriceTypeGroupId],
	   s.[Address1],
	   s.[Address2],
	   s.[City],
	   s.[State],
	   s.[ZipCode],
	--   format(ca.FirstDateOfQuarter,'yyyyMMdd') QuarterDate,
       s.[ImportedDate],
	   ifm.[DataSourceId],
	   s.[ProcessPipelineId],
	   case when s.OrderType in ('CPAK Return', 'DOD Order', 'DOD Return', 'Order CPAK') then 1 else 0 end RepackagedFlag
from [Raw].[Sales] s
  inner join [dbo].[ImportFileIDMapping] ifm
     on s.[DataSource] = ifm.[ClientImportCode]
  inner join [dbo].[Customer] c
     on s.[Account] = c.[AccountNumber]
	and ifm.ClientId = c.ClientId
  left join [dbo].[PharmacyItem] pi
     on s.ndc = pi.Ndc
  inner join Calendar ca
     on ifm.[ClientId] = ca.ClientId
	and s.TransactionDate = ca.CalendarDate
  left join Mapping.[PriceTypeGroupXref] ptx
	on c.ClientId = ptx.clientid
	and s.WholesalerAccountAttribute = ptx.[ClientPriceTypeCode]		
  left join supplier su
	on s.Wholesaler = su.SupplierName
where su.SupplierTypeId= 2 and su.MfrId is null

select * from dbo.PharmacyItemShortage pis where pis.ndc = '00955172050'

select * from NationalPriceDisruptions.ResultsGpi rg 