
    declare @today date = getdate();
    declare @Past30 date = dateadd(day, -30, @today);
    declare @Past60 date = dateadd(day, -60, @today);
    declare @Past90 date = dateadd(day, -90, @today);
    declare @Past6Months date = dateadd(month, -6, @today);
    declare @Past1Year date = dateadd(year, -1, @today);
    declare @Past2Year date = dateadd(year, -2, @today);


select a.customername,a.CustomerId,sum(a.[1YearUsageExtPrice]) as price from
(select s.clientid
             , s.CustomerId
             ,c.customername
             , s.ndc
             , s.InvoiceNumber
             , s.TransactionDate
             , s.PriceTypeGroupId
             , s.SupplierId
             , max(s.itemid) itemid
             , isnull(sum(s.qty), 0) as "1YearUsageQty"
          --   , isnull(sum(s.qty * s.unitprice), 0) as "1YearUsageExtPrice"
             , isnull(sum(ROUND((qty * unitprice),0)), 0) as "1YearUsageExtPrice"
             , isnull(sum(s.QtyOrdered), 0) as "1YearQtyOrdered"
             , count(1) as "1YearUsageTransactionCount"
       --      , @Past1Year as "1YearAsOfDate"
        from dbo.sales s join dbo.customer c on s.customerid = c.customerid
        where s.transactiondate >= '2020-10-04'--@Past1Year
              and s.[RepackagedFlag] = 0 --and s.CustomerId = 28
        group by s.clientid
               , s.CustomerId
               ,c.customername
               , s.ndc
               , s.PriceTypeGroupId
               , s.SupplierId
               ,s.InvoiceNumber 
               ,s.TransactionDate ) a group by a.customername,a.CustomerId
             
               
          --     select  * from customer where CustomerId =28
               
               select * from SalesTotals st 
 --individual              
 select a.member_identity  , sum(a.TOTALSPEND)  as spend, sum(a.TOTALSPENDR) as spendR       from   
(select	a11.member_key AS member_key,		
	max(a13.member_identity) AS member_identity,		
	a12.ndc AS ndc,		
	a11.invoice_date AS invoice_date,		
	a11.invoice_num AS invoice_num,		
	a11.invoice_price AS invoice_price,		
	Sum(case when a11.matrix_status_key in (0,1,2,4,5,6) then a11.sales_qty else 0 end) AS TOTALUNITS,		
	Sum(case when a11.matrix_status_key in (0,1,2,4,5,6) then round(a11.sales_dollars,0) else 0 end) AS TOTALSPENDR	,
	Sum(case when a11.matrix_status_key in (0,1,2,4,5,6) then a11.sales_dollars else 0 end) AS TOTALSPEND
from fact_bp_sales_detail_view	a11	
	join product_rpt	a12
	 on (a11.product_key = a12.product_key)	
	join member_view	a13
	 on (a11.member_key = a13.member_key)	
where	(a11.month_id in (2021410,2021309, 2021308, 2021307, 2021206, 2021205, 2021204, 2021103, 2021102, 2021101, 
2020412, 2020411, 2020410, 2020309)		
-- and a11.member_key in (310366) and  a11.invoice_date >= '2020-10-04'	
and a13.member_direct_parent_key in (12103) and a11.invoice_date >= '2020-10-04'	
 and a13.member_status in ('ACTIVE', 'TERMINATED'))			
group by	a11.member_key,		
	a12.ndc,		
	a11.invoice_date,		
	a11.invoice_num,		
	a11.invoice_price limit 500001) a group by a.member_identity
	
	select * from product_rpt pr 
	
	--Top health parent              
 select a.member_identity  , sum(a.TOTALSPEND)  as Spends       from   
(select	a11.member_key AS member_key,		
	max(a13.member_identity) AS member_identity,		
	a12.ndc AS ndc,		
	a11.invoice_date AS invoice_date,		
	a11.invoice_num AS invoice_num,		
	a11.invoice_price AS invoice_price,		
	Sum(case when a11.matrix_status_key in (0,1,2,4,5,6) then a11.sales_qty else 0 end) AS TOTALUNITS,		
	Sum(case when a11.matrix_status_key in (0,1,2,4,5,6) then a11.sales_dollars else 0 end) AS TOTALSPEND		
from fact_bp_sales_detail_view	a11	
	join product_rpt	a12
	 on (a11.product_key = a12.product_key)	
	join member_view	a13
	 on (a11.member_key = a13.member_key)	
where	(a11.month_id in (2021410,2021309, 2021308, 2021307, 2021206, 2021205, 2021204, 2021103, 2021102, 2021101, 
2020412, 2020411, 2020410, 2020309)		
 --and a11.member_key in (310366)		
 and a13.member_direct_parent_key in (12103) and a11.invoice_date >= '2020-10-04'		

 and a13.member_status in ('ACTIVE', 'TERMINATED'))			
group by	a11.member_key,		
	a12.ndc,		
	a11.invoice_date,		
	a11.invoice_num,		
	a11.invoice_price limit 500001) a group by a.member_identity
	
	select * from product_rpt pr 

