with maxdate as(
select max(quarterdate) as latestdate from dbo.AspPriceAndLimits  )
currenthpcsselect ndc, max(QuarterDate) as MaxDate
    from dbo.AspPriceAndLimits apal join maxdate on maxdate.latestdate = apal.QuarterDate 
    group by ndc 
 


select 1, SUBSTRING(
                    (   SELECT ', '+hcpcs.HcpcsCode  AS [text()]
                        FROM (
                        with maxdate as(
							select max(quarterdate) as latestdate from dbo.AspPriceAndLimits  )
						currenthcpcs as (
						select ndc, HcpcsCode as MaxDate
   						 from dbo.AspPriceAndLimits apal join maxdate on maxdate.latestdate = apal.QuarterDate 
    						group by ndc )	
                        SELECT DISTINCT apal.HcpcsCode FROM currenthcpcs apal WHERE apal.Ndc = pi.Ndc) AS hcpcs
                        ORDER BY pi.Ndc
                        FOR XML PATH ('')
                    ), 2, 1000) AS HcpcsCode 
            from PharmacyItem pi