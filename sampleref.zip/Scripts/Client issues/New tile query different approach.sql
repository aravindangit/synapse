SELECT * 
FROM (SELECT YEAR(transactiondate) [Year], 
������DATENAME(MONTH, transactiondate) [Month], 
������SUM(Qty * UnitCost) as [Sales Count]
	  sum(Unitcost) as
������     FROM dbo.sales where YEAR(transactiondate) = year(GETDATE()) 
								or 
								YEAR(transactiondate)=(YEAR(GETDATE()) - 1)
������     GROUP BY YEAR(transactiondate), 
������     DATENAME(MONTH, transactiondate)) AS MontlySalesData
PIVOT( SUM([Sales Count])�� 
����FOR Month IN ([January],[February],[March],[April],[May],
����[June],[July],[August],[September],[October],[November],
����[December])) AS pivotname

with FirstCTE as (select * from --[Year],[Month],[Total Spend],[Total Units] from
(SELECT YEAR(transactiondate) [Year], 
	case
�����concat(YEAR(transactiondate),'-',�DATENAME(MONTH, transactiondate)) [Month], 
������SUM(Qty * UnitCost) as [Total Spend]
--	  sum(Unitcost) as [Total Units] 
	  from dbo.sales s join dbo.customer c on s.customerid = c.customerid
where s.customerid = 44 and 
YEAR(s.transactiondate) = year(GETDATE()) 
								or 
								YEAR(s.transactiondate)=(YEAR(GETDATE()) - 1)
GROUP BY YEAR(transactiondate), 
������     DATENAME(MONTH, transactiondate)) AS MontlySalesData
PIVOT( SUM([Total Spend])�� 
����FOR [Month] IN (
		[January],
		[February],
		[March],
		[April],
		[May],
����	[June],
		[July],
		[August],
		[September],
		[October],
		[November],
����	[December])) AS pivotname)




SecondCTE as(
	Select
	[year],
--LAG (salary,1) OVER (ORDER BY salary) AS lower_salary
	CASE
    WHEN [year] = YEAR(GETDATE()) THEN  ([January]+[February]+[March]+[April]+[May]+
����[June]+[July]+[August]+[September]+[October]+isnull([November],0)+
����isnull([December],0)) 
    WHEN [year] = (YEAR(GETDATE()) - 1) THEN ([January]+[February]+[March]+[April]+[May]+
����[June]+[July]+[August]+[September]+[October]+[November]+
����[December])
	END as TotalsByYear,
)

 
SELECT YEAR(s.transactiondate) [Year], 
������MONTH(s.transactiondate) [Month],
	 case when YEAR(s.transactiondate) = year(GETDATE()) and MONTH(s.transactiondate) = 1
	 then sum(Qty * UnitCost) as [Current]

from dbo.sales s join dbo.customer c on s.customerid = c.customerid
where s.customerid = 44 and 
YEAR(s.transactiondate) = year(GETDATE()) 
								or 
								YEAR(s.transactiondate)=(YEAR(GETDATE()) - 1)
GROUP BY YEAR(transactiondate), 
������     MONTH(s.transactiondate)






with FirstCTE as(select * from --[Year],[Month],[Total Spend],[Total Units] from
(SELECT YEAR(transactiondate) [Year], 
	case when year(transactiondate)= year(GETDATE()) then
�����		concat('Current','-',�DATENAME(MONTH, transactiondate)) 
         else 
        	concat('Previous','-',�DATENAME(MONTH, transactiondate))
         end as [Month],
������SUM(Qty * UnitCost) as [Total Spend]
--	  sum(Unitcost) as [Total Units] 
	  from dbo.sales s join dbo.customer c on s.customerid = c.customerid
where s.customerid = 44 and 
YEAR(s.transactiondate) = year(GETDATE()) 
								or 
								YEAR(s.transactiondate)=(YEAR(GETDATE()) - 1)
GROUP BY YEAR(transactiondate), 
������     DATENAME(MONTH, transactiondate)) AS MontlySalesData
PIVOT( SUM([Total Spend])�� 
����FOR [Month] IN (
		[Current-January],
		[Current-February],
		[Current-March],
		[Current-April],
		[Current-May],
����	[Current-June],
		[Current-July],
		[Current-August],
		[Current-September],
		[Current-October],
		[Current-November],
����	[Current-December],
		[Previous-January],
		[Previous-February],
		[Previous-March],
		[Previous-April],
		[Previous-May],
����	[Previous-June],
		[Previous-July],
		[Previous-August],
		[Previous-September],
		[Previous-October],
		[Previous-November],
����	[Previous-December])) AS pivotname1),
SecondCTE as(select * from --[Year],[Month],[Total Spend],[Total Units] from
(SELECT YEAR(transactiondate) [Year2], 
	case when year(transactiondate)= year(GETDATE()) then
�����		concat('Current','-',�DATENAME(MONTH, transactiondate)) 
         else 
        	concat('Previous','-',�DATENAME(MONTH, transactiondate))
         end as [Month],
������SUM(Qty * UnitCost) as [Total Spend]
--	  sum(Unitcost) as [Total Units] 
	  from dbo.sales s join dbo.customer c on s.customerid = c.customerid
where s.customerid = 44 and 
YEAR(s.transactiondate) = year(GETDATE()) 
								or 
								YEAR(s.transactiondate)=(YEAR(GETDATE()) - 1)
GROUP BY YEAR(transactiondate), 
������     DATENAME(MONTH, transactiondate)) AS MontlySalesData
PIVOT( SUM([Total Spend])�� 
����FOR [Month] IN (
		[Current1-January],
		[Current1-February],
		[Current1-March],
		[Current1-April],
		[Current1-May],
����	[Current1-June],
		[Current1-July],
		[Current1-August],
		[Current1-September],
		[Current1-October],
		[Current1-November],
����	[Current1-December],
		[Previous1-January],
		[Previous1-February],
		[Previous1-March],
		[Previous1-April],
		[Previous1-May],
����	[Previous1-June],
		[Previous1-July],
		[Previous1-August],
		[Previous1-September],
		[Previous1-October],
		[Previous1-November],
����	[Previous1-December])) AS pivotname2),
ThirdCTE as(
select * from FirstCTE  cross join SecondCTE where [year] = 2021 and  year2 = 2020 ),
FourthCTE as(select * from --[Year],[Month],[Total Spend],[Total Units] from
(SELECT YEAR(transactiondate) [Year], 
	case when year(transactiondate)= year(GETDATE()) then
�����		concat('Current','-',�DATENAME(MONTH, transactiondate)) 
         else 
        	concat('Previous','-',�DATENAME(MONTH, transactiondate))
         end as [Month],
��
  	  sum(Unitcost) as [Total Units] 
	  from dbo.sales s join dbo.customer c on s.customerid = c.customerid
where s.customerid = 44 and 
YEAR(s.transactiondate) = year(GETDATE()) 
								or 
								YEAR(s.transactiondate)=(YEAR(GETDATE()) - 1)
GROUP BY YEAR(transactiondate), 
������     DATENAME(MONTH, transactiondate)) AS MontlySalesData
PIVOT( SUM([Total Units])�� 
����FOR [Month] IN (
		[Current-January],
		[Current-February],
		[Current-March],
		[Current-April],
		[Current-May],
����	[Current-June],
		[Current-July],
		[Current-August],
		[Current-September],
		[Current-October],
		[Current-November],
����	[Current-December],
		[Previous-January],
		[Previous-February],
		[Previous-March],
		[Previous-April],
		[Previous-May],
����	[Previous-June],
		[Previous-July],
		[Previous-August],
		[Previous-September],
		[Previous-October],
		[Previous-November],
����	[Previous-December])) AS pivotname1),
FifthCTE as(select * from --[Year],[Month],[Total Spend],[Total Units] from
(SELECT YEAR(transactiondate) [Year2], 
	case when year(transactiondate)= year(GETDATE()) then
�����		concat('Current','-',�DATENAME(MONTH, transactiondate)) 
         else 
        	concat('Previous','-',�DATENAME(MONTH, transactiondate))
         end as [Month],
��
  	  sum(Unitcost) as [Total Units] 
	  from dbo.sales s join dbo.customer c on s.customerid = c.customerid
where s.customerid = 44 and 
YEAR(s.transactiondate) = year(GETDATE()) 
								or 
								YEAR(s.transactiondate)=(YEAR(GETDATE()) - 1)
GROUP BY YEAR(transactiondate), 
������     DATENAME(MONTH, transactiondate)) AS MontlySalesData
PIVOT( SUM([Total Units])�� 
����FOR [Month] IN (
		[Current-January],
		[Current-February],
		[Current-March],
		[Current-April],
		[Current-May],
����	[Current-June],
		[Current-July],
		[Current-August],
		[Current-September],
		[Current-October],
		[Current-November],
����	[Current-December],
		[Previous-January],
		[Previous-February],
		[Previous-March],
		[Previous-April],
		[Previous-May],
����	[Previous-June],
		[Previous-July],
		[Previous-August],
		[Previous-September],
		[Previous-October],
		[Previous-November],
����	[Previous-December])) AS pivotname5),
SixthCTE as(
select pivotname5.* from FourthCTE  cross join FifthCTE) --where [year] = 2021 and  year2 = 2020 )


select pivotname5.* from ThirdCTE cross join  SixthCTE


=====================================================================================
SELECT YEAR(s.transactiondate) [Year], 
������MONTH(s.transactiondate) [Month],
	 case when YEAR(s.transactiondate) = year(GETDATE()) and MONTH(s.transactiondate) = 1
	 then sum(Qty * UnitCost) 
	  when YEAR(s.transactiondate) = year(GETDATE()) and MONTH(s.transactiondate) = 2
	 then sum(Qty * UnitCost) 
	  when YEAR(s.transactiondate) = year(GETDATE()) and MONTH(s.transactiondate) = 3
	 then sum(Qty * UnitCost) 
	  when YEAR(s.transactiondate) = year(GETDATE()) and MONTH(s.transactiondate) = 4
	 then sum(Qty * UnitCost) 
	  when YEAR(s.transactiondate) = year(GETDATE()) and MONTH(s.transactiondate) = 5
	 then sum(Qty * UnitCost) 
	  when YEAR(s.transactiondate) = year(GETDATE()) and MONTH(s.transactiondate) = 6
	 then sum(Qty * UnitCost)
	  when YEAR(s.transactiondate) = year(GETDATE()) and MONTH(s.transactiondate) = 7
	 then sum(Qty * UnitCost)
	  when YEAR(s.transactiondate) = year(GETDATE()) and MONTH(s.transactiondate) = 8
	 then sum(Qty * UnitCost) 
	  when YEAR(s.transactiondate) = year(GETDATE()) and MONTH(s.transactiondate) = 9
	 then sum(Qty * UnitCost)
	  when YEAR(s.transactiondate) = year(GETDATE()) and MONTH(s.transactiondate) = 10
	 then sum(Qty * UnitCost)
	  when YEAR(s.transactiondate) = year(GETDATE()) and MONTH(s.transactiondate) = 11
	 then sum(Qty * UnitCost)  
	  when YEAR(s.transactiondate) = year(GETDATE()) and MONTH(s.transactiondate) = 12
	 then sum(Qty * UnitCost)
	 when YEAR(s.transactiondate) = year(GETDATE()-1) and MONTH(s.transactiondate) = 1
	 then sum(Qty * UnitCost) 
	  when YEAR(s.transactiondate) = year(GETDATE()-1) and MONTH(s.transactiondate) = 2
	 then sum(Qty * UnitCost) 
	  when YEAR(s.transactiondate) = year(GETDATE()-1) and MONTH(s.transactiondate) = 3
	 then sum(Qty * UnitCost) 
	  when YEAR(s.transactiondate) = year(GETDATE()-1) and MONTH(s.transactiondate) = 4
	 then sum(Qty * UnitCost) 
	  when YEAR(s.transactiondate) = year(GETDATE()-1) and MONTH(s.transactiondate) = 5
	 then sum(Qty * UnitCost) 
	  when YEAR(s.transactiondate) = year(GETDATE()-1) and MONTH(s.transactiondate) = 6
	 then sum(Qty * UnitCost)
	  when YEAR(s.transactiondate) = year(GETDATE()-1) and MONTH(s.transactiondate) = 7
	 then sum(Qty * UnitCost)
	  when YEAR(s.transactiondate) = year(GETDATE()-1) and MONTH(s.transactiondate) = 8
	 then sum(Qty * UnitCost) 
	  when YEAR(s.transactiondate) = year(GETDATE()-1) and MONTH(s.transactiondate) = 9
	 then sum(Qty * UnitCost)
	  when YEAR(s.transactiondate) = year(GETDATE()-1) and MONTH(s.transactiondate) = 10
	 then sum(Qty * UnitCost)
	  when YEAR(s.transactiondate) = year(GETDATE()-1) and MONTH(s.transactiondate) = 11
	 then sum(Qty * UnitCost)  
	  when YEAR(s.transactiondate) = year(GETDATE()-1) and MONTH(s.transactiondate) = 12
	 then sum(Qty * UnitCost)
	 
	 
	 end as totalquantity,
	  case when YEAR(s.transactiondate) = year(GETDATE()) and MONTH(s.transactiondate) = 1
	 then sum(Qty * UnitCost) 
	  when YEAR(s.transactiondate) = year(GETDATE()) and MONTH(s.transactiondate) = 2
	 then sum(Qty * UnitCost) 
	  when YEAR(s.transactiondate) = year(GETDATE()) and MONTH(s.transactiondate) = 3
	 then sum(Qty * UnitCost) 
	  when YEAR(s.transactiondate) = year(GETDATE()) and MONTH(s.transactiondate) = 4
	 then sum(Qty * UnitCost) 
	  when YEAR(s.transactiondate) = year(GETDATE()) and MONTH(s.transactiondate) = 5
	 then sum(Qty * UnitCost) 
	  when YEAR(s.transactiondate) = year(GETDATE()) and MONTH(s.transactiondate) = 6
	 then sum(Qty * UnitCost)
	  when YEAR(s.transactiondate) = year(GETDATE()) and MONTH(s.transactiondate) = 7
	 then sum(Qty * UnitCost)
	  when YEAR(s.transactiondate) = year(GETDATE()) and MONTH(s.transactiondate) = 8
	 then sum(Qty * UnitCost) 
	  when YEAR(s.transactiondate) = year(GETDATE()) and MONTH(s.transactiondate) = 9
	 then sum(Qty * UnitCost)
	  when YEAR(s.transactiondate) = year(GETDATE()) and MONTH(s.transactiondate) = 10
	 then sum(Qty * UnitCost)
	  when YEAR(s.transactiondate) = year(GETDATE()) and MONTH(s.transactiondate) = 11
	 then sum(Qty * UnitCost)  
	  when YEAR(s.transactiondate) = year(GETDATE()) and MONTH(s.transactiondate) = 12
	 then sum(Qty * UnitCost)
	 when YEAR(s.transactiondate) = year(GETDATE()-1) and MONTH(s.transactiondate) = 1
	 then sum(Qty * UnitCost) 
	  when YEAR(s.transactiondate) = year(GETDATE()-1) and MONTH(s.transactiondate) = 2
	 then sum(Qty * UnitCost) 
	  when YEAR(s.transactiondate) = year(GETDATE()-1) and MONTH(s.transactiondate) = 3
	 then sum(Qty * UnitCost) 
	  when YEAR(s.transactiondate) = year(GETDATE()-1) and MONTH(s.transactiondate) = 4
	 then sum(Qty * UnitCost) 
	  when YEAR(s.transactiondate) = year(GETDATE()-1) and MONTH(s.transactiondate) = 5
	 then sum(Qty * UnitCost) 
	  when YEAR(s.transactiondate) = year(GETDATE()-1) and MONTH(s.transactiondate) = 6
	 then sum(Qty * UnitCost)
	  when YEAR(s.transactiondate) = year(GETDATE()-1) and MONTH(s.transactiondate) = 7
	 then sum(Qty * UnitCost)
	  when YEAR(s.transactiondate) = year(GETDATE()-1) and MONTH(s.transactiondate) = 8
	 then sum(Qty * UnitCost) 
	  when YEAR(s.transactiondate) = year(GETDATE()-1) and MONTH(s.transactiondate) = 9
	 then sum(Qty * UnitCost)
	  when YEAR(s.transactiondate) = year(GETDATE()-1) and MONTH(s.transactiondate) = 10
	 then sum(Qty * UnitCost)
	  when YEAR(s.transactiondate) = year(GETDATE()-1) and MONTH(s.transactiondate) = 11
	 then sum(Qty * UnitCost)  
	  when YEAR(s.transactiondate) = year(GETDATE()-1) and MONTH(s.transactiondate) = 12
	 then sum(Qty * UnitCost)
	 
	 
	 end as totalunits

from dbo.sales s join dbo.customer c on s.customerid = c.customerid
where s.customerid = 44 and 
YEAR(s.transactiondate) = year(GETDATE()) 
								or 
								YEAR(s.transactiondate)=(YEAR(GETDATE()) - 1)
GROUP BY YEAR(transactiondate), 
������     MONTH(s.transactiondate)