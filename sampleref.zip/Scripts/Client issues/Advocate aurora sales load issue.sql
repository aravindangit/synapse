SELECT count(*) FROM Raw.sales   --1724232
select count(*) from raw.PurchaseOrders po  --1724232


SELECT count(*) FROM dbo.sales  

--select * from dbo.Sales s --1724232
select count(*) from dbo.PurchaseOrder po 


select * from dbo.Sales s 

select * from Customer c 

select *
from [Raw].[PremierCustomerList]
where [Health System ID] = '@{pipeline().parameters.HealthSystemID}'

SELECT PremierCustomerSyncId, DataFactory, HealthSystemID, FacilityDirectParentID, Secret, DatasetInvoiceCode, DatasetPoCode, Status
FROM sqldbCogRxProdMasterdataSync.SyncControl.PremierCustomerSync;

select * from [dbo].[CustomerOrganization]  

select * from dbo.CustomerItem
select * from dbo.CustomerItemPricing cip 

select count(*) from dbo.SalesTotals st 
select * from dbo.SalesTotals st 
select count(*) from dbo.SalesTotalMonthly stm 

select * from client

--customer organization
select distinct fm.ClientId, 
                       [Facility Direct Parent ID] 'OrganizationNumber', 
					   [Facility Direct Parent] 'OrganizationName' ,
					   1 'IsActive'
		from [Raw].[PremierCustomerList] pcl
			inner join [dbo].[ImportFileIDMapping] fm
				on pcl.[Health System ID] = fm.ClientImportCode
		where [Health System ID] is not null
		
--customer table DataSource 
		select * from dbo.Customer c 

select distinct fm.ClientId 'clientid', 
					pcl.[Facility ID] 'AccountNumber', 
					pcl.[Facility Name] 'CustomerName', 
					pcl.[Facility AddrLine1] 'Address1', 
					pcl.[Facility AddrLine2] 'Address2', 
 					pcl.[Facility City]      'City',
					pcl.[Facility State]     'State', 
					pcl.[Facility Zip]       'Zip',
					pcl.[Facility DEA]       'DEA',
					pcl.[Premier_Relation]       'Premier_Relation',
					pcl.[SPC]       'SPC',
					pcl.[Division Name]       'Division Name',
					pcl.[DivisionId]       'DivisionId',
					co.CustomerOrganizationId 'CustomerOrganizationId', 
					--pcl.[Facility Direct Parent ID] 'OrganizationNumber', 
					--pcl.[Facility Direct Parent] 'OrganizationName',

--updating top parent to org name & ID
					case when fm.ClientImportCode='NY5011' then pcl.[Facility Direct Parent ID] else pcl.[Health System ID] end 'OrganizationNumber',
					case when fm.ClientImportCode='NY5011' then pcl.[Facility Direct Parent] else pcl.[Health System] end 'OrganizationName'
					from [Raw].[PremierCustomerList] pcl
						inner join [dbo].[ImportFileIDMapping] fm
							on pcl.[Health System ID] = fm.ClientImportCode
						inner join CustomerOrganization co
							on pcl.[Facility Direct Parent ID] = co.[OrganizationNumber]
							
							select * from raw.Sales s 
		
		
		select * from [dbo].[ImportFileIDMapping]
--issue1--three rows were not available 
		INSERT INTO [dbo].[ImportFileIDMapping] (ClientImportCode,Description,ClientId,ClientSupplierId,CpSupplierID,CustomerId,PriceListId,DataSourceId,PayerId,ReimbursementTypeId,ImportFileFrequencyTypeId,ImportFileMapUId,MPBFlag) VALUES
	 (N'PremierWholesaleInvoice',N'PremierWholesaleInvoice',7,NULL,1,NULL,NULL,17,NULL,NULL,1,N'689D401B-1A92-45EC-90E4-90031E29BC4F',NULL),
	 (N'PremierWholesalePO',N'PremierWholesalePO',7,NULL,1,NULL,NULL,17,NULL,NULL,1,N'B818CBD9-FBF5-4264-AF09-F5A35CD3EE30',NULL),
	 (N'WI0013',N'Premier Health System Id',7,NULL,NULL,NULL,NULL,17,NULL,NULL,NULL,N'69285D47-47BF-45EC-B9C2-4803A3B0C968',NULL);
	
	select * from dbo.DataSource ds where ds.DataSourceUID is NULL 
	
	INSERT INTO dbo.DataSource (DataSourceDesciption,DataSourceUID) VALUES
	 (N'FFF',NULL),
	 (N'Direct Entry',NULL),
	 (N'Apexus',NULL),
	 (N'AMERISOURCE BERGEN',NULL),
	 (N'GPO',NULL);
	 
	
--------------start-------------------------------
select ifm.[ClientId],
	   c.[CustomerId],
	   su.SupplierId SupplierId,
	   su.SupplierName SupplierName,
	   pi.ItemId,
       s.[TransactionDate],
       s.[Ndc],
       s.[ItemDescription],
       s.[OrderNumber],
       s.[LineNumber],
       s.[OrderType],
       s.[Qty],
	   s.[QtyOrdered],
      s.[UnitCost],
 s.[UnitPrice],
       s.[UOM],
       s.[InvoiceNumber],
	   s.[WholesalerAccountNumber],
	   s.[ChargeBackContractNumber],
	   s.[Markup/Markdown],
	   ptx.[PriceTypeGroupId],
	   s.[Address1],
	   s.[Address2],
	   s.[City],
	   s.[State],
	   s.[ZipCode],
	   format(ca.FirstDateOfQuarter,'yyyyMMdd') QuarterDate,
       s.[ImportedDate],
	   ifm.[DataSourceId],
	   s.[ProcessPipelineId],
	   case when s.OrderType in ('CPAK Return', 'DOD Order', 'DOD Return', 'Order CPAK') then 1 else 0 end RepackagedFlag
from [Raw].[Sales] s
  inner join [dbo].[ImportFileIDMapping] ifm
     on s.[DataSource] = ifm.[ClientImportCode]
  inner join [dbo].[Customer] c
     on s.[Account] = c.[AccountNumber]
	and ifm.ClientId = c.ClientId
  left join [dbo].[PharmacyItem] pi
     on s.ndc = pi.Ndc
  inner join Calendar ca
     on ifm.[ClientId] = ca.ClientId
	and s.TransactionDate = ca.CalendarDate
  left join Mapping.[PriceTypeGroupXref] ptx
	on c.ClientId = ptx.clientid
	and s.WholesalerAccountAttribute = ptx.[ClientPriceTypeCode]		
  left join supplier su
	on s.Wholesaler = su.SupplierName
where su.SupplierTypeId= 2 and su.MfrId is null
--------------end---------------------------------