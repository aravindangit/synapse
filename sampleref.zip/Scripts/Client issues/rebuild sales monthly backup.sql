-- =============================================
-- Author:		
-- Create date: November 2021
-- Description:	Rebuild the SalesTotalMonthly table with latest numbers
-- =============================================
ALTER PROCEDURE [DailyMaintinance].[RebuildSalesTotalMonthly]
as
begin
    -- SET NOCOUNT ON added to prevent extra result sets from interfering with SELECT statements.
    set nocount on;

    /*
    Notes on creating this procedure
    - Truncate existing table, if we go that route
    - Create CTE from Sales table
        - split transaction date into month and year columns (ints)
        - group and aggregate
    - merge or insert into existing table (for now, I'm just truncating/inserting instead of merging)
        -- match on key, update
        - new? insert
        - does not exist? ....hmm. delete, I suppose
            -- so, there might be value in keeping data past 3 years in this table. but we also don't want to risk having data in the table that does not line up to the sales table
            -- ultimately, I think it would make sense to keep a history past 3 years, but I think it requires more thought on how to work that into our archive/history process
    - rebuild indexes?    
    */

    -- we should examine if truncating or merginging is more performant
    truncate table [dbo].[SalesTotalMonthly];

    with SalesCte
    as (select ClientId
             , CustomerId
             , Ndc
             , PriceTypeGroupId
             , SupplierId
             , WholesalerAccountNumber
             , year(TransactionDate) as DateYear
             , month(TransactionDate) as DateMonth
             , isnull(Qty, 0) as QtyReceived
             , isnull(QtyOrdered, 0) as QtyOrdered
             -- converting from money to numeric. prices are (13,6) precision. large aggregates requires larger precision
             -- see https://docs.microsoft.com/en-us/sql/t-sql/data-types/decimal-and-numeric-transact-sql?view=sql-server-ver15 
             , isnull(round((qty * cast(unitprice as numeric(22,6))),6),0) as ExtendedPrice
        from Sales)
       , SalesAggregateCte
    as (select ClientId
             , CustomerId
             , Ndc
             , PriceTypeGroupId
             , SupplierId
             , WholesalerAccountNumber
             , DateYear
             , DateMonth
             , sum(QtyReceived) as QtyReceived
             , sum(QtyOrdered) as QtyOrdered
             , sum(ExtendedPrice) as ExtendedPrice
             , count(1) as TransactionCount
        from SalesCte
        group by ClientId
               , CustomerId
               , Ndc
               , PriceTypeGroupId
               , SupplierId
               , WholesalerAccountNumber
               , DateYear
               , DateMonth)
    --select * from SalesAggregateCte

    insert into [dbo].[SalesTotalMonthly]
    (
        [ClientId]
      , [CustomerId]
      , [Ndc]
      , [PriceTypeGroupId]
      , [SupplierId]
      , [WholesalerAccountNumber]
      , [DateYear]
      , [DateMonth]
      , [QtyOrdered]
      , [QtyReceived]
      , [ExtendedPrice]
      , [TransactionCount]
    )
    select ClientId
         , CustomerId
         , Ndc
         , PriceTypeGroupId
         , SupplierId
         , WholesalerAccountNumber
         , DateYear
         , DateMonth
         , QtyOrdered
         , QtyReceived
         , ExtendedPrice
         , TransactionCount
    from SalesAggregateCte;

end;

exec [DailyMaintinance].[RebuildSalesTotal];