SELECT distinct sw.ShortageWatchId,
		            pi.Ndc,
		            pi.ItemDescription,
                    pi.Manufacturer, 
		            sw.ProbabilityPercentage,
					swpt.Description [ProbabilityDescription],
                    sw.ProbabilityChange,
                    sw.IsNew,
		            sw.PeriodStartDate,
		            sw.PeriodEndDate,
                    sw.IsActive,
		            CASE WHEN cds.CustomerDrugShortageId IS NOT NULL THEN 1 ELSE 0 END AS IsManaged
				    , CASE pi.IsGenericDrug WHEN 0 THEN 'Brand' ELSE 'Generic' END IsGeneric
					, st.Days30Qty, st.Days30QtyOrdered
					, swr.Sources
					, cds.CustomerDrugShortageId
					, CASE
					    WHEN CHARINDEX('Unknown - ',cm.CustomerName) > 0 THEN cm.CustomerName
						WHEN cm.DEA IS NULL THEN cm.CustomerName + ' - ' + cm.AccountNumber
						ELSE cm.CustomerName + ' - ' + cm.AccountNumber + ' - ' + cm.DEA 
					END AS Facility,
					cm.CustomerId
    --        INTO #shortages
	        FROM Watch.ShortageWatch sw
				LEFT OUTER JOIN (
					SELECT swr.ShortageWatchId
						, swr.IsActive
						, replace(string_agg((swrt.Description),', ') WITHIN GROUP (ORDER BY swrt.Description ASC), ' Shortage','') as Sources
					FROM Watch.ShortageWatchReason AS swr
					left join watch.ShortageWatchReasonType swrt 
					on swrt.ShortageWatchReasonTypeId=swr.ShortageWatchReasonTypeId
					GROUP BY swr.ShortageWatchId, swr.IsActive) AS swr 
					ON sw.ShortageWatchId = swr.ShortageWatchId AND swr.IsActive = 1
				JOIN Watch.ShortageWatchProbabilityRange swpr ON sw.ClientId = swpr.ClientId
				JOIN Watch.ShortageWatchProbabilityType swpt 
				ON swpr.ShortageWatchProbabilityTypeId = swpt.ShortageWatchProbabilityTypeId
		        JOIN dbo.PharmacyItem pi ON sw.ItemId = pi.ItemId				
				LEFT OUTER JOIN CustomerDrugShortage AS cds ON cds.Ndc = pi.Ndc AND cds.ShortageStatusId = 1
                LEFT OUTER JOIN dbo.CustomerItemPricing AS cip ON cip.ItemId = pi.ItemId
				LEFT OUTER JOIN dbo.Customer AS cm ON cm.CustomerId = cip.CustomerId
				LEFT OUTER JOIN (
					SELECT st.ClientId
						, st.Ndc
						, st.ItemId
						, st.CustomerId
						, sum(st.[30DayUsageQty]) as Days30Qty, sum(st.[30DayQtyOrdered]) as Days30QtyOrdered
						FROM SalesTotals AS st 
						WHERE st.ClientId = 3
						GROUP BY st.Ndc, st.ItemId, st.ClientId, st.CustomerId) AS st ON st.Ndc = sw.Ndc AND st.ClientId = sw.ClientId and st.CustomerId=cm.CustomerId
	        WHERE sw.ClientId = 3
		        AND sw.IsActive = 1
				AND sw.ProbabilityPercentage > swpr.ProbabilityLow AND sw.ProbabilityPercentage <= swpr.ProbabilityHigh
		        and not exists (select 1 from dbo.CustomerDrugShortage cds where cds.Ndc = pi.Ndc and cds.ShortageStatusId = 1 and cds.ClientId = 3)
		        
		        
		        
		        
		        
		        
		        select * from dbo.CustomerDrugShortage cds 
		        
		        select * from dbo.Customer c 
		        
		        
		        declare @StartDate datetime = DATEADD(dd, DATEDIFF(dd, 0, getdate()), 0);
		      select @StartDate
		      --4948
		      
		     select count(distinct(NDC)) select * from [Watch].[NationalShortageWatch]
		        