
--E:\akenned2\source\repos\MarginAnalysis\API\MA_Common\Services\Shortage\Queries\ShortageQueries.cs
SELECT pis.Id
                 , pis.ItemId
                 , pis.Ndc
                 , pis.Source
                 , pis.STATUS
                 , pi.ItemDescription
                 , pis.UpdatedDate
                 , affectedNdcs.Ndcs AffectedNdcs
                 , availableNdcs.AvailableNdcs
                 , pis.ExternalLink
                 , pis.Reasons
                 , pis.EstimatedResupply
            FROM PharmacyItemShortage pis
                 JOIN PharmacyItem pi ON pis.ItemId = pi.ItemId
                 LEFT JOIN (
		            SELECT pisg.ExternalId
			             , STUFF(
				            (
					            --split each NDC by pipe, with optional description after tilda
					            SELECT N'|' + CASE
									              WHEN pii.ItemId IS NOT NULL
									              THEN dbo.FormatNdc(pisi.Ndc) + '~' + pii.ItemDescription
									              ELSE dbo.FormatNdc(pisi.Ndc)
								              END Ndc
					            FROM PharmacyItemShortage pisi
						             LEFT JOIN PharmacyItem pii ON pisi.Ndc = pii.Ndc
					            WHERE pisi.ExternalId = pisg.ExternalId
					            ORDER BY pii.ItemDescription FOR XML PATH(N''), TYPE
				            ).value(N'.[1]', N'nvarchar(max)'), 1, 1, N'') Ndcs
		            FROM PharmacyItemShortage pisg
		            GROUP BY pisg.ExternalId
	            ) affectedNdcs ON pis.ExternalId = affectedNdcs.ExternalId
                 LEFT JOIN (
		            SELECT pisg.Ndc
			             , STUFF((
			            --split each NDC by pipe, with optional description after tilda
			            SELECT N'|' + CASE
							              WHEN pia.ItemId IS NOT NULL
							              THEN dbo.FormatNdc(pissa.Value) + '~' + pia.ItemDescription
							              ELSE dbo.FormatNdc(pissa.Value)
						              END Ndc
			            FROM PharmacyItemShortage pisa
				             CROSS APPLY STRING_SPLIT(pisa.AvailableNdcs, ',') AS pissa
				             LEFT JOIN PharmacyItem pia ON pia.Ndc = dbo.FormatNdc(pissa.Value)
			            WHERE pisg.Ndc = pisa.Ndc
			            ORDER BY pia.ItemDescription FOR XML PATH(N''), TYPE
		            ).value(N'.[1]', N'nvarchar(max)'), 1, 1, N'') AvailableNdcs
		            FROM PharmacyItemShortage pisg
		            GROUP BY pisg.Ndc
	            ) availableNdcs ON pis.Ndc = availableNdcs.Ndc
            WHERE pis.Ndc = '63323001201'; --Param"