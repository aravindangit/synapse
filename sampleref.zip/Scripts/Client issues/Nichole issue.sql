SELECT AspPriceId, Ndc, itemId, QuarterDate, RevisionDate, HcpcsCode, HCPCSDescription, HcpcsCodeDosage, AspUnitPrice, PaymentLimit, IndependentEsrdLimit, VaccineLimit, DMEInfusionLimit, BloodLimit, PackageSize, PackageQuantity, BillableUnitsPerPackage, BillableUnitsPer11DigitNDC, IsCurrentRecords, ItemMasterItemId, DateAdded, DateChanged, ItemUId, DataSourceId
FROM sqldbCogRxProdNorthwell.dbo.AspPriceAndLimits;


select * from dbo.sales where InvoiceNumber in  ('3109489','3158025')

select * from [dbo].[PharmacyItem] 
where ndc in(select NDC from dbo.sales where InvoiceNumber in  ('3109489','3158025'))

select distinct(NDC) from dbo.sales where ndc not in (select ndc from dbo.PharmacyItem)



select * from [dbo].[PharmacyItem] where ndc= '25866056953'

select * from [dbo].[PharmacyItem] where ItemDescription like '%Senna%'
select distinct(divisionname) from dbo.Customer c 