select * from dbo.Sales s 

select * into dbo.salestotalsbkp1025 from SalesTotals st 


drop table SalesTotals


-- sqldbCogRxProdStLukes.dbo.SalesTotals definition

-- Drop table

-- DROP TABLE sqldbCogRxProdStLukes.dbo.SalesTotals;

CREATE TABLE dbo.SalesTotals (
	ClientId int NOT NULL,
	CustomerId int NOT NULL,
	Ndc varchar(11) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	PriceTypeGroupId int NOT NULL,
	SupplierId int NOT NULL,
	ItemId int NULL,
	EarliestAsOfDate date NULL,
	CreatedDate datetime DEFAULT getutcdate() NULL,
	UpdatedDate datetime DEFAULT getutcdate() NULL,
	[30DayQtyOrdered] int DEFAULT 0 NOT NULL,
	[30DayUsageQty] int DEFAULT 0 NOT NULL,
	[30DayUsageExtPrice] money DEFAULT 0 NOT NULL,
	[30DayUsageTransactionCount] int DEFAULT 0 NOT NULL,
	[30DayAsOfDate] date NULL,
	[60DayQtyOrdered] int DEFAULT 0 NOT NULL,
	[60DayUsageQty] int DEFAULT 0 NOT NULL,
	[60DayUsageExtPrice] money DEFAULT 0 NOT NULL,
	[60DayUsageTransactionCount] int DEFAULT 0 NOT NULL,
	[60DayAsOfDate] date NULL,
	[90DayQtyOrdered] int DEFAULT 0 NOT NULL,
	[90DayUsageQty] int DEFAULT 0 NOT NULL,
	[90DayUsageExtPrice] money DEFAULT 0 NOT NULL,
	[90DayUsageTransactionCount] int DEFAULT 0 NOT NULL,
	[90DayAsOfDate] date NULL,
	[6MonthQtyOrdered] int DEFAULT 0 NOT NULL,
	[6MonthUsageQty] int DEFAULT 0 NOT NULL,
	[6MonthUsageExtPrice] money DEFAULT 0 NOT NULL,
	[6MonthUsageTransactionCount] int DEFAULT 0 NOT NULL,
	[6MonthAsOfDate] date NULL,
	[1YearQtyOrdered] int DEFAULT 0 NOT NULL,
	[1YearUsageQty] int DEFAULT 0 NOT NULL,
	[1YearUsageExtPrice] money DEFAULT 0 NOT NULL,
	[1YearUsageTransactionCount] int DEFAULT 0 NOT NULL,
	[1YearAsOfDate] date NULL,
	[2YearQtyOrdered] int DEFAULT 0 NOT NULL,
	[2YearUsageQty] int DEFAULT 0 NOT NULL,
	[2YearUsageExtPrice] money DEFAULT 0 NOT NULL,
	[2YearUsageTransactionCount] int DEFAULT 0 NOT NULL,
	[2YearAsOfDate] date NULL,
	TotalDayQtyOrdered int DEFAULT 0 NOT NULL,
	TotalDayUsageQty int DEFAULT 0 NOT NULL,
	TotalDayUsageExtPrice money DEFAULT 0 NOT NULL,
	TotalDayUsageTransactionCount int DEFAULT 0 NOT NULL,
	CONSTRAINT PK_SalesTotals PRIMARY KEY (ClientId,CustomerId,Ndc,PriceTypeGroupId,SupplierId)
);
 CREATE NONCLUSTERED INDEX IX_SalesTotals_CliendId_CustomerId_ItemId ON dbo.SalesTotals (  ClientId ASC  , CustomerId ASC  , ItemId ASC  )  
	 WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
	 ON [PRIMARY ] ;
 CREATE NONCLUSTERED INDEX IX_SalesTotals_CliendId_CustomerId_Ndc ON dbo.SalesTotals (  ClientId ASC  , CustomerId ASC  , Ndc ASC  )  
	 WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
	 ON [PRIMARY ] ;
 CREATE NONCLUSTERED INDEX IX_SalesTotals_CliendId_Ndc ON dbo.SalesTotals (  ClientId ASC  , Ndc ASC  )  
	 WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
	 ON [PRIMARY ] ;
 CREATE NONCLUSTERED INDEX IX_SalesTotals_ClientIdItemId ON dbo.SalesTotals (  ClientId ASC  , ItemId ASC  )  
	 WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
	 ON [PRIMARY ] ;
 CREATE NONCLUSTERED INDEX IX_SalesTotals_ItemId ON dbo.SalesTotals (  ItemId ASC  )  
	 WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
	 ON [PRIMARY ] ;
 CREATE NONCLUSTERED INDEX IX_SalesTotals_Ndc ON dbo.SalesTotals (  Ndc ASC  )  
	 WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
	 ON [PRIMARY ] ;


-- sqldbCogRxProdStLukes.dbo.SalesTotals foreign keys

ALTER TABLE dbo.SalesTotals ADD CONSTRAINT FK_SalesTotals_Client_ClientId FOREIGN KEY (ClientId) REFERENCES dbo.Client(ClientId);
ALTER TABLE dbo.SalesTotals ADD CONSTRAINT FK_SalesTotals_Customer FOREIGN KEY (CustomerId) REFERENCES dbo.Customer(CustomerId);
ALTER TABLE dbo.SalesTotals ADD CONSTRAINT fk_SalesTotals_PriceTypeGroupId FOREIGN KEY (PriceTypeGroupId) REFERENCES dbo.PriceTypeGroup(PriceTypeGroupId);
ALTER TABLE dbo.SalesTotals ADD CONSTRAINT fk_SalesTotals_Supplier FOREIGN KEY (SupplierId) REFERENCES dbo.Supplier(SupplierId);
ALTER TABLE dbo.SalesTotals ADD CONSTRAINT fk_SalesTotals_itemId FOREIGN KEY (ItemId) REFERENCES dbo.PharmacyItem(ItemId);

select * from dbo.SalesTotals st 
exec DailyMaintinance.RebuildSalesTotal

select sum(Qty * UnitCost) from dbo.Sales s where customerid=548

select * from Customer c 

select
-- s.WholesalerAccountNumber as WAN
--, s.SupplierName as Wholesaler
sum([30DayUsageExtPrice]) as TotalCost30Day
, sum([60DayUsageExtPrice]) as TotalCost60Day
, sum([90DayUsageExtPrice]) as TotalCost90Day
, sum([1YearUsageExtPrice]) as TotalCost
--, c.CustomerId
--, c.CustomerName
from dbo.SalesTotals st 
join dbo.Sales s on s.CustomerId = st.CustomerId
where st.Customerid = 548
--group by s.WholesalerAccountNumber, s.SupplierName

2311858


select 
st.CustomerId,
s.WholesalerAccountNumber as WAN
, s.SupplierName as Wholesaler
--, c.CustomerName
, sum([30DayUsageExtPrice]) as TotalCost30Day
, sum([60DayUsageExtPrice]) as TotalCost60Day
, sum([90DayUsageExtPrice]) as TotalCost90Day
, sum([1YearUsageExtPrice]) as TotalCost
from dbo.sales s
left join dbo.salestotals st on st.ClientId = s.ClientId and st.SupplierId =s.SupplierId  and st.ItemId =s.ItemId 
join dbo.Customer c on c.CustomerId = s.CustomerId and c.ClientId = s.ClientId and c.CustomerId = st.CustomerId 
--and st.SupplierName =s.SupplierName 

where st.ClientId = 6
and st.Customerid = 44 --and s.WholesalerAccountNumber  = '2311858'
-- and OrganizationName = @name --Param
group by st.customerid,s.WholesalerAccountNumber, s.SupplierName,s.customerid
--wholesaler number 2311858
select distinct WholesalerAccountNumber from dbo.sales where Customerid = 44

select  * from dbo.sales where CustomerId =548 ;
select  * from dbo.SalesTotals where CustomerId =548 ;


select * from Customer where CustomerName like '%glen%'


select
c.CustomerId
, c.CustomerName
,(SELECT top 1 wholesaleraccountnumber FROM dbo.sales s WHERE s.customerid = c.CustomerId) AS WAN
,(SELECT top 1 SupplierName FROM dbo.sales s WHERE s.customerid = c.CustomerId) AS Suppliername
, sum([30DayUsageExtPrice]) as TotalCost30Day
, sum([60DayUsageExtPrice]) as TotalCost60Day
, sum([90DayUsageExtPrice]) as TotalCost90Day
, sum([1YearUsageExtPrice]) as TotalCost
from dbo.SalesTotals st
join dbo.Customer c on c.CustomerId = st.CustomerId and c.ClientId = st.ClientId
where st.ClientId = 6
and st.Customerid = 548
-- and OrganizationName = @name --Param
group by c.CustomerId, c.CustomerName 

select distinct wholesaleraccountnumber from dbo.sales where customerid = 44

select * from salestotals

548 100
salestotal
548 1 2 3