Premier_Relation varchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	SPC nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
	
	
---National wholesaler change	
	ALTER TABLE Raw.PremierCustomerList 
    ADD 
        [Premier_Relation] VARCHAR (255)  ,
		[SPC] VARCHAR (255);
		
	
---Client database premiercustomer list
	ALTER TABLE Raw.PremierCustomerList 
    ADD 
        [Premier_Relation] VARCHAR (255)  ,
		[SPC] VARCHAR (255);
---Client database customer table	
	ALTER TABLE dbo.Customer 
    ADD 
        [Premier_Relation] VARCHAR (255)  ,
		[SPC] VARCHAR (255);
		
--stored procedure change
	
	