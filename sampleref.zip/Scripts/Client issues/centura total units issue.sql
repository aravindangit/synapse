select top 1000 * from dbo.SalesTotalMonthly stm 
select CURRENT_TIMESTAMP 

--SELECT * FROM client
declare @clientId int = 2;
declare @id varchar(10) = '838509';

drop table if exists #SPENDBYMONTHLY;
drop table if exists #SPENDBYYEARLY1;
drop table if exists #SPENDBYYEARLY2;
DECLARE @CURMONTH INT = DATEPART(m, GETDATE()) ;

            ;WITH R(N) AS
            (
                SELECT 1 UNION ALL SELECT N+1 FROM R
                WHERE N < 12
            ),

            PSTM AS (select R.N, UPPER(LEFT(DateName( month , DateAdd( month , R.N , -1 )),3)) AS MONTH, ISNULL(t.PCOST,0) AS PCOST, ISNULL(CAST(t.PUNITS AS BIGINT),0) AS PUNITS from R 
			Left JOIN (
			SELECT  stm.DateMonth, C.DIVISIONID,  
			CASE WHEN stm.DateMonth < @CURMONTH THEN SUM(STM.ExtendedPrice) ELSE 0 END AS PCOST  , 
			CASE WHEN stm.DateMonth < @CURMONTH THEN SUM(STM.QtyReceived) ELSE 0 END AS PUNITS
            FROM  SalesTotalMonthly STM			 
			JOIN CUSTOMER C ON C.CUSTOMERID = STM.CUSTOMERID 
			and STM.DateYear IN (YEAR(GETDATE()) - 1) AND STM.ClientId=@clientId  AND C.DIVISIONID=@id 
            GROUP BY C.DIVISIONID, stm.DateMonth )t on R.n = t.DateMonth
            ),

            CSTM AS (select R.N, UPPER(LEFT(DateName( month , DateAdd( month , R.N , -1 )),3)) AS MONTH, ISNULL(t.CCOST,0) AS CCOST, ISNULL(CAST(t.CUNITS AS BIGINT),0) AS CUNITS from R 
			Left JOIN (
			SELECT  stm.DateMonth, C.DIVISIONID,  
			CASE WHEN stm.DateMonth < @CURMONTH THEN SUM(STM.ExtendedPrice) ELSE 0 END AS CCOST  , 
			CASE WHEN stm.DateMonth < @CURMONTH THEN SUM(STM.QtyReceived) ELSE 0 END AS CUNITS
            FROM  SalesTotalMonthly STM			 
			JOIN CUSTOMER C ON C.CUSTOMERID = STM.CUSTOMERID 
			and STM.DateYear IN (YEAR(GETDATE())) AND STM.ClientId=@clientId  AND C.DIVISIONID=@id 
            GROUP BY C.DIVISIONID, stm.DateMonth )t on R.n = t.DateMonth
            )			

            SELECT P.N,P.[MONTH] as TransactionMonth, 
			CASE WHEN P.N < @CURMONTH THEN CCOST ELSE NULL END AS CCOST ,  
			CASE WHEN P.N < @CURMONTH THEN CUNITS ELSE NULL END AS CUNITS , 
			YEAR(GETDATE())  AS CDATEYEAR, 
			CASE WHEN P.N < @CURMONTH THEN PCOST ELSE NULL END AS PCOST,  
			CASE WHEN P.N < @CURMONTH THEN PUNITS ELSE NULL END AS PUNITS, 
			YEAR(GETDATE()) - 1  AS PDATEYEAR, 
            CASE WHEN PCOST > 0 THEN CAST((CCOST - PCOST) AS FLOAT) / CAST(PCOST AS FLOAT) * 100 * 100 / 100.00 ELSE 0.00 END CCHANGE,
            CASE WHEN PUNITS > 0 THEN CAST((CUNITS -  PUNITS) as float) / cast(PUNITS as float) * 100 * 100 /100.00  ELSE 0 END UCHANGE 
            INTO #SPENDBYMONTHLY FROM 
            PSTM P JOIN CSTM C ON P.N = C.N
            ORDER BY P.N;

			SELECT O.N AS ID,* INTO #SPENDBYYEARLY1 FROM (			
			SELECT * FROM #SPENDBYMONTHLY 
			UNION ALL
			SELECT 13 AS N,'SUMMARY' AS TRANSACTIONMONTH, SUM(T.CCOST) AS CCOST,  SUM(T.CUNITS) AS CUNITS, MAX(T.CDATEYEAR) AS CDATEYEAR, 
			SUM(T.PCOST) AS PCOST,  SUM(T.PUNITS) AS PUNITS, MAX(T.PDATEYEAR) AS PDATEYEAR,
			SUM(T.CCHANGE) CCHANGE,SUM(T.UCHANGE) UCHANGE            
			FROM
			#SPENDBYMONTHLY T
			)O ORDER BY O.N;


			;WITH R(N) AS
            (
                SELECT 1 UNION ALL SELECT N+1 FROM R
                WHERE N < 12
            ),

            PSTM AS (select R.N, UPPER(LEFT(DateName( month , DateAdd( month , R.N , -1 )),3)) AS MONTH, ISNULL(t.PCOST,0) AS PCOST, ISNULL(CAST(t.PUNITS AS BIGINT),0) AS PUNITS from R 
			Left JOIN (
			SELECT  stm.DateMonth, C.DIVISIONID,  
			SUM(STM.ExtendedPrice) AS PCOST  , 
			SUM(STM.QtyReceived)  PUNITS
            FROM  SalesTotalMonthly STM			 
			JOIN CUSTOMER C ON C.CUSTOMERID = STM.CUSTOMERID 
			and STM.DateYear IN (YEAR(GETDATE()) - 2) AND STM.ClientId=@clientId  AND C.DIVISIONID=@id 
            GROUP BY C.DIVISIONID, stm.DateMonth )t on R.n = t.DateMonth
            ),

            CSTM AS (select R.N, UPPER(LEFT(DateName( month , DateAdd( month , R.N , -1 )),3)) AS MONTH, ISNULL(t.CCOST,0) AS CCOST, ISNULL(CAST(t.CUNITS AS BIGINT),0) AS CUNITS from R 
			Left JOIN (
			SELECT  stm.DateMonth, C.DIVISIONID,  
			SUM(STM.ExtendedPrice)  AS CCOST  , 
			SUM(STM.QtyReceived) AS CUNITS
            FROM  SalesTotalMonthly STM			 
			JOIN CUSTOMER C ON C.CUSTOMERID = STM.CUSTOMERID 
			and STM.DateYear IN (YEAR(GETDATE()) - 1) AND STM.ClientId=@clientId  AND C.DIVISIONID=@id 
            GROUP BY C.DIVISIONID, stm.DateMonth )t on R.n = t.DateMonth
            )	

            SELECT P.N,P.[MONTH] as TransactionMonth, 
			CCOST ,  
			CUNITS , 
			YEAR(GETDATE()) - 1  AS CDATEYEAR, 
			PCOST,  
			PUNITS, 
			YEAR(GETDATE()) - 2  AS PDATEYEAR, 
            CASE WHEN PCOST > 0 THEN CAST((CCOST - PCOST) AS FLOAT) / CAST(PCOST AS FLOAT) * 100 * 100 / 100.00 ELSE 0.00 END CCHANGE,
            CASE WHEN PUNITS > 0 THEN CAST((CUNITS -  PUNITS) as float) / cast(PUNITS as float) * 100 * 100 /100.00  ELSE 0 END UCHANGE 
            INTO #SPENDBYMONTHLY1 FROM 
            PSTM P JOIN CSTM C ON P.N = C.N
            ORDER BY P.N;

			SELECT O.N + 13 AS ID,* INTO #SPENDBYYEARLY2 FROM (			
			SELECT * FROM #SPENDBYMONTHLY1
			UNION ALL
			SELECT 13 AS N,'SUMMARY' AS TRANSACTIONMONTH, SUM(T.CCOST) AS CCOST,  SUM(T.CUNITS) AS CUNITS, MAX(T.CDATEYEAR) AS CDATEYEAR, 
			SUM(T.PCOST) AS PCOST,  SUM(T.PUNITS) AS PUNITS, MAX(T.PDATEYEAR) AS PDATEYEAR,
			SUM(T.CCHANGE) CCHANGE,SUM(T.UCHANGE) UCHANGE            
			FROM
			#SPENDBYMONTHLY1 T
			)O ORDER BY O.N;

			SELECT * FROM (
			SELECT * FROM #SPENDBYYEARLY1
			UNION ALL
			SELECT * FROM #SPENDBYYEARLY2
			)T ORDER BY 1;
			
		
		select sum(s.qty) as quantityreceived,sum(s.QtyOrdered) as quantityordered  from dbo.Sales s 
		where s.CustomerId in (select customerid from customer where divisionid = '838509')
		and year(s.TransactionDate) = 2020
		
		select sum(stm.QtyReceived) as quantityreceived, sum(stm.QtyOrdered) as quantityordered 
		from dbo.SalesTotalMonthly stm 
		where stm.DateYear = 2020 
		and stm.CustomerId in (select customerid from customer where divisionid = '838509')