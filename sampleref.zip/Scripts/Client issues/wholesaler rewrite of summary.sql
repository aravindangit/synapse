WITH YEARTOTALS_CTE AS (
	select s.clientid,
	       sup.SupplierId,
		   year(s.TransactionDate) TransactionYear,
		   sum(s.UnitCost * s.Qty) Cost,
		   sum(s.Qty) Quantity
	/*from Sales s
		join PharmacyItem pi 
			on s.ItemId = pi.ItemId
		join Supplier sup 
			on pi.MfrId = sup.MfrId*/
		from Sales s join supplier sup on s.SupplierId = sup.SupplierId 
		   join suppliertype st on st.SupplierTypeId = sup.SupplierTypeId 
	where year(s.TransactionDate) >= year(getdate()) - 1
	  and month(s.TransactionDate) <= month(getdate())
	  and (month(s.TransactionDate) < month(getdate())
	   or day(s.TransactionDate) <= day(getdate()))
	group by s.clientid, sup.SupplierId, year(s.TransactionDate)
	/*select month(getdate());
	select day(getdate());*/
),
RANK_CTE AS (
	select s.clientid,
	       sup.SupplierId,
		   sum(s.UnitCost * s.Qty) Cost,
		   dense_rank() over (order by sum(s.UnitCost * s.Qty) desc) CostRank,
		   sum(s.Qty) Quantity,
		   dense_rank() over (order by sum(s.Qty) desc) QuantityRank,
		   count(1) over () TotalCount
	/*from Sales s
	   join PharmacyItem pi 
	       on s.ItemId = pi.ItemId
	   join Supplier sup 
	       on pi.MfrId = sup.MfrId*/
	from Sales s join supplier sup on s.SupplierId = sup.SupplierId 
		   join suppliertype st on st.SupplierTypeId = sup.SupplierTypeId        
	where s.TransactionDate >= dateadd(month, -12, getdate())
	group by s.clientid, sup.SupplierId
),
CONTRACTED_CTE AS (
	select tc.clientid,
	       tc.supplierid,
		   count(1) ItemsPurchased,
		   count(case when tc.ItemId is not null then 1 else null end) ItemsOnContract,
		   SUM(tc.qty) as qty,
		   SUM(tc.qty_oncontract) as qty_oncontract,
		   SUM(tc.spend) as spend,
		   SUM(tc.spend_oncontract) as spend_oncontract
	from (select s.clientid,
	             sup.supplierid,
				 sci.ItemId,
				 SUM(s.qty) as qty,
				 SUM(CASE WHEN sci.itemid IS NOT NULL THEN s.qty ELSE 0 END) as qty_oncontract,
				 SUM(s.qty * s.unitcost) as spend,
				 SUM(CASE WHEN sci.itemid IS NOT NULL THEN s.qty * s.unitcost ELSE 0 END) as spend_oncontract
		   from Sales s join supplier sup on s.SupplierId = sup.SupplierId 
		   join suppliertype st on st.SupplierTypeId = sup.SupplierTypeId 
		----      join PharmacyItem pi 
			 /*     on s.ItemId = pi.ItemId
			  join Supplier sup 
			      on pi.MfrId = sup.MfrId*/
			  left join (select distinct c.SupplierId,
			                    sci.ItemId
						 from Contract.Contract c
						    join Contract.SubContract sc 
							    on sc.ContractId = c.ContractId
							join Contract.SubContractItem sci 
							    on sci.SubContractId = sc.SubContractId
						 where sci.IsActive = 1) sci 
				 on sci.SupplierId = sup.SupplierId
				and sci.ItemId = s.ItemId
		   where s.TransactionDate >= dateadd(month, -12, getdate())
		   group by s.clientid, sup.supplierid, s.ItemId,sci.ItemId) tc
	 GROUP BY tc.clientid,tc.supplierid
)
--select count(distinct(SupplierId)) from mv.SupplierSummary ss 
insert into [MV].[wholesalersummary]
		(clientid, 
		 supplierid, 
		 y_transactionyear, 
		 y_cost, 
		 y_qty, 
		 r_cost, 
		 r_costrank, 
		 r_qty, 
		 r_qtyrank, 
		 r_totalcount, 
		 c_items, 
		 c_contracted, 
		 c_purchased, 
		 c_purchasedoncontract,
		 c_spend,
		 c_spendoncontract)
SELECT   r.clientid as 'clientid', 
       r.supplierid as 'supplierid', 
	  y.transactionyear as 'y_transactionyear', 
	   y.cost as 'y_cost', 
	   y.quantity as 'y_qty', 
	   r.cost as 'r_cost', 
	   r.costrank as 'r_costrank', 
	   r.quantity as 'r_qty', 
	   r.quantityrank as 'r_qtyrank', 
	   r.totalcount as 'r_totalcount', 
	   c.itemspurchased as 'c_items', 
	   c.itemsoncontract as 'c_contracted', 
	   c.qty as 'c_purchased', 
	   c.qty_oncontract as 'c_purchasedoncontract', 
	   c.spend as 'c_spend', 
	   c.spend_oncontract as 'c_spendoncontract' 
FROM RANK_CTE r 
   JOIN CONTRACTED_CTE c 
       ON r.supplierid = c.supplierid 
	  and r.clientid = c.clientid
    JOIN YEARTOTALS_CTE y 
      ON r.supplierid = y.supplierid 
	 and r.clientid = y.clientid
ORDER BY r.clientid, r.supplierid, y.transactionyear

--select * into mv.wholesalersummary from tempout

--select * from  mv.SupplierSummary 

--select distinct(supplierid) from sales order by SupplierId asc



-- CogRxDemo.MV.SupplierSummary definition

-- Drop table

-- DROP TABLE CogRxDemo.MV.SupplierSummary;

/*
CREATE TABLE CogRxDemo.MV.wholesalersummary (
	clientid int NOT NULL,
	supplierid int NOT NULL,
	y_transactionyear int NULL,
	y_cost money NULL,
	y_qty int NULL,
	r_cost money NULL,
	r_costrank bigint NULL,
	r_qty int NULL,
	r_qtyrank bigint NULL,
	r_totalcount int NULL,
	c_items int NULL,
	c_contracted int NULL,
	c_purchased int NULL,
	c_purchasedoncontract int NULL,
	c_spend money NULL,
	c_spendoncontract money NULL,
	DateCreated datetime DEFAULT getdate() NULL
);


*/
