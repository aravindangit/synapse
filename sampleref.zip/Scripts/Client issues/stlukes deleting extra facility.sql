SELECT CustomerId, CustomerUId, ClientId, DataSourceId, AccountNumber, CustomerOrganizationId, OrganizationNumber, OrganizationName, CustomerName, PriceList, AddrLine1, AddrLine2, City, State, Zip, ParentCustomerId, CotId, CustomImportCode, GlDept, Status, DateImported, DateChanged, CustomerPatientCareAreaId, CustomerBusinessTypeId, CustomerPurchaseTypeId, CustomerSpecialtyTypeId, CustomerRegionId, DeaLicenseNum, DeaLicenseExpiration, StateLicenseNum, StateLicenseExpiration, HinNum, GlnNum, [340bId], [340bType], HierarchyNum, HierarchyName, CustomerHrsaNumber, BusinessType, PatientCareArea, ClassOfTrade, BockingData, Notes, SysStartTime, SysEndTime, DEA, Premier_Relation, SPC
FROM sqldbCogRxProdStLukes.dbo.Customer;

select * from dbo.Customer c where c.CustomerId = '86' and AccountNumber = 761021;

select * into dbo.customerbkp08312021 from dbo.Customer
select * from dbo.customerbkp08312021
--DELETE FROM table_name WHERE condition;
--one recrod
select * from dbo.Customer where CustomerId = '86' and AccountNumber = 761021;
delete from dbo.Customer where CustomerId = '86' and AccountNumber = 761021;
--one record
delete from dbo.CustomerPriceList where CustomerId = '86'
--three record
delete from dbo.CustomerItemPricingHistoryMonthly where CustomerId = '86'
--one record
delete from dbo.CustomerItemPricing  where CustomerId = '86'
--one record
select * from SalesArchive where CustomerId = '86'


SELECT * FROM raw.premiercustomerlist

select * from dbo.Customer
