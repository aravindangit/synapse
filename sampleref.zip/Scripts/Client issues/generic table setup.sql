select CONCAT('DELETE ',TABLE_SCHEMA,'.',TABLE_NAME) as tablename from loopingtable l where l.status='A'

select CONCAT('SELECT * FROM ',TABLE_SCHEMA,'.',TABLE_NAME) as tablename from loopingtable l where l.status='A'

select * from dbo.loopingtable l 

update dbo.loopingtable set TABLE_SCHEMA = 'Watch'
where TABLE_NAME in ('ShortageWatchProbabilityType','ShortageWatchReasonType')

INSERT INTO dbo.loopingtable VALUES ('I','dbo','DataSource',NULL);
INSERT INTO dbo.loopingtable VALUES ('I','App','NotificationType',NULL);
INSERT INTO dbo.loopingtable VALUES ('I','App','PermissionType',NULL);
INSERT INTO dbo.loopingtable VALUES ('I','App','ReportPermission',NULL);
INSERT INTO dbo.loopingtable VALUES ('I','Contract','CalculationType',NULL);
INSERT INTO dbo.loopingtable VALUES ('I','Contract','ContractStatus',NULL);
INSERT INTO dbo.loopingtable VALUES ('I','Contract','DistributionType',NULL);
INSERT INTO dbo.loopingtable VALUES ('I','Contract','Frequency',NULL);
INSERT INTO dbo.loopingtable VALUES ('I','Contract','PaymentMethod',NULL);
INSERT INTO dbo.loopingtable VALUES ('I','Contract','PriceCalculationType',NULL);
INSERT INTO dbo.loopingtable VALUES ('I','Contract','ProductType',NULL);
INSERT INTO dbo.loopingtable VALUES ('I','dbo','AttributeType',NULL);
INSERT INTO dbo.loopingtable VALUES ('I','dbo','EntityType',NULL);
INSERT INTO dbo.loopingtable VALUES ('I','dbo','InventoryType',NULL);
INSERT INTO dbo.loopingtable VALUES ('I','dbo','LeadTimeType',NULL);
INSERT INTO dbo.loopingtable VALUES ('I','dbo','MeetingType',NULL);
INSERT INTO dbo.loopingtable VALUES ('I','dbo','PayerType',NULL);
INSERT INTO dbo.loopingtable VALUES ('I','dbo','PharmacySignalType',NULL);
INSERT INTO dbo.loopingtable VALUES ('I','dbo','PriceList',NULL);
INSERT INTO dbo.loopingtable VALUES ('I','dbo','PriceTypeGroup',NULL);
INSERT INTO dbo.loopingtable VALUES ('I','dbo','SalesPercentileType',NULL);
INSERT INTO dbo.loopingtable VALUES ('I','dbo','ShortageCommentType',NULL);
INSERT INTO dbo.loopingtable VALUES ('I','dbo','ShortageImpact',NULL);
INSERT INTO dbo.loopingtable VALUES ('I','dbo','ShortageType',NULL);
INSERT INTO dbo.loopingtable VALUES ('I','dbo','SupplierType',NULL);
INSERT INTO dbo.loopingtable VALUES ('I','Project','EntityAcceptanceType',NULL);
INSERT INTO dbo.loopingtable VALUES ('I','Project','ProjectRecommendationAddReason',NULL);
INSERT INTO dbo.loopingtable VALUES ('I','Project','ProjectStatus',NULL);
INSERT INTO dbo.loopingtable VALUES ('I','Project','ProjectType',NULL);
INSERT INTO dbo.loopingtable VALUES ('I','Project','ShortageWatchProbabilityType',NULL);
INSERT INTO dbo.loopingtable VALUES ('I','Project','ShortageWatchReasonType',NULL);


-------------------------------

delete dbo	GxImport
delete dbo	gximport1
delete dbo	client
delete App	UserData
dbo	CatalogStatusType
dbo	DataSource
App	NotificationType
App	PermissionType
App	ReportPermission
Contract	CalculationType
Contract	ContractStatus
Contract	DistributionType
Contract	Frequency
Contract	PaymentMethod
Contract	PriceCalculationType
Contract	ProductType
dbo	AttributeType
dbo	EntityType
dbo	InventoryType
dbo	LeadTimeType
dbo	MeetingType
dbo	PayerType
dbo	PharmacySignalType
dbo	PriceList
dbo	PriceTypeGroup
dbo	SalesPercentileType
dbo	ShortageCommentType
dbo	ShortageImpact
dbo	ShortageType
dbo	SupplierType
Project	EntityAcceptanceType
Project	ProjectRecommendationAddReason
Project	ProjectStatus
Project	ProjectType
Project	ShortageWatchProbabilityType
Project	ShortageWatchReasonType
dbo	CustomerPurchaseType
dbo	DrugForm
dbo	ShortageStatus



SELECT * FROM dbo.GxImport
SELECT * FROM dbo.gximport1
SELECT * FROM dbo.client
SELECT * FROM App.UserData
SELECT * FROM dbo.CatalogStatusType
SELECT * FROM dbo.DataSource
SELECT * FROM App.NotificationType
SELECT * FROM App.PermissionType
SELECT * FROM App.ReportPermission
SELECT * FROM Contract.CalculationType
SELECT * FROM Contract.ContractStatus
SELECT * FROM Contract.DistributionType
SELECT * FROM Contract.Frequency
SELECT * FROM Contract.PaymentMethod
SELECT * FROM Contract.PriceCalculationType
SELECT * FROM Contract.ProductType
SELECT * FROM dbo.AttributeType
SELECT * FROM dbo.EntityType
SELECT * FROM dbo.InventoryType
SELECT * FROM dbo.LeadTimeType
SELECT * FROM dbo.MeetingType
SELECT * FROM dbo.PayerType
SELECT * FROM dbo.PharmacySignalType
SELECT * FROM dbo.PriceList
SELECT * FROM dbo.PriceTypeGroup
SELECT * FROM dbo.SalesPercentileType
SELECT * FROM dbo.ShortageCommentType
SELECT * FROM dbo.ShortageImpact
SELECT * FROM dbo.ShortageType
SELECT * FROM dbo.SupplierType
SELECT * FROM Project.EntityAcceptanceType
SELECT * FROM Project.ProjectRecommendationAddReason
SELECT * FROM Project.ProjectStatus
SELECT * FROM Project.ProjectType
SELECT * FROM Watch.ShortageWatchProbabilityType
SELECT * FROM Watch.ShortageWatchReasonType

select * from dbo.CustomerPurchaseType

DELETE dbo.GxImport
DELETE dbo.gximport1
DELETE dbo.client
DELETE App.UserData
DELETE dbo.CatalogStatusType
DELETE dbo.CustomerPurchaseType
DELETE dbo.DrugForm
DELETE dbo.ShortageStatus

----select 

SELECT * FROM dbo.GxImport
SELECT * FROM dbo.gximport1
SELECT * FROM dbo.client
SELECT * FROM App.UserData
SELECT * FROM dbo.CatalogStatusType
SELECT * FROM dbo.CustomerPurchaseType
SELECT * FROM dbo.DrugForm
SELECT * FROM dbo.ShortageStatus
