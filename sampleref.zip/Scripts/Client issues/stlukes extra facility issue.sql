select distinct fm.ClientId 'clientid', 
					pcl.[Facility ID] 'AccountNumber', 
					pcl.[Facility Name] 'CustomerName', 
					pcl.[Facility AddrLine1] 'Address1', 
					pcl.[Facility AddrLine2] 'Address2', 
 					pcl.[Facility City]      'City',
					pcl.[Facility State]     'State', 
					pcl.[Facility Zip]       'Zip',
					pcl.[Facility DEA]       'DEA',
					pcl.[Premier_Relation]       'Premier_Relation',
					pcl.[SPC]       'SPC',
					co.CustomerOrganizationId 'CustomerOrganizationId', 
					case when fm.ClientImportCode='NY5011' then pcl.[Facility Direct Parent ID] else pcl.[Health System ID] end 'OrganizationNumber',
					case when fm.ClientImportCode='NY5011' then pcl.[Facility Direct Parent] else pcl.[Health System] end 'OrganizationName'
					from [Raw].[PremierCustomerList] pcl
						inner join [dbo].[ImportFileIDMapping] fm
							on pcl.[Health System ID] = fm.ClientImportCode
						inner join CustomerOrganization co
							on pcl.[Facility Direct Parent ID] = co.[OrganizationNumber]
							
							
	select count(*) from Customer c 						
							
select
                 c.CustomerUId
                ,c.CustomerId
                ,c.ClientId
				,c.AccountNumber
				,c.OrganizationName
				,c.CustomerName
				,c.PriceList
				,c.AddrLine1
				,c.AddrLine2
				,c.City
				,c.State
				,c.Zip
				,c.Premier_Relation as PremierRelation 
				,c.SPC as ServiceProviderClass
			from Customer c
			where c.ClientId = 5 --Param
            and c.CustomerId = @id --Param";
            
           select * from customer where AccountNumber = '761021'
           
           select * from dbo.Sales s 
           
           
           
       
(select
	distinct a.clientid,
	a.Account,
	a.CustomerName,
	a.Address1 'Address1',
						a.Address2 'Address2',
						a.city,
	a.state,
	a.zipcode,
						string_agg(a.WholesalerAccountAttribute,
	',') as WholesalerAccountAttribute
from
	(
	select
		distinct ifm.clientid,
		s.Account,
		'Unknown - ' + s.Account CustomerName, 
		s.Address1,
		s.Address2,
		s.city,
		s.state,
		s.zipcode,
		s.WholesalerAccountAttribute
	from
		[Raw].sales s
	inner join [dbo].[ImportFileIDMapping] ifm
     on s.[DataSource] = ifm.[ClientImportCode]
		and s.WholesalerAccountAttribute is not null
	left join [dbo].[Customer] c
     on s.[Account] = c.[AccountNumber] and ifm.ClientId = c.ClientId
      where s.city = 'BETHLEHEM'
	--where s.[DataSource] = '17'
	) a
group by
	clientid,
	Account,
	Address1,
	Address2,
	city,
	state,
	zipcode,
	CustomerName
	
	select * from dbo.Sales s 	where Address1 = '5325 NORTHGATE DR STE 101'
	select * from dbo.SalesArchive sa 
	select * from premier.WholesalerInvoicesArchive where FacilityCity = 'BETHLEHEM'
	
	
	select * from premier.WholesalerInvoicesArchive where FacilityCity = 'BETHLEHEM'
and FacilityAddress1 is not NULL and FacilityAddress1 like '%NORTHGATE%'