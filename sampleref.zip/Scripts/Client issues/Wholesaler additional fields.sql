select * from dbo.Customer c 


select * from dbo.Sales s 
=====================================================
ALTER TABLE Premier.WholesalerInvoices
add OrderDate datetime NULL,
	ReasonCodeDesc varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL;

ALTER TABLE dbo.sales 
ADD OrderDate datetime NULL,
	ReasonCodeDesc varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL;

ALTER TABLE raw.Sales 
add OrderDate datetime NULL,
	ReasonCodeDesc varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL;

==============================================

ALTER TABLE dbo.sales 
ADD ReasonCodeDesc varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL;

--altering dbo sales table
ALTER TABLE raw.Sales 
add OrderDate datetime NULL,
	ReasonCodeDesc varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL;

OrderDate,ReasonCodeDesc
select * from raw.Sales s 

--altering raw sales table
ALTER TABLE raw.Sales 
add OrderDate datetime NULL,
	ReasonCodeDesc varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL;

ALTER TABLE premier.WholesalerInvoices  
add OrderDate datetime NULL,
	ReasonCodeDesc varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL;

	OrderDate datetime NULL

OrderDate datetime NULL
SELECT Id, HealthSystemID, FacilityDirectParentID, FacilityID, FacilityAddress1, FacilityAddress2, FacilityCity, FacilityState, FacilityZipCode, NDC, ItemId, BrandName, GenericName, LabelName, WholesalerPurchaseType, WholesalerLoadPrice, Supplier, InvoiceDate, InvoiceNumber, InvoicePrice, Wholesaler, DistributionCenterName, WholesalerAccountNumber, WholesalerAccountName, LineNumberfromInvoice, ContractLeadName, ServiceProviderClass, ShipMethod, ShippingDate, WholesalerPkgQty, WholesalerOrderLineNumber, WholesalerCatalogNumber, UnitofMeasure, WholesalerAccountAttribute, ChargeBackContractNumber, [Markup/Markdown], PremierAwardStatus, PremierContractNumber, TotalUnits, TotalSpend, QuantityOrdered, AddedDate, ProcessPipelineId, OriginalFileName, AdlPath, ReasonCodeDesc, OrderDate
FROM sqldbCogRxProdNationalWholesaler.Premier.WholesalerInvoices;

select count(*) from Premier.WholesalerInvoices where itemid is not null

--customer backup 

select * into dbo.customerapr2022 from dbo.Customer c 

select * from dbo.customerapr2022

update dbo.Customer 
 set dbo.Customer.DivisionName = bkp.DivisionName,
     dbo.Customer.DivisionId = bkp.DivisionId
from dbo.Customer cust join customerapr2022 bkp
 on bkp.AccountNumber = cust.AccountNumber
 
 select * from Customer c
 select top 100 * from premier.WholesalerInvoices wi  
 select top 100 * from dbo.Sales s  where s.ReasonCodeDesc  is not null
 select top 100 * from dbo.SalesTotals st
 select top 100 * from dbo.SalesTotalMonthly stm
 

