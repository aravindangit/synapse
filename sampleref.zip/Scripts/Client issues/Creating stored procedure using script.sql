/*
SELECT SkuCount, LaunchStatus, Manufaturer, GenericName, DosageForm, Strength, PackageSizeInMl, PackageQuantity, NDC, [SellingUnitPrice ], Rebate, ProjectedAvailabilityDateAtWholesaler, FirmAvailabilityDateAtWholesaler, FFFItemCode, [FFF Or Alternate (Prime) Wholesaler], [Drug Shortage ASHP/FDA], Comments, [Product Launch Date], [Contract End Date], [Base Contract Price], [Each Price], [PGx Each Price], [Difference PGx to Base], [Admin Fee Incremental], [Total Admin Fee], [Pays On], [WAC Price], [DSH ], IHP, [Contract Number], [Controlled Substance], [API Source], [Finished Good Production], [Annual Sales Value Premier (Contract Supplier)], [Annual Sales Value Premier (Molecule)], [Annual Sales Value PGx ONLY], [Type of Drug and/or Indication], CivicaDrug, ImportDate
FROM sqldbCogRxProdItemMaster.dbo.GxImport;

select * from pharmacyitem p 
*/

--adding new column
ALTER TABLE dbo.PharmacyItem 
ADD Gx_Indicator char(1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL


---creating stored procedure
CREATE PROCEDURE Integrations.UpdatePharmacyItemUsingGxImport
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	--to update Gx indicator in the pharmacy item table
	SET NOCOUNT ON;
UPDATE  a
   set  a.[Gx_Indicator] =  'Y'
		from dbo.pharmacyitem a join dbo.GxImport b on a.ndc = b.ndc
	
END;

