SELECT NationalPricePredictionId, NationalPricePredictionGuid, RecordSyncDate, IsActive, Ndc, PriceDate, RunDate, TrainDate, WacUnitPrice, PeriodFirstIdentified, Month0ProbabilityOfIncrease, Month0PredictedWacUnitPrice, Month1ProbabilityOfIncrease, Month1PredictedWacUnitPrice, Month1PercentIncrease, Month1Period, Month2ProbabilityOfIncrease, Month2PredictedWacUnitPrice, Month2PercentIncrease, Month2Period, Month3ProbabilityOfIncrease, Month3PredictedWacUnitPrice, Month3PercentIncrease, Month3Period
FROM sqldbCogRxProdItemMaster.Predictive.NationalPricePrediction;


Execute Predictive.LoadNationalPricePredictionFromRaw;

--backup process
select * into Predictive.NationalPricePredictionbkp09012021 from Predictive.NationalPricePrediction

--countvalidation
--matching records 3740
select count(*) from Predictive.NationalPricePredictionbkp09012021
select count(*) from Predictive.NationalPricePrediction


--enriching the data
Execute [Predictive].[LoadNationalPricePredictionFromRaw]

--validate the records

select count(*) from [Predictive].[NationalPricePrediction]

    select distinct [NationalPricePredictionGuid]
         , [RecordSyncDate]
         -- todo: when automating, old values will be inactivated first
         , 1 as [IsActive]
         , rawr.[Ndc]
         , rawr.[PriceDate]
         , rawr.[RunDate]
         , rawr.[TrainDate]
         , rawr.[WacPrice] as WacUnitPrice
         -- todo: This will need to be more complicated to determine actual period identified
         , case
               when lastMonth.PeriodFirstIdentified is not null then
                   lastMonth.PeriodFirstIdentified
               else
                   dateadd(d, 1, eomonth(rawr.PriceDate))
           end as [PeriodFirstIdentified]
         , rawr.[Month0ProbabilityOfIncrease]
         , rawr.Month0PredictedWacPrice as [Month0PredictedWacUnitPrice]
         , rawr.[Month1ProbabilityOfIncrease]
         , rawr.[Month1PredictedWacPrice] as [Month1PredictedWacUnitPrice]
         , dbo.CalculatePriceIncrease(rawr.WacPrice, rawr.Month1PredictedWacPrice) as [Month1PercentIncrease]
         , dateadd(d, 1, eomonth(rawr.PriceDate)) as [Month1Period]
         , rawr.[Month2ProbabilityOfIncrease]
         , rawr.[Month2PredictedWacPrice] as [Month2PredictedWacUnitPrice]
         , dbo.CalculatePriceIncrease(rawr.WacPrice, rawr.Month2PredictedWacPrice) as [Month2PercentIncrease]
         , dateadd(d, 2, eomonth(rawr.PriceDate)) as [Month2Period]
         , rawr.[Month3ProbabilityOfIncrease]
         , rawr.[Month3PredictedWacPrice] as [Month3PredictedWacUnitPrice]
         , dbo.CalculatePriceIncrease(rawr.WacPrice, rawr.Month3PredictedWacPrice) as [Month3PercentIncrease]
         , dateadd(d, 3, eomonth(rawr.PriceDate)) as [Month3Period]
    from Predictive.NationalPricePredictionRaw rawr
        left join @currentBeforeRun as lastMonth on rawr.Ndc = lastMonth.NDC
    where IsFalsePositive = 0
          and (Month1PredictedWacPrice > WacPrice)
          or (Month2PredictedWacPrice > WacPrice)
          
          
   select count(*) from dbo.salestotalsbkp09012021 from dbo.SalesTotals st 
   
   --truncate table dbo.SalesTotals 
   
  -- execute DailyMaintinance.RebuildSalesTotal
