select * into dbo.salestotalsnov22021 from dbo.SalesTotals st 

select * from dbo.salestotalsnov22021

select * from dbo.SalesTotals st 

exec [DailyMaintinance].[RebuildSalesTotalWan]

    declare @today date = getdate();
    declare @Past30 date = dateadd(day, -30, @today);
    declare @Past60 date = dateadd(day, -60, @today);
    declare @Past90 date = dateadd(day, -90, @today);
    declare @Past6Months date = dateadd(month, -6, @today);
    declare @Past1Year date = dateadd(year, -1, @today);
    declare @Past2Year date = dateadd(year, -2, @today);

   -- Truncate table [dbo].[SalesTotals];
    --build 30Day
    merge [dbo].[SalesTotals] as target
    using
    (   select clientid
             , CustomerId
             , ndc
             , PriceTypeGroupId
             , SupplierId
             , WholesalerAccountNumber --change
             , max(itemid) itemid
             , isnull(sum(qty), 0) as "30DayUsageQty"
             , isnull(sum(ROUND((qty * unitprice),0)), 0) as "30DayUsageExtPrice"
             , isnull(sum(QtyOrdered), 0) as "30DayQtyOrdered"
             , count(1) as "30DayUsageTransactionCount"
             , @Past30 as "30DayAsOfDate"
        from dbo.Sales
        where transactiondate >= @Past30
              and [RepackagedFlag] = 0
        group by clientid
               , CustomerId
               , ndc
               , PriceTypeGroupId
               , SupplierId
               , WholesalerAccountNumber) as source
    on (   target.clientid = source.clientid
           and target.CustomerId = source.CustomerId
           and target.ndc = source.ndc
           and target.PriceTypeGroupId = source.PriceTypeGroupId
           and target.SupplierId = source.SupplierId
           and target.WholesalerAccountNumber = source.WholesalerAccountNumber)
    when matched then
        update set itemid = source.itemid
                 , [30DayUsageQty] = source.[30DayUsageQty]
                 , [30DayUsageExtPrice] = source.[30DayUsageExtPrice]
                 , [30DayQtyOrdered] = source.[30DayQtyOrdered]
                 , [30DayUsageTransactionCount] = source.[30DayUsageTransactionCount]
                 , [30DayAsOfDate] = source.[30DayAsOfDate]
                 , [UpdatedDate] = getutcdate()
    when not matched then
        insert
        (   clientid
          , CustomerId
          , itemid
          , ndc
          , PriceTypeGroupId
          , SupplierId
          , WholesalerAccountNumber
          , [30DayUsageQty]
          , [30DayUsageExtPrice]
          , [30DayQtyOrdered]
          , [30DayUsageTransactionCount]
          , [30DayAsOfDate])
        values
        (source.clientid, source.CustomerId, source.itemid, source.ndc, source.PriceTypeGroupId, source.SupplierId
       , source.WholesalerAccountNumber,source.[30DayUsageQty], source.[30DayUsageExtPrice], source.[30DayQtyOrdered]
       , source.[30DayUsageTransactionCount], source.[30DayAsOfDate])
    when not matched by source then
        update set target.[30DayUsageQty] = 0
                 , target.[30DayUsageExtPrice] = 0
                 , target.[30DayQtyOrdered] = 0
                 , target.[30DayUsageTransactionCount] = 0
                 , target.[30DayAsOfDate] = @Past30;