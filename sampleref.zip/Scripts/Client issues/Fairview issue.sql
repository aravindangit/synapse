select * from Customer c where AccountNumber in ('644700','763311')


select * from CustomerOrganization
select * from raw.PremierCustomerList pcl where pcl.[Facility AddrLine1] in 
('9645 GROVE CIR N STE 200','2355 HIGHWAY 36 W STE 100')

9645 GROVE CIR N STE 200

2355 HIGHWAY 36 W STE 100

select * from  [dbo].[ImportFileIDMapping] fm

9645 GROVE CIR N STE 200
MAPLE GROVE, MN 55369-2684

2355 HIGHWAY 36 W STE 100
MINNEAPOLIS, MN 55437

select distinct fm.ClientId 'clientid', 
					pcl.[Facility ID] 'AccountNumber', 
					pcl.[Facility Name] 'CustomerName', 
					pcl.[Facility AddrLine1] 'Address1', 
					pcl.[Facility AddrLine2] 'Address2', 
 					pcl.[Facility City]      'City',
					pcl.[Facility State]     'State', 
					pcl.[Facility Zip]       'Zip',
					pcl.[Facility DEA]       'DEA',
					pcl.[Premier_Relation]       'Premier_Relation',
					pcl.[SPC]       'SPC',
					co.CustomerOrganizationId 'CustomerOrganizationId', 
					--pcl.[Facility Direct Parent ID] 'OrganizationNumber', 
					--pcl.[Facility Direct Parent] 'OrganizationName',

--updating top parent to org name & ID
					case when fm.ClientImportCode='NY5011' then pcl.[Facility Direct Parent ID] else pcl.[Health System ID] end 'OrganizationNumber',
					case when fm.ClientImportCode='NY5011' then pcl.[Facility Direct Parent] else pcl.[Health System] end 'OrganizationName'
					from [Raw].[PremierCustomerList] pcl
						inner join [dbo].[ImportFileIDMapping] fm
							on pcl.[Health System ID] = fm.ClientImportCode
						inner join CustomerOrganization co
							on pcl.[Facility Direct Parent ID] = co.[OrganizationNumber]
							
							
(select distinct a.clientid, a.Account, a.CustomerName, a.Address1 'Address1',
						a.Address2 'Address2',
						a.city, a.state, a.zipcode,
						string_agg(a.WholesalerAccountAttribute,',') as WholesalerAccountAttribute
						from (select distinct ifm.clientid, s.Account, 'Unknown - ' + s.Account CustomerName, 
						s.Address1, s.Address2, s.city, s.state, s.zipcode, s.WholesalerAccountAttribute
					from [Raw].sales s
					inner join [dbo].[ImportFileIDMapping] ifm
     on s.[DataSource] = ifm.[ClientImportCode] and s.WholesalerAccountAttribute is not null
	 left join [dbo].[Customer] c
     on s.[Account] = c.[AccountNumber]
	and ifm.ClientId = c.ClientId --where s.[DataSource] = '17'
	) a 
	group by clientid, Account, Address1, Address2, city, state, zipcode, CustomerName)
	
	
	
	select distinct fm.ClientId 'clientid', 
					pcl.[Facility ID] 'AccountNumber', 
					pcl.[Facility Name] 'CustomerName', 
					pcl.[Facility AddrLine1] 'Address1', 
					pcl.[Facility AddrLine2] 'Address2', 
 					pcl.[Facility City]      'City',
					pcl.[Facility State]     'State', 
					pcl.[Facility Zip]       'Zip',
					pcl.[Facility DEA]       'DEA',
					pcl.[Premier_Relation]       'Premier_Relation',
				--	pcl.[SPC]       'SPC',
				--	co.CustomerOrganizationId 'CustomerOrganizationId', 
					--pcl.[Facility Direct Parent ID] 'OrganizationNumber', 
					--pcl.[Facility Direct Parent] 'OrganizationName',

--updating top parent to org name & ID
					case when fm.ClientImportCode='NY5011' then pcl.[Facility Direct Parent ID] else pcl.[Health System ID] end 'OrganizationNumber',
					case when fm.ClientImportCode='NY5011' then pcl.[Facility Direct Parent] else pcl.[Health System] end 'OrganizationName'
					from [Raw].[PremierCustomerList] pcl
						inner join [dbo].[ImportFileIDMapping] fm
							on pcl.[Health System ID] = fm.ClientImportCode
						inner join CustomerOrganization co
							on pcl.[Facility Direct Parent ID] = co.[OrganizationNumber]
							
							
select * from [Raw].[PremierCustomerList]
							