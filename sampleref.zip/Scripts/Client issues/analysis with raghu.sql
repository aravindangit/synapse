DECLARE @clientId int = 2;

DECLARE @id varchar(10) = '838509';
;WITH R(N) AS
            (
                SELECT 1 UNION ALL SELECT N+1 FROM R
                WHERE N < 12
            ),

            PSTM AS (select R.N, UPPER(LEFT(DateName( month , DateAdd( month , R.N , -1 )),3)) AS MONTH, 
            ISNULL(t.PCOST,0) AS PCOST, 
            ISNULL(CAST(t.PUNITS AS BIGINT),0) AS PUNITS,
             ISNULL(CAST(t.punitsordered AS BIGINT),0) AS PUNITSOR
            from R 
			Left JOIN (
			SELECT  stm.DateMonth, C.DIVISIONID,  
			SUM(STM.ExtendedPrice) AS PCOST  , 
			SUM(STM.QtyReceived)  PUNITS,
			sum(stm.qtyordered) punitsordered
            FROM  SalesTotalMonthly STM			 
			JOIN CUSTOMER C ON C.CUSTOMERID = STM.CUSTOMERID 
			and STM.DateYear IN (YEAR(GETDATE()) - 2) AND STM.ClientId=@clientId  AND C.DIVISIONID=@id 
            GROUP BY C.DIVISIONID, stm.DateMonth )t on R.n = t.DateMonth) 
            
            select * from pstm
            
            SELECT  stm.DateMonth, C.DIVISIONID,  
			SUM(STM.ExtendedPrice) AS PCOST  , 
			SUM(STM.QtyReceived)  PUNITS,
			sum(stm.qtyordered) punitsordered
            FROM  SalesTotalMonthly STM			 
			JOIN CUSTOMER C ON C.CUSTOMERID = STM.CUSTOMERID 
			and STM.DateYear IN (YEAR(GETDATE()) - 2) AND STM.ClientId=2  AND C.DIVISIONID='838509' 
            GROUP BY C.DIVISIONID, stm.DateMonth 