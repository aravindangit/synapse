declare @clientId int = 4,@WholesalerId int = 2396,@supplierid int = 1075, @from varchar(20) = '02/10/2022', @to varchar(20) = '05/10/2022',@pageNumber int = 0,
@pageSize int = 10000000,@sortDirection varchar(20) = '',@sortColumn varchar(20) = '';


		 ;with utilization as (
	            select pi.Ndc
			            ,pi.ItemDescription as 'Description'
			            ,c.OrganizationName as 'Organization'
						,[dbo].[fn_DivisionName](c.DivisionName, c.DivisionId) as 'Division'
						,[dbo].[fn_FacilityName](c.CustomerName,c.AccountNumber,c.DEA)  AS 'Facility'
			            ,c.CustomerName as 'Account'
			            ,s.TransactionDate
			            ,s.Qty
			            ,s.UnitCost
			            ,s.UnitCost * Qty as 'TotalCost'
						,s.WholesalerAccountNumber
						,s.OrderType
						,s.WholesalerCBID
						,s.CostofDistribution
						,ptg.PriceTypeGroupDescription as 'AccountType'
						,s.InvoiceNumber
						,s.SupplierName
			            ,st.Usage30
			            ,st.Usage60
			            ,st.Usage90
			            ,st.Cost30
			            ,st.Cost60
			            ,st.Cost90

						, pi.DrugName as BrandName
						, pi.GpiDrugName as GenericName						
						, df.DosageFormDescription as DosageForm
						, pi.DrugStrength + pi.DrugStrengthUom as Strength
						, dose.UnitDoseCode -- ask if we should include
						, dose.UnitDoseDescription -- ask if we should include
						, pi.PackageSize as PackageSize
						, pi.CasePack as PackageQuantity
						, pi.PackageDescription as PackagingDescription
						, packageUom.PackageSizeUomCode as Uom
						, packageUom.PackageSizeUomDescription as UomDescription
						, isnull(s.OrderDate, '') 'OrderDate'
						, c.Premier_Relation as 'PremierRelation'
						, c.SPC as ServiceProviderClass

		            from Sales s
			            join PharmacyItem pi on s.ItemId = pi.ItemId and s.ClientId = @clientId
			            join Supplier sup on pi.MfrId = sup.MfrId and sup.SupplierId = @SupplierId
			            join Customer c on s.CustomerId = c.CustomerId and s.ClientId = c.ClientId
						join PriceTypeGroup ptg ON s.PriceTypeGroupId = ptg.PriceTypeGroupId
			            join (
				            select st.Ndc
						            , sum([30DayUsageQty])		 [Usage30]	
						            , sum([60DayUsageQty])		 [Usage60]	
						            , sum([90DayUsageQty])		 [Usage90]	
						            , sum([30DayUsageExtPrice]) [Cost30]	
						            , sum([60DayUsageExtPrice]) [Cost60]	
						            , sum([90DayUsageExtPrice]) [Cost90]	
				            from SalesTotals st
				            join PharmacyItem pi on st.ItemId = pi.ItemId and st.ClientId = @clientId
				            join Supplier sup on pi.MfrId = sup.MfrId and sup.SupplierId = @SupplierId
				            group by st.Ndc) st on st.Ndc = pi.Ndc

						left join ItemMaster.BrandNameTypes bnt on bnt.BrandNameTypeId = pi.BrandNameTypeId
						left join ItemMaster.DosageForm df on df.DosageFormId = pi.DosageFormId
						left join ItemMaster.PackageSizeUom packageUom on packageUom.PackageSizeUomId = pi.PackageSizeUomId
						left join ItemMaster.UnitDose dose on dose.UnitDoseId = pi.UnitDoseId

		            where s.TransactionDate >= @from
			            and s.TransactionDate < dateadd(day, 1, @to) and c.status = 'A'
            --            ***SUPPLIERCLAUSE***
			--			***FILTERS***
            ),
            utilizationTotals as (
				            SELECT sum(u.Qty) SearchResultTotalQty
		                         , sum(u.UnitCost) SearchResultTotalUnitCost
		                         , sum(u.TotalCost) SearchResultTotalCost
	                        from utilization u
                        ),
            utilizationPeriods as (
              SELECT sum(stp.Usage30) [SearchResultUsage30]
		            ,sum(stp.Usage60) [SearchResultUsage60]
		            ,sum(stp.Usage90) [SearchResultUsage90]
		            ,sum(stp.Cost30) [SearchResultCost30]
		            ,sum(stp.Cost60) [SearchResultCost60]
		            ,sum(stp.Cost90) [SearchResultCost90]
	            FROM ( select st.Ndc
				            , sum([30DayUsageQty])		 [Usage30]	
				            , sum([60DayUsageQty])		 [Usage60]	
				            , sum([90DayUsageQty])		 [Usage90]	
				            , sum([30DayUsageExtPrice]) [Cost30]	
				            , sum([60DayUsageExtPrice]) [Cost60]	
				            , sum([90DayUsageExtPrice]) [Cost90]	
			            from SalesTotals st
			            join PharmacyItem pi on st.ItemId = pi.ItemId and st.ClientId = @clientId
			            join Supplier sup on pi.MfrId = sup.MfrId and sup.SupplierId = @SupplierId
			            join Customer c on st.CustomerId = c.CustomerId and st.ClientId = c.ClientId
					    where c.status = 'A'
			            group by st.Ndc ) stp
            )

            select 
                            u.Ndc
                            ,u.Description
							,u.Division
							,u.Facility
				            ,u.Organization
				            ,u.Account            
	                        ,u.TransactionDate
	                        ,u.Qty
                            ,u.UnitCost
                            ,u.TotalCost
							,u.WholesalerAccountNumber
							,u.OrderType
							,u.WholesalerCBID
							,u.CostofDistribution
							,u.AccountType
							,u.InvoiceNumber
							,u.SupplierName
				            ,u.Usage30
				            ,u.Usage60
				            ,u.Usage90
				            ,u.Cost30
				            ,u.Cost60
				            ,u.Cost90
							,u.OrderDate
	                        ,src.SearchResultCount
                            ,ut.SearchResultTotalUnitCost
	                        ,ut.SearchResultTotalCost
	                        ,ut.SearchResultTotalQty
				            ,up.SearchResultUsage30
	                        ,up.SearchResultUsage60
	                        ,up.SearchResultUsage90
	                        ,up.SearchResultCost30
	                        ,up.SearchResultCost60
	                        ,up.SearchResultCost90

							, u.BrandName
							, u.GenericName						
							, u.DosageForm
							, u.Strength
							, u.UnitDoseCode 
							, u.UnitDoseDescription 
							, u.PackageSize
							, u.PackageQuantity
							, u.PackagingDescription
							, u.Uom
							, u.UomDescription
							, u.PremierRelation
							, u.ServiceProviderClass

                        from utilization u
				            join utilizationTotals ut on 1 = 1
				            join utilizationPeriods up on 1 = 1
	                        join (select count(1) SearchResultCount from utilization                                 
								 ) src on 1 = 1
                             
							
                        order by
	                        case when @sortColumn = 'Ndc' and @sortDirection = 'asc' then u.Ndc end,
	                        case when @sortColumn = 'Ndc' and @sortDirection = 'desc' then u.Ndc end desc,
	                        case when @sortColumn = 'Description' and @sortDirection = 'asc' then u.Description end,
	                        case when @sortColumn = 'Description' and @sortDirection = 'desc' then u.Description end desc,
							case when @sortColumn = 'WholesalerAccountNumber' and @sortDirection = 'asc' then u.WholesalerAccountNumber end,
							case when @sortColumn = 'WholesalerAccountNumber' and @sortDirection = 'desc' then u.WholesalerAccountNumber end desc,
							case when @sortColumn = 'OrderType' and @sortDirection = 'asc' then u.OrderType end,
							case when @sortColumn = 'OrderType' and @sortDirection = 'desc' then u.OrderType end desc,
							case when @sortColumn = 'WholesalerCBID' and @sortDirection = 'asc' then u.WholesalerCBID end,
							case when @sortColumn = 'WholesalerCBID' and @sortDirection = 'desc' then u.WholesalerCBID end desc,
							case when @sortColumn = 'CostofDistribution' and @sortDirection = 'asc' then u.CostofDistribution end,
							case when @sortColumn = 'CostofDistribution' and @sortDirection = 'desc' then u.CostofDistribution end desc,
							case when @sortColumn = 'AccountType' and @sortDirection = 'asc' then u.AccountType end,
							case when @sortColumn = 'AccountType' and @sortDirection = 'desc' then u.AccountType end desc,
							case when @sortColumn = 'InvoiceNumber' and @sortDirection = 'asc' then u.InvoiceNumber end,
							case when @sortColumn = 'InvoiceNumber' and @sortDirection = 'desc' then u.InvoiceNumber end desc,
				            case when @sortColumn = 'Organization' and @sortDirection = 'asc' then u.Organization end,
	                        case when @sortColumn = 'Organization' and @sortDirection = 'desc' then u.Organization end desc,
				            case when @sortColumn = 'Account' and @sortDirection = 'asc' then u.Account end,
							case when @sortColumn = 'SupplierName' and @sortDirection = 'asc' then u.SupplierName end,
							case when @sortColumn = 'SupplierName' and @sortDirection = 'desc' then u.SupplierName end desc,
	                        case when @sortColumn = 'Account' and @sortDirection = 'desc' then u.Account end desc,
	                        case when @sortColumn = 'TransactionDate' and @sortDirection = 'asc' then u.TransactionDate end,
	                        case when @sortColumn = 'TransactionDate' and @sortDirection = 'desc' then u.TransactionDate end desc,
	                        case when @sortColumn = 'Qty' and @sortDirection = 'asc' then u.Qty end,
	                        case when @sortColumn = 'Qty' and @sortDirection = 'desc' then u.Qty end desc,
	                        case when @sortColumn = 'UnitCost' and @sortDirection = 'asc' then u.UnitCost end,
	                        case when @sortColumn = 'UnitCost' and @sortDirection = 'desc' then u.UnitCost end desc,
				            case when @sortColumn = 'TotalCost' and @sortDirection = 'asc' then u.TotalCost end,
	                        case when @sortColumn = 'TotalCost' and @sortDirection = 'desc' then u.TotalCost end desc,
							case when @sortColumn = 'OrderDate' and @sortDirection = 'asc' then u.OrderDate end,
							case when @sortColumn = 'OrderDate' and @sortDirection = 'desc' then u.OrderDate end desc
                        offset @pageNumber * @pageSize rows --Param
                        fetch next @pageSize rows only;
						
						select 
			            DISTINCT 
						[dbo].[fn_DivisionName](c.DivisionName, c.DivisionId) as 'Division',
						[dbo].[fn_FacilityName](c.CustomerName,c.AccountNumber,c.DEA)  AS 'Facility',
						s.SupplierName AS 'Wholesaler',
						s.OrderType AS 'OrderType',
						s.WholesalerAccountNumber AS 'WholesalerAccountNumber',
						ptg.PriceTypeGroupDescription as 'AccountType',
						c.Premier_Relation as 'PremierRelation',
						c.SPC as ServiceProviderClass

		            from Sales s
			            join PharmacyItem pi on s.ItemId = pi.ItemId and s.ClientId = @clientId
			            join Supplier sup on pi.MfrId = sup.MfrId and sup.SupplierId = @SupplierId
			            join Customer c on s.CustomerId = c.CustomerId and s.ClientId = c.ClientId
						join PriceTypeGroup ptg ON s.PriceTypeGroupId = ptg.PriceTypeGroupId
			            join (
				            select st.Ndc
						            , sum([30DayUsageQty])		 [Usage30]	
						            , sum([60DayUsageQty])		 [Usage60]	
						            , sum([90DayUsageQty])		 [Usage90]	
						            , sum([30DayUsageExtPrice]) [Cost30]	
						            , sum([60DayUsageExtPrice]) [Cost60]	
						            , sum([90DayUsageExtPrice]) [Cost90]	
				            from SalesTotals st
				            join PharmacyItem pi on st.ItemId = pi.ItemId and st.ClientId = @clientId
				            join Supplier sup on pi.MfrId = sup.MfrId and sup.SupplierId = @SupplierId
				            group by st.Ndc) st on st.Ndc = pi.Ndc
		            where s.TransactionDate >= @from
			            and s.TransactionDate < dateadd(day, 1, @to) and c.status = 'A';
			            
			           
------------supplier overview query----------------------------
declare @clientId int = 4,@WholesalerId int = 2396,@supplierid int = 2396, @from varchar(20) = '02/10/2022', @to varchar(20) = '05/10/2022',@pageNumber int = 0,
@pageSize int = 10000000,@sortDirection varchar(20) = '',@sortColumn varchar(20) = '';
	select 
					c.CustomerId
					, c.CustomerName
					, dbo.fn_DivisionName(c.DivisionName, c.DivisionId) 'Division'
					, sum([30DayUsageExtPrice]) as TotalCost30Day
					, sum([60DayUsageExtPrice]) as TotalCost60Day
					, sum([90DayUsageExtPrice]) as TotalCost90Day
					, sum([1YearUsageExtPrice]) as TotalCost
				from SalesTotals st							
						join dbo.Customer c on c.CustomerId = st.CustomerId and c.ClientId = st.ClientId
				        join PharmacyItem pi on st.ItemId = pi.ItemId and st.ClientId = @clientId --Param
				        join Supplier sup on pi.MfrId = sup.MfrId and sup.SupplierId = @supplierId --Param
				where c.status = 'A'
				group by c.CustomerId, c.CustomerName, c.DivisionName, c.DivisionId
				order by c.CustomerName			
				
				select * from premier.WholesalerInvoices where InvoiceNumber = '2401019'
				
				select * from supplier where mfrid is null