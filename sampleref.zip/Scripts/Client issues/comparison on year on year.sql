ELECT JOB,
SUM(CASE WHEN DEPTNO = 'A00' THEN 1 ELSE 0 END) AS A00,
SUM(CASE WHEN DEPTNO = 'B01' THEN 1 ELSE 0 END) AS B01,
SUM(CASE WHEN DEPTNO = 'C01' THEN 1 ELSE 0 END) AS C01,
SUM(CASE WHEN DEPTNO = 'D11' THEN 1 ELSE 0 END) AS D11,
SUM(CASE WHEN DEPTNO = 'D21' THEN 1 ELSE 0 END) AS D21,
SUM(CASE WHEN DEPTNO = 'E01' THEN 1 ELSE 0 END) AS E01,
SUM(CASE WHEN DEPTNO = 'E11' THEN 1 ELSE 0 END) AS E11,
SUM(CASE WHEN DEPTNO = 'E21' THEN 1 ELSE 0 END) AS E21
FROM EMP
GROUP BY JOB
============================================================================
declare @clientId as int = (select clientid from Client);
declare @customerId as int = 21;
-- selecting spend by facility, I suppose
select
    c.CustomerId
    ,c.CustomerName
    ,ptg.PriceTypeGroupDescription
    ,cal.CalendarYear
    ,cal.CalendarMonth
    /*SUM(CASE WHEN DEPTNO = 'A00' THEN 1 ELSE 0 END) AS A00,
	SUM(CASE WHEN DEPTNO = 'B01' THEN 1 ELSE 0 END) AS B01,
	SUM(CASE WHEN DEPTNO = 'C01' THEN 1 ELSE 0 END) AS C01,
	SUM(CASE WHEN DEPTNO = 'D11' THEN 1 ELSE 0 END) AS D11,
	SUM(CASE WHEN DEPTNO = 'D21' THEN 1 ELSE 0 END) AS D21,
	SUM(CASE WHEN DEPTNO = 'E01' THEN 1 ELSE 0 END) AS E01,
	SUM(CASE WHEN DEPTNO = 'E11' THEN 1 ELSE 0 END) AS E11,
	SUM(CASE WHEN DEPTNO = 'E21' THEN 1 ELSE 0 END) AS E21*/
    ,sum(s.Qty * s.UnitCost) as Spend
    ,s.TransactionDate 
from Sales s 
    join Customer c on s.CustomerId = c.CustomerId
    join PriceTypeGroup ptg on s.PriceTypeGroupId = ptg.PriceTypeGroupId
    join Calendar cal on cal.CalendarDate = s.TransactionDate
where c.ClientId = @clientId
    and c.CustomerId = @customerId
group by c.CustomerId
        ,c.CustomerName
        ,ptg.PriceTypeGroupDescription
        ,cal.CalendarYear
        ,cal.CalendarMonth
===========================================================================
select sum(Qty * UnitCost) as spend,MONTH(TransactionDate) from sales where year(TransactionDate) = '2021'
group by MONTH(TransactionDate) ,year(TransactionDate) order by MONTH(TransactionDate)
------------------------------------------------------------------------------------------
declare @clientId as int = (select clientid from Client);
declare @customerId as int = 21;
-- selecting spend by facility, I suppose
select
    c.CustomerId
    ,c.CustomerName
    ,ptg.PriceTypeGroupDescription
    ,cal.CalendarYear
    ,cal.CalendarMonth
    ,sum(s.Qty * s.UnitCost) as Spend
from Sales s 
    join Customer c on s.CustomerId = c.CustomerId
    join PriceTypeGroup ptg on s.PriceTypeGroupId = ptg.PriceTypeGroupId
    join Calendar cal on cal.CalendarDate = s.TransactionDate
where c.ClientId = @clientId
    and c.CustomerId = @customerId
group by c.CustomerId
        ,c.CustomerName
        ,ptg.PriceTypeGroupDescription
        ,cal.CalendarYear
        ,cal.CalendarMonth
        
==================================================================================
SELECT *
FROM (SELECT YEAR(transactiondate) [Year], 
�������DATENAME(MONTH, transactiondate) [Month], 
�������SUM(Qty * UnitCost) as [Sales Count]
������FROM dbo.sales 
������GROUP BY YEAR(transactiondate), 
������DATENAME(MONTH, transactiondate)) AS MontlySalesData
PIVOT( sum([Sales Count])
����FOR Month IN ([January],[February],[March],[April],[May],
����[June],[July],[August],[September],[October],[November],
����[December])) AS MNamePivot
        
        
  select year(transactiondate), month(transactiondate),sum(qty),
  lag(sum(salesamount),12) over ( order by year(orderdate),month(orderdate))
  from dbo.Sales s where year(orderdate) in 2021,2021
  group by year(order date),month(oirderdate)
 ==================================================  
  select year(transactiondate), month(transactiondate),sum(qty*UnitCost) -
  lag(sum(qty*UnitCost),12)  over ( order by year(transactiondate),month(transactiondate)) as aravind
  from dbo.Sales   
  group by year(transactiondate),month(transactiondate)
 ====================================================
 --MERGE 
 select * from
 (select year(transactiondate) [Year], 
  DATENAME(MONTH, transactiondate) [Month],
 -- (sum(qty*UnitCost)  - lag(sum(qty*UnitCost),12)  
    (sum(qty*UnitCost)  - lag(sum(qty*UnitCost),12) 
  over(order by year(transactiondate),DATENAME(MONTH, transactiondate))) as [costdifference] 
  from dbo.Sales   where year(transactiondate) = year(GETDATE()) or year(transactiondate)=(YEAR(GETDATE()) - 1)
  group by year(transactiondate), DATENAME(MONTH, transactiondate)) AS costcalc
  PIVOT( SUM([costdifference])�� 
����FOR Month IN ([January],[February],[March],[April],[May],
����[June],[July],[August],[September],[October],[November],
����[December])) AS MNamePivot
 
 =====================================================
;with ROWCTE(ROWNO) as  
   (  
     SELECT 
  ROW_NUMBER() OVER(ORDER BY name ASC) AS ROWNO
FROM sys.databases 
WHERE database_id <= 10
    )  
 
with pivotingCTE as (SELECT * 
FROM (SELECT YEAR(transactiondate) [Year], 
�������DATENAME(MONTH, transactiondate) [Month], 
�������SUM(Qty * UnitCost) as [Sales Count]
������FROM dbo.sales 
������GROUP BY YEAR(transactiondate), 
������DATENAME(MONTH, transactiondate)) AS MontlySalesData
PIVOT( SUM([Sales Count])�� 
����FOR Month IN ([January],[February],[March],[April],[May],
����[June],[July],[August],[September],[October],[November],
����[December])) AS pivotname),

--over(order by year(transactiondate),DATENAME(MONTH, transactiondate))) as [costdifference] 
 secondCTE as (
select [year],
--LAG (salary,1) OVER (ORDER BY salary) AS lower_salary
	CASE
    WHEN [year] = YEAR(GETDATE()) THEN  ([January]+[February]+[March]+[April]+[May]+
����[June]+[July]+[August]+[September]+[October]+isnull([November],0)+
����isnull([December],0)) 
    WHEN [year] = (YEAR(GETDATE()) - 1) THEN ([January]+[February]+[March]+[April]+[May]+
����[June]+[July]+[August]+[September]+[October]+[November]+
����[December])
	END as TotalsByYear,
	[January] - LAG([January]) OVER ( ORDER BY [Year]) as JanuaryDiff,
	[February] - LAG([February]) OVER ( ORDER BY [Year]) as FebruaryDiff,
	[March] - LAG([March]) OVER ( ORDER BY [Year]) as MarchDiff,
	[April] - LAG([April]) OVER ( ORDER BY [Year]) as AprilDiff,
	[May] - LAG([May]) OVER ( ORDER BY [Year]) as MayDiff,
����[June] - LAG([June]) OVER ( ORDER BY [Year]) as JuneDiff,
	[July] - LAG([July]) OVER ( ORDER BY [Year]) as JulyDiff,
	[August] - LAG([August]) OVER ( ORDER BY [Year]) as AugustDiff,
	[September] - LAG([September]) OVER ( ORDER BY [Year]) as SeptemberDiff,
	[October] - LAG([October]) OVER ( ORDER BY [Year]) as OctoberDiff,
	[November] - LAG([November]) OVER ( ORDER BY [Year]) as NovemberDiff,
	[December] - LAG([December]) OVER ( ORDER BY [Year]) as DecemberDiff
	from pivotingCTE
    where [year] = year(GETDATE()) or [year]=(YEAR(GETDATE()) - 1) )
    select *,TotalsByYear - lag(TotalsByYear) OVER ( ORDER BY [Year]) as YearDifference, 
    ((TotalsByYear - lag(TotalsByYear) OVER ( ORDER BY [Year]))/lag(TotalsByYear) OVER ( ORDER BY [Year])) * 100 
   from secondCTE --where [year]=(YEAR(GETDATE()));
--select * from dbo.aravindansample