DROP TABLE IF EXISTS #templookup

select [Facility Name] as [Name], [Facility ID] as Id into #templookup 
from raw.PremierCustomerList		

select [Facility Name] from raw.PremierCustomerList
group by [Facility Name]
having count([Facility Name]) > 1

select * from raw.PremierCustomerList 
where  [Facility name] = 'THCC - TRINITY PROFESSIONAL GROUP - PRIMARY CARE' 

select Name,Id from #templookup as abc group by abc.name having count(Name) > 1

select distinct fm.ClientId 'clientid', 
					pcl.[Facility ID] 'AccountNumber', 
					pcl.[Facility Name] 'CustomerName', 
					pcl.[Facility AddrLine1] 'Address1', 
					pcl.[Facility AddrLine2] 'Address2', 
 					pcl.[Facility City]      'City',
					pcl.[Facility State]     'State', 
					pcl.[Facility Zip]       'Zip',
					pcl.[Facility DEA]       'DEA',
					pcl.[Premier_Relation]       'Premier_Relation',
					pcl.[SPC]       'SPC',
					pcl.[Division Name]       'Division Name',
					(select lk.[id] from 
					#templookup as lk where lk.Name =  pcl.[Division Name] ) as 'DivisionId' ,
					co.CustomerOrganizationId 'CustomerOrganizationId', 
					--pcl.[Facility Direct Parent ID] 'OrganizationNumber', 
					--pcl.[Facility Direct Parent] 'OrganizationName',

--updating top parent to org name & ID
					case when fm.ClientImportCode='NY5011' then pcl.[Facility Direct Parent ID] else pcl.[Health System ID] end 'OrganizationNumber',
					case when fm.ClientImportCode='NY5011' then pcl.[Facility Direct Parent] else pcl.[Health System] end 'OrganizationName'
					from [Raw].[PremierCustomerList] pcl
						inner join [dbo].[ImportFileIDMapping] fm
							on pcl.[Health System ID] = fm.ClientImportCode
						inner join CustomerOrganization co
							on pcl.[Facility Direct Parent ID] = co.[OrganizationNumber]