with inactivecte as (
select
	c.customerid
from
	dbo.customer c
where
	not exists (
	select
		1
	from
		dbo.sales s
	where
		s.customerid = c.customerid
		and s.TransactionDate >= DATEADD(year,-3, GETDATE())))
update
	dbo.customer
set
	status = 'I',
	DateChanged = GETDATE()
where
	CustomerId in (
	select
		customerid
	from
		inactivecte)