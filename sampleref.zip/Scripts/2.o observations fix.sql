insert into (ClientId,UserDataId,DashboardTypeId,Description,PermissionTypeId,PermissionKey,Sort,Active) VALUES
	 (2,4,1,N'My Committee Activity',5,N'Projects',1,1),
	 (2,4,2,N'Buy In Impact',8,N'BuyIns',2,1),
	 (2,4,3,N'Active Projects',5,N'Projects',3,1),
	 (2,4,4,N'Inventory Recommendations',10,N'InventoryPlanning',4,1),
	 (2,4,5,N'Last Viewed Items',1,N'Products',5,1),
	 (2,4,6,N'Managed Shortages',7,N'SignalsShortages',6,1),
	 (2,4,7,N'Top Opportunities',9,N'Margins',7,1),
	 (2,4,8,N'Saved Product Searches',1,N'Products',8,1),
	 (2,4,9,N'Contracts To Review',2,N'Contracts',9,1),
	 (2,4,10,N'Patent Expiration',1,N'Products',10,1),
	 (2,4,11,N'Patent Exclusivity',1,N'Products',11,1),
	 (2,4,12,N'Current Stock Outs',1,N'Products',12,1),
	 (2,4,13,N'Top Price Increases',1,N'Products',13,1),
	 (2,4,14,N'Top Price Decreases',1,N'Products',14,1);

	
INSERT INTO App.DashboardType (Description,PermissionTypeId,DateAdded,DateChanged,UserAddedUserDataId,UserChangedUserDataId) VALUES
	 (N'My Committee Activity',5,'2020-12-21 09:37:15.163','2020-12-21 09:37:15.163',1,1),
	 (N'Buy In Impact',8,'2020-12-21 09:37:15.163','2020-12-21 09:37:15.163',1,1),
	 (N'Active Projects',5,'2020-12-21 09:37:15.163','2020-12-21 09:37:15.163',1,1),
	 (N'Inventory Recommendations',10,'2020-12-21 09:37:15.163','2020-12-21 09:37:15.163',1,1),
	 (N'Last Viewed Items',1,'2020-12-21 09:37:15.163','2020-12-21 09:37:15.163',1,1),
	 (N'Managed Shortages',7,'2020-12-21 09:37:15.163','2020-12-21 09:37:15.163',1,1),
	 (N'Top Opportunities',9,'2020-12-21 09:37:15.163','2020-12-21 09:37:15.163',1,1),
	 (N'Saved Product Searches',1,'2020-12-21 09:37:15.163','2020-12-21 09:37:15.163',1,1),
	 (N'Contracts To Review',2,'2020-12-21 09:37:15.163','2020-12-21 09:37:15.163',1,1),
	 (N'Patent Expiration',1,'2020-12-21 09:37:15.163','2020-12-21 09:37:15.163',1,1);
INSERT INTO App.DashboardType (Description,PermissionTypeId,DateAdded,DateChanged,UserAddedUserDataId,UserChangedUserDataId) VALUES
	 (N'Patent Exclusivity',1,'2020-12-21 09:37:15.163','2020-12-21 09:37:15.163',1,1),
	 (N'Current Stock Outs',1,'2020-12-21 09:37:15.163','2020-12-21 09:37:15.163',1,1),
	 (N'Top Price Increases',1,'2020-12-21 09:37:15.163','2020-12-21 09:37:15.163',1,1),
	 (N'Top Price Decreases',1,'2020-12-21 09:37:15.163','2020-12-21 09:37:15.163',1,1);
	
	
	
INSERT INTO App.UserDashboard (ClientId,UserDataId,DashboardTypeId,Sort,Active,DateAdded,DateChanged,UserAddedUserDataId,UserChangedUserDataId) VALUES
	 (2,4,1,1,1,'2021-01-04 11:38:50.350','2021-01-04 11:38:50.350',2,2),
	 (2,4,2,2,1,'2021-01-04 11:38:50.353','2021-01-04 11:38:50.353',2,2),
	 (2,4,3,3,1,'2021-01-04 11:38:50.360','2021-01-04 11:38:50.360',2,2),
	 (2,4,4,4,1,'2021-01-04 11:38:50.363','2021-01-04 11:38:50.363',2,2),
	 (2,4,5,5,1,'2021-01-04 11:38:50.370','2021-01-04 11:38:50.370',2,2),
	 (2,4,6,6,1,'2021-01-04 11:38:50.373','2021-01-04 11:38:50.373',2,2),
	 (2,4,7,7,1,'2021-01-04 11:38:50.377','2021-01-04 11:38:50.377',2,2),
	 (2,4,8,8,1,'2021-01-04 11:38:50.387','2021-01-04 11:38:50.387',2,2),
	 (2,4,9,9,1,'2021-01-04 11:38:50.393','2021-01-04 11:38:50.393',2,2),
	 (2,4,10,10,1,'2021-01-04 11:38:50.397','2021-01-04 11:38:50.397',2,2);
INSERT INTO App.UserDashboard (ClientId,UserDataId,DashboardTypeId,Sort,Active,DateAdded,DateChanged,UserAddedUserDataId,UserChangedUserDataId) VALUES
	 (2,4,11,11,1,'2021-01-04 11:38:50.400','2021-01-04 11:38:50.400',2,2),
	 (2,4,12,12,1,'2021-01-04 11:38:50.403','2021-01-04 11:38:50.403',2,2),
	 (2,4,13,13,1,'2021-01-04 11:38:50.410','2021-01-04 11:38:50.410',2,2),
	 (2,4,14,14,1,'2021-01-04 11:38:50.413','2021-01-04 11:38:50.413',2,2);
	
	
	
	
	 SELECT ud.[UserDashboardId]
               , ud.[ClientId]
               , ud.[UserDataId]
               , ud.[DashboardTypeId]
               , d.[Description]
               , d.[PermissionTypeId]
               , p.[Description] [PermissionKey]
               , ud.[Sort]
               , ud.[Active]
            FROM App.UserDashboard ud
            JOIN App.DashboardType d ON ud.DashboardTypeId = d.DashboardTypeId
            LEFT JOIN App.PermissionType p ON d.PermissionTypeId = p.Id
         --   WHERE ud.ClientId = 2 AND ud.UserDataId = 4
            --AND ***PERMISSION_CLAUSE***
            ORDER BY ud.Sort asc

 MERGE INTO Project.ProjectDefaults as Target
	        USING (SELECT 2, 1) AS Source (ClientId, ProjectTypeId)
	        ON (Target.ClientId = Source.ClientId AND Target.ProjectTypeId = Source.ProjectTypeId)
	        WHEN MATCHED THEN
		        UPDATE SET DecisionMakerId = null
				         , EntityAcceptanceTypeId = null
				         , DateChanged = GETDATE()
				         , UserChangedUserDataId = 4
	        WHEN NOT MATCHED THEN
		        INSERT (ClientId, ProjectTypeId, DecisionMakerId, EntityAcceptanceTypeId, DateAdded, DateChanged, UserAddedUserDataId, UserChangedUserDataId)
		        VALUES (2, 1, null, null, GETDATE(), GETDATE(), 4, 4)
            OUTPUT inserted.ProjectDefaultId;
           
           
           select * from Project.ProjectDefaults
           
           
           
 SELECT ud.[UserDashboardId]
               , ud.[ClientId]
               , ud.[UserDataId]
               , ud.[DashboardTypeId]
               , d.[Description]
               , d.[PermissionTypeId]
               , p.[Description] [PermissionKey]
               , ud.[Sort]
               , ud.[Active]
            FROM App.UserDashboard ud
            JOIN App.DashboardType d ON ud.DashboardTypeId = d.DashboardTypeId
            LEFT JOIN App.PermissionType p ON d.PermissionTypeId = p.Id
         --   WHERE ud.ClientId = 2 AND ud.UserDataId = 4
            --AND ***PERMISSION_CLAUSE***
            ORDER BY ud.Sort asc
            
            select * from app.PermissionType pt 
            select * from App.DashboardType
            select * from App.UserDashboard
           
           	