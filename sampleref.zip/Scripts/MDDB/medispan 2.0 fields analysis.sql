 SELECT
      s.name AS SchemaName
     ,t.name AS TableName
     ,c.name AS ColumnName
 FROM sys.schemas AS s
 JOIN sys.tables AS t ON t.schema_id = s.schema_id
 JOIN sys.columns AS c ON c.object_id = t.object_id
 ORDER BY
      SchemaName
     ,TableName
     ,ColumnName;
    
 SELECT distinct TABLE_SCHEMA AS SchemaName,TABLE_NAME AS TableName
   --   TABLE_SCHEMA AS SchemaName
  --   ,TABLE_NAME AS TableName
  --   ,COLUMN_NAME AS ColumnName
 FROM INFORMATION_SCHEMA.COLUMNS
 where TABLE_NAME like '%mf2%'
 ORDER BY
      SchemaName
     ,TableName
   --  ,ColumnName;