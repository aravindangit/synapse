

drop table rawWK.mddb_m25gppc;
CREATE TABLE rawWK.mddb_m25gppc (
    GenericProductPackagingCode varchar(8) NULL,
    PackageSize int NULL,
    PackageSizeUnitofMeasure varchar(2) NULL,
    PackageQuantity int NULL,
    UnitDoseUnitofUse varchar(8) NULL,
    PackageDescriptionCode varchar(2) NULL,
    GenericProductIdentifier varchar(14) NULL,
    TransactionCode varchar(1) NULL,
    LastChangeDate varchar(8) NULL,
    Reserve varchar(15) NULL);

NDC-UPC-HRI
Reserve-1
ModiferCode
TransactionCode
LastChangeDate
Reserve-2
    CREATE TABLE rawWK.mddb_m25nmod (
    [NDC-UPC-HRI] varchar(11) Not NULL,
    [Reserve-1] varchar(1) NULL,
    ModiferCode varchar(6) NULL,
    TransactionCode varchar(1) NULL,
    LastChangeDate varchar(8) null,
    [Reserve-2] varchar(5) NULL);
    

    drop table rawwk.mddb_m25gprr where gppcunitprice > 0

    CREATE TABLE rawWK.mddb_m25gprr (
    GenericProductPackagingCode varchar(8)  NULL,
    GPPCPriceCode varchar(1) NULL,
    GPPCUnitPrice  DECIMAL(13,5) NULL,
    GPPCEffDate varchar(8) NULL,
    TransactionCode varchar(1) null,
    [Reserve] varchar(5) NULL);

 CREATE TABLE rawWK.mddb_m25tcrf (
    TherapeuticClassificationCode varchar(10)  NULL,
    Reserve1 varchar(4)  NULL,
    RecordTypeCode varchar(1)  NULL,
    TCGPIName varchar(60)  NULL,
    Reserve2 varchar(19)  NULL,
    TransactionCode varchar(1)  NULL,
    LastChangeDate varchar(8)  NULL);

    select * from rawwk.mddb_m25tcrf
GenericProductPackagingCode
GPPCPriceCode
GPPCUnitPrice
GPPCEffDate
TransactionCode
Reserve

ModifierCode
ModifierDescription
TransactionCode
LastChangeDate
Reserve

 CREATE TABLE rawWK.mddb_m25mod (
    ModifierCode varchar(6)  NULL,
    ModifierDescription varchar(25)  NULL,
    TransactionCode varchar(1)  NULL,
    LastChangeDate varchar(8)  NULL,
    Reserve varchar(24)  NULL); 

    select top 10 * from rawWK.mddb_m25gppc
    select top 10 * from rawwk.mddb_m25nmod
    select * from rawwk.mddb_m25gprr where GPPCUnitPrice > 0

































































ALTER TABLE rawWK.mddb_m25gppc
DROP COLUMN PackageCode;
	CustomerId int IDENTITY(1,1) NOT NULL,
	CustomerUId uniqueidentifier DEFAULT newsequentialid() NULL,
	ClientId int NOT NULL,
	DataSourceId int NULL,
	AccountNumber varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CustomerOrganizationId int NULL,
	OrganizationNumber varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	OrganizationName varchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CustomerName varchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	PriceList varchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	AddrLine1 varchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	AddrLine2 varchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	City varchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	State varchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Zip varchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ParentCustomerId int NULL,
	CotId int NULL,
	CustomImportCode varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	GlDept int NULL,
	Status char(1) COLLATE SQL_Latin1_General_CP1_CI_AS DEFAULT 'A' NULL,
	DateImported datetime DEFAULT getdate() NULL,
	DateChanged datetime DEFAULT getdate() NULL,
	CustomerPatientCareAreaId int NULL,
	CustomerBusinessTypeId int NULL,
	CustomerPurchaseTypeId int NULL,
	CustomerSpecialtyTypeId int NULL,
	CustomerRegionId int NULL,
	DeaLicenseNum varchar(15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DeaLicenseExpiration datetime NULL,
	StateLicenseNum varchar(15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	General_CP1_CI_AS NULL,
	Premier_Relation varchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	SPC varchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DivisionName varchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DivisionId varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_Customer PRIMARY KEY (CustomerId)
);
 