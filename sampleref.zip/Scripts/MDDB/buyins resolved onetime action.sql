

insert into app.BuyInResolved
([ClientId],[Ndc],[WholesalerSupplierId],[CustomerId],[UserAddedId],[DateAdded],[DivisionID] ,[Status],[AccountType])

VALUES
(5,'50242012047',1,)

select * from Supplier
select * from Client

select * from customer where AccountNumber = 'AH7671'
insert into dbo.roi_tracking ( [Ndc] , [Division] , [Facility] , [Wholesaler] , [WholesalerAccountNumber] , [ROI_Track_Date] , [ROI_Start_Date] , [ROI_End_Date] , [Status] , [Estimated_Advance_Purchase_Units] , [Actual_Quantity] , [Units_to_Count_for_ROI] , [Actual_ROI] , [Clientid] , [IsActive] , [Current_Price] , [Reason_ROI] , [Actual_Percentage_Increase] ) 
values (/* Ndc */'50242012047' ,/* Division */'' ,/* Facility */'ST. LUKE''S HOSPITAL - CARBON CAMPUS - AH7671 - FS0850479' ,/* Wholesaler */'McKesson' ,/* WholesalerAccountNumber */null ,/* ROI_Track_Date */'2022-11-16 12:39:56.363' ,/* ROI_Start_Date */null ,/* ROI_End_Date */null ,/* Status */'In Process ROI' ,/* Estimated_Advance_Purchase_Units */10 ,/* Actual_Quantity */null ,/* Units_to_Count_for_ROI */0 ,/* Actual_ROI */null ,/* Clientid */5 ,/* IsActive */1 ,/* Current_Price */6720.1001 ,/* Reason_ROI */null ,/* Actual_Percentage_Increase */null ); 
 
insert into dbo.roi_tracking ( [Ndc] , [Division] , [Facility] , [Wholesaler] , [WholesalerAccountNumber] , [ROI_Track_Date] , [ROI_Start_Date] , [ROI_End_Date] , [Status] , [Estimated_Advance_Purchase_Units] , [Actual_Quantity] , [Units_to_Count_for_ROI] , [Actual_ROI] , [Clientid] , [IsActive] , [Current_Price] , [Reason_ROI] , [Actual_Percentage_Increase] ) 
values (/* Ndc */'00003089431' ,/* Division */'' ,/* Facility */'ST. LUKE''S HOSPITAL - CARBON CAMPUS - AH7671 - FS0850479' ,/* Wholesaler */'McKesson' ,/* WholesalerAccountNumber */null ,/* ROI_Track_Date */'2022-11-16 12:40:45.280' ,/* ROI_Start_Date */null ,/* ROI_End_Date */null ,/* Status */'In Process ROI' ,/* Estimated_Advance_Purchase_Units */10 ,/* Actual_Quantity */null ,/* Units_to_Count_for_ROI */0 ,/* Actual_ROI */null ,/* Clientid */5 ,/* IsActive */1 ,/* Current_Price */614.7 ,/* Reason_ROI */null ,/* Actual_Percentage_Increase */null ); 
 
insert into dbo.roi_tracking ( [Ndc] , [Division] , [Facility] , [Wholesaler] , [WholesalerAccountNumber] , [ROI_Track_Date] , [ROI_Start_Date] , [ROI_End_Date] , [Status] , [Estimated_Advance_Purchase_Units] , [Actual_Quantity] , [Units_to_Count_for_ROI] , [Actual_ROI] , [Clientid] , [IsActive] , [Current_Price] , [Reason_ROI] , [Actual_Percentage_Increase] ) 
values (/* Ndc */'00173088214' ,/* Division */'' ,/* Facility */'ST. LUKE''S HOSPITAL - CARBON CAMPUS - AH7671 - FS0850479' ,/* Wholesaler */'McKesson' ,/* WholesalerAccountNumber */null ,/* ROI_Track_Date */'2022-11-16 12:41:32.940' ,/* ROI_Start_Date */null ,/* ROI_End_Date */null ,/* Status */'In Process ROI' ,/* Estimated_Advance_Purchase_Units */7 ,/* Actual_Quantity */null ,/* Units_to_Count_for_ROI */0 ,/* Actual_ROI */null ,/* Clientid */5 ,/* IsActive */1 ,/* Current_Price */87.97 ,/* Reason_ROI */null ,/* Actual_Percentage_Increase */null ); 
 
insert into dbo.roi_tracking ( [Ndc] , [Division] , [Facility] , [Wholesaler] , [WholesalerAccountNumber] , [ROI_Track_Date] , [ROI_Start_Date] , [ROI_End_Date] , [Status] , [Estimated_Advance_Purchase_Units] , [Actual_Quantity] , [Units_to_Count_for_ROI] , [Actual_ROI] , [Clientid] , [IsActive] , [Current_Price] , [Reason_ROI] , [Actual_Percentage_Increase] ) 
values (/* Ndc */'00006027731' ,/* Division */'' ,/* Facility */'ST. LUKE''S HOSPITAL - CARBON CAMPUS - AH7671 - FS0850479' ,/* Wholesaler */'McKesson' ,/* WholesalerAccountNumber */null ,/* ROI_Track_Date */'2022-11-16 12:41:51.750' ,/* ROI_Start_Date */null ,/* ROI_End_Date */null ,/* Status */'In Process ROI' ,/* Estimated_Advance_Purchase_Units */7 ,/* Actual_Quantity */null ,/* Units_to_Count_for_ROI */0 ,/* Actual_ROI */null ,/* Clientid */5 ,/* IsActive */1 ,/* Current_Price */484.59 ,/* Reason_ROI */null ,/* Actual_Percentage_Increase */null ); 
 
insert into dbo.roi_tracking ( [Ndc] , [Division] , [Facility] , [Wholesaler] , [WholesalerAccountNumber] , [ROI_Track_Date] , [ROI_Start_Date] , [ROI_End_Date] , [Status] , [Estimated_Advance_Purchase_Units] , [Actual_Quantity] , [Units_to_Count_for_ROI] , [Actual_ROI] , [Clientid] , [IsActive] , [Current_Price] , [Reason_ROI] , [Actual_Percentage_Increase] ) 
values (/* Ndc */'50458058010' ,/* Division */'' ,/* Facility */'ST. LUKE''S HOSPITAL - CARBON CAMPUS - AH7671 - FS0850479' ,/* Wholesaler */'McKesson' ,/* WholesalerAccountNumber */null ,/* ROI_Track_Date */'2022-11-16 12:42:15.517' ,/* ROI_Start_Date */null ,/* ROI_End_Date */null ,/* Status */'In Process ROI' ,/* Estimated_Advance_Purchase_Units */7 ,/* Actual_Quantity */null ,/* Units_to_Count_for_ROI */0 ,/* Actual_ROI */null ,/* Clientid */5 ,/* IsActive */1 ,/* Current_Price */1611.97 ,/* Reason_ROI */null ,/* Actual_Percentage_Increase */null ); 
 
insert into app.BuyInResolved ( [ClientId] , [Ndc] , [WholesalerSupplierId] , [CustomerId] , [UserAddedId] , [DateAdded] , [DivisionID] , [Status] , [AccountType] ) 
values (5 ,'50242012047' ,1 ,90,2 ,getdate() ,null ,/* Status */'TrackedReviewed' ,/* AccountType */'GPO' ); 
insert into app.BuyInResolved ( [ClientId] , [Ndc] , [WholesalerSupplierId] , [CustomerId] , [UserAddedId] , [DateAdded] , [DivisionID] , [Status] , [AccountType] ) 
values (5 ,'00003089431' ,1 ,90 ,2 ,getdate() ,null ,/* Status */'TrackedReviewed' ,/* AccountType */'GPO' ); 
insert into app.BuyInResolved ( [ClientId] , [Ndc] , [WholesalerSupplierId] , [CustomerId] , [UserAddedId] , [DateAdded] , [DivisionID] , [Status] , [AccountType] ) 
values (5,'00173088214' ,1 ,90 ,2 ,getdate() ,null ,/* Status */'TrackedReviewed' ,/* AccountType */'GPO' ); 
insert into app.BuyInResolved ( [ClientId] , [Ndc] , [WholesalerSupplierId] , [CustomerId] , [UserAddedId] , [DateAdded] , [DivisionID] , [Status] , [AccountType] ) 
values (5 ,'00006027731' ,1 ,90 ,2 ,getdate() ,null ,/* Status */'TrackedReviewed' ,/* AccountType */'GPO' ); 
insert into app.BuyInResolved ( [ClientId] , [Ndc] , [WholesalerSupplierId] , [CustomerId] , [UserAddedId] , [DateAdded] , [DivisionID] , [Status] , [AccountType] ) 
values (5 ,'50458058010' ,1 ,90 ,2 ,getdate() ,null ,/* Status */'TrackedReviewed' ,/* AccountType */'GPO' ); 

select * from dbo.ROI_Tracking
select * from app.BuyInResolved

SELECT * FROM APP.UserData
SELECT * FROM DBO.Client

insert into app.BuyInResolved ( [ClientId] , [Ndc] , [WholesalerSupplierId] , [CustomerId] , [UserAddedId] , [DateAdded] , [DivisionID] , [Status] , [AccountType] ) 
values (7 ,'00074055402' ,1 ,532 ,2 ,getdate() ,null ,/* Status */'TrackedReviewed' ,/* AccountType */'GPO' ); 
select * from customer where AccountNumber = 'WI2381'
 


insert into app.BuyInResolved ( [ClientId] , [Ndc] , [WholesalerSupplierId] , [CustomerId] , [UserAddedId] , [DateAdded] , [DivisionID] , [Status] , [AccountType] ) 
values (1 ,'65649030303' ,2 ,57,2 ,getdate() ,null ,/* Status */'TrackedReviewed' ,/* AccountType */'GPO' ); 
insert into app.BuyInResolved ( [ClientId] , [Ndc] , [WholesalerSupplierId] , [CustomerId] , [UserAddedId] , [DateAdded] , [DivisionID] , [Status] , [AccountType] ) 
values (1 ,'63833038602' ,2 ,57 ,2 ,getdate() ,null ,/* Status */'TrackedReviewed' ,/* AccountType */'GPO' ); 
insert into app.BuyInResolved ( [ClientId] , [Ndc] , [WholesalerSupplierId] , [CustomerId] , [UserAddedId] , [DateAdded] , [DivisionID] , [Status] , [AccountType] ) 
values (1,'00186037028' ,2 ,57 ,2 ,getdate() ,null ,/* Status */'TrackedReviewed' ,/* AccountType */'GPO' ); 
insert into app.BuyInResolved ( [ClientId] , [Ndc] , [WholesalerSupplierId] , [CustomerId] , [UserAddedId] , [DateAdded] , [DivisionID] , [Status] , [AccountType] ) 
values (1 ,'00003089331' ,2 ,57 ,2 ,getdate() ,null ,/* Status */'TrackedReviewed' ,/* AccountType */'GPO' ); 
insert into app.BuyInResolved ( [ClientId] , [Ndc] , [WholesalerSupplierId] , [CustomerId] , [UserAddedId] , [DateAdded] , [DivisionID] , [Status] , [AccountType] ) 
values (1 ,'58468008001' ,2 ,57 ,2 ,getdate() ,null ,/* Status */'TrackedReviewed' ,/* AccountType */'GPO' ); 
insert into app.BuyInResolved ( [ClientId] , [Ndc] , [WholesalerSupplierId] , [CustomerId] , [UserAddedId] , [DateAdded] , [DivisionID] , [Status] , [AccountType] ) 
values (1 ,'00131181067' ,2 ,57 ,2 ,getdate() ,null ,/* Status */'TrackedReviewed' ,/* AccountType */'GPO' ); 
select * from app.UserData

SELECT * from dbo.ROI_Tracking
select * from dbo.Supplier where SupplierName like '%Cardinal Health%'

select * from dbo.customer where AccountNumber = 'nc7777'

select * from app.BuyInResolved

select * from dbo.ROI_Tracking

update dbo.ROI_Tracking
set status = 'In Process'
where status = 'In Process ROI';

select * from dbo.ROI_Tracking where status like '%ROI%'