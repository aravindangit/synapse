select * from dbo.ROI_Information

insert into  dbo.roi_history_dropped_pred
([action],
[Ndc],
[ROI_Check_Date],
[ROI_Start_Date],
[ROI_End_Date],
[Actual_Percentage_Increase],
[last_updated] )
select  
'INSERTED' as [action],
[Ndc],
[ROI_Check_Date],
[ROI_Start_Date],
[ROI_End_Date],
[Actual_Percentage_Increase],
GETDATE()
 from dbo.ROI_Information
 where [ROI_End_Date] is not NULL

select * into dbo.roi_history_dropped_pred from dbo.ROI_history

select distinct last_updated from dbo.roi_history_dropped_pred


with recordcomparisoncte as ( 
select 
[Ndc],
[ROI_Check_Date],
[ROI_Start_Date],
[last_updated] ,
dense_rank() over(order BY last_updated ) as ranking
from dbo.roi_history_dropped_pred)
select ndc from recordcomparisoncte where ranking = 1
EXCEPT
select ndc from recordcomparisoncte where ranking = 2

select * from dbo.ROI_history

select top 5 * into dbo.customersourcetesting from dbo.customer

select top 5 * into dbo.customertargettesting from dbo.customer

select * from dbo.customersourcetesting
select * from dbo.customertargettesting

delete from dbo.customertargettesting where customerid > 3


select customerid,AccountNumber from dbo.customersourcetesting
EXCEPT
select customerid,AccountNumber from dbo.customertargettesting
CREATE TABLE Persons (
    ID int NOT NULL,
    LastName varchar(255) NOT NULL,
    FirstName varchar(255),
    Age int,
    City varchar(255) DEFAULT 'Sandnes'
);
--creating table to capture dropped ndc from the prediction list
CREATE TABLE dbo.roi_dropped_prediction (
      ndc VARCHAR(11) not NULL,
      last_updated DATETIME DEFAULT (GETDATE()));


--production version
with recordcomparisoncte as ( 
select 
[Ndc],
[last_updated] ,
dense_rank() over(order BY last_updated desc ) as ranking
from dbo.roi_history_dropped_pred),
droppedndc as ( 
select ndc from recordcomparisoncte where ranking = 2
EXCEPT
select ndc from recordcomparisoncte where ranking = 1)
insert into dbo.roi_dropped_prediction (ndc)
select ndc from droppedndc
