select * from SyncControl.MemberCustomerSync

INSERT INTO SyncControl.MemberCustomerSync (
    [Member_Environment]
    , [Member_azure_sql_url]
    , [Member_azure_db]
    , [Member_Tenant]
    , [Member_Service_Principal]
    , [Member_Secret]
    , [Status]
    )
    values('AAH'
    , 'sqlcogrxprodcommonspirit.database.windows.net'
    , 'sqldbCogRxProdAdvocateAurora'
    , 'b110eddf-23ae-457c-a6f3-734d592b2847'
    , '7aee9959-dc91-4e83-b0fc-51e0ff91adbb'
    , 'Secret-Cogrx-Client-Databases'
    , 'A')

----creating new lookup table for 1.o environment.
--drop table [SyncControl].[PremierCustomerSyncNewSp]
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [SyncControl].[PremierCustomerSyncNewSp](
	[PremierCustomerSyncId] [int] IDENTITY(1,1) NOT NULL,
	[DataFactory] [varchar](250) NULL,
	[HealthSystemID] [varchar](50) NULL,
	[FacilityDirectParentID] [varchar](50) NULL,
	[Secret] [varchar](250) NULL,
	[DatasetInvoiceCode] [varchar](50) NULL,
	[DatasetPoCode] [varchar](50) NULL,
    [Member_Environment] [varchar](250) NULL,
	[Member_azure_sql_url] [varchar](250) NULL,
	[Member_azure_db] [varchar](50) NULL,
	[Member_Tenant] [varchar](50) NULL,
	[Member_Service_Principal] [varchar](250) NULL,
	[Member_Secret] [varchar](50) NULL,
	[Status] [char](1) NULL
) ON [PRIMARY]
GO
ALTER TABLE [SyncControl].[PremierCustomerSyncNewSp] ADD  CONSTRAINT [PK_PremierCustomerSync_PremierCustomerSyncId1] PRIMARY KEY CLUSTERED 
(
	[PremierCustomerSyncId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
------
    select * from SyncControl.MemberCustomerSync

    delete from SyncControl.MemberCustomerSync where Member_Environment = 'AAH'

   update SyncControl.MemberCustomerSync 
   set status = 'I'
   where Member_Environment = 'AAH'


   insert into [SyncControl].[PremierCustomerSyncNewSp] ([DataFactory],[HealthSystemID],[FacilityDirectParentID],[Secret],[DatasetInvoiceCode],[DatasetPoCode],[Status])
select 'adf-Premier-DataReceive-prod','CO5012',NULL,'Secret-CogRX-DB-CommonSpirit','PremierWholesaleInvoice','PremierWholesalePO','A' UNION ALL
select 'adf-Premier-DataReceive-prod','PA0023',NULL,'Secret-CogRX-DB-stluke','PremierWholesaleInvoice','PremierWholesalePO','A' UNION ALL
select 'adf-Premier-DataReceive-prod','NY5011','NY0024','Secret-CogRX-DB-northwell','PremierWholesaleInvoice','PremierWholesalePO','A' UNION ALL
select 'adf-Premier-DataReceive-prod','MN2013',NULL,'Secret-CogRX-DB-Fairview','PremierWholesaleInvoice','PremierWholesalePO','A' UNION ALL
select 'adf-Premier-DataReceive-prod','743692',NULL,'Secret-CogRX-DB-upmc','PremierWholesaleInvoice','PremierWholesalePO','A' UNION ALL
select 'adf-Premier-DataReceive-prod','NY5011','NY5073','Secret-CogRX-DB-Demo','PremierWholesaleInvoice','PremierWholesalePO','I' UNION ALL
select 'adf-Premier-DataReceive-prod','WI0013',NULL,'Secret-CogRX-DB-AdvocateAurora','PremierWholesaleInvoice','PremierWholesalePO','A' UNION ALL
select 'adf-Premier-DataReceive-prod','CO5012','838509','Secret-CogRX-DB-Centura','PremierWholesaleInvoice','PremierWholesalePO','A' UNION ALL
select 'adf-Premier-DataReceive-prod','PA5036',NULL,'Secret-CogRX-DB-JeffersonHealth','PremierWholesaleInvoice','PremierWholesalePO','A';

update [SyncControl].[PremierCustomerSyncNewSp]
set  [Member_Environment] = '',
	[Member_azure_sql_url] = 'sqlcogrxprodcommonspirit.database.windows.net',
	[Member_azure_db] = 'sqldbCogRxProdAdvocateAurora',
	[Member_Tenant] = 'b110eddf-23ae-457c-a6f3-734d592b2847',
	[Member_Service_Principal] = '7aee9959-dc91-4e83-b0fc-51e0ff91adbb',
	[Member_Secret] = 'Secret-Cogrx-Client-Databases',
	[Status] = 'A'
where secret = 'Secret-CogRX-DB-AdvocateAurora'

select * from [SyncControl].[PremierCustomerSyncNewSp] where [Status]= 'A'

 update [SyncControl].[PremierCustomerSyncNewSp]
 set status = 'I'
 where secret != 'Secret-CogRX-DB-AdvocateAurora'

 select [PremierCustomerSyncId],
 [DataFactory],
 [HealthSystemID],
 [FacilityDirectParentID],
 [Secret],
 [DatasetInvoiceCode],
 [DatasetPoCode],
 [Member_Environment],
 [Member_azure_sql_url],
 [Member_azure_db],
 [Member_Tenant],
 [Member_Service_Principal],
 [Member_Secret],
 [Status] from SyncControl.PremierCustomerSyncNewSp