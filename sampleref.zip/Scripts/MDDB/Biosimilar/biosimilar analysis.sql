
select distinct hcpcscode  from AspPriceAndLimitsbiobkp where hcpcsnotes like '8%%'

ALTER TABLE Authors  ADD isActiveAuthor BIT;

select * from dbo.AspPriceAndLimits where hcpcsnotes is not null
alter table dbo.AspPriceAndLimits 
    add  HcpcsNotes varchar(255) null,
      IsBiosimilar bit;

      alter table dbo.AspPriceAndLimitsbiobkp add IsBiosimilar AS
      case when hcpcsnotes = '8% of reference add-on applied' then 1 else 0 end
HcpcsNotes,IsBiosimilar
--8% of reference add-on applied
20220922
select * from dbo.AspPriceAndLimits where hcpcsnotes is not null


select * from dbo.AspPriceAndLimitsbiobkp where isbiosimilar = 1

select * from [rawWK].[pb2lmn_PaymentAllowanceLimitNotesFile]
--change 1
--add the below piece of code in the following sp [Integrations].[MergeWoltersKluwerAspItemPrice]
With LatestNotesCte as (
select HcpcsCode,QuarterDate, notes from  (
    SELECT hcpcscode
        , quarterdate
        , notes AS notes
        , ROW_NUMBER() OVER(partition by hcpcscode,quarterdate order by revisiondate desc) as rownum
    FROM [rawWK].[pb2lmn_PaymentAllowanceLimitNotesFile]) AS A WHERE A.ROWNUM = 1)
update apl
set apl.HcpcsNotes = bpl.notes 
FROM dbo.AspPriceAndLimits apl
JOIN LatestNotesCte bpl
    ON apl.HcpcsCode = bpl.HcpcsCode
        AND apl.QuarterDate = bpl.QuarterDate


--change 2 change the following view [Sync].[vw_AspPriceAndLimits]

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER VIEW [Sync].[vw_AspPriceAndLimits]
AS
SELECT        dbo.ItemMaster.ItemUId, dbo.AspPriceAndLimits.AspPriceId, dbo.AspPriceAndLimits.Ndc, dbo.AspPriceAndLimits.itemId, dbo.AspPriceAndLimits.QuarterDate, dbo.AspPriceAndLimits.RevisionDate, 
                         dbo.AspPriceAndLimits.HcpcsCode, dbo.AspPriceAndLimits.HCPCSDescription, dbo.AspPriceAndLimits.HcpcsCodeDosage, dbo.AspPriceAndLimits.AspUnitPrice, dbo.AspPriceAndLimits.PaymentLimit, 
                         dbo.AspPriceAndLimits.IndependentEsrdLimit, dbo.AspPriceAndLimits.VaccineLimit, dbo.AspPriceAndLimits.DMEInfusionLimit, dbo.AspPriceAndLimits.BloodLimit, dbo.AspPriceAndLimits.PackageSize, 
                         dbo.AspPriceAndLimits.PackageQuantity, dbo.AspPriceAndLimits.BillableUnitsPerPackage, dbo.AspPriceAndLimits.BillableUnitsPer11DigitNDC, dbo.AspPriceAndLimits.IsCurrentRecords, 
                         dbo.AspPriceAndLimits.DateAdded, dbo.AspPriceAndLimits.DateChanged, dbo.AspPriceAndLimits.DataSourceId,
                         dbo.AspPriceAndLimits.HcpcsNotes,dbo.AspPriceAndLimits.IsBiosimilar
FROM            dbo.AspPriceAndLimits INNER JOIN
                         dbo.ItemMaster ON dbo.AspPriceAndLimits.itemId = dbo.ItemMaster.ItemId
GO

-- change 3 add the mapping field to contain hcpcsnotes in the sync process
    --pipline name 8_SyncItemMasterToCognativeRxItemTables_Configurable
    --activity name AspPriceAndLimits_Master


select * into dbo.AspPriceAndLimitsbiobkp from AspPriceAndLimits


--prerequisite adding new column to hold the notes column
alter table dbo.AspPriceAndLimitsbiobkp
ADD [HcpcsNotes]  varchar(255)  NULL 



SELECT tt.name     AS Table_Type,
  c.name           AS Column_Name,
  st.name          AS Datatype, 
  CASE WHEN st.name = 'numeric' THEN '(' + Convert(varchar(5), c.precision) + ',' + Convert(varchar(5), c.scale) + ')' 
  WHEN st.name IN ('char', 'nchar', 'varchar', 'nvarchar') THEN '(' + Convert(varchar(5), c.max_length) + ')' 
  ELSE '' END      AS Size,
  CASE WHEN c.is_nullable = 0 THEN 'NOT NULL,'
  ELSE ',' END     AS Nullable
FROM sys.table_types tt
  INNER JOIN sys.columns c ON c.object_id = tt.type_table_object_id
  INNER JOIN sys.systypes st ON (st.xusertype = c.system_type_id AND st.uid = 4)
ORDER BY tt.name, c.column_id


 [ItemMasterSync].[AspPriceAndLimitsType]

SELECT s.name, o.name, def = OBJECT_DEFINITION(d.referencing_id) 
  FROM sys.sql_expression_dependencies AS d
  INNER JOIN sys.objects AS o
     ON d.referencing_id = o.[object_id]
  INNER JOIN sys.schemas AS s
     ON o.[schema_id] = s.[schema_id]
  WHERE d.referenced_database_name IS NULL
    AND d.referenced_schema_name = N'ItemMasterSync'
    AND d.referenced_entity_name = N'AspPriceAndLimitsType';










------------------------------------------
DROP TYPE [ItemMasterSync].[AspPriceAndLimitsType]

CREATE TYPE [ItemMasterSync].[AspPriceAndLimitsTypeNew] AS TABLE(
	[ItemUId] [uniqueidentifier] NULL,
	[AspPriceId] [int] NOT NULL,
	[Ndc] [varchar](11) NULL,
	[itemId] [int] NULL,
	[QuarterDate] [varchar](8) NULL,
	[RevisionDate] [varchar](8) NULL,
	[HcpcsCode] [char](5) NOT NULL,
	[HCPCSDescription] [varchar](60) NULL,
	[HcpcsCodeDosage] [varchar](30) NULL,
	[AspUnitPrice] [numeric](13, 6) NULL,
	[PaymentLimit] [numeric](13, 5) NULL,
	[IndependentEsrdLimit] [numeric](13, 5) NULL,
	[VaccineLimit] [numeric](13, 5) NULL,
	[DMEInfusionLimit] [numeric](13, 5) NULL,
	[BloodLimit] [numeric](13, 5) NULL,
	[PackageSize] [numeric](15, 5) NULL,
	[PackageQuantity] [numeric](15, 5) NULL,
	[BillableUnitsPerPackage] [numeric](15, 5) NULL,
	[BillableUnitsPer11DigitNDC] [numeric](15, 5) NULL,
	[IsCurrentRecords] [bit] NULL,
	[DateAdded] [datetime] NULL,
	[DateChanged] [datetime] NULL,
	[DataSourceId] [int] NOT NULL,
  [HcpcsNotes] [varchar](255) null,
  [IsBiosimilar] bit
)


select HcpcsCode,
cast((PaymentLimit / 1.08) as decimal(13,6)) AspUnitPriceactual,
paymentlimit/ 1.08 as actualasp,(aspunitprice + AspUnitPrice*.02) as bioaspunitprice,
AspUnitPrice,
PaymentLimit,HcpcsNotes,IsBiosimilar from [dbo].[AspPriceAndLimits]
where HcpcsNotes = '8% of reference add-on applied'

select * into dbo.AspPriceAndLimitstesting from dbo.AspPriceAndLimits

update 
cast((m.paymentlimit / 1.06) as decimal(13,6)) AspUnitPrice

select * from dbo.AspPriceAndLimits

select * from AspPriceAndLimitstesting where HcpcsNotes = '8% of reference add-on applied'
update [dbo].[AspPriceAndLimitstesting]
set aspunitprice = cast((paymentlimit / 1.08) as decimal(13,6)), isbiosimilar = 1
where HcpcsNotes = '8% of reference add-on applied'
select * from AspPriceAndLimitstesting where HcpcsNotes = '8% of reference add-on applied'

