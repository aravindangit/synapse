SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [Integrations].[MergeWoltersKluwerNationalItemPrice] 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from interfering with SELECT statements.
	SET NOCOUNT ON;


declare @iDataSource int = 10;


MERGE [dbo].[NationalPharmacyItemPrice] AS tar
	USING (select pi.itemid,
				   npf.Ndc_Upc_Hri NDC,
				   pi.NdcFormatCode ,
				   pt.WkPriceCodeId,
				   npf.Price_Effective_Date PriceEffectiveDate,
				   npf.Unit_Price UnitPrice,
				   npf.extended_unit_price ExtendedUnitPrice,
				   npf.Package_Price PackagePrice,
				   ai.AwpIndicatorId AwpIndicatorId,
				   @iDataSource DataSourceId
			from [rawWK].[mf2prc_NdcPriceFile] npf
				left join [dbo].[PharmacyItem] pi
					on npf.Ndc_Upc_Hri = pi.ndc
				inner join [WoltersKluwer].[PriceTypeXref] pt
					on npf.Price_Code = pt.WkPriceCode
				left join [WoltersKluwer].[AwpIndicator] ai
					on npf.awp_indicator_code = ai.AwpIndicatorCode) AS src
	ON tar.NDC = src.NDC
	 and tar.WkPriceCodeId = src.WkPriceCodeId
	 and tar.PriceEffectiveDate = src.PriceEffectiveDate
	WHEN MATCHED 
			AND (tar.UnitPrice != src.UnitPrice
				or (src.UnitPrice is null and tar.UnitPrice is not null)
				or (src.UnitPrice is not null and tar.UnitPrice is null)
				or tar.ExtendedUnitPrice != src.ExtendedUnitPrice
				or (src.ExtendedUnitPrice is null and tar.ExtendedUnitPrice is not null)
				or (src.ExtendedUnitPrice is not null and tar.ExtendedUnitPrice is null)
				or tar.PackagePrice != src.PackagePrice
				or (src.PackagePrice is null and tar.PackagePrice is not null)
				or (src.PackagePrice is not null and tar.PackagePrice is null)
				or tar.AwpIndicatorId != src.AwpIndicatorId
				or (src.AwpIndicatorId is null and tar.AwpIndicatorId is not null)
				or (src.AwpIndicatorId is not null and tar.AwpIndicatorId is null)
				or tar.DataSourceId != src.DataSourceId)
		THEN
		UPDATE SET
			tar.PriceEffectiveDate = src.PriceEffectiveDate,
			tar.UnitPrice = src.UnitPrice,
			tar.ExtendedUnitPrice = src.ExtendedUnitPrice,
			tar.PackagePrice = src.PackagePrice,
			tar.AwpIndicatorId = src.AwpIndicatorId,
			tar.DataSourceId = src.DataSourceId,
			tar.DateChanged = getdate()
	WHEN NOT MATCHED THEN
		INSERT
		(	itemid,
			NDC,
			NdcFormatCode ,
			WkPriceCodeId,
			PriceEffectiveDate,
			UnitPrice,
			ExtendedUnitPrice,
			PackagePrice,
			AwpIndicatorId,
			DataSourceId
		)
		VALUES
		(   src.itemid,
			src.NDC,
			src.NdcFormatCode ,
			src.WkPriceCodeId,
			src.PriceEffectiveDate,
			src.UnitPrice,
			src.ExtendedUnitPrice,
			src.PackagePrice,
			src.AwpIndicatorId,
			src.DataSourceId
		);


--Log data activity
declare @BeginDate datetime
declare @EndData datetime
declare @PipelineRunId varchar(50)

exec [Integrations].[LogDataFeed] 'WoltersKluwerNationalItemPrice', 'WoltersKluwerFeed', @BeginDate, @EndData, @PipelineRunId;

END
GO
