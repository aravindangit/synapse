
DECLARE @CLIENTID INT = 6, @sortColumn VARCHAR(50)='NDC', @sortDirection VARCHAR(5)='asc',
@pageNumber INT=0, @pageSize int = 10, @ndc VARCHAR(11) = '73796027854'
with prices as (
	            select np.PriceDate
		            ,np.WkPriceCodeId PriceListId
		            ,np.PackagePrice
	            from PharmacyItem pi
		            join NationalPharmacyItemPriceMonthly np on np.ItemId = pi.ItemId
	            where pi.Ndc = @ndc --Param
		            and np.WkPriceCodeId = 5 --WAC
		            and np.PriceDate > dateadd(yy, -7, getdate())

	            union all

	            select cp.PriceDate
		            ,cp.PriceListId
		            ,cp.PackagePrice
	            from PharmacyItem pi
		            join CustomerItemPricingHistoryMonthly cp on pi.ItemId = cp.ItemId
	            where pi.Ndc = @ndc --Param
		            and cp.ClientId = @clientId --Param
		            and cp.PriceDate > dateadd(yy, -7, getdate())
            )

            select p.PriceDate
	            ,sum(case when p.PriceListId = 4 then p.PackagePrice else null end) WacPrice
	            ,sum(case when p.PriceListId = 2 then p.PackagePrice else null end) Price340b
	            ,sum(case when p.PriceListId = 3 then p.PackagePrice else null end) HospitalPrice
            from prices p
            group by p.PriceDate
            order by p.PriceDate";