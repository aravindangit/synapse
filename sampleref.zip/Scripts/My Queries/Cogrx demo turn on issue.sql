select * from [Sync].[vw_GetNdcWithIngredients]

---turn on rebuild sales stored procedure
declare @today Date = getdate();
declare @Past30 Date = dateadd(day,-30, @today)
declare @Past60 Date = dateadd(day,-60, @today)
declare @Past90 Date = dateadd(day,-90, @today)
declare @Past6Months Date = dateadd(month,-6, @today)
declare @Past1Year Date = dateadd(Year,-1, @today)
declare @Past2Year Date = dateadd(Year,-2, @today)


--build 30Day
select clientid, CustomerId, ndc, PriceTypeGroupId, Max(itemid) itemid, sum(qty) '30DayUsageQty', sum(qty * unitprice) '30DayUsageExtPrice', 
sum(QtyOrdered) '30DayQtyOrdered',
count(*) '30DayUsageTransactionCount', @Past30 '30DayAsOfDate'
	   from sales
	   where transactiondate >= @Past30
	     and [RepackagedFlag] = 0
	   group by clientid, CustomerId, ndc, PriceTypeGroupId

--Build 60Day
select clientid, CustomerId, ndc, PriceTypeGroupId, Max(itemid) itemid, sum(qty) '60DayUsageQty', sum(qty * unitprice) '60DayUsageExtPrice',
sum(QtyOrdered) '60DayQtyOrdered',
count(*) '60DayUsageTransactionCount', @Past60 '60DayAsOfDate'
	   from sales
	   where transactiondate >= @Past60
	     and [RepackagedFlag] = 0
	   group by clientid, CustomerId, ndc, PriceTypeGroupId


--Build 90 day
select clientid, CustomerId, ndc, PriceTypeGroupId, Max(itemid) itemid, sum(qty) '90DayUsageQty', sum(qty * unitprice) '90DayUsageExtPrice',
sum(QtyOrdered) '90DayQtyOrdered',
count(*) '90DayUsageTransactionCount', @Past90 '90DayAsOfDate'
	   from sales
	   where transactiondate >= @Past90
	     and [RepackagedFlag] = 0
	   group by clientid, CustomerId, ndc, PriceTypeGroupId
	   
	   select top 100 * from dbo.Sales order by TransactionDate desc
	   
	   declare @today Date = getdate();
declare @Past30 Date = dateadd(day,-30, @today)
declare @Past60 Date = dateadd(day,-60, @today)
declare @Past90 Date = dateadd(day,-90, @today)
declare @Past6Months Date = dateadd(month,-6, @today)
declare @Past1Year Date = dateadd(Year,-1, @today)
declare @Past2Year Date = dateadd(Year,-2, @today)


select clientid, CustomerId, ndc, PriceTypeGroupId, Max(itemid) itemid, sum(qty) '2YearUsageQty', sum(qty * unitprice) '2YearUsageExtPrice',
sum(QtyOrdered) '2YearQtyOrdered',
count(*) '2YearUsageTransactionCount',  @Past2Year '2YearAsOfDate'
	   from sales
	   where transactiondate >= @Past2Year
	     and [RepackagedFlag] = 0 
	   group by clientid, CustomerId, ndc, PriceTypeGroupId
	   
	   
	   select max(TransactionDate), min(TransactionDate) from dbo.sales 
	  
	   select max(TransactionDate), min(TransactionDate) from dbo.Sales_bkp_12_mar_21 sbm 
	   
	    select max(TransactionDate), min(TransactionDate) from dbo.SalesArchive sa 
	   
	   
	   
	   
	   
	   
	   select * from [Premier].[WholesalerInvoices]where ([HealthSystemID] = 'NY5011'   and [FacilityDirectParentID] = 'NY5073')

select clientid, CustomerId,ndc, PriceTypeGroupId, Max(itemid) itemid, sum(qty) 'TotalDayUsageQty', sum(qty * unitprice) 'TotalDayUsageExtPrice',
sum(QtyOrdered) 'TotalDayQtyOrdered',
count(*) 'TotalDayUsageTransactionCount', cast(min(transactiondate) as date) 'EarliestAsOfDate'
	   from sales
	   where [RepackagedFlag] = 0
	   group by clientid, CustomerId, ndc, PriceTypeGroupId
	   
	   
	   select * from dbo.Sales s 
	   
select *
from [Premier].[WholesalerInvoices]
where ([HealthSystemID] = 'NY5011'
   and [FacilityDirectParentID] = 'NY5073')
   
   select *
from [Premier].[WholesalerInvoices]
where ([HealthSystemID] = 'NY5011'
   and [FacilityID] = 'NY5073')
Select * from premier.WholesalerInvoices wi 

[Premier].[WholesalerInvoices]
	   
	   
	   
	   
	   
	   
	   
	   select * from PharmacyItem pi2 