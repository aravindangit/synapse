---------------------------------query1----------------------------------
---query one answer to figure out why the data came as null from the pharmacy spend system?? navita to check??

--health system id = NY5011 AND DIRECT PARENT ID = NY5073 Date YYYYMMDD

/*Findings
 * 
 * */

-- Answer for pricelist : The price list is calcualted for last 13 months in the sytem
SELECT * FROM [Premier].[WholesalerInvoices] where WholesalerAccountAttribute is NULL 
and InvoiceDate >= '2021-01-01' and InvoiceDate <='2021-03-31' AND FacilityID = 'NY2059'

select min([InvoiceDate]) from [Premier].[WholesalerInvoices]

select * from Integrations.Logf
select * from dbo.Customer c 

|name                          |type_desc           |is_updated|
|------------------------------|--------------------|----------|
|DemoDataMasking               |SQL_STORED_PROCEDURE|1         |
|InsertSalesRecordsUsingPremier|SQL_STORED_PROCEDURE|1         |
|UpdateCustomerAccount         |SQL_STORED_PROCEDURE|1         |
|UpdateCustomersFromPremier    |SQL_STORED_PROCEDURE|1         |
|UpdateCustomersFromPremierTest|SQL_STORED_PROCEDURE|1         |


select distinct(FacilityDirectParentID) FROM [Premier].[WholesalerInvoices]

/*SELECT [HealthSystemID],
       [FacilityDirectParentID],
       [Secret],
       [DatasetInvoiceCode],
       [DatasetPoCode]
  FROM [SyncControl].[PremierCustomerSync]
  where [DataFactory] = 'adf-Premier-DataReceive-prod'
      and [Status] = 'A'*/
/*|HealthSystemID|FacilityDirectParentID|Secret                      |DatasetInvoiceCode     |DatasetPoCode     |
|--------------|----------------------|----------------------------|-----------------------|------------------|
|CO5012        |                      |Secret-CogRX-DB-CommonSpirit|PremierWholesaleInvoice|PremierWholesalePO|
|PA0023        |                      |Secret-CogRX-DB-stluke      |PremierWholesaleInvoice|PremierWholesalePO|
|NY5011        |NY0024                |Secret-CogRX-DB-northwell   |PremierWholesaleInvoice|PremierWholesalePO|
|MN2013        |                      |Secret-CogRX-DB-Fairview    |PremierWholesaleInvoice|PremierWholesalePO|
|743692        |                      |Secret-CogRX-DB-upmc        |PremierWholesaleInvoice|PremierWholesalePO|*/

select distinct(HealthSystemID) from Premier.WholesalerInvoices wi 
select * from SyncControl.PremierCustomerSync pcs 

SELECT count(*) FROM [Premier].[WholesalerInvoices] where WholesalerAccountAttribute is NULL 
and InvoiceDate >= '2021-01-01' and InvoiceDate <= '2021-03-31'

--count is 5050
select
	distinct a.clientid,
	a.Account,
	a.CustomerName,
	a.Address1 'Address1',
	a.Address2 'Address2',
	a.city,
	a.state,
	a.zipcode,
	string_agg(a.WholesalerAccountAttribute,',') as WholesalerAccountAttribute
from
	(
	select
		distinct ifm.clientid,
		s.Account,
		'Unknown - ' + s.Account CustomerName, 
		s.Address1,
		s.Address2,
		s.city,
		s.state,
		s.zipcode,
		s.WholesalerAccountAttribute
	from
		[Raw].sales s
	inner join [dbo].[ImportFileIDMapping] ifm
     on
		s.[DataSource] = ifm.[ClientImportCode]
		and s.WholesalerAccountAttribute is not null
	left join [dbo].[Customer] c
     on
		s.[Account] = c.[AccountNumber]
		and ifm.ClientId = c.ClientId
	where s.DataSource = 'PremierWholesaleInvoice') a
group by clientid, Account, Address1, Address2, city, state, zipcode, CustomerName


select min(TransactionDate) , max(TransactionDate) from raw.Sales s 

select * from raw.Sales s 
--premier.LoadInvoiceAndPO - loading raw sales data from premier.wholesaler data.
---------------------------------query1----------------------------------
---------------------------------query2----------------------------------

select a11.member_key AS member_key,
       max(a13.member_identity) AS member_identity,
       a15.man_dist AS man_dist,
       a15.ndc as ndc,
       a11.month_id AS month_id,
       max(a14.month_desc) AS month_desc,
       a12.bus_partner_id AS bus_partner_id,
       max(a12.bus_partner_desc) AS bus_partner_desc,
       a11.whsl_acct_att AS whsl_acct_att,
       Sum(case
               when a11.matrix_status_key in (0,1,2,4,5,6) then a11.sales_dollars
               else 0
           end) AS TOTALSPEND
from fact_bp_sales_detail_view a11
join product_rpt        a15 on (a11.product_key = a15.product_key)
join bus_partner_source a12 on (a11.bp_source_id = a12.bp_source_id)
join member_view a13 on (a11.member_key = a13.member_key)
join trans_current_month_37_view a14 on (a11.month_id = a14.month_id)
where (a11.month_id in (2021103,
                        2021102,
                        2021101)
       and a11.member_key in (310452)
       and a12.bus_partner_id in (11,
                                  740,
                                  4,
                                  8,
                                  12,
                                  1)
       and a13.member_status in ('ACTIVE',
                                 'TERMINATED'))
group by a11.member_key,
         a11.month_id,
         a12.bus_partner_id,
         a11.whsl_acct_att,
         a15.man_dist,
         a15.ndc
limit 500001

    12.man_dist AS man_dist,               join        product_rpt        a12
                 on        (a11.product_key = a12.product_key)r_source

-- Local Temporary Stored Procedure
CREATE PROC ##cogrxspend(@mfid int)
AS
BEGIN 
--select sum([90DayUsageExtPrice]) from (
select clientid, 
		CustomerId, 
		ndc, 
		PriceTypeGroupId, 
		Max(itemid) itemid, 
		sum(qty) '90DayUsageQty', 
		sum(qty * unitprice) '90DayUsageExtPrice',
		sum(QtyOrdered) '90DayQtyOrdered',
		count(*) '90DayUsageTransactionCount'
	--	@Past90 '90DayAsOfDate'
       from dbo.sales
       where (transactiondate >= '2021-01-01' and transactiondate <='2021-03-31')
         and [RepackagedFlag] = 0
         and itemid in (select distinct itemid from PharmacyItem where MfrId=@mfid)
       group by clientid, CustomerId, ndc, PriceTypeGroupId--) a
       
       se
 select top 10  * from sales      
       --MfrId=971	, 924
END

Exec ##cogrxspend 971;

select * from dbo.Manufacturer m 

select * from bus_partner_source

select * from member_view
select * from fact_bp_sales_detail_view

declare @clientId as int = 4
DECLARE @from date = '01-01-2021'  --mmddyyyy
DECLARE @to date = '31-03-2021';
with 
            utilization as (
	            select pi.Ndc
                        ,pi.ItemDescription as 'Description'
                        ,s.CustomerId
			            ,s.TransactionDate
			            ,s.Qty
			            ,s.UnitCost
			            ,s.UnitCost * Qty as 'TotalCost'
		            from PharmacyItem pi 
                        join Sales s on s.ItemId = pi.ItemId
			            join Customer c on s.CustomerId = c.CustomerId and s.ClientId = c.ClientId
		            where s.ClientId = @clientId -- Param
			            and c.CustomerId = @customerId and c.ClientId = s.ClientId -- Param
			       --     ***CUSTOMERCLAUSE***
            ),
            utilizationTotals as (
	            select sum(case when u.TransactionDate > dateadd(dd, -30, getdate()) then u.Qty else 0 end) Usage30
		            ,sum(case when u.TransactionDate > dateadd(dd, -60, getdate()) then u.Qty else 0 end) Usage60
		            ,sum(case when u.TransactionDate > dateadd(dd, -90, getdate()) then u.Qty else 0 end) Usage90
		            ,sum(case when u.TransactionDate > dateadd(dd, -30, getdate()) then u.TotalCost else 0 end) Cost30
		            ,sum(case when u.TransactionDate > dateadd(dd, -60, getdate()) then u.TotalCost else 0 end) Cost60
		            ,sum(case when u.TransactionDate > dateadd(dd, -90, getdate()) then u.TotalCost else 0 end) Cost90
		            ,sum(u.Qty) TotalUsage
		            ,sum(u.UnitCost) TotalUnitCost
		            ,sum(u.TotalCost) TotalTotalCost
	            from utilization u
            ),
            utilizationDetail as (
	            select tu.Ndc
						,tu.Description
                        ,tu.CustomerId			            
			            ,tu.TransactionDate
			            ,tu.Qty
			            ,tu.UnitCost
			            ,tu.UnitCost * Qty as 'TotalCost'
		            from utilization tu
		            where tu.TransactionDate >= @from
			            and tu.TransactionDate < dateadd(day, 1, @to)
            )

            select 
                s.Ndc
                ,s.Description
                ,s.CustomerId	            
	            ,s.TransactionDate
	            ,s.Qty
                ,s.UnitCost
                ,s.TotalCost
	            ,totals.TotalCount as SearchResultCount
                ,totals.SearchResultTotalUnitCost
	            ,totals.SearchResultTotalCost
	            ,totals.SearchResultTotalQty
	            ,totalUsage.Usage30 AS SearchResultUsage30
	            ,totalUsage.Usage60 AS SearchResultUsage60
	            ,totalUsage.Usage90 AS SearchResultUsage90
	            ,totalUsage.Cost30 AS SearchResultCost30
	            ,totalUsage.Cost60 AS SearchResultCost60
	            ,totalUsage.Cost90 AS SearchResultCost90
	            ,totalUsage.TotalUsage
	            ,totalUsage.TotalUnitCost
	            ,totalUsage.TotalTotalCost
            from utilizationDetail s
	            join (select count(1) as TotalCount
                            ,sum(u.UnitCost) as SearchResultTotalUnitCost
				            ,sum(u.TotalCost) as SearchResultTotalCost
				            ,sum(u.Qty) as SearchResultTotalQty
			            from utilizationDetail u) totals on 1 = 1
	            join (select ut.Usage30
			            ,ut.Usage60
			            ,ut.Usage90
			            ,ut.Cost30
			            ,ut.Cost60
			            ,ut.Cost90
			            ,ut.TotalUsage
			            ,ut.TotalUnitCost
			            ,ut.TotalTotalCost
		              from utilizationTotals ut) totalUsage on 1 = 1
            order by
	            case when @sortColumn = 'Ndc' and @sortDirection = 'asc' then s.Ndc end,
	            case when @sortColumn = 'Ndc' and @sortDirection = 'desc' then s.Ndc end desc,
	            case when @sortColumn = 'Description' and @sortDirection = 'asc' then s.Description end,
	            case when @sortColumn = 'Description' and @sortDirection = 'desc' then s.Description end desc,
	            case when @sortColumn = 'TransactionDate' and @sortDirection = 'asc' then s.TransactionDate end,
	            case when @sortColumn = 'TransactionDate' and @sortDirection = 'desc' then s.TransactionDate end desc,
	            case when @sortColumn = 'Qty' and @sortDirection = 'asc' then s.Qty end,
	            case when @sortColumn = 'Qty' and @sortDirection = 'desc' then s.Qty end desc,
	            case when @sortColumn = 'UnitCost' and @sortDirection = 'asc' then s.UnitCost end,
	            case when @sortColumn = 'UnitCost' and @sortDirection = 'desc' then s.UnitCost end desc,
				case when @sortColumn = 'TotalCost' and @sortDirection = 'asc' then s.TotalCost end,
	            case when @sortColumn = 'TotalCost' and @sortDirection = 'desc' then s.TotalCost end desc
---------------------------------query2----------------------------------
	            
	            select * from dbo.customer