
CREATE PROCEDURE [DailyMaintinance].[ReBuildAcctSummaryMV]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

delete [MV].[AcctSummary];

WITH YEARTOTALS_CTE AS (
	select s.clientid,
			c.customerid,
			year(s.TransactionDate) TransactionYear,
			sum(s.UnitCost * s.Qty) Cost,
			sum(s.Qty) qty
	from dbo.Sales s
		join dbo.Customer c 
			on c.CustomerId = s.CustomerId
	where year(s.TransactionDate) >= year(getdate()) - 1
		and month(s.TransactionDate) <= month(getdate())
		and (month(s.TransactionDate) < month(getdate())
		or day(s.TransactionDate) <= day(getdate()))
	group by s.clientid,
				c.customerid,
				year(s.TransactionDate)
	),
RANK_CTE AS (
	select s.clientid,
	   	   c.customerid,
		   sum(s.UnitCost * s.Qty) Cost,
		   DENSE_RANK() OVER (ORDER BY sum(s.UnitCost * s.Qty) desc ) CostRank,
		   sum(s.Qty) Quantity,
		   DENSE_RANK() OVER (ORDER BY sum(s.Qty) desc ) QuantityRank,
		   count(1) over () TotalCount
	from dbo.Sales s
		join dbo.Customer c 
			on c.CustomerId = s.CustomerId
	WHERE s.TransactionDate >= DATEADD(month, -12, GETDATE())
	group by s.clientid,
		     c.customerid
	),
CONTRACTED_CTE AS (
	select tc.clientid,
		   tc.customerid,
		   count(1) ItemsPurchased,
		   count(case when tc.ItemId is not null then 1 else null end) ItemsOnContract,
		   SUM(tc.qty) as qty,
		   SUM(tc.qty_oncontract) as qty_oncontract,
		   SUM(tc.spend) as spend,
		   SUM(tc.spend_oncontract) as spend_oncontract
	from (
		select c.clientid,
			   c.customerid, 
			   SUM(s.qty) as qty,
			   SUM(CASE WHEN sci.itemid IS NOT NULL THEN s.qty ELSE 0 END) as qty_oncontract,
			   SUM(s.qty * s.unitcost) as spend, 
			   SUM(CASE WHEN sci.itemid IS NOT NULL THEN s.qty * s.unitcost ELSE 0 END) as spend_oncontract, 
			   sci.itemid, 
			   case when sci.ItemId is null then 'N' else 'Y' end as OnContract
		from dbo.Sales s
			join dbo.Customer c 
				on c.CustomerId = s.CustomerId
		--Old join as of 11/6/2019
			--left join Contract.SubContractItem si
			--	on si.ItemId = s.ItemId				
		--New join as of 11/6/2019  <JCW>
			left join Contract.Contract con			
				on con.ClientId = s.ClientId		
			left join Contract.SubContract sc		
				on sc.ContractId = con.ContractId	
			left join Contract.SubContractItem sci	
				on sci.ItemId = s.ItemId and sci.SubContractId = sc.SubContractId
		where s.TransactionDate >= DATEADD(month, -12, GETDATE())
		group by c.clientid, c.customerid, s.ItemId, sci.ItemId) tc
	GROUP BY tc.clientid, tc.customerid
)
insert into [MV].[AcctSummary]
	(clientid,
	 customerid,
	 y_transactionyear,
	 y_cost,
	 y_qty,
	 r_cost,
	 r_costrank,
	 r_qty,
	 r_qtyrank,
	 r_totalcount,
	 c_items,
	 c_contracted,
	 c_purchased,
	 c_purchasedoncontract,
	 c_spend,
	 c_spendoncontract)
SELECT r.clientid as 'clientid', 
	   r.customerid as 'customerid', 
	   y.transactionyear as 'y_transactionyear', 
	   y.cost as 'y_cost', 
	   y.qty as 'y_qty', 
	   r.cost as 'r_cost', 
	   r.costrank as 'r_costrank', 
	   r.quantity as 'r_qty', 
	   r.quantityrank as 'r_qtyrank', 
	   r.totalcount as 'r_totalcount', 
	   c.itemspurchased as 'c_items', 
	   c.itemsoncontract as 'c_contracted', 
	   c.qty as 'c_purchased', 
	   c.qty_oncontract as 'c_purchasedoncontract', 
	   c.spend as 'c_spend', c.spend_oncontract as 'c_spendoncontract'
FROM RANK_CTE r
	JOIN CONTRACTED_CTE c 
		ON r.customerid = c.customerid 
		and r.clientid = c.clientid
	LEFT JOIN YEARTOTALS_CTE y 
		ON r.customerid = y.customerid 
		and r.clientid = y.clientid
ORDER BY r.clientid, r.customerid, y.transactionyear


END


  select * from dbo.customer where divisionid is null
		     
		     
		     
		     
		     
		     
		     
		     select * from mv.AcctSummary as2 
		     
		     
		     select distinct divisionid,* from dbo.customer




with rankcte as (
	select s.clientid,
		   c.DivisionId ,
	--   	   c.customerid,
		   sum(s.UnitCost * s.Qty) Cost,
		   DENSE_RANK() OVER (ORDER BY sum(s.UnitCost * s.Qty) desc ) CostRank,
		   sum(s.Qty) Quantity,
		   DENSE_RANK() OVER (ORDER BY sum(s.Qty) desc ) QuantityRank,
		   count(1) over () TotalCount
	from dbo.Sales s
		join dbo.Customer c 
			on c.CustomerId = s.CustomerId
--	WHERE s.TransactionDate >= DATEADD(month, -12, GETDATE())
	group by s.clientid,
		--	 c.customerid,
		     c.divisionid)
		     
		   		     
SELECT
sum(y_cost) AS Y_Cost
,sum(y_qty) AS Y_Qty
,sum(r_cost) AS R_Cost
--,r_costrank AS R_CostRank
--,DENSE_RANK() OVER (ORDER BY sum(y_cost) desc ) R_CostRank
--,DENSE_RANK() OVER (ORDER BY sum(y_qty) desc ) R_QtyRank
,rc.CostRank
,rc.QuantityRank
,sum(r_qty) AS R_Qty
--,r_qtyrank AS R_QtyRank
,rc.totalcount AS R_TotalCount
,sum(c_items) AS C_Items
,sum(c_contracted) AS C_Contracted
,sum(c_purchased) AS C_Qty
,sum(c_purchasedoncontract) AS C_QtyOnContract
,sum(c_spend) AS C_Spend
,sum(c_spendoncontract) AS C_SpendOnContract
FROM MV.AcctSummary act jOIN customer c on act.customerid = c.CustomerId
join rankcte as rc on rc.divisionid = c.DivisionId 
WHERE act.clientid in (select clientid from client) --and y_transactionyear = Year(getdate()) 
--and c.DivisionId = 'AD1413'
group by rc.CostRank
,rc.QuantityRank
,rc.totalcount
--GROUP BY act.y_transactionyear	


SELECT
clientId AS ClientId
--,organizationname AS OrganizationName
,y_transactionyear AS Y_TransactionYear
,y_cost AS Y_Cost
,y_qty AS Y_Qty
,r_cost AS R_Cost
,r_costrank AS R_CostRank
,r_qty AS R_Qty
,r_qtyrank AS R_QtyRank
,r_totalcount AS R_TotalCount
,c_items AS C_Items
,c_contracted AS C_Contracted
,c_purchased AS C_Qty
,c_purchasedoncontract AS C_QtyOnContract
,c_spend AS C_Spend
,c_spendoncontract AS C_SpendOnContract
FROM MV.AcctSummary as2 
WHERE clientid in (select clientid from client) 
and customerid= 62
--AND organizationname = @name;


		     
		     