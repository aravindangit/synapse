
truncate table xrefwanload;
truncate table xrefcbidload;

with distinctWan
as (select distinct WholesalerAccountNumber from Sales)
   , xrefWan
as (select 'WAN-' + cast(row_number() over (order by WholesalerAccountNumber asc) as varchar(25)) as Maskwan
         , WholesalerAccountNumber
    from distinctWan) 
insert into dbo.xrefwanload
		(Maskedwan ,
		WholesalerAccountNumber) 
 select Maskwan,
 		WholesalerAccountNumber 
 		from xrefwan;
 	
 	
with distinctCbid
as (select distinct WholesalerCBID from Sales)
   , xrefCbid
as ((select 'CBID-' + cast(row_number() over (order by WholesalerCBID asc) as varchar(25)) as maskcbid
          , WholesalerCBID
     from distinctCbid))
insert into dbo.xrefcbidload
		(Maskedcbid ,
		WholesalerCBID) 
 select maskcbid,
 		WholesalerCBID 
 		from xrefCbid;

update sa 
set sa.WholesalerAccountNumber = wa.maskedwan
from dbo.sales sa join xrefwanload wa on sa.WholesalerAccountNumber = wa.WholesalerAccountNumber;
    
update sa 
set sa.WholesalerCBID = wa.Maskedcbid
from dbo.sales sa join xrefcbidload wa on sa.WholesalerCBID = wa.WholesalerCBID    ;
 	
truncate table dbo.SalesTotals;
truncate table dbo.SalesTotalMonthly;
exec [DailyMaintinance].[RebuildSalesTotal];




	

