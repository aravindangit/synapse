SELECT DISTINCT ------ 53.648113 
                         a.HcpcsCode AS JCode,
                         a.Ndc 
                        ,MIN(i.DrugName) AS Brand
                        ,aspCurrent.CurrentAspUnitPrice
                        ,aspCurrent.AverageAwpUnitPrice
                    FROM AspPriceAndLimits a
                    JOIN PharmacyItem i ON a.ItemId = i.ItemId
                    JOIN Sales s ON s.ItemId = i.ItemId
                    JOIN (
SELECT DISTINCT
   a.HcpcsCode,
   MAX(a.AspUnitPrice) AS 'CurrentAspUnitPrice',
AVG(c.AwpUnitPrice) AS 'AverageAwpUnitPrice'
FROM AspPriceAndLimits a
JOIN NationalPharmacyItemPriceCurrent c ON c.Ndc = a.Ndc
WHERE a.IsCurrentRecords = 1
GROUP BY a.HcpcsCode
) AS aspCurrent ON aspCurrent.HcpcsCode = a.HcpcsCode
                    WHERE s.ClientId = 6
                    and a.HcpcsCode like 'J%' or a.HcpcsCode like 'Q%'
                    GROUP BY a.HcpcsCode, aspCurrent.CurrentAspUnitPrice, aspCurrent.AverageAwpUnitPrice, a.Ndc
                    ORDER BY a.HcpcsCode

                    
 select NDC,AspUnitPrice * 1.06 , PaymentLimit from AspPriceAndLimits where HcpcsCode = 'J1745' AND IsCurrentRecords = 1
 
 
 |JCode|Ndc        |Brand            |CurrentAspUnitPrice|AverageAwpUnitPrice|
|-----|-----------|-----------------|-------------------|-------------------|
|J0129|00003218713|Orencia          |53.648113          |1918.630981        |
|J0129|00003218811|Orencia          |53.648113          |1918.630981        |
|J0129|00003218851|Orencia ClickJect|53.648113          |1918.630981        |
|J0132|00574080530|Acetylcysteine   |0.890566           |7.585562           |
|J0132|25021081230|Acetylcysteine   |0.890566           |7.585562           |
|J0132|55150025930|Acetylcysteine   |0.890566           |7.585562           |

 
 select * from NationalPharmacyItemPriceCurrent where ndc='57894003001'
 
 
 
 SELECT * FROM rawWK.fgpfile_FederalGovernmentPricesFile WHERE external_drug_identifier = '57894003001'
 
 
 select top 10 * from [dbo].[NationalPharmacyItemPrice] where ndc = '57894003001' order by PriceEffectiveDate DESC
 
 select top 10 * from [rawWK].[fgpfile_FederalGovernmentPricesFile] where external_drug_identifier = '57894003001'
 
 
 input for [dbo].[NationalPharmacyItemPrice]
 
 select pi.itemid,
				   npf.[external_drug_identifier] NDC,
				   pi.NdcFormatCode ,
				   pt.WkPriceCodeId,
				   npf.[price_effective_date] PriceEffectiveDate,
				   npf.Unit_Price UnitPrice
		--		   @iDataSource DataSourceId
			from [rawWK].[fgpfile_FederalGovernmentPricesFile] npf
				left join [dbo].[PharmacyItem] pi
					on npf.[external_drug_identifier] = pi.ndc
				inner join [WoltersKluwer].[PriceTypeXref] pt
					on npf.Price_type = pt.WkPriceCode
			where (npf.price_type in (1,2) and npf.pharmacy_type = 'C'  ) 
			    or npf.price_type not in (1,2)
			    
			    
			    
			    
			    
			  select pi.itemid,
				   npf.Ndc_Upc_Hri NDC,
				   pi.NdcFormatCode ,
				   pt.WkPriceCodeId,
				   npf.Price_Effective_Date PriceEffectiveDate,
				   npf.Unit_Price UnitPrice,
				   npf.extended_unit_price ExtendedUnitPrice,
				   npf.Package_Price PackagePrice,
				   ai.AwpIndicatorId AwpIndicatorId
				--   @iDataSource DataSourceId
			from [rawWK].[mf2prc_NdcPriceFile] npf
				left join [dbo].[PharmacyItem] pi
					on npf.Ndc_Upc_Hri = pi.ndc
				inner join [WoltersKluwer].[PriceTypeXref] pt
					on npf.Price_Code = pt.WkPriceCode
				left join [WoltersKluwer].[AwpIndicator] ai
					on npf.awp_indicator_code = ai.AwpIndicatorCode
					where npf.ndc_upc_hri = '57894003001'
					
					
					select * from [rawWK].[mf2prc_NdcPriceFile] where ndc_upc_hri = '57894003001'
