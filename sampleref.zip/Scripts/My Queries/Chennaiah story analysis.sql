                      SELECT
                         DrugStrength
                        ,SUM(Inc_Days) as Inc_Days
                        ,SUM(MissingUnits) as MissingUnits
                        ,SUM(MissingDollars) as MissingDollars
                        ,ROW_NUMBER() OVER(ORDER BY SUM(Inc_Days) DESC) as rownumber
                    FROM [NationalPriceDisruptions].[IncidentsNdc]
                    WHERE GpiName = 'Phenylephrine HCl (Mydriatic)' and HealthSystemId is not NULL 
                    GROUP BY DrugStrength WITH ROLLUP
                    ORDER BY SUM(Inc_Days) DESC
                   -- with roll up;
                    
                    
      select * from NationalPriceDisruptions.IncidentsNdc where GpiName = 'Phenylephrine HCl (Mydriatic)' and HealthSystemId is Null
      
      select * from [NationalPriceDisruptions].[ResultsNdc] where GpiName = 'Phenylephrine HCl (Mydriatic)'
      
      	SELECT i.[Ndc]
	    , i.[HealthSystemId]
		, i.[Gpi10]
		, i.[GpiName]
		, i.[DrugStrength]
		, i.[AvgPrice]
		, i.[Inc_Days]
		, i.[MissingDollars]
		, i.[MissingUnits]
		, hscount = (SELECT DISTINCT COUNT(a.healthsystemid) FROM [NationalPriceDisruptions].[IncidentsNdc] a WHERE a.ndc = i.ndc AND a.healthsystemid IS NOT NULL)
		, hsmax = (SELECT MAX(inc_days) FROM [NationalPriceDisruptions].[IncidentsNdc] a WHERE a.ndc = i.ndc AND a.healthsystemid IS NOT NULL)
	FROM [NationalPriceDisruptions].[IncidentsNdc] i where i.GpiName = 'Phenylephrine HCl (Mydriatic)'
	WHERE --healthsystemid IS NULL AND ndc IS NOT NULL
	i.GpiName = 'Phenylephrine HCl (Mydriatic)'
	
	select sum([MissingUnits]) from
	(SELECT ndc
	, healthsystemid
	, MAX(drugid) as gpi10
	, MAX(gpiname) as gpiname
	, MAX(drugstrength) as drugstrength
	, MAX(avgprice) as avgprice
	, count(*) as inc_days
	, SUM(missingdollars) as missingdollars
	, SUM(missingunits) as missingunits
--	, @ReportedDate
FROM [NationalPriceDisruptions].[RawInvoices]
WHERE ((quantityordered >= 1 and fillrate <= 0.5 AND fillrate >= 0) OR (quantityordered = 1 AND fillrate = 0)) and  GpiName = 'Phenylephrine HCl (Mydriatic)'
GROUP BY ndc
	, healthsystemid with rollup) a
--WITH ROLLUP;
	
	
	
--select
--	sum([MissingUnits])
--from
--	(
	SELECT
		ndc ,
		healthsystemid ,
		MAX(drugid) as gpi10 ,
		MAX(gpiname) as gpiname ,
		MAX(drugstrength) as drugstrength ,
		MAX(avgprice) as avgprice ,
		count(*) as inc_days ,
		SUM(missingdollars) as missingdollars ,
		SUM(missingunits) as missingunits
		--	, @ReportedDate

		FROM [NationalPriceDisruptions].[RawInvoices]
	WHERE
		((quantityordered >= 1
			and fillrate <= 0.5
			AND fillrate >= 0)
		OR (quantityordered = 1
			AND fillrate = 0))
		and GpiName = 'Phenylephrine HCl (Mydriatic)'
	GROUP BY
		ndc ,
		healthsystemid with rollup
	--WITH ROLLUP;
		
		
SELECT
	DrugStrength ,
	SUM(Inc_Days) as Inc_Days ,
	SUM(MissingUnits) as MissingUnits ,
	SUM(MissingDollars) as MissingDollars ,
	ROW_NUMBER() OVER(ORDER BY SUM(Inc_Days) DESC) as rownumber
FROM
	[NationalPriceDisruptions].[IncidentsNdc]
WHERE
	GpiName = 'Phenylephrine HCl (Mydriatic)' and HealthSystemId is NULL 
GROUP BY
	DrugStrength
ORDER BY
	SUM(Inc_Days) DESC
	
	
	
	 select * from [Mapping].[PremierSupplierXref] 
	 
	 
select * from Predictive.NDCPricePredictions where IsActive = 1 and NDC = '00944270007';

UPDATE Predictive.NDCPricePredictions set IsActive = 0
where IsActive = 1 and NDC = '00944270007'

select * from Predictive.NDCPricePredictions where  IsActive = 0 and NDC = '00944270007'


select * from Predictive.NDCPricePredictions where wholesa




UPDATE Predictive.NDCPricePredictions set IsActive = 0
where IsActive = 1 NDC in ('00944270005',
'17478050305',
'00944270004',
'13533080024',
'13533080024',
'00944270002',
'13533080071',
'13533080071',
'00944265804',
'00944265603')

select * from Predictive.NDCPricePredictions where IsActive = 1 and NDC in ('00944270005',
'17478050305',
'00944270004',
'13533080024',
'13533080024',
'00944270002',
'13533080071',
'13533080071',
'00944265804',
'00944265603')

select * from Predictive.NDCPricePredictions
