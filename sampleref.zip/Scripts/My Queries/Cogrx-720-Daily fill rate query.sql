---Daily fill rate table populating query

declare @gpiname as varchar(100) = 'Propofol';

WITH CTE_ASHP AS (
	                SELECT
						 Ndc
						,UpdatedDate
						,AvailableNdcs
						,AddedDateTime
						,Reasons
						,EstimatedResupply
	                FROM dbo.PharmacyItemShortage
	                WHERE isActive = 1 AND Source = 'ASHP' AND Status <> 'R'
                )
                SELECT 
					 r.Ndc
	                ,r.Gpi10
	                ,r.GpiName
	                ,r.Inc_Days
	                ,r.MissingDollars
	                ,r.MissingUnits
	                ,r.HsCount
	                ,pi.Manufacturer
	                ,pi.ItemDescription
	                ,nat.WacPackagePrice as 'Wac'
                    ,r.AvgPrice
	                ,convert(varchar, ashp.UpdatedDate, 23) as 'ShortUpdate'
                    ,convert(varchar, ashp.AddedDateTime, 23) as 'ShortAdded'
                    ,ashp.AvailableNdcs as 'ShortAvailable'
	                ,ashp.Reasons as 'ShortReasons'
	                ,ashp.EstimatedResupply as 'ShortResupply'
                FROM NationalPriceDisruptions.ResultsNdc r
                JOIN dbo.PharmacyItem pi ON r.Ndc = pi.Ndc
                JOIN dbo.NationalPharmacyItemPriceCurrent nat ON r.Ndc = nat.Ndc
                LEFT JOIN CTE_ASHP ashp ON r.Ndc = ashp.Ndc
                WHERE 
	                GpiName = @gpiname
                ORDER BY Inc_Days DESC;