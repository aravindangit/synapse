select * from sqldbCogRxProdStLukes.NationalPriceDisruptions.ResultsGpi

                WITH CTE_ASHP AS (
	                SELECT
						 Ndc
						,UpdatedDate
						,AvailableNdcs
						,AddedDateTime
						,Reasons
						,EstimatedResupply
	                FROM dbo.PharmacyItemShortage
	                WHERE isActive = 1 AND Source = 'ASHP' AND Status <> 'R'
                )
                SELECT 
					 r.Ndc
	                ,r.Gpi10
	                ,r.GpiName
	                ,r.Inc_Days
	                ,r.MissingDollars
	                ,r.MissingUnits
	                ,r.HsCount
	                ,pi.Manufacturer
	                ,pi.ItemDescription
	                ,nat.WacPackagePrice as 'Wac'
                    ,r.AvgPrice
	                ,convert(varchar, ashp.UpdatedDate, 23) as 'ShortUpdate'
                    ,convert(varchar, ashp.AddedDateTime, 23) as 'ShortAdded'
                    ,ashp.AvailableNdcs as 'ShortAvailable'
	                ,ashp.Reasons as 'ShortReasons'
	                ,ashp.EstimatedResupply as 'ShortResupply'
            --    FROM ***PREFIX***ResultsNdc r
	              FROM NationalPriceDisruptions.ResultsNdc r
                JOIN dbo.PharmacyItem pi ON r.Ndc = pi.Ndc
                JOIN dbo.NationalPharmacyItemPriceCurrent nat ON r.Ndc = nat.Ndc
                LEFT JOIN CTE_ASHP ashp ON r.Ndc = ashp.Ndc
                WHERE 
	                GpiName = 'Gabapentin'                        --@gpiname
                ORDER BY Inc_Days DESC;


select top 10 * from NationalPriceDisruptions.ResultsNdc

[PriceDisruptions].[BuildResultsNdc] from [PriceDisruptions].[IncidentsNdc](loaded from raw invoices - [PriceDisruptions].[RawInvoices]
and the sp is [PriceDisruptions].[BuildIncidentsNdc] from nationalwholes saler database.

next - [PriceDisruptions].[BuildRawInvoices] using [PriceDisruptions].[Transform]
[PriceDisruptions].[AvgPrices] to load rawinvoices

this inturn loaded from premier.WholesalerInvoices with below
tables
premier.wholesalerinvoices
dbo.calendar
dbo.pharmacyitem
dbo.NationalPharmacyItemPriceCurrent
[ItemMaster].[WkGpiDescriptions]
 and sp is [PriceDisruptions].[BuildTransform]
)


SELECT pi.pricingkey
	, pi.isgenericdrug
	, MAX(c.wacunitprice) as equ_maxwac
	, MAX(c.awpunitprice) as equ_maxawp
FROM pharmacyitem pi
JOIN pharmacyitem equ ON pi.ndc = equ.ndc AND pi.isgenericdrug = equ.isgenericdrug
LEFT JOIN nationalpharmacyitempricecurrent c ON equ.ndc = c.ndc
GROUP BY pi.pricingkey, pi.isgenericdrug;
----------------------------------------------------------------------
--sample
|pricingkey|isgenericdrug|equ_maxwac  |equ_maxawp  |
|----------|-------------|------------|------------|
|          |0            |79200.000000|95040.000000|
|          |1            |94350.000000|99950.000000|
----------------------------------------------------------------------

select * from [PriceDisruptions].[WacPricekey]


create proc ##buildtransform()
Go
begin
	
SELECT 
	i.ndc as 'ndc'
	, i.quantityordered as 'quantityordered'
	, i.invoiceprice as 'invoiceprice'
	, i.totalspend as 'totalspend'
	, i.totalunits as 'totalunits'
	, i.premiercontractnumber as 'contractnumber'
	, i.healthsystemid as 'healthsystemid'
	, i.facilitystate as 'facilitystate'
	, c.firstdateofmonth as 'fmonth'
	, pi.manufacturer
	, pi.drugname
	, pi.pricingkey as 'pricingkey'
	, pi.isgenericdrug as 'isgenericdrug'
	, pi.drugstrength + ' ' + pi.drugstrengthuom as 'drugstrength'
	, LEFT(pi.gpi, 10) as 'drugid'
	, nat.wacunitprice as 'wac'
	, wk.gpiname as 'gpiname'
	, convert(varchar, invoicedate, 23) as 'invoicedatestring'
	, CASE WHEN i.wholesaler != '' THEN i.wholesaler ELSE 'OTHER' END AS d_wholesaler
	, DATEDIFF(day, invoicedate, GETDATE()) as 'daysago'
FROM premier.wholesalerinvoices i
	JOIN calendar c ON c.calendardate = i.invoicedate
	LEFT JOIN pharmacyitem pi ON i.ndc = pi.ndc
	LEFT JOIN NationalPharmacyItemPriceCurrent nat ON i.ndc = nat.ndc
	JOIN [ItemMaster].[WkGpiDescriptions] wk ON LEFT(pi.gpi, 10) = wk.gpicodesegment
WHERE c.clientid IS NULL
	--AND DATEDIFF(day, invoicedate, GETDATE()) <=30;
	AND invoicedate >= @StartDate
	AND invoicedate <=  @EndDate;
END

CREATE PROC ##sunit
AS
BEGIN 
	
declare @StartDate Date = getdate();
declare @EndDate Date = dateadd(day,-90, @StartDate)
declare @Past30 Date = dateadd(day,-30, @StartDate)
declare @Past60 Date = dateadd(day,-60, @StartDate)
declare @Past90 Date = dateadd(day,-90, @StartDate)
declare @Past6Months Date = dateadd(month,-6, @StartDate)
declare @Past1Year Date = dateadd(Year,-1, @StartDate)
declare @Past2Year Date = dateadd(Year,-2, @StartDate)

select @StartDate
select @EndDate
SELECT 
	i.ndc as 'ndc'
	, i.quantityordered as 'quantityordered'
	, i.invoiceprice as 'invoiceprice'
	, i.totalspend as 'totalspend'
	, i.totalunits as 'totalunits'
	, i.premiercontractnumber as 'contractnumber'
	, i.healthsystemid as 'healthsystemid'
	, i.facilitystate as 'facilitystate'
	, c.firstdateofmonth as 'fmonth'
	, pi.manufacturer
	, pi.drugname
	, pi.pricingkey as 'pricingkey'
	, pi.isgenericdrug as 'isgenericdrug'
	, pi.drugstrength + ' ' + pi.drugstrengthuom as 'drugstrength'
	, LEFT(pi.gpi, 10) as 'drugid'
	, nat.wacunitprice as 'wac'
	, wk.gpiname as 'gpiname'
	, convert(varchar, invoicedate, 23) as 'invoicedatestring'
	, CASE WHEN i.wholesaler != '' THEN i.wholesaler ELSE 'OTHER' END AS d_wholesaler
	, DATEDIFF(day, invoicedate, GETDATE()) as 'daysago'
FROM premier.wholesalerinvoices i
	JOIN calendar c ON c.calendardate = i.invoicedate
	LEFT JOIN pharmacyitem pi ON i.ndc = pi.ndc
	LEFT JOIN NationalPharmacyItemPriceCurrent nat ON i.ndc = nat.ndc
	JOIN [ItemMaster].[WkGpiDescriptions] wk ON LEFT(pi.gpi, 10) = wk.gpicodesegment
WHERE c.clientid IS NULL
	--AND DATEDIFF(day, invoicedate, GETDATE()) <=30;
	AND invoicedate >= '2021-03-10'
	AND invoicedate <=  '2021-06-07' and wk.gpiname = 'Gabapentin' and i.ndc = '63739059110';
END  -- '2021-01-01'

execute ##sunit;



	SELECT i.[Ndc]
	    , i.[HealthSystemId]
		, i.[Gpi10]
		, i.[GpiName]
		, i.[DrugStrength]
		, i.[AvgPrice]
		, i.[Inc_Days]
		, i.[MissingDollars]
		, i.[MissingUnits]
		, hscount = (SELECT DISTINCT COUNT(a.healthsystemid) FROM [PriceDisruptions].[IncidentsNdc] a WHERE a.ndc = i.ndc AND a.healthsystemid IS NOT NULL)
		, hsmax = (SELECT MAX(inc_days) FROM [PriceDisruptions].[IncidentsNdc] a WHERE a.ndc = i.ndc AND a.healthsystemid IS NOT NULL)
	FROM [PriceDisruptions].[IncidentsNdc] i
	WHERE healthsystemid IS NULL AND ndc IS NOT NULL
	
	
	select * from [PriceDisruptions].[ResultsNdc]
	
	
SELECT  ndc
	, healthsystemid,quantityordered,fillrate
	, MAX(drugid) as gpi10
	, MAX(gpiname) as gpiname
	, MAX(drugstrength) as drugstrength
	, MAX(avgprice) as avgprice
	, count(*) as inc_days
	, SUM(missingdollars) as missingdollars
	, SUM(missingunits) as missingunits
	--, @ReportedDate
FROM [PriceDisruptions].[RawInvoices] With (NoLock)
WHERE  ((quantityordered >= 1 and fillrate <= 0.5 AND fillrate >= 0) OR (quantityordered = 1 AND fillrate = 0))
and gpiname = 'Gabapentin' and Ndc = '63739059110'
GROUP BY ndc  --, inc_days
	, healthsystemid,quantityordered,fillrate
	
	
select Top 5 * from [PriceDisruptions].[RawInvoices];


-------------------------------
WITH BASE_CTE AS (
	SELECT i.[Ndc]
	    , i.[HealthSystemId]
		, i.[Gpi10]
		, i.[GpiName]
		, i.[DrugStrength]
		, i.[AvgPrice]
		, i.[Inc_Days]
		, i.[MissingDollars]
		, i.[MissingUnits]
		, hscount = (SELECT DISTINCT COUNT(a.healthsystemid) FROM [PriceDisruptions].[IncidentsNdc] a WHERE a.ndc = i.ndc AND a.healthsystemid IS NOT NULL)
		, hsmax = (SELECT MAX(inc_days) FROM [PriceDisruptions].[IncidentsNdc] a WHERE a.ndc = i.ndc AND a.healthsystemid IS NOT NULL)
	FROM [PriceDisruptions].[IncidentsNdc] i
	WHERE healthsystemid IS NULL AND ndc IS NOT NULL
),
CALC_CTE AS (
	SELECT Ndc
	    , HealthSystemId
		, Gpi10
		, GpiName
		, DrugStrength
		, AvgPrice
		, Inc_Days
		, MissingDollars
		, MissingUnits
		, hscount
		, hsmax
	, CAST(inc_days AS DECIMAL(10,2)) / 30 as incperday
	, (CAST(inc_days AS DECIMAL(10,2)) - CAST(hsmax AS DECIMAL(10,2))) / 30 as incperday_notop  --inc/day not incl the top guy
	, 1 - (CAST(hsmax as DECIMAL(10,2)) / CAST(inc_days AS DECIMAL(10,2))) as spread
FROM BASE_CTE
)
SELECT c.[Ndc]
    , c.[HealthSystemId]
    , c.[Gpi10]
    , c.[GpiName]
    , c.[DrugStrength]
    , c.[AvgPrice]
    , c.[Inc_Days]
    , c.[MissingDollars]
    , c.[MissingUnits]
    , c.[HsCount]
    , c.[HsMax]
    , c.[IncPerDay]
    , c.[IncPerDay_NoTop]
    , c.[Spread]

FROM CALC_CTE c where c.[GpiName] = 'Gabapentin'
ORDER BY inc_days DESC;-- gpiname, mfr






SELECT DISTINCT COUNT(a.healthsystemid) FROM [PriceDisruptions].[IncidentsNdc] a WHERE a.ndc = i.ndc AND a.healthsystemid IS NOT NULL)
		, hsmax = (SELECT MAX(inc_days) FROM [PriceDisruptions].[IncidentsNdc] a WHERE a.ndc = i.ndc AND a.healthsystemid IS NOT NULL)
	FROM [PriceDisruptions].[IncidentsNdc] i
	WHERE healthsystemid IS NULL AND ndc IS NOT NULL
	
	
SELECT i.[Ndc]
	    , i.[HealthSystemId]
		, i.[Gpi10]
		, i.[GpiName]
		, i.[DrugStrength]
		, i.[AvgPrice]
		, i.[Inc_Days]
		, i.[MissingDollars]
		, i.[MissingUnits]
		, hscount = (SELECT DISTINCT COUNT(a.healthsystemid) FROM [PriceDisruptions].[IncidentsNdc] a WHERE a.ndc = i.ndc AND a.healthsystemid IS NOT NULL)
		, hsmax = (SELECT MAX(inc_days) FROM [PriceDisruptions].[IncidentsNdc] a WHERE a.ndc = i.ndc AND a.healthsystemid IS NOT NULL)
	FROM [PriceDisruptions].[IncidentsNdc] i
	WHERE healthsystemid IS NULL AND ndc IS NOT NULL and i.GpiName = 'Gabapentin' and i.ndc = '63739059110' ;
	
select DISTINCT(i.healthsystemid) from [PriceDisruptions].[IncidentsNdc] i where i.GpiName = 'Gabapentin' and i.ndc = '63739059110' ;