declare @clientId int = 6
declare @ndcs varchar(11) = ('00069080901')
--select clientid from Client c 
            select 
                 pi.ItemId Id
                ,pi.ItemUId
	            ,pi.PricingKey
	            ,pi.Ndc
                ,pi.Ndc11
                ,pi.PreviousNdc
                ,ppi.ItemDescription PreviousNdcDescription
                ,pi.ReplacedByNdc
                ,rbpi.ItemDescription ReplacedByNdcDescription
                ,pi.GPI
	            ,pi.ItemDescription Description
			    ,CASE 
				    WHEN EXISTS(
						SELECT 1 
						FROM ItemMaster.FdaProductApplications fpa 
						WHERE fpa.MarketingStatus = 'DISCN' 
							AND fpa.ItemId = pi.ItemId
						) THEN '**** DISCONTINUED ****'
					ELSE '' 
					END MarketingStatus 
	            ,pi.DrugName BrandName
	            ,pi.Ingredients GenericName
                ,pi.Manufacturer
                ,pi.IsGenericDrug
	            ,pi.PackageDescription PackDescription
	            ,isnull(pi.PackageSize, 1)  PackSize
	            ,pi.CasePack
                ,pi.DrugStrength + pi.DrugStrengthUOM DrugStrength
                ,sc.StorageConditionDescription
	            ,uom.PackageSizeUomDescription
	            ,ob.OrangeBookCode
	            ,ahfs.AhfsCode
	            ,df.DosageFormDescription Dose
	            ,cast(case when cpr.Returnable = 'Y' then 1 else 0 end as bit) Returnable
	            ,cpr.OnHandInventoryQuantity Inventory
                ,ci.DefSubInv DefaultSubInventoryCode
	            ,cpr.Status
	            ,cpr.FormularyStatus Formulary
	            ,cipg.Price340b Price340B
	            ,cipg.PriceWac PriceWAC
	            ,pis.Shortage
	            ,psg.SignalTypeDescription SignalType
	            ,s.Qty SumUsed
                ,CAST(CASE
					WHEN EXISTS(
						SELECT 1
						FROM Predictive.NDCPricePredictions npp
						WHERE npp.ClientId = @clientId
						AND npp.IsActive = 1
						AND npp.ItemId = pi.ItemId
						)
					THEN 1
					ELSE 0
					END
					AS bit) HasBuyInAlert
				,cast(case when excl.BuyInExclusionId IS NOT NUll then 1 else 0 end as bit) HasActiveBuyInExclusion
                ,SUBSTRING(
                    (   SELECT ', '+hcpcs.HcpcsCode  AS [text()]
                        FROM (SELECT DISTINCT apal.HcpcsCode FROM AspPriceAndLimits apal WHERE apal.Ndc = pi.Ndc) AS hcpcs
                        ORDER BY pi.Ndc
                        FOR XML PATH ('')
                    ), 2, 1000) AS HcpcsCode 
            from PharmacyItem pi
                left join CustomerItem ci on ci.ItemId = pi.ItemId and ci.ClientId = @clientId --Param
	            left join ItemMaster.PackageSizeUom uom on pi.PackageSizeUomId = uom.PackageSizeUomId
	            left join (
		            select s.ItemId
			            ,sum(s.Qty) Qty
		            from Sales s
		            where s.ClientId = @clientId --Param
			            and s.TransactionDate > dateadd(yy, -2, getdate())
		            group by s.ItemId
	            ) s on pi.ItemId = s.ItemId
                left join PharmacyItem ppi on pi.PreviousNdc = ppi.Ndc
                left join PharmacyItem rbpi on pi.ReplacedByNdc = rbpi.Ndc
                left join ItemMaster.StorageCondition sc on pi.StorageConditionId = sc.StorageConditionId
	            left join ItemMaster.OrangeBook ob on pi.OrangeBookId = ob.OrangeBookId
	            left join ClientPharmacyRisk cpr on cpr.ItemId = pi.ItemId
		            and cpr.ClientId = @clientId --Param
	            left join (select cip.ItemId
					            ,max(case when cip.PriceListId = 2 then cip.PriceAmount else null end) Price340b
					            ,max(case when cip.PriceListId = 4 then cip.PriceAmount else null end) PriceWac
				            from CustomerItemPricing cip
				            where cip.ClientId = @clientId --Param
				            group by cip.ItemId) cipg on cipg.ItemId = pi.ItemId
	            left join (select pisg.ItemId
					            ,stuff(
						            (select N', ' + pis.Source
						            from PharmacyItemShortage pis
						            where pis.ItemId = pisg.ItemId
						            for xml path(N''), type).value(N'.[1]', N'nvarchar(max)'), 1, 1, N''
					            ) Shortage
				            from PharmacyItemShortage pisg
				            where pisg.ItemId is not null
					            and pisg.Status != 'R'
				            group by pisg.ItemId
	            ) pis on pis.ItemId = pi.ItemId
	            left join (select ps.ItemId --Duplicate PharmacySignals records
					            ,pst.SignalTypeDescription
				            from PharmacySignals ps
					            join PharmacySignalType pst on ps.SignalTypeId = pst.SignalTypeId
				            where ps.SignalTypeId = 3
					            and ps.Status = 'A'
					            and ps.ClientId = @clientId --Param
				            group by ps.ItemId
					            ,pst.SignalTypeDescription) psg on psg.ItemId = pi.ItemId
	            left join ItemMaster.DosageForm df on pi.DosageFormId = df.DosageFormId
	            left join (select piahfsg.ItemId
			            ,stuff(
				            (select N', ' + trim(str(ahfs.AhfsCode))
				            from PharmacyItemAhfs piahfs
					            join ItemMaster.AHFS ahfs on piahfs.AhfsId = ahfs.AhfsId
				            where piahfs.ItemId = piahfsg.ItemId
				            for xml path(N''), type).value(N'.[1]', N'nvarchar(max)'), 1, 1, N''
			            ) AhfsCode
		            from PharmacyItemAhfs piahfsg
		            where piahfsg.Status = 'A'
		            group by piahfsg.ItemId
	            ) ahfs on pi.ItemId = ahfs.ItemId
				left join App.BuyInExclusion excl on excl.BuyInExclusionId = (SELECT TOP 1 excl.BuyInExclusionId from App.BuyInExclusion excl WHERE  pi.ItemId = excl.ItemId and excl.ClientId = @clientId
                and (excl.ExclusionEndDate > GETDATE() or excl.ExclusionEndDate IS NULL))
            where pi.ndc = '00069080901' --Param
            
            
            SELECT DISTINCT HcpcsCode FROM AspPriceAndLimits where ndc = '00069080901'
            
            select * from AspPriceAndLimits where ndc = '00069080901'
            
            
            
            
            
       select      SUBSTRING(
                    (   SELECT ', '+hcpcs.HcpcsCode  AS [text()]
                        FROM (SELECT DISTINCT apal.HcpcsCode FROM AspPriceAndLimits apal WHERE apal.Ndc = pi.Ndc) AS hcpcs
                        ORDER BY pi.Ndc
                        FOR XML PATH ('')
                    ), 2, 1000) AS HcpcsCode 
                    
                    
  -----get current prices
declare @ndc varchar(11) = ('00069080901');
 with CurrentPricing as (
	            select npipc.Ndc
		            ,'WAC' PriceType
		            ,npipc.WacUnitPrice UnitPrice
		            ,npipc.WacPackagePrice PackagePrice
		            ,null HcpcsCode
		            ,null HcpcsDescription
		            ,null PaymentLimit
		            ,null HcpcsCodeDosage
		            ,null PackageSize
		            ,null PackageQuantity
		            ,null BillableUnits
		            ,null BillableUnitsPackage
	            from NationalPharmacyItemPriceCurrent npipc

	            union all

	            select npipc.Ndc
		            ,'AWP' PriceType
		            ,npipc.AwpUnitPrice UnitPrice
		            ,npipc.AwpPackagePrice PackagePrice
		            ,null HcpcsCode
		            ,null HcpcsDescription
		            ,null PaymentLimit
		            ,null HcpcsCodeDosage
		            ,null PackageSize
		            ,null PackageQuantity
		            ,null BillableUnits
		            ,null BillableUnitsPackage
	            from NationalPharmacyItemPriceCurrent npipc

	            union all

	            select npipc.Ndc
		            ,'FUL' PriceType
		            ,npipc.AcaFulUnitPrice UnitPrice
		            ,npipc.AcaFulPackagePrice PackagePrice
		            ,null HcpcsCode
		            ,null HcpcsDescription
		            ,null PaymentLimit
		            ,null HcpcsCodeDosage
		            ,null PackageSize
		            ,null PackageQuantity
		            ,null BillableUnits
		            ,null BillableUnitsPackage
	            from NationalPharmacyItemPriceCurrent npipc

	            union all

	            select npipc.Ndc
		            ,'NADAC' PriceType
		            ,npipc.NadacGenericUnitPrice UnitPrice
		            ,npipc.NadacGenericPackagePrice PackagePrice
		            ,null HcpcsCode
		            ,null HcpcsDescription
		            ,null PaymentLimit
		            ,null HcpcsCodeDosage
		            ,null PackageSize
		            ,null PackageQuantity
		            ,null BillableUnits
		            ,null BillableUnitsPackage
	            from NationalPharmacyItemPriceCurrent npipc

	            union all

	            select npipc.Ndc
		            ,'AMP' PriceType
		            ,npipc.AmpUnitPrice UnitPrice
		            ,npipc.AmpPackagePrice PackagePrice
		            ,null HcpcsCode
		            ,null HcpcsDescription
		            ,null PaymentLimit
		            ,null HcpcsCodeDosage
		            ,null PackageSize
		            ,null PackageQuantity
		            ,null BillableUnits
		            ,null BillableUnitsPackage
	            from NationalPharmacyItemPriceCurrent npipc

	            union all

	            select npipc.Ndc
		            ,'DP' PriceType
		            ,npipc.DpUnitPrice UnitPrice
		            ,npipc.DpPackagePrice PackagePrice
		            ,null HcpcsCode
		            ,null HcpcsDescription
		            ,null PaymentLimit
		            ,null HcpcsCodeDosage
		            ,null PackageSize
		            ,null PackageQuantity
		            ,null BillableUnits
		            ,null BillableUnitsPackage
	            from NationalPharmacyItemPriceCurrent npipc

	            union all

	            select apl.Ndc
		            ,'ASP' PriceType
		            ,apl.AspUnitPrice UnitPrice
		            ,apl.AspUnitPrice * apl.PackageQuantity PackagePrice
		            ,apl.HcpcsCode
		            ,apl.HcpcsDescription
		            ,apl.PaymentLimit
		            ,apl.HcpcsCodeDosage
		            ,apl.PackageSize
		            ,apl.PackageQuantity
		            ,apl.BillableUnitsPerPackage BillableUnits
		            ,apl.BillableUnitsPer11DigitNdc BillableUnitsPackage
	            from AspPriceAndLimits apl
	            where apl.IsCurrentRecords = 1 and ndc = '00069080901'
            )

            select *
            from CurrentPricing cp
            where cp.Ndc = @ndc --Param
	            and (cp.UnitPrice is not null
		            or cp.PackagePrice is not null)
            order by cp.PriceType
	            ,cp.UnitPrice;
	           
	           select * from AspPriceAndLimits apl where ndc = '00069080901'
	            where apl.IsCurrentRecords = 1 and ndc = '00069080901'
	            
	            
	            
	            SELECT NDC FROM AspPriceAndLimits
	            
	            
	            
	            
	            
	        

select t.username, t.date, t.value
from MyTable t
inner join (
    select username, max(date) as MaxDate
    from MyTable
    group by username
) tm on t.username = tm.username and t.date = tm.MaxDate

--seems to be a solution

with maxdate as(
select max(quarterdate) as latestdate from dbo.AspPriceAndLimits  )
select ndc, max(QuarterDate) as MaxDate
    from dbo.AspPriceAndLimits apal join maxdate on maxdate.latestdate = apal.QuarterDate 
    group by ndc

    select distinct(quarterdate),ndc,HcpcsCode from dbo.AspPriceAndLimits where ndc = '00069080901'
    
with maxdate as(
select max(quarterdate) as latestdate from dbo.AspPriceAndLimits  ),
latestndc as (select ndc, max(QuarterDate) as maxidate
    from dbo.AspPriceAndLimits apal join maxdate on maxdate.latestdate = apal.QuarterDate 
    group by ndc),
notlatestndc as (select ndc, QuarterDate
    from dbo.AspPriceAndLimits apal join maxdate on maxdate.latestdate <> apal.QuarterDate
    group by ndc,quarterdate) 
  --  group by ndc)   
select NDC from notlatestndc a where a.ndc not in (select ndc from latestndc)
    

select t.username, t.date, t.value
from MyTable t
inner join (
    select ndc, max(QuarterDate) as MaxDate
    from dbo.AspPriceAndLimits apal 
    where quarterdate = max(QuarterDate)
    group by ndc
) tm on t.username = tm.username and t.date = tm.MaxDate





===================================latest
 select 
                 pi.ItemId Id
                ,pi.ItemUId
	            ,pi.PricingKey
	            ,pi.Ndc
                ,pi.Ndc11
                ,pi.PreviousNdc
                ,ppi.ItemDescription PreviousNdcDescription
                ,pi.ReplacedByNdc
                ,rbpi.ItemDescription ReplacedByNdcDescription
                ,pi.GPI
	            ,pi.ItemDescription Description
			    ,CASE 
				    WHEN EXISTS(
						SELECT 1 
						FROM ItemMaster.FdaProductApplications fpa 
						WHERE fpa.MarketingStatus = 'DISCN' 
							AND fpa.ItemId = pi.ItemId
						) THEN '**** DISCONTINUED ****'
					ELSE '' 
					END MarketingStatus 
	            ,pi.DrugName BrandName
	            ,pi.Ingredients GenericName
                ,pi.Manufacturer
                ,pi.IsGenericDrug
	            ,pi.PackageDescription PackDescription
	            ,isnull(pi.PackageSize, 1)  PackSize
	            ,pi.CasePack
                ,pi.DrugStrength + pi.DrugStrengthUOM DrugStrength
                ,sc.StorageConditionDescription
	            ,uom.PackageSizeUomDescription
	            ,ob.OrangeBookCode
	            ,ahfs.AhfsCode
	            ,df.DosageFormDescription Dose
	            ,cast(case when cpr.Returnable = 'Y' then 1 else 0 end as bit) Returnable
	            ,cpr.OnHandInventoryQuantity Inventory
                ,ci.DefSubInv DefaultSubInventoryCode
	            ,cpr.Status
	            ,cpr.FormularyStatus Formulary
	            ,cipg.Price340b Price340B
	            ,cipg.PriceWac PriceWAC
	            ,pis.Shortage
	            ,psg.SignalTypeDescription SignalType
	            ,s.Qty SumUsed
                ,CAST(CASE
					WHEN EXISTS(
						SELECT 1
						FROM Predictive.NDCPricePredictions npp
						WHERE npp.ClientId = @clientId
						AND npp.IsActive = 1
						AND npp.ItemId = pi.ItemId
						)
					THEN 1
					ELSE 0
					END
					AS bit) HasBuyInAlert
				,cast(case when excl.BuyInExclusionId IS NOT NUll then 1 else 0 end as bit) HasActiveBuyInExclusion
                ,SUBSTRING(
                    (   SELECT ', '+hcpcs.HcpcsCode  AS [text()]
                        FROM (SELECT DISTINCT apal.HcpcsCode FROM AspPriceAndLimits apal WHERE apal.Ndc = pi.Ndc) AS hcpcs
                        ORDER BY pi.Ndc
                        FOR XML PATH ('')
                    ), 2, 1000) AS HcpcsCode 
            from PharmacyItem pi
                left join CustomerItem ci on ci.ItemId = pi.ItemId and ci.ClientId = @clientId --Param
	            left join ItemMaster.PackageSizeUom uom on pi.PackageSizeUomId = uom.PackageSizeUomId
	            left join (
		            select s.ItemId
			            ,sum(s.Qty) Qty
		            from Sales s
		            where s.ClientId = @clientId --Param
			            and s.TransactionDate > dateadd(yy, -2, getdate())
		            group by s.ItemId
	            ) s on pi.ItemId = s.ItemId
                left join PharmacyItem ppi on pi.PreviousNdc = ppi.Ndc
                left join PharmacyItem rbpi on pi.ReplacedByNdc = rbpi.Ndc
                left join ItemMaster.StorageCondition sc on pi.StorageConditionId = sc.StorageConditionId
	            left join ItemMaster.OrangeBook ob on pi.OrangeBookId = ob.OrangeBookId
	            left join ClientPharmacyRisk cpr on cpr.ItemId = pi.ItemId
		            and cpr.ClientId = @clientId --Param
	            left join (select cip.ItemId
					            ,max(case when cip.PriceListId = 2 then cip.PriceAmount else null end) Price340b
					            ,max(case when cip.PriceListId = 4 then cip.PriceAmount else null end) PriceWac
				            from CustomerItemPricing cip
				            where cip.ClientId = @clientId --Param
				            group by cip.ItemId) cipg on cipg.ItemId = pi.ItemId
	            left join (select pisg.ItemId
					            ,stuff(
						            (select N', ' + pis.Source
						            from PharmacyItemShortage pis
						            where pis.ItemId = pisg.ItemId
						            for xml path(N''), type).value(N'.[1]', N'nvarchar(max)'), 1, 1, N''
					            ) Shortage
				            from PharmacyItemShortage pisg
				            where pisg.ItemId is not null
					            and pisg.Status != 'R'
				            group by pisg.ItemId
	            ) pis on pis.ItemId = pi.ItemId
	            left join (select ps.ItemId --Duplicate PharmacySignals records
					            ,pst.SignalTypeDescription
				            from PharmacySignals ps
					            join PharmacySignalType pst on ps.SignalTypeId = pst.SignalTypeId
				            where ps.SignalTypeId = 3
					            and ps.Status = 'A'
					            and ps.ClientId = @clientId --Param
				            group by ps.ItemId
					            ,pst.SignalTypeDescription) psg on psg.ItemId = pi.ItemId
	            left join ItemMaster.DosageForm df on pi.DosageFormId = df.DosageFormId
	            left join (select piahfsg.ItemId
			            ,stuff(
				            (select N', ' + trim(str(ahfs.AhfsCode))
				            from PharmacyItemAhfs piahfs
					            join ItemMaster.AHFS ahfs on piahfs.AhfsId = ahfs.AhfsId
				            where piahfs.ItemId = piahfsg.ItemId
				            for xml path(N''), type).value(N'.[1]', N'nvarchar(max)'), 1, 1, N''
			            ) AhfsCode
		            from PharmacyItemAhfs piahfsg
		            where piahfsg.Status = 'A'
		            group by piahfsg.ItemId
	            ) ahfs on pi.ItemId = ahfs.ItemId
				left join App.BuyInExclusion excl on excl.BuyInExclusionId = (SELECT TOP 1 excl.BuyInExclusionId from App.BuyInExclusion excl WHERE  pi.ItemId = excl.ItemId and excl.ClientId = @clientId
                and (excl.ExclusionEndDate > GETDATE() or excl.ExclusionEndDate IS NULL))
            where pi.ndc in @ndcs --Param";
            
           
           
           
 --------------------------------------------------------------------------------
 select distinct ndc,QuarterDate from dbo.AspPriceAndLimits apal where IsCurrentRecords = 1 
order by QuarterDate desc


select * from dbo.AspPriceAndLimits where ndc = '00069080901'

select count(*) from dbo.AspPriceAndLimits apal 

select * from AspPriceAndLimits 
where QuarterDate = (select max(quarterdate) as Quarterdate from AspPriceAndLimits apal )


update AspPriceAndLimits set Is_hcpcs_active = 'Y'
where QuarterDate = (select max(quarterdate) as Quarterdate from AspPriceAndLimits apal )

select max(quarterdate),ndc,HcpcsCode from dbo.AspPriceAndLimits
where ndc = '59572098401'
group by ndc, HcpcsCode 
order by quarterdate desc



 SELECT DISTINCT 
                 a.hcpcscode as JCode
                ,MIN(i.drugname) as Brand
            FROM asppriceandlimits a
            JOIN pharmacyitem i ON a.itemid = i.itemid
            JOIN sales s ON s.itemid = i.itemid
            WHERE s.clientid = 6 and a.is_hcpcs_active = 'Y'
           -- AND a.hcpcscode LIKE 'Q5%'
               -- OR i.drugname LIKE @input + '%'
            GROUP BY a.hcpcscode
            ORDER BY a.hcpcscode

select * from AspPriceAndLimits apal where apal.HcpcsCode = 'Q5102'



 with aspUnitPrice as (
                        select top 1 with ties
                            a.HcpcsCode
                            ,a.HCPCSDescription
                            , a.QuarterDate
                            , a.AspUnitPrice
                        from AspPriceAndLimits a
                        where  a.is_hcpcs_active = 'Y' 
                        order by row_number() over (partition by a.HcpcsCode order by a.QuarterDate desc)
                    )
                    , avgAwpUnitPrice as (
                        select 
                             a.HcpcsCode
                             , avg(c.AwpUnitPrice / a.BillableUnitsPer11DigitNDC) as 'AverageAwpUnitPrice'
                        from AspPriceAndLimits a
                            join NationalPharmacyItemPriceCurrent c on c.Ndc = a.Ndc
                        where a.IsCurrentRecords = 1
                        group by a.HcpcsCode
                    )
                    select asp.HcpcsCode as JCode
                            , asp.HCPCSDescription as Brand
                            , asp.AspUnitPrice as CurrentAspUnitPrice
                            , awp.AverageAwpUnitPrice
                    from aspUnitPrice asp
                    join avgAwpUnitPrice awp on asp.HcpcsCode = awp.HcpcsCode
                    where asp.HcpcsCode like 'J%'
                          or asp.HcpcsCode like 'Q%'


          