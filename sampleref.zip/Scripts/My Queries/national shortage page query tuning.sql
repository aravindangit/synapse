--ALTER INDEX ALL ON NationalPriceDisruptions.RawInvoices
--DISABLE;

select top 100 * from [NationalPriceDisruptions].[RawInvoices]
select top 100 * from dbo.Sales s 
ALTER INDEX ALL ON [NationalPriceDisruptions].[RawInvoices]
REBUILD;
select is_disabled,* from sys.indexes
where object_id = (select top 1 object_id from sys.objects where name = 'rawinvoices')

CREATE NONCLUSTERED INDEX IX_NationalPriceDisruptions_RawInvoices_GpiName ON NationalPriceDisruptions.RawInvoices 
(  GpiName ASC  )  
INCLUDE ( InvoiceDateString , QuantityOrdered , TotalUnits ) 
WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , 
IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
ON [PRIMARY ] ;

select * from Supplier s 

select * from NationalPriceDisruptions

CREATE NONCLUSTERED INDEX IX_NationalPriceDisruptions_RawInvoices_GpiName_test ON NationalPriceDisruptions.RawInvoices
(  GpiName ASC,DrugStrength ASC, FacilityState ASC, Manufacturer ASC)  
	 INCLUDE ( InvoiceDateString , QuantityOrdered , TotalUnits ) 
	 WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
	 ON [PRIMARY ] ;
	 
CREATE NONCLUSTERED INDEX IX_NationalPriceDisruptions_RawInvoices_GpiName_test1 ON NationalPriceDisruptions.RawInvoices
(  GpiName ASC,DrugStrength ASC, FacilityState ASC, Manufacturer ASC,
InvoiceDateString ASC , QuantityOrdered ASC , TotalUnits ASC)   
WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
ON [PRIMARY ] ;
	 	
	
ALTER INDEX IX_NationalPriceDisruptions_RawInvoices_GpiName_test ON NationalPriceDisruptions.RawInvoices
DISABLE;

dropping all indexs:

declare @qry nvarchar(max);
select @qry = 
(SELECT  'DROP INDEX ' + quotename(ix.name) + ' ON ' + quotename(object_schema_name(object_id)) + '.' + quotename(OBJECT_NAME(object_id)) + '; '
FROM  sys.indexes ix
WHERE   ix.Name IS NOT null and ix.Name like '%rawinvoices%'
for xml path(''));
exec sp_executesql @qry