SELECT member_key, member_id, member_name, member_name2, dea, hin, member_address, member_address2, member_city, member_state, member_state_desc, member_zip, member_fax, member_phone, member_signee, member_signee_title, member_sign_date, member_start_date, member_end_date, provider_primary_service_id, provider_primary_service_desc, hrm_name, rmvp_name, member_direct_parent_id, member_direct_parent_name, member_direct_parent_name2, member_direct_parent_rel_date, member_cur_top_par_id, member_cur_top_par_name, member_cur_top_par_name2, member_cur_top_par_rel_date, member_cur_top_par_class, member_olm, rc_member, rc_dea, rc_name, rc_dir_of_pharmacy, rc_dop_email_addr, rc_address_1, rc_city, rc_state, rc_zip, rc_phone, rc_fax, rc_wholesaler, rc_top_parent_id, rc_top_parent_name, rc_spc, rc_hin, member_status, member_single_phys_spec, member_cur_top_par_sales_region, member_spc, direct_mail_flag, sdi_id, dsh_id, member_top_parent_key, member_direct_parent_key, total_sales_volume, premier_relation
FROM public."member"
where member_name in ('MONTER CANCER CENTER LIJMC');
(
'STATEN ISLAND UNIVERSITY HOSPITAL - METHADONE UNIT',
'NORTHWELL - CONCORDE MEDICAL',
'CARDIOVASCULAR ASSOCIATES OF NEW YORK',
'PHYSICIANS OF UNIVERSITY HOSPITAL',
'EASTERN SUFFOLK CARDIOLOGY',
'ADAM M. KATOF, DO, PLLC',
'NORTH FORK RADIOLOGY',
'GARY SHORE, MD, PC',
'GO HEALTH - AMSTERDAM FFF',
'HEALTHCARE ASSOCIATES IN MEDICINE, PC',
'LENOX HEALTH GREENWICH VILLAGE',
'STATEN ISLAND UNIVERSITY HOSPITAL',
'NORTH SHORE - LONG ISLAND JEWISH HEALTH SYSTEM',
'NORTH SHORE UNIVERSITY HOSPITAL - DRUG TREATMENT &',
'STATEN ISLAND PULMONARY ASSOCIATES',
'RICHMOND MEDICAL ASSOCIATES',
'SWAMY & ARITON CARDIOLOGY')
;


select * from product_rpt where ndc = '57894019506' fetch first 10 rows only;

select * from fact_bp_sales_detail_view where product_key = 603547;

select * from member_view ;

select * from fact_bp_sales_detail_view fetch first 10 rows only;

select    a11.member_key AS member_key,a12.ndc, a14.member_status,
               max(a14.member_identity) AS member_identity,
               a13.bus_partner_id AS bus_partner_id,
               max(a13.bus_partner_desc) AS bus_partner_desc,
               a12.man_dist AS man_dist,
               Sum(case when a11.matrix_status_key in (0,1,2,4,5,6)  then a11.qty_ordered  else 0 end) AS QUANTITYORDERED,
               Sum(case when a11.matrix_status_key in (0,1,2,4,5,6)  then a11.sales_qty  else 0 end) AS TOTALUNITS,
               Sum(case when a11.matrix_status_key in (0,1,2,4,5,6)  then a11.sales_dollars  else 0 end) AS TOTALSPEND,
               Sum(case when a11.matrix_status_key = 6 then a11.sales_qty  else 0 end) AS WACUNITS,
               Sum(case when a11.matrix_status_key = 6 then a11.sales_dollars  else 0 end) AS WACSPEND,
               Sum(case when a11.matrix_status_key = 5 then a11.sales_qty  else 0 end) AS M340BUNITS,
               Sum(case when a11.matrix_status_key = 5 then a11.sales_dollars  else 0 end) AS M340BSPEND,
               Sum(case when a11.matrix_status_key in (0,1,2,4)  then a11.sales_qty  else 0 end) AS TOTALUNITSEXCLUDING340BWAC,
               Sum(case when a11.matrix_status_key in (0,1,2,4)  then a11.sales_dollars  else 0 end) AS TOTALSPENDEXCLUDING340BWAC
from      fact_bp_sales_detail_view            a11
               join        product_rpt        a12
                 on        (a11.product_key = a12.product_key)
               join        bus_partner_source         a13
                 on        (a11.bp_source_id = a13.bp_source_id)
               join        member_view    a14
                 on        (a11.member_key = a14.member_key)
where    (a11.quarter_id in (20211)
--where    ((a11.invoice_date >= '2021-01-01' and a11.invoice_date <='2021-01-31')
and a14.member_top_parent_key in (61885)
and a13.bus_partner_id in (1, 4, 8, 11, 12)
and a14.member_status in ('ACTIVE', 'TERMINATED'))  -- and  a12.man_dist = 'JANSSEN BIOTECH')
group by              a11.member_key,
               a13.bus_partner_id,
               a12.man_dist,
               a12.ndc,
               a14.member_status limit 500001
               
           select member_status from product_rpt where ndc = '57894019506'
           
 select    a11.member_key AS member_key,a12.ndc, a14.member_status,
               max(a14.member_identity) AS member_identity,
               a13.bus_partner_id AS bus_partner_id,
               max(a13.bus_partner_desc) AS bus_partner_desc,
               a12.man_dist AS man_dist,
               Sum(case when a11.matrix_status_key in (0,1,2,4,5,6)  then a11.qty_ordered  else 0 end) AS QUANTITYORDERED,
               Sum(case when a11.matrix_status_key in (0,1,2,4,5,6)  then a11.sales_qty  else 0 end) AS TOTALUNITS,
               Sum(case when a11.matrix_status_key in (0,1,2,4,5,6)  then a11.sales_dollars  else 0 end) AS TOTALSPEND,
               Sum(case when a11.matrix_status_key = 6 then a11.sales_qty  else 0 end) AS WACUNITS,
               Sum(case when a11.matrix_status_key = 6 then a11.sales_dollars  else 0 end) AS WACSPEND,
               Sum(case when a11.matrix_status_key = 5 then a11.sales_qty  else 0 end) AS M340BUNITS,
               Sum(case when a11.matrix_status_key = 5 then a11.sales_dollars  else 0 end) AS M340BSPEND,
               Sum(case when a11.matrix_status_key in (0,1,2,4)  then a11.sales_qty  else 0 end) AS TOTALUNITSEXCLUDING340BWAC,
               Sum(case when a11.matrix_status_key in (0,1,2,4)  then a11.sales_dollars  else 0 end) AS TOTALSPENDEXCLUDING340BWAC
from      fact_bp_sales_detail_view            a11
               join        product_rpt        a12
                 on        (a11.product_key = a12.product_key)
               join        bus_partner_source         a13
                 on        (a11.bp_source_id = a13.bp_source_id)
               join        member_view    a14
                 on        (a11.member_key = a14.member_key)
--where    (a12.man_dist = 'JANSSEN BIOTECH' and a12.ndc = '57894019506')
where    (a12.ndc = '55513073001')
group by              a11.member_key,
               a13.bus_partner_id,
               a12.man_dist,
               a12.ndc,
               a14.member_status limit 500001

 
-- * Comments
-- * (transactiondate >= '2021-01-01' and transactiondate <='2021-03-31')
--invoice_date
select    a11.member_key AS member_key,a12.ndc, a14.member_status,
               max(a14.member_identity) AS member_identity,
               a13.bus_partner_id AS bus_partner_id,
               max(a13.bus_partner_desc) AS bus_partner_desc,
               a12.man_dist AS man_dist,
               Sum(case when a11.matrix_status_key in (0,1,2,4,5,6)  then a11.qty_ordered  else 0 end) AS QUANTITYORDERED,
               Sum(case when a11.matrix_status_key in (0,1,2,4,5,6)  then a11.sales_qty  else 0 end) AS TOTALUNITS,
               Sum(case when a11.matrix_status_key in (0,1,2,4,5,6)  then a11.sales_dollars  else 0 end) AS TOTALSPEND,
               Sum(case when a11.matrix_status_key = 6 then a11.sales_qty  else 0 end) AS WACUNITS,
               Sum(case when a11.matrix_status_key = 6 then a11.sales_dollars  else 0 end) AS WACSPEND,
               Sum(case when a11.matrix_status_key = 5 then a11.sales_qty  else 0 end) AS M340BUNITS,
               Sum(case when a11.matrix_status_key = 5 then a11.sales_dollars  else 0 end) AS M340BSPEND,
               Sum(case when a11.matrix_status_key in (0,1,2,4)  then a11.sales_qty  else 0 end) AS TOTALUNITSEXCLUDING340BWAC,
               Sum(case when a11.matrix_status_key in (0,1,2,4)  then a11.sales_dollars  else 0 end) AS TOTALSPENDEXCLUDING340BWAC
from      fact_bp_sales_detail_view            a11
               join        product_rpt        a12
                 on        (a11.product_key = a12.product_key)
               join        bus_partner_source         a13
                 on        (a11.bp_source_id = a13.bp_source_id)
               join        member_view    a14
                 on        (a11.member_key = a14.member_key)
--where    (a11.quarter_id in (20211)
--where    ((a11.invoice_date >= '2021-01-01' and a11.invoice_date <='2021-01-31')
and a14.member_top_parent_key in (61885)
and a13.bus_partner_id in (1, 4, 8, 11, 12)
and a14.member_status in ('ACTIVE', 'TERMINATED') and  a12.man_dist = 'JANSSEN BIOTECH')
group by              a11.member_key,
               a13.bus_partner_id,
               a12.man_dist,
               a12.ndc,
               a14.member_status limit 500001  
               
               
               
               
 select top 10 *               
from      fact_bp_sales_detail_view            a11
               join        product_rpt        a12
                 on        (a11.product_key = a12.product_key)
               join        bus_partner_source         a13
                 on        (a11.bp_source_id = a13.bp_source_id) and a12.man_dist = 'JANSSEN BIOTECH';
                
                
 select    a11.member_key AS member_key,a12.ndc, a14.member_status,
               max(a14.member_identity) AS member_identity,
               a13.bus_partner_id AS bus_partner_id,
               max(a13.bus_partner_desc) AS bus_partner_desc,
               a12.man_dist AS man_dist,
               Sum(case when a11.matrix_status_key in (0,1,2,4,5,6)  then a11.qty_ordered  else 0 end) AS QUANTITYORDERED,
               Sum(case when a11.matrix_status_key in (0,1,2,4,5,6)  then a11.sales_qty  else 0 end) AS TOTALUNITS,
               Sum(case when a11.matrix_status_key in (0,1,2,4,5,6)  then a11.sales_dollars  else 0 end) AS TOTALSPEND,
               Sum(case when a11.matrix_status_key = 6 then a11.sales_qty  else 0 end) AS WACUNITS,
               Sum(case when a11.matrix_status_key = 6 then a11.sales_dollars  else 0 end) AS WACSPEND,
               Sum(case when a11.matrix_status_key = 5 then a11.sales_qty  else 0 end) AS M340BUNITS,
               Sum(case when a11.matrix_status_key = 5 then a11.sales_dollars  else 0 end) AS M340BSPEND,
               Sum(case when a11.matrix_status_key in (0,1,2,4)  then a11.sales_qty  else 0 end) AS TOTALUNITSEXCLUDING340BWAC,
               Sum(case when a11.matrix_status_key in (0,1,2,4)  then a11.sales_dollars  else 0 end) AS TOTALSPENDEXCLUDING340BWAC
from      fact_bp_sales_detail_view            a11
               join        product_rpt        a12
                 on        (a11.product_key = a12.product_key)
               join        bus_partner_source         a13
                 on        (a11.bp_source_id = a13.bp_source_id)
               join        member_view    a14
                 on        (a11.member_key = a14.member_key)
where    (a11.quarter_id in (20211)
--where    ((a11.invoice_date >= '2021-01-01' and a11.invoice_date <='2021-01-31')
and a14.member_top_parent_key in (61885)
and a13.bus_partner_id in (1, 4, 8, 11, 12)
and a14.member_status in ('ACTIVE', 'TERMINATED') )--and  a12.man_dist = 'JANSSEN BIOTECH')
group by              a11.member_key,
               a13.bus_partner_id,
               a12.man_dist,
               a12.ndc,
               a14.member_status limit 500001
               
 -------------------------------------------------------------------
 select    a11.member_key AS member_key, 
               max(a14.member_identity) AS member_identity,
               a13.bus_partner_id AS bus_partner_id,
               max(a13.bus_partner_desc) AS bus_partner_desc,
               a12.man_dist AS man_dist,
               Sum(case when a11.matrix_status_key in (0,1,2,4,5,6)  then a11.qty_ordered  else 0 end) AS QUANTITYORDERED,
               Sum(case when a11.matrix_status_key in (0,1,2,4,5,6)  then a11.sales_qty  else 0 end) AS TOTALUNITS,
               Sum(case when a11.matrix_status_key in (0,1,2,4,5,6)  then a11.sales_dollars  else 0 end) AS TOTALSPEND,
               Sum(case when a11.matrix_status_key = 6 then a11.sales_qty  else 0 end) AS WACUNITS,
               Sum(case when a11.matrix_status_key = 6 then a11.sales_dollars  else 0 end) AS WACSPEND,
               Sum(case when a11.matrix_status_key = 5 then a11.sales_qty  else 0 end) AS M340BUNITS,
               Sum(case when a11.matrix_status_key = 5 then a11.sales_dollars  else 0 end) AS M340BSPEND,
               Sum(case when a11.matrix_status_key in (0,1,2,4)  then a11.sales_qty  else 0 end) AS TOTALUNITSEXCLUDING340BWAC,
               Sum(case when a11.matrix_status_key in (0,1,2,4)  then a11.sales_dollars  else 0 end) AS TOTALSPENDEXCLUDING340BWAC
from      fact_bp_sales_detail_view            a11
               join        product_rpt        a12
                 on        (a11.product_key = a12.product_key)
               join        bus_partner_source         a13
                 on        (a11.bp_source_id = a13.bp_source_id)
               join        member_view    a14
                 on        (a11.member_key = a14.member_key)
where    (a11.quarter_id in (20211)
and a14.member_top_parent_key in (61885)
and a13.bus_partner_id in (1, 4, 8, 11, 12)
and a14.member_status in ('ACTIVE', 'TERMINATED')
and man_dist = 'JANSSEN BIOTECH')
	group by              a11.member_key,
               a13.bus_partner_id,
               a12.man_dist limit 500001

               
 select * from fact_bp_sales_detail_view limit 100 ;
select max(invoice_date) from fact_bp_sales_detail where quarter_id in (20211) LIMIT 10;
 
------------------------------------------------------------------
--updating

select    a11.member_key AS member_key,a12.ndc, a14.member_status,
               max(a14.member_identity) AS member_identity,
               a13.bus_partner_id AS bus_partner_id,
               max(a13.bus_partner_desc) AS bus_partner_desc,
               a12.man_dist AS man_dist,
               Sum(case when a11.matrix_status_key in (0,1,2,4,5,6)  then a11.qty_ordered  else 0 end) AS QUANTITYORDERED,
               Sum(case when a11.matrix_status_key in (0,1,2,4,5,6)  then a11.sales_qty  else 0 end) AS TOTALUNITS,
               Sum(case when a11.matrix_status_key in (0,1,2,4,5,6)  then a11.sales_dollars  else 0 end) AS TOTALSPEND,
               Sum(case when a11.matrix_status_key = 6 then a11.sales_qty  else 0 end) AS WACUNITS,
               Sum(case when a11.matrix_status_key = 6 then a11.sales_dollars  else 0 end) AS WACSPEND,
               Sum(case when a11.matrix_status_key = 5 then a11.sales_qty  else 0 end) AS M340BUNITS,
               Sum(case when a11.matrix_status_key = 5 then a11.sales_dollars  else 0 end) AS M340BSPEND,
               Sum(case when a11.matrix_status_key in (0,1,2,4)  then a11.sales_qty  else 0 end) AS TOTALUNITSEXCLUDING340BWAC,
               Sum(case when a11.matrix_status_key in (0,1,2,4)  then a11.sales_dollars  else 0 end) AS TOTALSPENDEXCLUDING340BWAC
from      fact_bp_sales_detail_view            a11
               join        product_rpt        a12
                 on        (a11.product_key = a12.product_key)
               join        bus_partner_source         a13
                 on        (a11.bp_source_id = a13.bp_source_id)
               join        member_view    a14
                 on        (a11.member_key = a14.member_key)
where    (a11.quarter_id in (20212)
--where    ((a11.invoice_date >= '2021-01-01' and a11.invoice_date <='2021-01-31')
and a14.member_top_parent_key in (61885)
and a13.bus_partner_id in (1, 4, 8, 11, 12)
and a14.member_status in ('ACTIVE', 'TERMINATED') and  a12.man_dist = 'JANSSEN BIOTECH')
group by              a11.member_key,
               a13.bus_partner_id,
               a12.man_dist,
               a12.ndc,
               a14.member_status limit 500001
               
               
---fillrate
               
select	a12.member_top_parent_key AS member_top_parent_key,	
	max(a15.member_top_parent_info) AS member_top_parent_info,	
	a13.ndc AS ndc,	
	a11.invoice_date AS invoice_date,	
	Sum(case when a11.matrix_status_key in (0,1,2,4,5,6)� then a11.sales_dollars� else 0 end) AS TOTALSPEND,	
	Sum(case when a11.matrix_status_key in (0,1,2,4,5,6)� then a11.qty_ordered� else 0 end) AS QUANTITYORDERED,	
	Sum(case when a11.matrix_status_key in (0,1,2,4,5,6)� then a11.sales_qty� else 0 end) AS TOTALUNITS	
from	fact_bp_sales_detail_view	a11
	join	member_view
	� on 	(a11.member_key = a12.member_key)
	join	product_rpt
	� on 	(a11.product_key = a13.product_key)
	join	bus_partner_source
	� on 	(a11.bp_source_id = a14.bp_source_id)
	join	member_top_parent_view a15
	� on 	(a12.member_top_parent_key = a15.member_top_parent_key)
where	(a11.month_id in (2021206, 2021205, 2021204, 2021103)	
 and a14.bus_partner_id in (11, 1, 12, 4, 8)		
 and a13.ndc in ('63739059110')		
 and a12.member_status in ('ACTIVE', 'TERMINATED'))		
group by	a12.member_top_parent_key,	
	a13.ndc,	
	a11.invoice_date limit 500001	

	
select	a12.member_top_parent_key AS member_top_parent_key,	
	max(a15.member_top_parent_info) AS member_top_parent_info,	
	a13.ndc AS ndc,	
	a11.invoice_date AS invoice_date,	
	Sum(case when a11.matrix_status_key in (0,1,2,4,5,6)� then a11.sales_dollars� else 0 end) AS TOTALSPEND,	
	Sum(case when a11.matrix_status_key in (0,1,2,4,5,6)� then a11.qty_ordered� else 0 end) AS QUANTITYORDERED,	
	Sum(case when a11.matrix_status_key in (0,1,2,4,5,6)� then a11.sales_qty� else 0 end) AS TOTALUNITS	
from	fact_bp_sales_detail_view	a11
	join	member_view
	� on 	(a11.member_key = a12.member_key)
	join	product_rpt
	� on 	(a11.product_key = a13.product_key)
	join	bus_partner_source
	� on 	(a11.bp_source_id = a14.bp_source_id)
	join	member_top_parent_view a15
	� on 	(a12.member_top_parent_key = a15.member_top_parent_key)
where	(a11.month_id in (2021206, 2021205, 2021204, 2021103)	
 and a14.bus_partner_id in (11, 1, 12, 4, 8)		
 and a13.ndc in ('63739059110')		
 and a12.member_status in ('ACTIVE', 'TERMINATED'))		
group by	a12.member_top_parent_key,	
	a13.ndc,	
	a11.invoice_date limit 500001	

	
select	a12.member_top_parent_key AS member_top_parent_key,	
	max(a15.member_top_parent_info) AS member_top_parent_info,	
	a13.ndc AS ndc,	
	a11.invoice_date AS invoice_date,	
	Sum(case when a11.matrix_status_key in (0,1,2,4,5,6)� then a11.sales_dollars� else 0 end) AS TOTALSPEND,	
	Sum(case when a11.matrix_status_key in (0,1,2,4,5,6)� then a11.qty_ordered� else 0 end) AS QUANTITYORDERED,	
	Sum(case when a11.matrix_status_key in (0,1,2,4,5,6)� then a11.sales_qty� else 0 end) AS TOTALUNITS	
from	fact_bp_sales_detail_view	a11
	join	member_view a12
	� on 	(a11.member_key = a12.member_key)
	join	product_rpt a13
	� on 	(a11.product_key = a13.product_key)
	join	bus_partner_source a14
	� on 	(a11.bp_source_id = a14.bp_source_id)
	join	member_top_parent_view a15
	� on 	(a12.member_top_parent_key = a15.member_top_parent_key)
where	(a11.month_id in (2021206, 2021205, 2021204, 2021103)	
 and a14.bus_partner_id in (11, 1, 12, 4, 8)		
 and a13.ndc in ('63739059110')		
 and a12.member_status in ('ACTIVE', 'TERMINATED'))		
group by	a15.member_top_parent_key,	
	a13.ndc,	
	a11.invoice_date limit 500001	
	
	
	
select	a12.member_top_parent_key AS member_top_parent_key,		
	max(a15.member_top_parent_info) AS member_top_parent_info,		
	a13.ndc AS ndc,		
	a11.invoice_date AS invoice_date,		
	Sum(case when a11.matrix_status_key in (0,1,2,4,5,6)� then a11.sales_dollars� else 0 end) AS TOTALSPEND,		
	Sum(case when a11.matrix_status_key in (0,1,2,4,5,6)� then a11.qty_ordered� else 0 end) AS QUANTITYORDERED,		
	Sum(case when a11.matrix_status_key in (0,1,2,4,5,6)� then a11.sales_qty� else 0 end) AS TOTALUNITS		
from	fact_bp_sales_detail_view	a11	
	join	member_view	a12
	� on 	(a11.member_key = a12.member_key)	
	join	product_rpt	a13
	� on 	(a11.product_key = a13.product_key)	
	join	bus_partner_source	a14
	� on 	(a11.bp_source_id = a14.bp_source_id)	
	join	member_top_parent_view	a15
	� on 	(a12.member_top_parent_key = a15.member_top_parent_key)	
where	(a11.month_id in (2021206, 2021205, 2021204, 2021103)		
 and a14.bus_partner_id in (11, 1, 12, 4, 8)			
 and a13.ndc in ('63739059110')			
 and a12.member_status in ('ACTIVE', 'TERMINATED'))			
group by	a12.member_top_parent_key,		
	a13.ndc,		
	a11.invoice_date limit 500001		
			

