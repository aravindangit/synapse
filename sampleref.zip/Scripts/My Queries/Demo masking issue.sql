select * from dbo.Customer c 


update Customer set CustomerOrganizationId = 9


select * from dbo.CustomerOrganization co 



delete from dbo.CustomerOrganization where organizationNumber = 'NY0024'

update Customer 
set AccountNumber = case 
						 when AccountNumber = 'NY5073' THEN 'NC9999'
						 when AccountNumber = 'NY5029' THEN 'NC8888'
						 when AccountNumber = 'NY2179' THEN 'NC7777'
				    end,
    CustomerName = case 
						 when CustomerName = 'NY5073' THEN 'Long Island Jewish Hospital'
						 when CustomerName = 'NY5029' THEN 'Wellness Medical Center'
						 when CustomerName = 'NY2179' THEN 'Hope Hospital'
				    end,
    DEA = case 
						 when DEA = 'NY5073' THEN 'XX1234567'
						 when DEA = 'NY5029' THEN 'YY1234567'
						 when DEA = 'NY2179' THEN 'ZZ9876543'
				    end;
			
				    
				   
				   
				   
				   
				   
				   