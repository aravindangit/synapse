select    a12.member_top_parent_key AS member_top_parent_key,       
    max(a15.member_top_parent_info) AS member_top_parent_info,       
    a13.ndc AS ndc,       
    a11.invoice_date AS invoice_date,       
    Sum(case when a11.matrix_status_key in (0,1,2,4,5,6)  then a11.sales_dollars  else 0 end) AS TOTALSPEND,       
    Sum(case when a11.matrix_status_key in (0,1,2,4,5,6)  then a11.qty_ordered  else 0 end) AS QUANTITYORDERED,       
    Sum(case when a11.matrix_status_key in (0,1,2,4,5,6)  then a11.sales_qty  else 0 end) AS TOTALUNITS       
from    fact_bp_sales_detail_view    a11   
    join    member_view    a12
      on     (a11.member_key = a12.member_key)   
    join    product_rpt    a13
      on     (a11.product_key = a13.product_key)   
    join    bus_partner_source    a14
      on     (a11.bp_source_id = a14.bp_source_id)   
    join    member_top_parent_view    a15
      on     (a12.member_top_parent_key = a15.member_top_parent_key)   
where    (a11.month_id in (2021206, 2021205, 2021204, 2021103)       
 and a14.bus_partner_id in (11, 1, 12, 4, 8)           
 and a13.ndc in ('63739059110')           
 and a12.member_status in ('ACTIVE', 'TERMINATED'))           
group by    a12.member_top_parent_key,       
    a13.ndc,       
    a11.invoice_date limit 500001