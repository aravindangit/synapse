DECLARE @ndc VARCHAR(11) = '66741000010';
with CurrentPricing as (
	            select npipc.Ndc
		            ,'WAC' PriceType
		            ,npipc.WacUnitPrice UnitPrice
		            ,npipc.WacPackagePrice PackagePrice
		            ,null HcpcsCode
		            ,null HcpcsDescription
		            ,null PaymentLimit
		            ,null HcpcsCodeDosage
		            ,null PackageSize
		            ,null PackageQuantity
		            ,null BillableUnits
		            ,null BillableUnitsPackage
	            from NationalPharmacyItemPriceCurrent npipc

	            union all

	            select npipc.Ndc
		            ,'AWP' PriceType
		            ,npipc.AwpUnitPrice UnitPrice
		            ,npipc.AwpPackagePrice PackagePrice
		            ,null HcpcsCode
		            ,null HcpcsDescription
		            ,null PaymentLimit
		            ,null HcpcsCodeDosage
		            ,null PackageSize
		            ,null PackageQuantity
		            ,null BillableUnits
		            ,null BillableUnitsPackage
	            from NationalPharmacyItemPriceCurrent npipc

	            union all

	            select npipc.Ndc
		            ,'FUL' PriceType
		            ,npipc.AcaFulUnitPrice UnitPrice
		            ,npipc.AcaFulPackagePrice PackagePrice
		            ,null HcpcsCode
		            ,null HcpcsDescription
		            ,null PaymentLimit
		            ,null HcpcsCodeDosage
		            ,null PackageSize
		            ,null PackageQuantity
		            ,null BillableUnits
		            ,null BillableUnitsPackage
	            from NationalPharmacyItemPriceCurrent npipc

	            union all

	            select npipc.Ndc
		            ,'NADAC' PriceType
		            ,npipc.NadacGenericUnitPrice UnitPrice
		            ,npipc.NadacGenericPackagePrice PackagePrice
		            ,null HcpcsCode
		            ,null HcpcsDescription
		            ,null PaymentLimit
		            ,null HcpcsCodeDosage
		            ,null PackageSize
		            ,null PackageQuantity
		            ,null BillableUnits
		            ,null BillableUnitsPackage
	            from NationalPharmacyItemPriceCurrent npipc

	            union all

	            select npipc.Ndc
		            ,'AMP' PriceType
		            ,npipc.AmpUnitPrice UnitPrice
		            ,npipc.AmpPackagePrice PackagePrice
		            ,null HcpcsCode
		            ,null HcpcsDescription
		            ,null PaymentLimit
		            ,null HcpcsCodeDosage
		            ,null PackageSize
		            ,null PackageQuantity
		            ,null BillableUnits
		            ,null BillableUnitsPackage
	            from NationalPharmacyItemPriceCurrent npipc

	            union all

	            select npipc.Ndc
		            ,'DP' PriceType
		            ,npipc.DpUnitPrice UnitPrice
		            ,npipc.DpPackagePrice PackagePrice
		            ,null HcpcsCode
		            ,null HcpcsDescription
		            ,null PaymentLimit
		            ,null HcpcsCodeDosage
		            ,null PackageSize
		            ,null PackageQuantity
		            ,null BillableUnits
		            ,null BillableUnitsPackage
	            from NationalPharmacyItemPriceCurrent npipc

	            union all

	            select apl.Ndc
		            ,'ASP' PriceType
		            ,apl.AspUnitPrice UnitPrice
		            ,apl.AspUnitPrice * apl.PackageQuantity PackagePrice
		            ,apl.HcpcsCode
		            ,apl.HcpcsDescription
		            ,apl.PaymentLimit
		            ,apl.HcpcsCodeDosage
		            ,apl.PackageSize
		            ,apl.PackageQuantity
		            ,apl.BillableUnitsPerPackage BillableUnits
		            ,apl.BillableUnitsPer11DigitNdc BillableUnitsPackage
	            from AspPriceAndLimits apl
	            where apl.IsCurrentRecords = 1
            )

            select *
            from CurrentPricing cp
            where cp.Ndc = @ndc --Param
	            and (cp.UnitPrice is not null
		            or cp.PackagePrice is not null)
            order by cp.PriceType
	            ,cp.UnitPrice;