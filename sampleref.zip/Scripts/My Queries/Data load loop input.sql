SELECT SyncDataFactoryListId, DataFactoyName, PiplineName, ListName
FROM Masterdata_Sync.SyncControl.SyncDataFactoryList;


SELECT [HealthSystemID],
       [FacilityDirectParentID],
       [Secret],
       [DatasetInvoiceCode],
       [DatasetPoCode]
  FROM [SyncControl].[PremierCustomerSync]
  where [DataFactory] = 'adf-Premier-DataReceive-prod'
      and [Status] = 'A';
     
select * from [SyncControl].[PremierCustomerSync];


SELECT PremierCustomerSyncId, DataFactory, HealthSystemID, FacilityDirectParentID, Secret, DatasetInvoiceCode, DatasetPoCode, Status
FROM Masterdata_Sync.SyncControl.PremierCustomerSync;


SELECT [HealthSystemID],
       [FacilityDirectParentID],
       [Secret],
       [DatasetInvoiceCode],
       [DatasetPoCode]
  FROM [SyncControl].[PremierCustomerSync]
  where [DataFactory] = 'Customer Data Load Loop'
      and [Status] = 'A'
      
      
      
      
      


SELECT [Health System], [Health System ID], [Facility Direct Parent], [Facility Direct Parent ID], [Facility Name], [Facility ID], ImportedDate, [Facility AddrLine1], [Facility AddrLine2], [Facility City], [Facility State], [Facility Zip], [Facility DEA]
FROM CogRxDemo.Raw.PremierCustomerList;


select *
from [Raw].[PremierCustomerList]
where ([Health System ID] = 'NY5011'
    and [Facility Direct Parent ID] = 'NY0024')
    or [Facility ID] = 'NY0024'