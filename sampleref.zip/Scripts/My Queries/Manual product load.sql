select count(*) from public.product where product_key != 0


select * into dbo.productimport from dbo.pharmacyitem p 

select top 100 * from dbo.pharmacyitem p 


drug_id_25
,drug_id_22
,drug_id_19
,drug_id_18


ALTER TABLE dbo.pharmacyitem 
    ADD 
        [drug_id_25] VARCHAR (255) ,
		[drug_id_22] VARCHAR (255) ,
        [drug_id_19] VARCHAR (255) ,
		[drug_id_18] VARCHAR (255);
	
	ALTER TABLE dbo.pharmacyitem add ProductSyncdate datetime NULL;
select * from dbo.pharmacyitem p 

	select top 500 * from pharmacyitem where ndc = '46122005762'
	select *  from dbo.productimport p 
	
	select * from dbo.productimport p 
	
UPDATE  a
	    set  a.[drug_id_25] =  b.[drug_id_25],
		a.[drug_id_22] =  b.[drug_id_22],
        a.[drug_id_19] =  b.[drug_id_19],
		a.[drug_id_18] =  b.[drug_id_18]
		from dbo.pharmacyitem a join productimport b on a.ndc = b.ndc
		
		
		
	    select a.ndc,b.*  
		from dbo.pharmacyitem a join productimport b on a.ndc = b.ndc
		
		
		
		
		

  SET 
      C.OrderCount = O.OrderQuantity
FROM Customers C
     JOIN Orders O ON C.Customerid = O.CustomerID;

	
	


