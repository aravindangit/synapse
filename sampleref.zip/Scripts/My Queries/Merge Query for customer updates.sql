SELECT [Health System], [Health System ID], [Facility Direct Parent], [Facility Direct Parent ID], [Facility Name], [Facility ID], ImportedDate
FROM CogRxDemo.Raw.PremierCustomerList;

CREATE TABLE [dbo].[Locations_testing1](
  [LocationID] [int] NULL,
  [LocationName] [varchar](100) NULL) 
  
  

CREATE TABLE [dbo].[Locations_stage_testing](
  [LocationID] [int] NULL,
  [LocationName] [varchar](100) NULL) 
  
  

INSERT INTO Locations_testing1 values ('kumbakonam',5,'Richmond Road'),('chennai',6,'Brigade Road') ,
('kalpakkam',7,'Houston Street')
INSERT INTO Locations_stage_testing values (1,'Richmond Cross') ,(3,'Houston Street'), (4,'Canal Street')

select * from dbo.locations_testing;
select * from dbo.Locations_stage_testing;

MERGE Locations_testing T
USING Locations_stage_testing S ON T.LocationID=S.LocationID
WHEN MATCHED THEN
UPDATE SET LocationName=S.LocationName
WHEN NOT MATCHED BY TARGET --if the data is not available in the target then insert from source.
THEN 
INSERT (LocationID,LocationName)
VALUES (S.LocationID,S.LocationName)
WHEN NOT MATCHED BY SOURCE 
THEN 
DELETE;

select * from dbo.Locations_testing;



