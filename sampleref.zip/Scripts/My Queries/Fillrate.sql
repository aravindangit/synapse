SELECT  ndc
	, healthsystemid,quantityordered,fillrate
	, MAX(drugid) as gpi10
	, MAX(gpiname) as gpiname
	, MAX(drugstrength) as drugstrength
	, MAX(avgprice) as avgprice
	, count(*) as inc_days
	, SUM(missingdollars) as missingdollars
	, SUM(missingunits) as missingunits
	--, @ReportedDate
FROM [PriceDisruptions].[RawInvoices] With (NoLock)
WHERE  ((quantityordered >= 1 and fillrate <= 0.5 AND fillrate >= 0) OR (quantityordered = 1 AND fillrate = 0))
and gpiname = 'Gabapentin' and Ndc = '63739059110'
GROUP BY ndc  --, inc_days
	, healthsystemid,quantityordered,fillrate