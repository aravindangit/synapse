select ndc.ndc_upc_hri 'ndc',
		fndc.ndc10 'ndc10',
		fndc.ndc11 'ndc11',
		isnull(dnf.drug_name,'') + ' ' + isnull(dnf.strength,'') + isnull(dnf.strength_unit_of_measure,'') + ' ' + isnull(df.DosageFormDescription,'') + ' ' + isnull(ml.MfrName,'') + ' ' + isnull((convert(varchar(10),gppc.package_quantity) + 'X' + convert(varchar(10),Convert(DOUBLE PRECISION,gppc.package_size))),'') + isnull(gppc.[package_size_uom],'') 'ItemDescription',
		isnull(dnf.drug_name,'') + ' ' + isnull(dnf.strength,'') + isnull(dnf.strength_unit_of_measure,'') + ' ' + isnull(df.DosageFormAbbreviation,'') + ' ' + isnull(ml.MfrName,'') + ' ' + isnull((convert(varchar(10),gppc.package_quantity) + 'X' + convert(varchar(10),Convert(DOUBLE PRECISION,gppc.package_size))),'') + isnull(gppc.[package_size_uom],'') 'ItemShortDescription',
		ndc.id_number_format_code 'NdcFormatCode',
		ndc.old_ndc_upc_hri 'PreviousNdc',
		ndc.new_ndc_upc_hri 'ReplacedByNdc',
		gppc.package_quantity 'CasePack',
		gppc.package_size 'PackageSize',
		wkpd.PackageDescription 'PackageDescription',
		dnf.strength 'DrugStrength',
		dnf.strength_unit_of_measure 'DrugStrengthUom',
		dnf.drug_name 'DrugName',
		ing.[Ingredients] 'Ingredients',
		CASE dnf.brand_name_code WHEN 'B' THEN 1 WHEN 'G' THEN 1 ELSE 0 END AS 'IsGenericDrug',
		CASE dnf.multi_source_code WHEN 'O' THEN 1 WHEN 'Y' THEN 1 ELSE 0 END AS 'IsItemMultiSourced',
		CASE ndc.repackaged_code WHEN 'X' THEN 1 ELSE 0 END AS 'IsItemRepackaged',
		wksc.StorageConditionId 'StorageConditionId',
		ud.UnitDoseId 'UnitDoseId',
		psu.[PackageSizeUomId] 'PackageSizeUomId',
		df.DosageFormId 'DosageFormId',
		wkbnt.[BrandNameTypeId] 'BrandNameTypeId',
		ml.[NdcLabelerNum] 'LabelerId',
		ml.MfrId 'mfrId',
		obc.OrangeBookId 'OrangeBookId',
		dcc.DeaClassId 'DeaClassId',
		gppc.generic_product_identifier 'GPI',
		CASE WHEN dnf.multi_source_code in ('M','N') and dnf.brand_name_code in ('T') THEN 'Trademarked Products'
			WHEN dnf.multi_source_code in ('O') and dnf.brand_name_code in ('T') THEN 'Trademarked Products'
			WHEN dnf.multi_source_code in ('O') and dnf.brand_name_code in ('B','G') THEN 'Branded Generic or Generic Products Based on End-User Requirements'
			WHEN dnf.multi_source_code in ('Y') and dnf.brand_name_code in ('T') THEN 'Trademarked or Generic Products Based on End-User Requirements'
			WHEN dnf.multi_source_code in ('Y') and dnf.brand_name_code in ('B','G') THEN 'Branded Generic or Generic Products'
			WHEN dnf.multi_source_code in ('M','N') and dnf.brand_name_code in ('G') THEN 'Generic Products'
			WHEN dnf.multi_source_code in ('M','N') and dnf.brand_name_code in ('B') THEN 'Branded Generic Products'
			ELSE 'Unknown'
		END 'TypeOfBrandDesciption',
		dnf.drug_descriptor_id 'DrugDescriptorId',
		bec.BioEquivalenceId 'BioEquivalenceId',
		@iDataSource 'DataSourceId',
		left(gppc.generic_product_identifier, 10) 'GPIDrugNameCode',
		tcgpi.tcgpi_name 'GpiDrugName'
	from [rawWK].[mf2ndc_NdcFile] ndc
	left join [rawWK].[mf2ndc_FormattedNdc] fndc
		on ndc.ndc_upc_hri = fndc.ndc_upc_hri
	left join rawWK.mf2gppc_GppcFile gppc
		on ndc.generic_product_pack_code = gppc.generic_product_pack_code
	left join [WoltersKluwer].[PackageDescription] wkpd
		on gppc.package_description_code = wkpd.PackageDescriptionCode
	left join [rawWK].[mf2name_DrugNameFile] dnf
		on ndc.drug_descriptor_id = dnf.drug_descriptor_id
	left join [WoltersKluwer].[BrandNameTypes] wkbnt
		on dnf.brand_name_code = wkbnt.[BrandNameTypeCode]
	left join [dbo].[ManufacturerLabeler] ml
		on ndc.medispan_labeler_id = ml.MedispanLabelerId
	left join [dbo].[OrangeBook] obc
		on ndc.tee_code = obc.[OrangeBookCode]
	left join [WoltersKluwer].[DosageForm] df
		on dnf.Dosage_Form = df.[DosageFormCode]
	left join [WoltersKluwer].[DeaClassCode] dcc
		on ndc.dea_class_code = dcc.[DeaClassId]
	left join [rawWK].[mf2_NdcIngredients] ing
		on ndc.ndc_upc_hri = ing.ndcupchri
	LEFT JOIN [WoltersKluwer].[StorageCondition] wksc
		on ndc.storage_condition_code = wksc.StorageConditionCode
	left join [WoltersKluwer].[UnitDose] ud
		on gppc.unit_dose_unit_use_pkg_code = ud.UnitDoseCode
	left join [WoltersKluwer].[PackageSizeUom] psu
		on gppc.[package_size_uom] = psu.[PackageSizeUomCode]
	left join [WoltersKluwer].[BioEquivalenceCode] bec
		on dnf.[bioequivalence_code] = bec.[BioEquivalenceCode]
	left join [rawWK].[mf2tcgpi_TcGpiNameFile] tcgpi
		on left(gppc.generic_product_identifier, 10) = tcgpi.tcgpi_id
	WHERE ndc = '63739059110'