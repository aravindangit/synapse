SELECT State, StateCode, Region, Division
FROM sqldbCogRxProdCommonSpirit.MasterData.USCensusRegions;


select count(*) from raw.PremierCustomerList pcl2 where 
select * from raw.PremierCustomerList pcl where pcl.[Facility Name] in 
('CENTER FOR PEDIATRIC SURGERY',
'MASH URGENT CARE',
'SOUTHEASTERN NEPHROLOGY',
'THE MENKES SURGERY CENTER',
'SAINT JOSEPH HEALTH SYSTEM - ORTHO ASSOCIATES',
'SAINT JOSEPH HEALTH SYSTEM - SLEEP LAB',
'P V I MANAGEMENT, LLC')

select * from raw.PremierCustomerList pcl2 ;
select * from raw.PremierCustomerList pcl where [Facility AddrLine1] is Null;

select * from dbo.Customer c where c.AddrLine1 is Null;

select distinct fm.ClientId 'clientid', 
					pcl.[Facility ID] 'AccountNumber', 
					pcl.[Facility Name] 'CustomerName', 
					pcl.[Facility AddrLine1] 'Address1', 
					pcl.[Facility AddrLine2] 'Address2', 
 					pcl.[Facility City]      'City',
					pcl.[Facility State]     'State', 
					pcl.[Facility Zip]       'Zip',
					co.CustomerOrganizationId 'CustomerOrganizationId', 
					--pcl.[Facility Direct Parent ID] 'OrganizationNumber', 
					--pcl.[Facility Direct Parent] 'OrganizationName',

--updating top parent to org name & ID
					case when fm.ClientImportCode='NY5011' then pcl.[Facility Direct Parent ID] else pcl.[Health System ID] end 'OrganizationNumber',
					case when fm.ClientImportCode='NY5011' then pcl.[Facility Direct Parent] else pcl.[Health System] end 'OrganizationName'
					from [Raw].[PremierCustomerList] pcl
						inner join [dbo].[ImportFileIDMapping] fm
							on pcl.[Health System ID] = fm.ClientImportCode
						inner join CustomerOrganization co
							on pcl.[Facility Direct Parent ID] = co.[OrganizationNumber]