[Raw].[PremierCustomerList]

select * from premier.WholesalerInvoices wi 

select count(*) from raw.PremierCustomerList pcl 

select count(*) from [Premier].[WholesalerInvoices]