DECLARE @CLIENTID INT = 6, @sortColumn VARCHAR(50)='NDC', @sortDirection VARCHAR(5)='asc', 
@pageNumber INT=0, @pageSize int = 1000

drop table #shortages



       SELECT distinct sw.ShortageWatchId,
           pi.Ndc,
           pi.ItemDescription,
                    pi.Manufacturer, 
           sw.ProbabilityPercentage,
swpt.Description [ProbabilityDescription],
                    sw.ProbabilityChange,
                    sw.IsNew,
           sw.PeriodStartDate,
           sw.PeriodEndDate,
                    sw.IsActive,
           CASE WHEN cds.CustomerDrugShortageId IS NOT NULL THEN 1 ELSE 0 END AS IsManaged
   , CASE pi.IsGenericDrug WHEN 0 THEN 'Brand' ELSE 'Generic' END IsGeneric
, st.Days30Qty, st.Days30QtyOrdered
, swr.Sources
, cds.CustomerDrugShortageId
, CASE
WHEN CHARINDEX('Unknown - ', cm.CustomerName) > 0 THEN cm.CustomerName 
ELSE cm.CustomerName + ' - ' + cm.AccountNumber 
END AS Facility
            INTO #shortages
       FROM Watch.ShortageWatch sw
LEFT OUTER JOIN (
SELECT swr.ShortageWatchId
, swr.IsActive
, replace(string_agg((swrt.Description),', ') WITHIN GROUP (ORDER BY swrt.Description ASC), ' Shortage','') as Sources
FROM Watch.ShortageWatchReason AS swr
left join watch.ShortageWatchReasonType swrt on swrt.ShortageWatchReasonTypeId=swr.ShortageWatchReasonTypeId
GROUP BY swr.ShortageWatchId, swr.IsActive) AS swr ON sw.ShortageWatchId = swr.ShortageWatchId AND swr.IsActive = 1
LEFT OUTER JOIN (
SELECT st.ClientId
, st.Ndc
, st.ItemId
, sum(st.[30DayUsageQty]) as Days30Qty, sum(st.[30DayQtyOrdered]) as Days30QtyOrdered
FROM SalesTotals AS st 
WHERE st.ClientId = @clientId
GROUP BY st.Ndc, st.ItemId, st.ClientId) AS st ON st.Ndc = sw.Ndc AND st.ClientId = sw.ClientId
JOIN Watch.ShortageWatchProbabilityRange swpr ON sw.ClientId = swpr.ClientId
JOIN Watch.ShortageWatchProbabilityType swpt ON swpr.ShortageWatchProbabilityTypeId = swpt.ShortageWatchProbabilityTypeId
       JOIN dbo.PharmacyItem pi ON sw.ItemId = pi.ItemId 
LEFT OUTER JOIN CustomerDrugShortage AS cds ON cds.Ndc = pi.Ndc AND cds.ShortageStatusId = 1
                LEFT OUTER JOIN dbo.CustomerItemPricing AS cip ON cip.ItemId = pi.ItemId
LEFT OUTER JOIN dbo.Customer AS cm ON cm.CustomerId = cip.CustomerId
       WHERE sw.ClientId = @clientId
       AND sw.IsActive = 1
AND sw.ProbabilityPercentage > swpr.ProbabilityLow AND sw.ProbabilityPercentage <= swpr.ProbabilityHigh
       and not exists (select 1 from dbo.CustomerDrugShortage cds where cds.Ndc = pi.Ndc and cds.ShortageStatusId = 1 and cds.ClientId = @clientId)
       

            ;with filteredResults as (
                SELECT s.ShortageWatchId
           , s.Ndc
           , s.ItemDescription
           , s.ProbabilityPercentage
, s.ProbabilityDescription
                    , s.ProbabilityChange
                    , s.IsNew
           , s.PeriodStartDate
           , s.PeriodEndDate
                    , s.IsActive
           , s.IsManaged
, s.IsGeneric
, s.Days30Qty, s.Days30QtyOrdered
, s.Sources
, s.CustomerDrugShortageId
, s.Facility
                FROM #shortages AS s
                WHERE 1 = 1
AND (s.Days30Qty <> 0)
                 

            )

            SELECT s.ShortageWatchId,
              s.Ndc,
              s.ItemDescription,
              s.ProbabilityPercentage,
  s.ProbabilityDescription,
                   s.ProbabilityChange,
                   s.IsNew,
              s.PeriodStartDate,
              s.PeriodEndDate,
                   s.IsActive,
                   s.IsManaged,
  s.IsGeneric,
  s.Days30Qty as QtyPurchased, s.Days30QtyOrdered as QtyOrdered, CASE WHEN s.Days30QtyOrdered <> 0 THEN  CAST(((CAST(s.Days30Qty AS DECIMAL(10,0)) / CAST(s.Days30QtyOrdered  AS DECIMAL(10,0))) * 100) AS DECIMAL(10,0)) ELSE s.Days30QtyOrdered end AS FillRate,
  s.Sources,
  s.CustomerDrugShortageId,
              sc.TotalCount SearchResultCount,
  s.Facility AS Facility  
  
            FROM filteredResults s
           JOIN (select count(1) TotalCount from filteredResults) sc on 1=1
            ORDER BY
                CASE WHEN @sortColumn = 'IsNew' and @sortDirection = 'asc' THEN s.IsNew end,
           CASE WHEN @sortColumn = 'IsNew' and @sortDirection = 'desc' THEN s.IsNew end desc,
           CASE WHEN @sortColumn = 'Ndc' and @sortDirection = 'asc' THEN s.Ndc end,
           CASE WHEN @sortColumn = 'Ndc' and @sortDirection = 'desc' THEN s.Ndc end desc,
           CASE WHEN @sortColumn = 'ItemDescription' and @sortDirection = 'asc' THEN s.ItemDescription end,
           CASE WHEN @sortColumn = 'ItemDescription' and @sortDirection = 'desc' THEN s.ItemDescription end desc,
           CASE WHEN @sortColumn = 'ProbabilityPercentage' and @sortDirection = 'asc' THEN s.ProbabilityPercentage end,
           CASE WHEN @sortColumn = 'ProbabilityPercentage' and @sortDirection = 'desc' THEN s.ProbabilityPercentage end desc,
                CASE WHEN @sortColumn = 'ProbabilityChange' and @sortDirection = 'asc' THEN s.ProbabilityChange end,
           CASE WHEN @sortColumn = 'ProbabilityChange' and @sortDirection = 'desc' THEN s.ProbabilityChange end desc,
           CASE WHEN @sortColumn = 'PeriodStartDate' and @sortDirection = 'asc' THEN s.PeriodStartDate end,
           CASE WHEN @sortColumn = 'PeriodStartDate' and @sortDirection = 'desc' THEN s.PeriodStartDate end desc,
           CASE WHEN @sortColumn = 'PeriodEndDate' and @sortDirection = 'asc' THEN s.PeriodEndDate end,
           CASE WHEN @sortColumn = 'PeriodEndDate' and @sortDirection = 'desc' THEN s.PeriodEndDate end desc,
           CASE WHEN @sortColumn = 'IsGeneric' and @sortDirection = 'asc' THEN s.IsGeneric end,
           CASE WHEN @sortColumn = 'IsGeneric' and @sortDirection = 'desc' THEN s.IsGeneric end desc,
           CASE WHEN @sortColumn = 'Days30Qty' and @sortDirection = 'asc' THEN s.Days30Qty end, CASE WHEN @sortColumn = 'Days30Qty' and @sortDirection = 'desc' THEN s.Days30Qty end desc,
           CASE WHEN @sortColumn = 'Sources' and @sortDirection = 'asc' THEN s.Sources end,
           CASE WHEN @sortColumn = 'Sources' and @sortDirection = 'desc' THEN s.Sources end desc
            OFFSET @pageNumber * @pageSize rows
            FETCH NEXT @pageSize rows only;



            SELECT Distinct s.Sources
               -- , Manufacturer
                , s.ProbabilityDescription
                , s.Facility
            FROM #shortages AS s
            INNER JOIN Watch.ShortageWatchReason AS swr ON s.ShortageWatchId = swr.ShortageWatchId
            INNER JOIN Watch.ShortageWatchReasonType AS swrt ON swr.ShortageWatchReasonTypeId = swrt.ShortageWatchReasonTypeId
            INNER JOIN Watch.ShortageWatch sw ON s.ShortageWatchId = sw.ShortageWatchId
   INNER JOIN PharmacyItem pi ON sw.ItemId = pi.ItemId
--WHERE s.Facility = 'NUHEALTH - 602097'
