SELECT CustomerId, CustomerUId, ClientId, DataSourceId, AccountNumber, CustomerOrganizationId, OrganizationNumber, OrganizationName, CustomerName, PriceList, AddrLine1, AddrLine2, City, State, Zip, ParentCustomerId, CotId, CustomImportCode, GlDept, Status, DateImported, DateChanged, CustomerPatientCareAreaId, CustomerBusinessTypeId, CustomerPurchaseTypeId, CustomerSpecialtyTypeId, CustomerRegionId, DeaLicenseNum, DeaLicenseExpiration, StateLicenseNum, StateLicenseExpiration, HinNum, GlnNum, [340bId], [340bType], HierarchyNum, HierarchyName, CustomerHrsaNumber, BusinessType, PatientCareArea, ClassOfTrade, BockingData, Notes, SysStartTime, SysEndTime
FROM CogRxDemo.dbo.Customer;

update dbo.Customer 
 set AddrLine1 = NULL ,
     AddrLine2 = NULL ,
     City = NULL ,
     State  = NULL ,
     Zip = NULL 
     WHERE SysStartTime = '2021-06-02 16:19:44'

 
 select COUNT(*) from dbo.customer where AddrLine1 IS NULL ;