





-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [DailyMaintinance].[RebuildSalesTotal]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;


declare @today Date = getdate();
declare @Past30 Date = dateadd(day,-30, @today)
declare @Past60 Date = dateadd(day,-60, @today)
declare @Past90 Date = dateadd(day,-90, @today)
declare @Past6Months Date = dateadd(month,-6, @today)
declare @Past1Year Date = dateadd(Year,-1, @today)
declare @Past2Year Date = dateadd(Year,-2, @today)


--build 30Day
select clientid, CustomerId, ndc, PriceTypeGroupId, Max(itemid) itemid, sum(qty) '30DayUsageQty', sum(qty * unitprice) '30DayUsageExtPrice', 
sum(QtyOrdered) '30DayQtyOrdered',
count(*) '30DayUsageTransactionCount', @Past30 '30DayAsOfDate'
	   from sales
	   where transactiondate >= @Past30
	     and [RepackagedFlag] = 0
	   group by clientid, CustomerId, ndc, PriceTypeGroupId) AS source


--Build 60Day
MERGE [dbo].[SalesTotals] AS target
USING (select clientid, CustomerId, ndc, PriceTypeGroupId, Max(itemid) itemid, sum(qty) '60DayUsageQty', sum(qty * unitprice) '60DayUsageExtPrice',
sum(QtyOrdered) '60DayQtyOrdered',
count(*) '60DayUsageTransactionCount', @Past60 '60DayAsOfDate'
	   from sales
	   where transactiondate >= @Past60
	     and [RepackagedFlag] = 0
	   group by clientid, CustomerId, ndc, PriceTypeGroupId) AS source
ON (target.clientid = source.clientid and
    target.CustomerId = source.CustomerId and
	target.ndc = source.ndc and
	target.PriceTypeGroupId = source.PriceTypeGroupId)
WHEN MATCHED THEN
    UPDATE SET itemid = source.itemid,
			   [60DayUsageQty] = source.[60DayUsageQty], 
	           [60DayUsageExtPrice] = source.[60DayUsageExtPrice],
			   [60DayQtyOrdered] = source.[60DayQtyOrdered],
			   [60DayUsageTransactionCount] = source.[60DayUsageTransactionCount],
			   [60DayAsOfDate] = source.[60DayAsOfDate],
			   [UpdatedDate] = getutcdate()
WHEN NOT MATCHED THEN
    INSERT (clientid, CustomerId, itemid, ndc, PriceTypeGroupId, [60DayUsageQty], [60DayUsageExtPrice], [60DayQtyOrdered], [60DayUsageTransactionCount], [60DayAsOfDate])
    VALUES (source.clientid, source.CustomerId, source.itemid, source.ndc, source.PriceTypeGroupId, source.[60DayUsageQty], source.[60DayUsageExtPrice], source.[60DayQtyOrdered], source.[60DayUsageTransactionCount], source.[60DayAsOfDate])
WHEN NOT MATCHED BY source THEN
	UPDATE SET
			target.[60DayUsageQty] = 0,
			target.[60DayUsageExtPrice] = 0,
			target.[60DayQtyOrdered]=0,
			target.[60DayUsageTransactionCount] = 0,
			target.[60DayAsOfDate] = @Past60;


--Build 90 day
MERGE [dbo].[SalesTotals] AS target
USING (select clientid, CustomerId, ndc, PriceTypeGroupId, Max(itemid) itemid, sum(qty) '90DayUsageQty', sum(qty * unitprice) '90DayUsageExtPrice',
sum(QtyOrdered) '90DayQtyOrdered',
count(*) '90DayUsageTransactionCount', @Past90 '90DayAsOfDate'
	   from sales
	   where transactiondate >= @Past90
	     and [RepackagedFlag] = 0
	   group by clientid, CustomerId, ndc, PriceTypeGroupId) AS source
ON (target.clientid = source.clientid and
    target.CustomerId = source.CustomerId and
	target.ndc = source.ndc and
	target.PriceTypeGroupId = source.PriceTypeGroupId)
WHEN MATCHED THEN
    UPDATE SET itemid = source.itemid,
			   [90DayUsageQty] = source.[90DayUsageQty], 
	           [90DayUsageExtPrice] = source.[90DayUsageExtPrice],
			   [90DayQtyOrdered] = source.[90DayQtyOrdered],
			   [90DayUsageTransactionCount] = source.[90DayUsageTransactionCount],
			   [90DayAsOfDate] = source.[90DayAsOfDate],
			   [UpdatedDate] = getutcdate()
WHEN NOT MATCHED THEN
    INSERT (clientid, CustomerId, itemid, ndc, PriceTypeGroupId, [90DayUsageQty], [90DayUsageExtPrice], [90DayQtyOrdered], [90DayUsageTransactionCount], [90DayAsOfDate])
    VALUES (source.clientid, source.CustomerId, source.itemid, source.ndc, source.PriceTypeGroupId, source.[90DayUsageQty], source.[90DayUsageExtPrice], source.[90DayQtyOrdered], source.[90DayUsageTransactionCount], source.[90DayAsOfDate])
WHEN NOT MATCHED BY source THEN
	UPDATE SET
			target.[90DayUsageQty] = 0,
			target.[90DayUsageExtPrice] = 0,
			target.[90DayQtyOrdered] = 0,
			target.[90DayUsageTransactionCount] = 0,
			target.[90DayAsOfDate] = @Past90;


--Build 6Month
MERGE [dbo].[SalesTotals] AS target
USING (select clientid, CustomerId, ndc, PriceTypeGroupId, Max(itemid) itemid, sum(qty) '6MonthUsageQty', sum(qty * unitprice) '6MonthUsageExtPrice',
sum(QtyOrdered) '6MonthQtyOrdered',
count(*) '6MonthUsageTransactionCount',  @Past6Months '6MonthAsOfDate'
	   from sales
	   where transactiondate >= @Past6Months
	     and [RepackagedFlag] = 0
	   group by clientid, CustomerId, ndc, PriceTypeGroupId) AS source
ON (target.clientid = source.clientid and
    target.CustomerId = source.CustomerId and
	target.ndc = source.ndc and
	target.PriceTypeGroupId = source.PriceTypeGroupId)
WHEN MATCHED THEN
    UPDATE SET itemid = source.itemid,
			   [6MonthUsageQty] = source.[6MonthUsageQty], 
			   [6MonthUsageExtPrice] = source.[6MonthUsageExtPrice],
			   [6MonthQtyOrdered] = source.[6MonthQtyOrdered],
			   [6MonthUsageTransactionCount] = source.[6MonthUsageTransactionCount],
			   [6MonthAsOfDate] = source.[6MonthAsOfDate],
			   [UpdatedDate] = getutcdate()
WHEN NOT MATCHED THEN
    INSERT (clientid, CustomerId, itemid, ndc, PriceTypeGroupId, [6MonthUsageQty], [6MonthUsageExtPrice], [6MonthQtyOrdered], [6MonthUsageTransactionCount], [6MonthAsOfDate])
    VALUES (source.clientid, source.CustomerId, source.itemid, source.ndc, source.PriceTypeGroupId, source.[6MonthUsageQty], source.[6MonthUsageExtPrice], source.[6MonthQtyOrdered], source.[6MonthUsageTransactionCount], source.[6MonthAsOfDate])
WHEN NOT MATCHED BY source THEN
	UPDATE SET
			target.[6MonthUsageQty] = 0,
			target.[6MonthUsageExtPrice] = 0,
			target.[6MonthQtyOrdered] = 0,
			target.[6MonthUsageTransactionCount] = 0,
			target.[6MonthAsOfDate] =  @Past6Months;


--Build 1 year
MERGE [dbo].[SalesTotals] AS target
USING (select clientid, CustomerId, ndc, PriceTypeGroupId, Max(itemid) itemid, sum(qty) '1YearUsageQty', sum(qty * unitprice) '1YearUsageExtPrice',
sum(QtyOrdered) '1YearQtyOrdered',
count(*) '1YearUsageTransactionCount',  @Past1Year '1YearAsOfDate'
	   from sales
	   where transactiondate >= @Past1Year
	     and [RepackagedFlag] = 0
	   group by clientid, CustomerId, ndc, PriceTypeGroupId) AS source
ON (target.clientid = source.clientid and
    target.CustomerId = source.CustomerId and
	target.ndc = source.ndc and
	target.PriceTypeGroupId = source.PriceTypeGroupId)
WHEN MATCHED THEN
    UPDATE SET itemid = source.itemid,
			   [1YearUsageQty] = source.[1YearUsageQty], 
			   [1YearUsageExtPrice] = source.[1YearUsageExtPrice],
			   [1YearQtyOrdered] = source.[1YearQtyOrdered],
			   [1YearUsageTransactionCount] = source.[1YearUsageTransactionCount],
			   [1YearAsOfDate] = source.[1YearAsOfDate],
			   [UpdatedDate] = getutcdate()
WHEN NOT MATCHED THEN
    INSERT (clientid, CustomerId, itemid, ndc, PriceTypeGroupId, [1YearUsageQty], [1YearUsageExtPrice], [1YearQtyOrdered], [1YearUsageTransactionCount], [1YearAsOfDate])
    VALUES (source.clientid, source.CustomerId, source.itemid, source.ndc, source.PriceTypeGroupId, source.[1YearUsageQty], source.[1YearUsageExtPrice], source.[1YearQtyOrdered], source.[1YearUsageTransactionCount], source.[1YearAsOfDate])
WHEN NOT MATCHED BY source THEN
	UPDATE SET
			target.[1YearUsageQty] = 0,
			target.[1YearUsageExtPrice] = 0,
			target.[1YearQtyOrdered] = 0,
			target.[1YearUsageTransactionCount] = 0,
			target.[1YearAsOfDate] =  @Past1Year;


--Build 2 Year
		
declare @today Date = getdate();
declare @Past30 Date = dateadd(day,-30, @today)
declare @Past60 Date = dateadd(day,-60, @today)
declare @Past90 Date = dateadd(day,-90, @today)
declare @Past6Months Date = dateadd(month,-6, @today)
declare @Past1Year Date = dateadd(Year,-1, @today)
declare @Past2Year Date = dateadd(Year,-2, @today)

--solution
SQL ISNULL function
May 10, 2019 by Rajendra Gupta
ApexSQL pricing
This article explores the SQL ISNULL function to replace NULL values in expressions or table records with examples.

Introduction
We define the following parameters while designing a table in SQL Server

Data types for a particular column
Allow NULL or Not Null values in SQL Server
1
2
3
4
5
6
CREATE TABLE table_name
( 
  column1 datatype [ NULL],
  column2 datatype [NOT NULL ],
  ...
);
If we do not provide any value for column allow NULL values, SQL Server assumes NULL as default value.

1
2
3
4
5
CREATE TABLE Employee
(EmployeeID     INT IDENTITY(1, 1) NOT NULL, 
 EmployeeName   VARCHAR(50) NOT NULL, 
 EmployeeSalary INT NULL
);
Let�s insert a few records in the Employee table.

1
2
3
4
5
6
7
8
9
10
INSERT INTO Employee
(EmployeeName, 
 EmployeeSalary
)
VALUES
('Rajendra', 
 55645
);
INSERT INTO Employee(EmployeeName)
VALUES('Rajendra');
View the records in the table, and we can see a NULL value against EmployeeID 2 because we did not insert any value for this column.


We might have a requirement to replace NULL values with a particular value while viewing the records. We do not want to update values in the table. We can do this using SQL ISNULL Function. Let�s explore this in the upcoming section.

SQL Server ISNULL Function overview
We can replace NULL values with a specific value using the SQL Server ISNULL Function. The syntax for the SQL ISNULL function is as follow.

SQL Server ISNULL (expression, replacement)

Expression: In this parameter, we specify the expression in which we need to check NULL values
Replacement: We want to replace the NULL with a specific value. We need to specify replacement value here
The SQL Server ISNULL function returns the replacement value if the first parameter expression evaluates to NULL. SQL Server converts the data type of replacement to data type of expression. Let�s explore SQL ISNULL with examples.

Example 1: SQL Server ISNULL function in an argument
In this example, SQL ISNULL function returns the second argument value because the first argument is NULL:


SELECT ISNULL(NULL, 100) result;
SQL ISNULL function in an argument
In the following examples, we can see the following.

If the first argument is NULL, it returns the value of the second argument.
If the first argument is NOT NULL, it returns the first argument value as output.
1

  SELECT ISNULL(NULL, 'SQLServer') result;
  SELECT ISNULL('SQLShack', 'SQLServer') result;
SQL ISNULL function
Example 2: SQL Server ISNULL to replace a value in existing column values
At the beginning of this article, we created the Employee table and inserted NULL values in it. We can use SQL ISNULL to replace existing NULL values with a specific value.

For example, we want to return Employee salary 10,000 if it is NULL in the Employee table. In the following query, we used SQL ISNULL function to replace the value.


  SELECT Employeeid, 
     ISNULL(EmployeeSalary, 10000) EmployeeSalary
  FROM Employee;
replace a value in existing column values
Let�s update the NULL value in the Employee table using the following update statement.

Update Employee set EmployeeSalary =65656 where EmployeeID =2
We do not have any NULL value in the table now; therefore if we run the query with SQL Server ISNULL, it returns actual values of the rows.

replace a value in existing column values
Example 3: SQL Server ISNULL with aggregate functions
We can use SQL ISNULL with aggregate functions such as SUM, AVG as well. Suppose we want to perform sum of EmployeeSalary present in Employee table. If EmployeeSalary is NULL, it should be replaced with 10000 before adding the salaries.

Before we move, update the EmployeeSalary as NULL for EmployeeID 2 using the following query.

Update Employee set EmployeeSalary =NULL where EmployeeID =2
In the following query, we replaced the NULL value with value 10000 first and then performed SUM on it. You can visualize it with the following screenshot.

SELECT SUM(ISNULL(EmployeeSalary, 10000))
FROM Employee;

select clientid, CustomerId, ndc, PriceTypeGroupId, Max(itemid) itemid, sum(qty) '2YearUsageQty', sum(qty * unitprice) '2YearUsageExtPrice',
sum(QtyOrdered) '2YearQtyOrdered',
count(*) '2YearUsageTransactionCount',  @Past2Year '2YearAsOfDate'
	   from sales
	   where transactiondate >= @Past2Year
	     and [RepackagedFlag] = 0
	   group by clientid, CustomerId, ndc, PriceTypeGroupId



--Build totals for all time
MERGE [dbo].[SalesTotals] AS target
USING (select clientid, CustomerId,ndc, PriceTypeGroupId, Max(itemid) itemid, sum(qty) 'TotalDayUsageQty', sum(qty * unitprice) 'TotalDayUsageExtPrice',
sum(QtyOrdered) 'TotalDayQtyOrdered',
count(*) 'TotalDayUsageTransactionCount', cast(min(transactiondate) as date) 'EarliestAsOfDate'
	   from sales
	   where [RepackagedFlag] = 0
	   group by clientid, CustomerId, ndc, PriceTypeGroupId) AS source
ON (target.clientid = source.clientid and
    target.CustomerId = source.CustomerId and
	target.ndc = source.ndc and
	target.PriceTypeGroupId = source.PriceTypeGroupId)
WHEN MATCHED THEN
    UPDATE SET itemid = source.itemid,
			   TotalDayUsageQty = source.TotalDayUsageQty, 
	           TotalDayUsageExtPrice = source.TotalDayUsageExtPrice,
			   TotalDayQtyOrdered = source.TotalDayQtyOrdered,
			   TotalDayUsageTransactionCount = source.TotalDayUsageTransactionCount,
			   EarliestAsOfDate = source.EarliestAsOfDate,
			   [UpdatedDate] = getutcdate()
WHEN NOT MATCHED THEN
    INSERT (clientid, CustomerId, itemid, ndc, PriceTypeGroupId, TotalDayUsageQty, TotalDayUsageExtPrice, TotalDayQtyOrdered, TotalDayUsageTransactionCount, EarliestAsOfDate)
    VALUES (source.clientid,  source.CustomerId, source.itemid, source.ndc, source.PriceTypeGroupId, source.TotalDayUsageQty, source.TotalDayUsageExtPrice, source.TotalDayQtyOrdered, source.TotalDayUsageTransactionCount, source.EarliestAsOfDate);
--ending

update [dbo].[SalesTotals]
	set [30DayAsOfDate] = @Past30
where [30DayAsOfDate] is null


update [dbo].[SalesTotals]
	set [60DayAsOfDate] = @Past60
where [60DayAsOfDate] is null


update [dbo].[SalesTotals]
	set [90DayAsOfDate] = @Past90
where [90DayAsOfDate] is null


update [dbo].[SalesTotals]
	set [6MonthAsOfDate] = @Past6Months
where [6MonthAsOfDate] is null


update [dbo].[SalesTotals]
	set [1YearAsOfDate] = @Past1Year
where [1YearAsOfDate] is null

--start
/*update [dbo].[SalesTotals]
	set [2YearAsOfDate] = @Past2Year
where [2YearAsOfDate] is null*/

--end

END
