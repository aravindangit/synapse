
---------------------------------------
select * from [dbo].[ImportFileIDMapping];
--------------------------------------
declare @today Date = getdate();
declare @Past30 Date = dateadd(day,-30, @today)
declare @Past60 Date = dateadd(day,-60, @today)
declare @Past90 Date = dateadd(day,-90, @today)
declare @Past6Months Date = dateadd(month,-6, @today)
declare @Past1Year Date = dateadd(Year,-1, @today)
declare @Past2Year Date = dateadd(Year,-2, @today)
select @Past30

 
select
	sum([90DayUsageExtPrice])
from
	(
	select
		clientid,
		CustomerId,
		ndc,
		PriceTypeGroupId,
		Max(itemid) itemid,
		sum(qty) '90DayUsageQty',
		sum(qty * unitprice) '90DayUsageExtPrice',
		sum(QtyOrdered) '90DayQtyOrdered',
		count(*) '90DayUsageTransactionCount',
		@Past90 '90DayAsOfDate'
	from
		sales
	where
		transactiondate >= @Past30
		and [RepackagedFlag] = 0
		and itemid in (
		select
			distinct itemid
		from
			PharmacyItem
		where
			MfrId = 971)
	group by
		clientid,
		CustomerId,
		ndc,
		PriceTypeGroupId) a


-----------------------------------------------------------------------------------
SELECT ClientId, CustomerId, SupplierId, ItemId, SupplierName, TransactionDate, Ndc, ItemDescription, OrderNumber, LineNumber, OrderType, Qty, UnitCost, UnitPrice, UOM, InvoiceNumber, WholesalerAccountNumber, WholesalerCBID, CostofDistribution, Address1, Address2, City, State, ZipCode, ImportedDate, SalesId, PriceTypeGroupId, DataSourceId, QuarterDate, ProcessPipelineId, RepackagedFlag, QtyOrdered
FROM sqldbCogRxProdStLukes.dbo.Sales;




declare @today Date = getdate();
declare @Past30 Date = dateadd(day,-30, @today)
declare @Past60 Date = dateadd(day,-60, @today)
declare @Past90 Date = dateadd(day,-90, @today)
declare @Past6Months Date = dateadd(month,-6, @today)
declare @Past1Year Date = dateadd(Year,-1, @today)
declare @Past2Year Date = dateadd(Year,-2, @today)

 

select @Past30

 
select MfrId ,MfrName,MfrShortName from Manufacturer m 
where MfrName in ('JANSSEN BIOTECH','AMGEN','GENENTECH','ABBVIE');

select clientid, CustomerId, ndc, PriceTypeGroupId, Max(itemid) itemid, sum(qty) '90DayUsageQty', sum(qty * unitprice) '90DayUsageExtPrice',
sum(QtyOrdered) '90DayQtyOrdered',
count(*) '90DayUsageTransactionCount', @Past90 '90DayAsOfDate'
       from sales
       where transactiondate >= @Past30
         and [RepackagedFlag] = 0
         and itemid in (select distinct itemid from PharmacyItem where MfrId=971)
       group by clientid, CustomerId, ndc, PriceTypeGroupId
       
execute dbo.FnAnalysis;


--------


CREATE PROCEDURE dbo.FnAnalysis
AS 


declare @today Date = getdate();
declare @Past30 Date = dateadd(day,-30, @today)
declare @Past60 Date = dateadd(day,-60, @today)
declare @Past90 Date = dateadd(day,-91, @today)
declare @Past6Months Date = dateadd(month,-6, @today)
declare @Past1Year Date = dateadd(Year,-1, @today)
declare @Past2Year Date = dateadd(Year,-2, @today)

 

select @Past30

 

--select sum([90DayUsageExtPrice]) from (
select clientid, 
		CustomerId, 
		ndc, 
		PriceTypeGroupId, 
		Max(itemid) itemid, 
		sum(qty) '90DayUsageQty', 
		sum(qty * unitprice) '90DayUsageExtPrice',
		sum(QtyOrdered) '90DayQtyOrdered',
		count(*) '90DayUsageTransactionCount'
	--	@Past90 '90DayAsOfDate'
       from dbo.sales
       where (transactiondate >= '2021-04-01' and transactiondate <='2021-06-30')
         and [RepackagedFlag] = 0
         and itemid in (select distinct itemid from PharmacyItem where MfrId=971)
       group by clientid, CustomerId, ndc, PriceTypeGroupId--) a
       
       
       --MfrId=971


select distinct itemid from PharmacyItem where MfrId=971
|MfrId|MfrName        |MfrShortName|
|-----|---------------|------------|
|14   |ABBVIE         |ABBVIE      |
|718  |GENENTECH      |GENENTECH   |
|924  |AMGEN          |AMGEN       |
|971  |JANSSEN BIOTECH|JANSSEN BI  |

-- Local Temporary Stored Procedure
CREATE PROC ##cogrxspend(@mfid int)
AS
BEGIN 
--select sum([90DayUsageExtPrice]) from (
select clientid, 
		CustomerId, 
		ndc, 
		PriceTypeGroupId, 
		Max(itemid) itemid, 
		sum(qty) '90DayUsageQty', 
		sum(qty * unitprice) '90DayUsageExtPrice',
		sum(QtyOrdered) '90DayQtyOrdered',
		count(*) '90DayUsageTransactionCount'
	--	@Past90 '90DayAsOfDate'
       from dbo.sales
       where (transactiondate >= '2021-01-01' and transactiondate <='2021-03-30')
         and [RepackagedFlag] = 0
         and itemid in (select distinct itemid from PharmacyItem where MfrId=@mfid)
       group by clientid, CustomerId, ndc, PriceTypeGroupId--) a
       
       --MfrId=971	, 924
END

Exec ##cogrxspend 971;
--------------------------------------
--key details - 
--where    (a12.man_dist = 'JANSSEN BIOTECH' and a12.ndc = '57894019506')
--where    (a12.ndc = '57894019506')
--quarter date in sales table - QuarterDate
--	 [UnitCost],
	 [UnitPrice],QuarterDate
--wholesaler invoices are loaded with the wholesale date and is the source for dbo.sales table.
--table details:
--[Premier].[WholesalerInvoices]  ==>>
|HealthSystemID|FacilityDirectParentID|Secret                      |DatasetInvoiceCode     |DatasetPoCode     |
|--------------|----------------------|----------------------------|-----------------------|------------------|
|CO5012        |                      |Secret-CogRX-DB-CommonSpirit|PremierWholesaleInvoice|PremierWholesalePO|
|PA0023        |                      |Secret-CogRX-DB-stluke      |PremierWholesaleInvoice|PremierWholesalePO|
|NY5011        |NY0024                |Secret-CogRX-DB-northwell   |PremierWholesaleInvoice|PremierWholesalePO|
|MN2013        |                      |Secret-CogRX-DB-Fairview    |PremierWholesaleInvoice|PremierWholesalePO|
|743692        |                      |Secret-CogRX-DB-upmc        |PremierWholesaleInvoice|PremierWholesalePO|

--sales table Impact
adf   -->  CognitiveRx-Daily-Processes


select * from premier.WholesalerInvoices wi 

select * from premier.WholesalerInvoices wi 
--key fields
TotalSpend
QuantityOrdered
AddedDate
Supplier
NDC
InvoiceDate
HealthSystemID
sum(TotalSpend)

select distinct itemid from PharmacyItem where MfrId=971

select sum(TotalSpend) from premier.WholesalerInvoices With (NoLock)
	where NDC = '57894019506' and HealthSystemID = 'PA0023'
    and (InvoiceDate >= '2021-01-01' and InvoiceDate <='2021-03-31') ;
