SELECT Ingredient, [DF;Route], Trade_Name, Applicant, Strength, Appl_Type, Appl_No, Product_No, TE_Code, Approval_Date, RLD, RS, [Type], Applicant_Full_Name, ImportedDate
FROM sqldbCogRxProdItemMaster.RawFda.OrangeBookProducts;


select count(*) from sqldbCogRxProdItemMaster.RawFda.OrangeBookProducts;

select * from dbo.orangebook

OrangeBookId	
OrangeBookCode	
OrangeBookShortDescription	
OrangeBookDescription	
OrangeBookEquivalenceTypeId