SELECT CustomerItemPriceId, ClientId, CpSupplierID, ItemId, PriceAmount, PriceStartDate, PriceEndDate, PriceStatusId, CustomerContractId, CustomerId, PriceListId, DataSourceId, DateAdded, DateChanged, Status, NDC, RiskKey, PricingKey, ReportedDate, PriceChangeDate, OldPrice, PercentageChange, DistributorAccountNo, Description
FROM sqldbCogRxProdFairview.dbo.CustomerItemPricing;

select count(*) from dbo.Sales s 



 CREATE NONCLUSTERED INDEX Ix_salestotals_clientid_1yearusage_performance ON dbo.SalesTotals (  ClientId ASC  , [1YearUsageQty] ASC  )  
	 WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
	 ON [PRIMARY ] ;
	 
	 
 CREATE NONCLUSTERED INDEX ix_CustomerItemPricing_client_NDC_performance ON dbo.CustomerItemPricing (  ClientId ASC  , NDC ASC  )  
	 INCLUDE ( CpSupplierID , CustomerId , PriceAmount , PriceListId ) 
	 WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
	 ON [PRIMARY ] ;
	 
	select * from Predictive.NationalPricePrediction npp where npp.IsActive = 1