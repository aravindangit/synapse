select
	a11.member_key as member_key,
	max(a13.member_identity) as member_identity,
	a11.month_id as month_id,
	max(a14.month_desc) as month_desc,
	a12.bus_partner_id as bus_partner_id,
	max(a12.bus_partner_desc) as bus_partner_desc,
	a11.whsl_acct_att as whsl_acct_att,
	Sum(
	case
	when a11.matrix_status_key in (0, 1, 2, 4, 5, 6)�then a11.sales_dollars�
	else 0
    end) as TOTALSPEND
from fact_bp_sales_detail_view a11
join bus_partner_source a12 on (a11.bp_source_id = a12.bp_source_id)
join member_view a13 on (a11.member_key = a13.member_key)
join trans_current_month_37_view a14 on (a11.month_id = a14.month_id)
where (a11.month_id in (2021103, 2021102, 2021101)�and a11.member_key in (310452)
�and a12.bus_partner_id in (11, 740, 4, 8, 12, 1)�
 and a13.member_status in ('ACTIVE', 'TERMINATED'))
group by
	a11.member_key,
	a11.month_id,
	a12.bus_partner_id,
	a11.whsl_acct_att