
declare @clientId as int = 4
declare @customerId as int = 41
DECLARE @from date = '01-01-2021'  --mmddyyyy
DECLARE @to date = '03-31-2021';


            with 
            utilization as (
            declare @clientId  int = 4
			declare @customerId  int = 41
	            select pi.Ndc
                        ,pi.ItemDescription as 'Description'
                        ,s.CustomerId
			            ,s.TransactionDate
			            ,s.Qty
			            ,s.UnitCost
			            ,s.UnitCost * Qty as 'TotalCost'
			            into #loadtemp1  
		            from PharmacyItem pi 
                        join Sales s on s.ItemId = pi.ItemId
			            join Customer c on s.CustomerId = c.CustomerId and s.ClientId = c.ClientId
		            where s.ClientId = @clientId -- Param
			            and c.CustomerId = @customerId and c.ClientId = s.ClientId -- Param
			            
            ),
            utilizationTotals as (
	            select sum(case when u.TransactionDate > dateadd(dd, -30, getdate()) then u.Qty else 0 end) Usage30
		            ,sum(case when u.TransactionDate > dateadd(dd, -60, getdate()) then u.Qty else 0 end) Usage60
		            ,sum(case when u.TransactionDate > dateadd(dd, -90, getdate()) then u.Qty else 0 end) Usage90
		            ,sum(case when u.TransactionDate > dateadd(dd, -30, getdate()) then u.TotalCost else 0 end) Cost30
		            ,sum(case when u.TransactionDate > dateadd(dd, -60, getdate()) then u.TotalCost else 0 end) Cost60
		            ,sum(case when u.TransactionDate > dateadd(dd, -90, getdate()) then u.TotalCost else 0 end) Cost90
		            ,sum(u.Qty) TotalUsage
		            ,sum(u.UnitCost) TotalUnitCost
		            ,sum(u.TotalCost) TotalTotalCost
	            from #loadtemp1 u --utilization u
            ),
            utilizationDetail as (
	            select tu.Ndc
						,tu.Description
                        ,tu.CustomerId			            
			            ,tu.TransactionDate
			            ,tu.Qty
			            ,tu.UnitCost
			            ,tu.UnitCost * Qty as 'TotalCost'
		            from utilization tu
		            where tu.TransactionDate >= @from
			            and tu.TransactionDate < dateadd(day, 1, @to)
            )

            select 
                s.Ndc
                ,s.Description
                ,s.CustomerId	            
	            ,s.TransactionDate
	            ,s.Qty
                ,s.UnitCost
                ,s.TotalCost
	            ,totals.TotalCount as SearchResultCount
                ,totals.SearchResultTotalUnitCost
	            ,totals.SearchResultTotalCost
	            ,totals.SearchResultTotalQty
	            ,totalUsage.Usage30 AS SearchResultUsage30
	            ,totalUsage.Usage60 AS SearchResultUsage60
	            ,totalUsage.Usage90 AS SearchResultUsage90
	            ,totalUsage.Cost30 AS SearchResultCost30
	            ,totalUsage.Cost60 AS SearchResultCost60
	            ,totalUsage.Cost90 AS SearchResultCost90
	            ,totalUsage.TotalUsage
	            ,totalUsage.TotalUnitCost
	            ,totalUsage.TotalTotalCost
            from utilizationDetail s
	            join (select count(1) as TotalCount
                            ,sum(u.UnitCost) as SearchResultTotalUnitCost
				            ,sum(u.TotalCost) as SearchResultTotalCost
				            ,sum(u.Qty) as SearchResultTotalQty
			            from utilizationDetail u) totals on 1 = 1
	            join (select ut.Usage30
			            ,ut.Usage60
			            ,ut.Usage90
			            ,ut.Cost30
			            ,ut.Cost60
			            ,ut.Cost90
			            ,ut.TotalUsage
			            ,ut.TotalUnitCost
			            ,ut.TotalTotalCost
		              from utilizationTotals ut) totalUsage on 1 = 1
            /*order by
	            case when @sortColumn = 'Ndc' and @sortDirection = 'asc' then s.Ndc end,
	            case when @sortColumn = 'Ndc' and @sortDirection = 'desc' then s.Ndc end desc,
	            case when @sortColumn = 'Description' and @sortDirection = 'asc' then s.Description end,
	            case when @sortColumn = 'Description' and @sortDirection = 'desc' then s.Description end desc,
	            case when @sortColumn = 'TransactionDate' and @sortDirection = 'asc' then s.TransactionDate end,
	            case when @sortColumn = 'TransactionDate' and @sortDirection = 'desc' then s.TransactionDate end desc,
	            case when @sortColumn = 'Qty' and @sortDirection = 'asc' then s.Qty end,
	            case when @sortColumn = 'Qty' and @sortDirection = 'desc' then s.Qty end desc,
	            case when @sortColumn = 'UnitCost' and @sortDirection = 'asc' then s.UnitCost end,
	            case when @sortColumn = 'UnitCost' and @sortDirection = 'desc' then s.UnitCost end desc,
				case when @sortColumn = 'TotalCost' and @sortDirection = 'asc' then s.TotalCost end,
	            case when @sortColumn = 'TotalCost' and @sortDirection = 'desc' then s.TotalCost end desc
            offset @pageNumber * @pageSize rows --Param
            fetch next @pageSize rows only*/
		              
		    --          select * from dbo.customer where customername like '%lenox%'
		              
		              
		              
		              
		              
select * from fact_bp_sales_detail_view limit 10;
select * from trans_current_month_37_view limit 10
--invoice_date
select a11.member_key AS member_key, max(a13.member_identity) AS member_identity, a11.month_id AS month_id, max(a14.month_desc) AS month_desc, a12.bus_partner_id AS bus_partner_id, max(a12.bus_partner_desc) AS bus_partner_desc, a11.whsl_acct_att AS whsl_acct_att, Sum(case when a11.matrix_status_key in (0,1,2,4,5,6)  then a11.sales_dollars  else 0 end) AS TOTALSPEN
from
fact_bp_sales_detail_view a11 join bus_partner_source a12   on
(a11.bp_source_id = a12.bp_source_id) join member_view a13   on
(a11.member_key = a13.member_key) join trans_current_month_37_view a14   on
(a11.month_id = a14.month_id) where
(a11.month_id in
(2021103, 2021102, 2021101) and a11.member_key in
(310452) and a12.bus_partner_id in
(11, 740, 4, 8, 12, 1) and a13.member_status in
('ACTIVE', 'TERMINATED'))group by a11.member_key, a11.month_id, a12.bus_partner_id, a11.whsl_acct_att limit 500001



select a11.member_key AS member_key,
       max(a13.member_identity) AS member_identity,
       a15.man_dist AS man_dist,
  --     a15.ndc as ndc,
       a11.invoice_date as invoicedate,
       a11.month_id AS month_id,
       max(a14.month_desc) AS month_desc,
       a12.bus_partner_id AS bus_partner_id,
       max(a12.bus_partner_desc) AS bus_partner_desc,
       a11.whsl_acct_att AS whsl_acct_att,
       Sum(case
               when a11.matrix_status_key in (0,1,2,4,5,6) then a11.sales_dollars
               else 0
           end) AS TOTALSPEND
from fact_bp_sales_detail_view a11
join product_rpt        a15 on (a11.product_key = a15.product_key)
join bus_partner_source a12 on (a11.bp_source_id = a12.bp_source_id)
join member_view a13 on (a11.member_key = a13.member_key)
join trans_current_month_37_view a14 on (a11.month_id = a14.month_id)
where (a11.month_id in (2021103,
                        2021102,
                        2021101)
       and a11.member_key in (310452)
       and a12.bus_partner_id in (11,
                                  740,
                                  4,
	                                  8,
                                  12,
                                  1)
       and a13.member_status in ('ACTIVE',
                                 'TERMINATED'))
group by a11.member_key,
         a11.month_id,
         a12.bus_partner_id,
         a11.whsl_acct_att,
         a11.invoice_date,
         a15.man_dist
      --   a15.ndc
limit 500001





select * from #loadtemp1

select * from dbo.sales where TransactionDate >= '01/01/2021' and TransactionDate <= '03/31/2021'

select top 10 * from   PharmacyItem pi where ndc = '85251921601'

select * from sales where ndc = '85251921601' AND TransactionDate = '01/29/2021'

select count(*) from sales

select count(*) from dbo.sales

select count(*) from raw.sales


select TransactionDate ,ClientId ,CustomerId,sum(UnitCost * Qty) from dbo.sales where TransactionDate >= '01/01/2021' and TransactionDate <= '03/31/2021'
and ItemId is NULL group by TransactionDate,ClientId,CustomerId with ROLLUP 



select * from premier.WholesalerInvoices wi where ndc = '60338201350'

select count(*) from premier.WholesalerInvoices wi  

select count(*) from premier.WholesalerInvoices wi where ItemId is NULL 

select * from PharmacyItem pi2 

select count(*) from raw.Sales s 

select count(*) from raw.sales where 




select ifm.[ClientId],
	   c.[CustomerId],
	   su.SupplierId SupplierId,
	   su.SupplierName SupplierName,
	   pi.ItemId,
       s.[TransactionDate],
       s.[Ndc],
       s.[ItemDescription],
       s.[OrderNumber],
       s.[LineNumber],
       s.[OrderType],
       s.[Qty],
	   s.[QtyOrdered],
      s.[UnitCost],
       s.[UnitPrice],
       s.[UOM],
       s.[InvoiceNumber],
	   s.[WholesalerAccountNumber],
	   s.[ChargeBackContractNumber],
	   s.[Markup/Markdown],
	   ptx.[PriceTypeGroupId],
	   s.[Address1],
	   s.[Address2],
	   s.[City],
	   s.[State],
	   s.[ZipCode],
	   format(ca.FirstDateOfQuarter,'yyyyMMdd') QuarterDate,
       s.[ImportedDate],
	   ifm.[DataSourceId],
	   s.[ProcessPipelineId],
	   case when s.OrderType in ('CPAK Return', 'DOD Order', 'DOD Return', 'Order CPAK') then 1 else 0 end RepackagedFlag
from [Raw].[Sales] s
  inner join [dbo].[ImportFileIDMapping] ifm
     on s.[DataSource] = ifm.[ClientImportCode]
  inner join [dbo].[Customer] c
     on s.[Account] = c.[AccountNumber]
	and ifm.ClientId = c.ClientId
  left join [dbo].[PharmacyItem] pi
     on s.ndc = pi.Ndc
  inner join Calendar ca
     on ifm.[ClientId] = ca.ClientId
	and s.TransactionDate = ca.CalendarDate
  left join Mapping.[PriceTypeGroupXref] ptx
	on c.ClientId = ptx.clientid
	and s.WholesalerAccountAttribute = ptx.[ClientPriceTypeCode]		
  left join supplier su
	on s.Wholesaler = su.SupplierName
where su.SupplierTypeId= 2 and su.MfrId is null and  s.DataSource = 'PremierWholesaleInvoice'
and s.ndc 
select * from ItemMaster where ItemCode in ('00264975606',
'60338201350',
'85251921601',
'60338210300',
'60338210380',
'85251850055',
'85412003462',
'53329008986',
'60338210380',
'85251850055',
'85815000002',
'17191005105',
'17191008101',
'17191008103',
'17191008110',
'60338210300',
'85251850055',
'85412003462',
'85251850055',
'85251850260',
'00264975506',
'60338210420',
'73852009652',
'17191008101',
'17191008103',
'17191008110',
'17191008120',
'85251850055',
'07061021608',
'60338210380',
'85251850055',
'60338210380',
'85412003462',
'60338210300',
'60338210380',
'85251850055',
'53329008986',
'60338210300',
'60338210380',
'85251850055',
'17191008101',
'17191008103',
'17191008110',
'85251850055',
'85251850260',
'70610177041',
'85251850000',
'85412046162',
'17191008101',
'17191008103',
'17191008120',
'60338210190',
'60338210300',
'60338210380',
'85251850055',
'85251850130',
'60338210300',
'60338210380',
'00264975506',
'17191005104',
'17191008101',
'17191008103',
'17191008110',
'85412003462',
'47270030021',
'60338210380',
'85815000002',
'99005030135',
'60338210420',
'85251850260',
'17191008101',
'17191008103',
'60338210300',
'60338210380',
'85251850055',
'00264975506',
'85412035265',
'85412046162',
'17191008110',
'37000003201',
'53329008986',
'60338210380',
'85251850055',
'85251850055',
'17191008101',
'85251850260',
'17191008103',
'85251850055',
'60338210380',
'85251850055',
'85412003462',
'17191008101',
'17191008120',
'85251850055',
'00264975606',
'85412000508',
'85412000508',
'00264975506',
'60338210300',
'60338210380',
'73852009652',
'85251850055',
'17191008110',
'85251850055',
'60338210380',
'17191008101',
'60338210420',
'85251850260',
'17191008101',
'17191008103',
'60338210380',
'85251850055',
'53329008986',
'85251850055',
'85251850055',
'85412003462',
'17191008103',
'60338210380',
'85251850055',
'85412003462',
'47270030021',
'60338210300',
'60338210380',
'60338210420',
'85251850086',
'85251850260',
'85815000002',
'17191008101',
'17191008103',
'17191008120',
'17191008505',
'85251850055',
'37000003201',
'60338210190',
'60338210300',
'60338210380',
'60338210300',
'60338210380',
'85251850055',
'17191008101',
'17191008103',
'85251850055',
'85251506921',
'00264975506',
'17191042701',
'60338210380',
'85251850055',
'85412003462',
'85251850055',
'08021456006')


select * from app.BuyInExclusion bie 


select * from dbo.Customer 

select top 10 *  from ItemMaster im where ItemCode in  ('08021456006','00131181067')

select top 10 * from ItemMaster im order by DateAdded DESC 