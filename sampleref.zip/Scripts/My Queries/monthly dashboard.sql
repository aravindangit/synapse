DECLARE @clientId INT = 1
    , @name VARCHAR(50) = 'Top Notch Health System'
    , @CURMONTH INT = 6;
    --drop table #SPENDBYMONTHLY;
    ;

WITH R (N)
AS (
    SELECT 1
    
    UNION ALL
    
    SELECT N + 1
    FROM R
    WHERE N < 12
    )
    , PSTM
AS (
    SELECT N
        , UPPER(LEFT(DateName(month, DateAdd(month, R.N, - 1)), 3)) AS MONTH
        , CASE 
            WHEN R.N < @CURMONTH
                THEN SUM(STM.ExtendedPrice)
            ELSE NULL
            END AS PCOST
        , CASE 
            WHEN R.N < @CURMONTH
                THEN SUM(STM.QtyReceived)
            ELSE NULL
            END AS PUNITS
    FROM R
    LEFT JOIN SalesTotalMonthly STM
        ON R.N = STM.DateMonth
            AND STM.DateYear IN (YEAR(GETDATE()) - 1)
            AND ClientId = @clientId
    GROUP BY N
        --ORDER BY N
    )
    , CSTM
AS (
    SELECT N
        , UPPER(LEFT(DateName(month, DateAdd(month, R.N, - 1)), 3)) AS MONTH
        , CASE 
            WHEN R.N < @CURMONTH
                THEN SUM(STM.ExtendedPrice)
            ELSE NULL
            END AS CCOST
        , CASE 
            WHEN R.N < @CURMONTH
                THEN SUM(STM.QtyReceived)
            ELSE NULL
            END AS CUNITS
    FROM R
    LEFT JOIN SalesTotalMonthly STM
        ON R.N = STM.DateMonth
            AND STM.DateYear IN (YEAR(GETDATE()))
            AND ClientId = @clientId
    GROUP BY N
    )
SELECT P.N
    , P.[MONTH] AS TransactionMonth
    , CASE 
        WHEN CCOST > 0
            THEN CCOST
        ELSE NULL
        END AS CCOST
    , CASE 
        WHEN CUNITS > 0
            THEN CUNITS
        ELSE NULL
        END AS CUNITS
    , YEAR(GETDATE()) AS CDATEYEAR
    , CASE 
        WHEN PCOST > 0
            THEN PCOST
        ELSE NULL
        END AS PCOST
    , CASE 
        WHEN PUNITS > 0
            THEN PUNITS
        ELSE NULL
        END AS PUNITS
    , YEAR(GETDATE()) - 1 AS PDATEYEAR
    , CASE 
        WHEN PCOST > 0
            THEN CAST((CCOST - PCOST) AS FLOAT) / CAST(PCOST AS FLOAT) * 100 * 100 / 100.00
        ELSE 0.00
        END CCHANGE
    , CASE 
        WHEN PUNITS > 0
            THEN CAST((CUNITS - PUNITS) AS FLOAT) / cast(PUNITS AS FLOAT) * 100 * 100 / 100.00
        ELSE 0
        END UCHANGE
INTO #SPENDBYMONTHLY
FROM PSTM P
JOIN CSTM C
    ON P.N = C.N
ORDER BY P.N;

SELECT O.N AS ID
    , *
INTO #SPENDBYYEARLY1
FROM (
    SELECT *
    FROM #SPENDBYMONTHLY
    
    UNION ALL
    
    SELECT 13 AS N
        , 'SUMMARY' AS TRANSACTIONMONTH
        , SUM(T.CCOST) AS CCOST
        , SUM(T.CUNITS) AS CUNITS
        , MAX(T.CDATEYEAR) AS CDATEYEAR
        , SUM(T.PCOST) AS PCOST
        , SUM(T.PUNITS) AS PUNITS
        , MAX(T.PDATEYEAR) AS PDATEYEAR
        , SUM(T.CCHANGE) CCHANGE
        , SUM(T.UCHANGE) UCHANGE
    FROM #SPENDBYMONTHLY T
    ) O
ORDER BY O.N;;

WITH R (N)
AS (
    SELECT 1
    
    UNION ALL
    
    SELECT N + 1
    FROM R
    WHERE N < 12
    )
    , PSTM
AS (
    SELECT N
        , UPPER(LEFT(DateName(month, DateAdd(month, R.N, - 1)), 3)) AS MONTH
        , SUM(STM.ExtendedPrice) AS PCOST
        , SUM(STM.QtyReceived) AS PUNITS
    FROM R
    LEFT JOIN SalesTotalMonthly STM
        ON R.N = STM.DateMonth
            AND STM.DateYear IN (YEAR(GETDATE()) - 2)
            AND ClientId = @clientId
    GROUP BY N
    )
    , CSTM
AS (
    SELECT N
        , UPPER(LEFT(DateName(month, DateAdd(month, R.N, - 1)), 3)) AS MONTH
        , SUM(STM.ExtendedPrice) AS CCOST
        , SUM(STM.QtyReceived) AS CUNITS
    FROM R
    LEFT JOIN SalesTotalMonthly STM
        ON R.N = STM.DateMonth
            AND STM.DateYear IN (YEAR(GETDATE()) - 1)
            AND ClientId = @clientId
    GROUP BY N
    )
SELECT P.N
    , P.[MONTH] AS TransactionMonth
    , CASE 
        WHEN CCOST > 0
            THEN CCOST
        ELSE NULL
        END AS CCOST
    , CASE 
        WHEN CUNITS > 0
            THEN CUNITS
        ELSE NULL
        END AS CUNITS
    , YEAR(GETDATE()) - 1 AS CDATEYEAR
    , CASE 
        WHEN PCOST > 0
            THEN PCOST
        ELSE NULL
        END AS PCOST
    , CASE 
        WHEN PUNITS > 0
            THEN PUNITS
        ELSE NULL
        END AS PUNITS
    , YEAR(GETDATE()) - 2 AS PDATEYEAR
    , CASE 
        WHEN PCOST > 0
            THEN CAST((CCOST - PCOST) AS FLOAT) / CAST(PCOST AS FLOAT) * 100 * 100 / 100.00
        ELSE 0.00
        END CCHANGE
    , CASE 
        WHEN PUNITS > 0
            THEN CAST((CUNITS - PUNITS) AS FLOAT) / cast(PUNITS AS FLOAT) * 100 * 100 / 100.00
        ELSE 0
        END UCHANGE
INTO #SPENDBYMONTHLY1
FROM PSTM P
JOIN CSTM C
    ON P.N = C.N
ORDER BY P.N;

SELECT O.N + 13 AS ID
    , *
INTO #SPENDBYYEARLY2
FROM (
    SELECT *
    FROM #SPENDBYMONTHLY1
    
    UNION ALL
    
    SELECT 13 AS N
        , 'SUMMARY' AS TRANSACTIONMONTH
        , SUM(T.CCOST) AS CCOST
        , SUM(T.CUNITS) AS CUNITS
        , MAX(T.CDATEYEAR) AS CDATEYEAR
        , SUM(T.PCOST) AS PCOST
        , SUM(T.PUNITS) AS PUNITS
        , MAX(T.PDATEYEAR) AS PDATEYEAR
        , SUM(T.CCHANGE) CCHANGE
        , SUM(T.UCHANGE) UCHANGE
    FROM #SPENDBYMONTHLY1 T
    ) O
ORDER BY O.N;

SELECT *
FROM (
    SELECT *
    FROM #SPENDBYYEARLY1
    
    UNION ALL
    
    SELECT *
    FROM #SPENDBYYEARLY2
    ) T
ORDER BY 1;
