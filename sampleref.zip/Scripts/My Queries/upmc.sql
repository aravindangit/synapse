--SET NOCOUNT ON;


Drop table if exists #tbl;

declare @iRwCnt int; --RowCount
declare @i int = 1; --iterator
declare @CategorySourceId  int = 5;

declare @SourceRecordId int
declare @Ndc varchar(11)
declare @itemid int
declare @ProbablilityPercentage float
declare @PeriodStartDate datetime
declare @PeriodEndDate datetime
declare @IsActive bit
declare @IsNew bit
declare @ProbabilityChange int
declare @CreatedDate datetime
declare @ReasonTypeId int;

declare @WatchId int

declare @AddDate datetime = getdate();
declare @StartDate datetime = DATEADD(dd, DATEDIFF(dd, 0, getdate()), 0);

declare @MaxFoundDate datetime = (select Max(CreatedDate) from [Watch].[NationalShortageWatch] nsw inner join [Watch].[NationalShortageWatchReason] nswr on nsw.NationalShortageWatchId = nswr.NationalShortageWatchId inner join [Watch].[ShortageWatchReasonType] swrt on swrt.ShortageWatchReasonTypeId = nswr.ShortageWatchReasonTypeId where swrt.CategorySourceId = @CategorySourceId)
declare @MaxCategoryFound int


create table #tbl(ID int Identity(1,1), 
				  SourceRecordId int,
                  Ndc varchar(11), 
				  itemid int, 
                  ProbablilityPercentage float, 
				  PeriodStartDate datetime, 
				  PeriodEndDate datetime, 
				  IsActive bit, 
				  IsNew bit, 
				  ProbabilityChange int, 
				  CreatedDate datetime,
				  ReasonTypeId int);

 if @CategorySourceId  = 5 --price disruption signals
	begin
		insert into #tbl
		(SourceRecordId, Ndc, itemid, ProbablilityPercentage, PeriodStartDate, PeriodEndDate, IsActive, IsNew, ProbabilityChange, CreatedDate,ReasonTypeId)
		select 0 'SourceRecordId'
            , r.ndc 'Ndc'
            , pi.Itemid 'ItemId'
            , .5 'ProbablilityPercentage'
            , @StartDate 'PeriodStartDate'
            , dateadd(d, 60, @StartDate) 'PeriodEndDate'
            , 1 IsActive
            , 1 IsNew
            , 0 ProbabilityChange
            , @AddDate 'CreatedDate'
            , 11 ReasonTypeId
        from NationalPriceDisruptions.ResultsNdc r
            join dbo.PharmacyItem pi on pi.Ndc = r.Ndc
            join NationalPriceDisruptions.ResultsGpi gpi on gpi.Gpi10 = r.Gpi10
        where gpi.HasShortage = 0
	end;


set @iRwCnt = @@ROWCOUNT; --SCOPE_IDENTITY() would also WORK
SELECT 'Total records:'+@iRwCnt

create clustered index idx_tmp on #tbl(ID) WITH FILLFACTOR = 100;


--begin loop
while @i <= @iRwCnt
SELECT 'below while:'+@i
--SELECT @iRwCnt
begin

	select @SourceRecordId = SourceRecordId,
		   @Ndc = Ndc,
		   @itemid = itemid,
		   @ProbablilityPercentage = ProbablilityPercentage,
		   @PeriodStartDate = PeriodStartDate,
		   @PeriodEndDate = PeriodEndDate,
		   @IsActive = IsActive,
		   @IsNew = IsNew,
		   @ProbabilityChange = ProbabilityChange,
		   @CreatedDate = CreatedDate,
		   @ReasonTypeId = ReasonTypeId
	from #tbl where ID = @i;

	begin tran
	
	if not exists (select * from [Watch].[NationalShortageWatch] with (updlock, rowlock, holdlock) where [NDC] = @Ndc)
		BEGIN
			select 'not exist'
		
			insert into [Watch].[NationalShortageWatch]
				([NDC],[ItemId],[ProbabilityPercentage],[PeriodStartDate],[PeriodEndDate],[IsActive],[IsNew],[ProbabilityChange],[CreatedDate] )
			VALUES
				(@Ndc,@itemid,@ProbablilityPercentage,@PeriodStartDate,@PeriodEndDate,@IsActive,@IsNew,@ProbabilityChange,@CreatedDate);

			--record is new, so grab the id that was just created
			set @WatchId = @@IDENTITY;

			insert into [Watch].[NationalShortageWatchReason]
				([NationalShortageWatchId], [ShortageWatchReasonTypeId],[SourceKey],[PeriodStartDate],[PeriodEndDate],[IsActive],temp)
			VALUES
				(@WatchId,@ReasonTypeId,@SourceRecordId,@PeriodStartDate,@PeriodEndDate,@IsActive,1)

		end 
	else
		begin
            SELECT 'exist'
			--look for the lowest category source id
			set @MaxCategoryFound = (select min(swrt.[CategorySourceId]) from [Watch].[NationalShortageWatch] nsw inner join [Watch].[NationalShortageWatchReason] nswr  with (updlock, rowlock, holdlock) on nsw.NationalShortageWatchId = nswr.NationalShortageWatchId inner join [Watch].[ShortageWatchReasonType] swrt on nswr.ShortageWatchReasonTypeId = swrt.ShortageWatchReasonTypeId where [NDC] = @Ndc)

				--get watchid
			set @WatchId = (select [NationalShortageWatchId] from [Watch].[NationalShortageWatch] with (updlock, rowlock, holdlock) where [NDC] = @Ndc)
					
			if @CategorySourceId <= @MaxCategoryFound
				BEGIN
					SELECT 'maxcategoryfound1:'+@MaxCategoryFound
				
					--up expirations date upped with any code, but only a lower category wi update the percentage.
					update [Watch].[NationalShortageWatch]
						set 
							[ProbabilityPercentage] = @ProbablilityPercentage,
							[PeriodEndDate] = @PeriodEndDate
					where [NationalShortageWatchId] = @WatchId 
				end
			else 
				BEGIN
					SELECT 'maxcategoryfound2:'+@MaxCategoryFound
					--up expirations date upped with any code.
					update [Watch].[NationalShortageWatch]
						set 
							[PeriodEndDate] = @PeriodEndDate
					where [NationalShortageWatchId] = @WatchId 
				end


			MERGE [Watch].NationalShortageWatchReason AS tar
			  USING (select @WatchId 'NationalShortageWatchId',
			                @ReasonTypeId 'ShortageWatchReasonTypeId',
							@SourceRecordId 'SourceKey',
							@PeriodStartDate 'PeriodStartDate',
							@PeriodEndDate 'PeriodEndDate',
							@IsActive 'IsActive') AS src
				ON tar.NationalShortageWatchId = src.NationalShortageWatchId
				and tar.ShortageWatchReasonTypeId = src.ShortageWatchReasonTypeId
			  WHEN MATCHED 
				  AND (tar.SourceKey != src.SourceKey
   						or (src.SourceKey is null and tar.SourceKey is not null)
						or (src.SourceKey is not null and tar.SourceKey is null)
						or tar.PeriodStartDate != src.PeriodStartDate
   						or (src.PeriodStartDate is null and tar.PeriodStartDate is not null)
						or (src.PeriodStartDate is not null and tar.PeriodStartDate is null)
						or tar.PeriodEndDate != src.PeriodEndDate
   						or (src.PeriodEndDate is null and tar.PeriodEndDate is not null)
						or (src.PeriodEndDate is not null and tar.PeriodEndDate is null)
						or tar.IsActive != src.IsActive
   						or (src.IsActive is null and tar.IsActive is not null)
						or (src.IsActive is not null and tar.IsActive is null)) then
						   --or tar.IsActive = 0) THEN
				  UPDATE SET  tar.SourceKey = src.SourceKey,
							  tar.PeriodStartDate = src.PeriodStartDate,
							  tar.PeriodEndDate = src.PeriodEndDate,
							  tar.IsActive = src.IsActive,
							  tar.DateChanged = getdate()
			  WHEN NOT MATCHED THEN
				  INSERT ([NationalShortageWatchId], [ShortageWatchReasonTypeId],[SourceKey],[PeriodStartDate],[PeriodEndDate],[IsActive],temp)
				  VALUES (src.NationalShortageWatchId, src.ShortageWatchReasonTypeId,src.SourceKey, src.[PeriodStartDate], src.[PeriodEndDate], src.[IsActive], '2');
			
		end

	commit tran

	set @i = @i + 1;
end
