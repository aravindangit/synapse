DECLARE @CLIENTID INT = 6, @sortColumn VARCHAR(50)='NDC', @sortDirection VARCHAR(5)='asc',
@pageNumber INT=0, @pageSize int = 10, @ndc VARCHAR(11) = '73796027854'

DECLARE @filterToClientCatalog BIT,
                @filterTohas340bPrice BIT,
                @filterToInventory  BIT,
                @filterToChannels BIT,
                @filterToClientActive BIT,
                @filterToClientInactive BIT,
                @filterToShortage BIT

--DROP TABLE #searchResults
            select distinct a.NDC FROM
            (select 
                 pie.ItemId
		        ,pie.ItemDescription
		        ,pie.Ndc
		        ,pie.Ndc11
		        ,pie.Manufacturer
		        ,po.LastTimePurchased
                ,CAST(pie.CasePack as varchar(7)) as 'CasePack'
		        ,case when pis.ShortageCount > 0 then 1 else 0 end OnShortage
		        ,cii.QuantityOnHand OnHand
		        ,st.Usage90
		        ,cip340b.Price340b
		        ,cip.MaxPrice
		        ,cip.MinPrice
		        ,cip.ChannelCount
    --        into #searchResults
	        from PharmacyItem pi
		        --join PharmacyItem pie on pie.TherapeuticEqKey = pi.TherapeuticEqKey
		        join PharmacyItem pie on pi.TherapeuticEqKey = pie.TherapeuticEqKey
	--	        join PharmacyItem pie on pi.PharmaceuticalEqKey = pie.PharmaceuticalEqKey
	--	        join PharmacyItem pie on pi.BioEqKey = pie.BioEqKey
	--	        join PharmacyItem pie on pi.DirectEqKey = pie.DirectEqKey
		        left join (
			        select pis.ItemId
				        ,count(1) ShortageCount
			        from PharmacyItemShortage pis
			        where pis.Status = 'S'
			        group by pis.ItemId
		        ) pis on pis.ItemId = pie.ItemId
		        left join (
			        select po.ItemId
                        ,po.ClientId
				        ,max(po.ApprovalDateTime) LastTimePurchased
			        from PurchaseOrder po
			        group by po.ItemId
                        ,po.ClientId
		        ) po on pie.ItemId = po.ItemId
		        left join (
                    select cii.ItemId
	                    ,cii.ClientId
	                    ,sum(cii.QuantityOnHand) QuantityOnHand
                    from CustomerItemInventory cii
                        where cii.InventoryTypeId < 4 --Only include items where inventory type is not other
                    group by cii.ItemId
	                    ,cii.ClientId
                ) cii on cii.ItemId = pie.ItemId
		        left join (
			        select st.ItemId
				        ,st.ClientId
				        ,sum(st.[90DayUsageQty]) Usage90
			        from SalesTotals st
			        group by st.ItemId
				        ,st.ClientId
		        ) st on st.ItemId = pie.ItemId
		        left join (
			        select cip.ClientId
				        ,cip.ItemId
				        ,max(cip.PriceAmount) Price340b
			        from CustomerItemPricing cip
			        where cip.Status = 'A'
				        and cip.PriceListId = 2
			        group by cip.ClientId
				        ,cip.ItemId
		        ) cip340b on cip340b.ItemId = pie.ItemId
		        left join (
			        select cip.ItemId
				        ,cip.ClientId
				        ,max(cip.PriceAmount) MaxPrice
			            ,min(cip.PriceAmount) MinPrice
	                    ,count(case when cip.PriceListId <> 3 then 1 else null end) + 
	                    count(distinct case when cip.PriceListId = 3 then cip.CpSupplierId else null end) ChannelCount
			        from CustomerItemPricing cip
			        where cip.PriceListId = 3
                        and cip.Status = 'A'
			        group by cip.ItemId
				        ,cip.ClientId
		        ) cip on cip.ItemId = pie.ItemId
		        left join CustomerItem ci on ci.ItemId = pie.ItemId
	  --      where pi.Ndc = @ndc --Param
	         where pi.Ndc in (select top 10000 ndc from pharmacyitem p) --@ndc --Param
		        and pi.Ndc != pie.Ndc
                and (po.ClientId is null or po.ClientId = @clientId) --Param
		        and (cii.ClientId is null or cii.ClientId = @clientId) --Param
		        and (st.ClientId is null or st.ClientId = @clientId) --Param
		        and (cip.ClientId is null or cip.ClientId = @clientId) --Param
		        and (ci.ClientId is null or ci.ClientId = @clientId) --Param) a
		        ) a
		      



