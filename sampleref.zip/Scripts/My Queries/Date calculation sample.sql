SELECT AspPriceId, Ndc, itemId, QuarterDate, RevisionDate, HcpcsCode, HCPCSDescription, HcpcsCodeDosage, AspUnitPrice, PaymentLimit, IndependentEsrdLimit, VaccineLimit, DMEInfusionLimit, BloodLimit, PackageSize, PackageQuantity, BillableUnitsPerPackage, BillableUnitsPer11DigitNDC, IsCurrentRecords, ItemMasterItemId, DateAdded, DateChanged, ItemUId, DataSourceId
FROM sqldbCogRxProdStLukes.dbo.AspPriceAndLimits;

execute dbo.FnAnalysis;

select distinct itemid from PharmacyItem where MfrId=971

select GETDATE() ;

select DATEADD(Day, -91,GETDATE()) ;

SELECT      GETDATE(), 'Today'
UNION ALL
SELECT      DATEADD(DAY,  10, GETDATE()), '10 Days Later'
UNION ALL
SELECT      DATEADD(DAY, �90, GETDATE()), '10 Days Earlier'
UNION ALL
SELECT      DATEADD(MONTH,  1, GETDATE()), 'Next Month'
UNION ALL
SELECT      DATEADD(MONTH, �1, GETDATE()), 'Previous Month'
UNION ALL
SELECT      DATEADD(YEAR,  1, GETDATE()), 'Next Year'
UNION ALL
SELECT      DATEADD(YEAR, �1, GETDATE()), 'Previous Year'
