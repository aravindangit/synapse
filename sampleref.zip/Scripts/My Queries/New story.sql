--SELECT * FROM PriceDisruptions.ResultsNdc where Ndc =  '00008092355'

----Raw invoice----
-------> [PriceDisruptions].[BuildRawInvoices]

SELECT
	i.[Ndc] ,
	i.[QuantityOrdered] ,
	i.[InvoicePrice] ,
	i.[TotalSpend] ,
	i.[TotalUnits] ,
	i.[ContractNumber] ,
	i.[HealthSystemId] ,
	i.[FacilityState] ,
	i.[FMonth] ,
	i.[Manufacturer] ,
	i.[DrugName] ,
	i.[PricingKey] ,
	i.[IsGenericDrug] ,
	i.[DrugStrength] ,
	i.[DrugId] ,
	i.[Wac] ,
	i.[GpiName] ,
	i.[InvoiceDateString] ,
	i.[D_Wholesaler] ,
	i.[DaysAgo] ,
	i.quantityordered * i.invoiceprice as PotentialSpend ,
	CASE
		WHEN quantityordered != 0 THEN CAST(i.totalunits AS DECIMAL(8,
		2))/ CAST(quantityordered AS DECIMAL(8,
		2))
		ELSE CAST(0 AS DECIMAL(8,
		2))
	END AS FillRate ,
	--(i.quantityordered * i.invoiceprice) - i.TotalSpend AS MissingDollars ,
	i.invoiceprice AS MissingDollars ,
	i.quantityordered - i.totalunits AS MissingUnits ,
	pk.equ_maxwac ,
	ap.avgprice
FROM
	[PriceDisruptions].[Transform] i
LEFT JOIN [PriceDisruptions].[AvgPrices] ap ON
	i.ndc = ap.ndc -- and i.ndc = '00378668910'
LEFT JOIN [PriceDisruptions].[WacPricekey] pk ON
	i.pricingkey = pk.pricingkey
	AND i.isgenericdrug = pk.isgenericdrug
where i.ndc = '00378668910'
	
----Raw invoice----




---Incidents NDC----
SELECT ndc
	, healthsystemid
	, MAX(drugid) as gpi10
	, MAX(gpiname) as gpiname
	, MAX(drugstrength) as drugstrength
	, MAX(avgprice) as avgprice
	, count(*) as inc_days
	--, SUM(missingdollars) as missingdollars
	,AVG(InvoicePrice) as averageinvoiceinter
	--,SUM(missingunits)
	, (AVG(InvoicePrice) * SUM(missingunits)) as missingdollars
	, SUM(missingunits) as missingunits
--	, @ReportedDate
FROM [PriceDisruptions].[RawInvoices]
WHERE ((quantityordered >= 1 and fillrate <= 0.5 AND fillrate >= 0) OR (quantityordered = 1 AND fillrate = 0)) 
and ndc = '17478020102'--'00008092355'--'00378668910'
GROUP BY ndc
	, healthsystemid
	with ROLLUP 
---Incidents NDC-------
	select * from [PriceDisruptions].[IncidentsNdc] where ndc = '00378668910' and HealthSystemId is null
	
	
	
	select * from PriceDisruptions.IncidentsNdc in2 where ndc = '00006302604'
	
	
	
Execute [PriceDisruptions].[BuildIncidentsNdc] '2021-06-15'

Execute [PriceDisruptions].[BuildResultsNdc] '2021-06-15', '2021-03-16' 

Execute [PriceDisruptions].[BuildResultsNdc] '2021-06-15'

select count(*) from PriceDisruptions.ResultsNdc rn  

select count(*) from PriceDisruptions.IncidentsNdc 

select top 100 * from PriceDisruptions.IncidentsNdc  

select top 100 * from PriceDisruptions.ResultsNdc rn 
	
--Dateformat 2021-06-14


SELECT i.[Ndc]
	    , i.[HealthSystemId]
		, i.[Gpi10]
		, i.[GpiName]
		, i.[DrugStrength]
		, i.[AvgPrice]
		, i.[Inc_Days]
		, i.[MissingDollars]
		, i.[MissingUnits]
		, hscount = (SELECT DISTINCT COUNT(a.healthsystemid) FROM [PriceDisruptions].[IncidentsNdc] a WHERE a.ndc = i.ndc AND a.healthsystemid IS NOT NULL)
		, hsmax = (SELECT MAX(inc_days) FROM [PriceDisruptions].[IncidentsNdc] a WHERE a.ndc = i.ndc AND a.healthsystemid IS NOT NULL)
	FROM [PriceDisruptions].[IncidentsNdc] i
	WHERE healthsystemid IS NULL AND ndc IS NOT NULL
	
	
	exec [PriceDisruptions].[BuildIncidentsGpi] @ReportedDate


	exec [PriceDisruptions].[BuildIncidentsGpiMfr] @ReportedDate
	
select top 100 * from PriceDisruptions.ResultsGpi  
select top 100 * from PriceDisruptions.ResultsNdc 
select count(*) from PriceDisruptions.IncidentsGpi ig
select t from PriceDisruptions.IncidentsGpi ig
select top 100 * from PriceDisruptions.IncidentsGpiMfr igm 

exec [PriceDisruptions].[BuildIncidentsGpi] '2021-06-16'
exec [PriceDisruptions].[BuildIncidentsGpiMfr] '2021-06-16'
exec [PriceDisruptions].[BuildResultsGpi] '2021-06-16'