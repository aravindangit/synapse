SELECT
--	e.BuyInExclusionId ,
	cm.CustomerName ,
	cm.AccountNumber,
	cm.DEA ,
--	e.ItemId ,
--	p.Ndc ,
--	p.ItemDescription ,
	CASE
		WHEN CHARINDEX('Unknown - ',cm.CustomerName) > 0 THEN cm.CustomerName
		WHEN cm.DEA IS NULL THEN cm.CustomerName + ' - ' + cm.AccountNumber
		ELSE cm.CustomerName + ' - ' + cm.AccountNumber + ' - ' + cm.DEA 
	END AS Facility ,
	e.DateAdded ,
	e.ExclusionEndDate ,
	CASE
		WHEN e.ExclusionEndDate IS NULL
		OR e.ExclusionEndDate > GETDATE() THEN 1
		ELSE 0
	END AS IsActive
FROM
	App.BuyInExclusion e
inner join dbo.PharmacyItem p ON
	e.ItemId = p.ItemId
left join Customer cm on
	cm.customerid = e.customerid
WHERE
 e.ItemId = '570496'
ORDER BY
	IsActive desc,
	e.ExclusionEndDate desc,
	e.DateAdded desc;

--select top 10 * from dbo.PharmacyItem  where ndc = '00009082501'

/*update dbo.Customer 
set DEA = 'TESTDEA'
WHERE DEA IS NULL */
SELECT * FROM Customer c 