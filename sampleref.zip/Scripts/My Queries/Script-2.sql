
DECLARE @clientId as int = 4
DECLARE @customerId as int = 41
DECLARE @from date = '07-05-2019'  --mmddyyyy
DECLARE @to date = '07-05-2021';



	              select pi.Ndc
                        ,pi.ItemDescription as 'Description'
                        ,s.CustomerId
			            ,s.TransactionDate
			            ,s.Qty
			            ,s.UnitCost
			            ,s.UnitCost * Qty as 'TotalCost'
			            INTO #aravind1
		            from PharmacyItem pi 
                        join Sales s on s.ItemId = pi.ItemId
			            join Customer c on s.CustomerId = c.CustomerId and s.ClientId = c.ClientId
		            where s.ClientId = 4 
			            and c.CustomerId = 41 and c.ClientId = s.ClientId 
			          
			            
 select * from #aravind1
       
	            select sum(case when u.TransactionDate > dateadd(dd, -30, '07/05/2021') then u.Qty else 0 end) Usage30
		            ,sum(case when u.TransactionDate > dateadd(dd, -60, '07/05/2021') then u.Qty else 0 end) Usage60
		            ,sum(case when u.TransactionDate > dateadd(dd, -90, '07/05/2021') then u.Qty else 0 end) Usage90
		            ,sum(case when u.TransactionDate > dateadd(dd, -30, '07/05/2021') then u.TotalCost else 0 end) Cost30
		            ,sum(case when u.TransactionDate > dateadd(dd, -60, '07/05/2021') then u.TotalCost else 0 end) Cost60
		            ,sum(case when u.TransactionDate > dateadd(dd, -90, '07/05/2021') then u.TotalCost else 0 end) Cost90
		            ,sum(u.Qty) TotalUsage
		            ,sum(u.UnitCost) TotalUnitCost
		            ,sum(u.TotalCost) TotalTotalCost
	            from #aravind1 u
            ),
            utilizationDetail as (
	            select tu.Ndc
						,tu.Description
                        ,tu.CustomerId			            
			            ,tu.TransactionDate
			            ,tu.Qty
			            ,tu.UnitCost
			            ,tu.UnitCost * Qty as 'TotalCost'
		            from utilization tu
		            where tu.TransactionDate >= @from
			            and tu.TransactionDate < dateadd(day, 1, @to)
            )

            select 
                s.Ndc
                ,s.Description
                ,s.CustomerId	            
	            ,s.TransactionDate
	            ,s.Qty
                ,s.UnitCost
                ,s.TotalCost
	            ,totals.TotalCount as SearchResultCount
                ,totals.SearchResultTotalUnitCost
	            ,totals.SearchResultTotalCost
	            ,totals.SearchResultTotalQty
	            ,totalUsage.Usage30 AS SearchResultUsage30
	            ,totalUsage.Usage60 AS SearchResultUsage60
	            ,totalUsage.Usage90 AS SearchResultUsage90
	            ,totalUsage.Cost30 AS SearchResultCost30
	            ,totalUsage.Cost60 AS SearchResultCost60
	            ,totalUsage.Cost90 AS SearchResultCost90
	            ,totalUsage.TotalUsage
	            ,totalUsage.TotalUnitCost
	            ,totalUsage.TotalTotalCost
            from utilizationDetail s
	            join (select count(1) as TotalCount
                            ,sum(u.UnitCost) as SearchResultTotalUnitCost
				            ,sum(u.TotalCost) as SearchResultTotalCost
				            ,sum(u.Qty) as SearchResultTotalQty
			            from utilizationDetail u) totals on 1 = 1
	            join (select ut.Usage30
			            ,ut.Usage60
			            ,ut.Usage90
			            ,ut.Cost30
			            ,ut.Cost60
			            ,ut.Cost90
			            ,ut.TotalUsage
			            ,ut.TotalUnitCost
			            ,ut.TotalTotalCost
		              from utilizationTotals ut) totalUsage on 1 = 1
          