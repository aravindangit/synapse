

select * from AspPriceAndLimits where Ndc = '63323062374'

select count(distinct(HcpcsCode)) as total from AspPriceAndLimits where Ndc = '00069080901'

select count(distinct(HcpcsCode)) as total,ndc from AspPriceAndLimits 
where 1=1
group by Ndc
having count(distinct(HcpcsCode)) > 1