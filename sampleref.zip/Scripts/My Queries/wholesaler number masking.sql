/* todo: mask WAN and CBID

1. Truncate dbo.SalesTotal, dbo.SalesTotalMonth tables
2. Create WAN Xref table
3. Update dbo.Sales.WholesalerAccountNumber based on xref
4. Create CBID Xref table
5. Update dbo.Sales.WholesalerCBID based on xref
6. Re-run SalesTotal/SalesTotalMonthly rebuild SP


*/



select * into salesmaskbkp from dbo.sales



select * into dbo.SalesTotalsdec from dbo.SalesTotals st 
select * into dbo.SalesTotalMonthlydec from dbo.SalesTotalMonthly stm 
truncate table dbo.SalesTotals;
truncate table dbo.SalesTotalMonthly;
exec [DailyMaintinance].[RebuildSalesTotal];


select * from dbo.SalesTotals st 
select * from dbo.SalesTotalMonthly stm 
--181,849
select distinct(WholesalerAccountNumber) from dbo.Sales s 
select distinct(WholesalerCBID) from dbo.sales s

--select * into dbo.masksales from dbo.sales
--create WAN xref
truncate table xrefwanload;
with distinctWan
as (select distinct WholesalerAccountNumber from Sales)
   , xrefWan
as (select 'WAN-' + cast(row_number() over (order by WholesalerAccountNumber asc) as varchar(25)) as Maskwan
         , WholesalerAccountNumber
    from distinctWan) 
insert into dbo.xrefwanload
		(Maskedwan ,
		WholesalerAccountNumber) 
 select Maskwan,
 		WholesalerAccountNumber 
 		from xrefwan
    
    select top 1000 * from sales 
--todo: make this an update statement to dbo.sales
  ---masking  
    update sa 
    set sa.WholesalerAccountNumber = wa.maskedwan
    from dbo.sales sa join xrefwanload wa on sa.WholesalerAccountNumber = wa.WholesalerAccountNumber
    ---reverse masking
    update sa 
    set sa.WholesalerAccountNumber = wa.WholesalerAccountNumber 
    from dbo.sales sa join xrefwanload wa on sa.WholesalerAccountNumber = wa.MaskedWan 
    
    select top 100 * from dbo.Sales 

    
    select count(*) from dbo.sales
    select count(SalesId) from dbo.sales
from xrefWan;
select * into salesbkp1228 from dbo.sales sa 
--create CBID xref
truncate table xrefcbidload;
with distinctCbid
as (select distinct WholesalerCBID from Sales)
   , xrefCbid
as ((select 'CBID-' + cast(row_number() over (order by WholesalerCBID asc) as varchar(25)) as maskcbid
          , WholesalerCBID
     from distinctCbid))
insert into dbo.xrefcbidload
		(Maskedcbid ,
		WholesalerCBID) 
 select maskcbid,
 		WholesalerCBID 
 		from xrefCbid
-- todo: make this an update statement to dbo.sales
 	--masking	
 	update sa 
    set sa.WholesalerCBID = wa.Maskedcbid
    from dbo.sales sa join xrefcbidload wa on sa.WholesalerCBID = wa.WholesalerCBID
    ---reverse masking
    update sa 
    set sa.WholesalerCBID = wa.WholesalerCBID 
    from dbo.sales sa join xrefcbidload wa on sa.WholesalerCBID = wa.MaskedCBID 
select *
from xrefcbidload

select * from xrefwanload 

select distinct wholesalercbid from sales

--todo: execute rebuild sales total SP



-- CogRxDemo.dbo.Sales definition

-- Drop table

-- DROP TABLE CogRxDemo.dbo.Sales;
drop table xrefwanload 
select s.WholesalerAccountNumber , w.wholesaleraccountnumber,w.maskedwan from sales s
join xrefwanload w on s.WholesalerAccountNumber = w.WholesalerAccountNumber

CREATE TABLE dbo.xrefwanload (
	MaskedWan varchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	WholesalerAccountNumber varchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL)
	
CREATE TABLE dbo.xrefcbidload (
	MaskedCBID	varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	WholesalerCBID varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL)
	
	select * from
	
	

