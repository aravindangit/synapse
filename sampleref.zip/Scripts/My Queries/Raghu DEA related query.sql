select
	distinct T.Facilityconcat,
	datefromparts(YEAR(T.TransactionDate), MONTH(T.TransactionDate), 1)  TransactionDate,
	sum(T.Qty) as quantity,
	sum(T.ExtendedCost) as extendedcost
from
	(
	SELECT
		CASE
			WHEN CHARINDEX('Unknown - ',
			c.CustomerName) > 0 THEN c.CustomerName
			WHEN c.DEA IS NULL THEN c.CustomerName + ' - ' + c.AccountNumber
			ELSE c.CustomerName + ' - ' + c.AccountNumber + ' - ' + c.DEA
		END as Facilityconcat ,
		s.TransactionDate as TransactionDate ,
		s.Qty AS Qty ,
		s.Qty * s.UnitCost AS ExtendedCost
	FROM
		PharmacyItem pi
	JOIN Sales s ON
		s.ItemId = pi.ItemId
	JOIN Customer c ON
		s.CustomerId = c.CustomerId
	JOIN PriceTypeGroup ptg ON
		s.PriceTypeGroupId = ptg.PriceTypeGroupId
	WHERE
		s.ClientId = 6 /*Param*/
		) as T
	--and pi.Ndc = @ndc /*Param*/
	--and s.TransactionDate >= @fromDate /*Param*/
	--   and s.TransactionDate <= @toDate /*Param*/

	GROUP BY YEAR(T.TransactionDate),
	MONTH(T.TransactionDate),
	T.Facilityconcat with ROLLUP 
ORDER BY
	Facilityconcat,
	--YEAR(T.TransactionDate),
	--MONTH(T.TransactionDate),
	TransactionDate,quantity,extendedcost
	
	
	
	/*CASE
		WHEN CHARINDEX('Unknown - ',c.CustomerName) > 0 THEN c.CustomerName
		WHEN c.DEA IS NULL THEN c.CustomerName + ' - ' + c.AccountNumber
		ELSE c.CustomerName + ' - ' + c.AccountNumber + ' - ' + c.DEA 
	END AS Facility ,
*/
	
	
	
	select 
            c.OrganizationName
                ,datefromparts(year(s.TransactionDate), month(s.TransactionDate), 1) TransactionDate
                ,sum(s.Qty) as Qty
                ,sum((s.Qty * s.UnitCost)) as ExtendedCost
            from PharmacyItem pi
           join Sales s on s.ItemId = pi.ItemId
           join Customer c on s.CustomerId = c.CustomerId
           join PriceTypeGroup ptg on s.PriceTypeGroupId = ptg.PriceTypeGroupId
            where s.ClientId = 6 /*Param*/
           --and pi.Ndc = @ndc /*Param*/
           --and s.TransactionDate >= @fromDate /*Param*/
             --   and s.TransactionDate <= @toDate /*Param*/
                
            group by year(s.TransactionDate), month(s.TransactionDate), c.OrganizationName
            order by c.OrganizationName, year(s.TransactionDate), month(s.TransactionDate)


            
          --  select * from customer