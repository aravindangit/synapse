with top20 as (
    select top 20 GpiName from [NationalPriceDisruptions].[ResultsGpi]  order by MissingUnits desc
        ),
 NdcsOrderQty as (select Ndc, sum(TotalUnits) NdcsFilled, sum(QuantityOrdered) NdcsOrdered from 
 NationalPriceDisruptions.RawInvoices ri join top20 on top20.GpiName = ri.GpiName 
 --where ((quantityordered >= 1 and fillrate <= 0.5 AND fillrate >= 0) OR (quantityordered = 1 AND fillrate = 0)) 
 group by Ndc )
-- get the GPI and NDC data
select 
         Gpi.GpiName
        --,Gpi.HealthSystemId
        ,Gpi.Gpi10
        ,Gpi.Inc_Days GpiLines  
        ,Gpi.MissingDollars GpiMissingDollars --spend impact
        ,Gpi.MissingUnits GpiMissingUnits   --missing units
        ,Gpi.HsCount GpiHealthSystemsAffected -- systems affected
        --,Gpi.HsMax GpiHsMax   --todo: determine what this actually is
        --,Gpi.IncPerDay GpiIncPerDay
        --,Gpi.IncPerDay_NoTop 
        --,Gpi.Spread
        ,Gpi.Filled GpiFilledUnits
        --,Gpi.ContractCount
        --,Gpi.GeneratedDate
        --,Gpi.SyncDate
       --,Ndc.*
        ,Ndc.Ndc
        ,Ndc.DrugStrength
        ,Ndc.Inc_Days   NdcLines
	    ,Ndc.MissingDollars NdcMissingDollars
        --,NdcsOrderQty.NdcsOrdered 'NdcOrderedUnits'
        ,NdcsOrderQty.NdcsFilled 'NdcFilledUnits'
	    ,Ndc.MissingUnits NdcMissingUnits
	    ,Ndc.HsCount NdcHealthSystemsAffected
	    ,pi.Manufacturer Supplier
	    ,pi.ItemDescription
	    ,nat.WacPackagePrice as 'WacPrice'
        ,Ndc.AvgPrice AvgInvoicePrice
        
  FROM [NationalPriceDisruptions].[ResultsGpi] Gpi
    join top20 t on t.GpiName = Gpi.GpiName
    join NationalPriceDisruptions.ResultsNdc Ndc on Gpi.GpiName= Ndc.GpiName
   JOIN dbo.PharmacyItem pi ON Ndc.Ndc = pi.Ndc
   JOIN dbo.NationalPharmacyItemPriceCurrent nat ON Ndc.Ndc = nat.Ndc
    join NdcsOrderQty NdcsOrderQty on NdcsOrderQty.Ndc = Ndc.Ndc
    where Gpi.GpiName = 'Pantoprazole Sodium'
  
 order by Gpi.MissingUnits desc;
  --order by Gpi.Inc_Days desc;


select * from NationalPriceDisruptions.ResultsGpi where gpiname = 'Pantoprazole Sodium' 
select * from NationalPriceDisruptions.ResultsNdc where gpiname = 'Pantoprazole Sodium'
group by ndc


select top 10 * from PriceDisruptions.ResultsGpi rg 
select distinct(NDC) from PriceDisruptions.ResultsNdc where gpiname = 'Pantoprazole Sodium'




WITH BASE_CTE AS (
	SELECT i.[Ndc]
	    , i.[HealthSystemId]
		, i.[Gpi10]
		, i.[GpiName]
		, i.[DrugStrength]
		, i.[AvgPrice]
		, i.[Inc_Days]
		, i.[MissingDollars]
		, i.[MissingUnits]
		, hscount = (SELECT DISTINCT COUNT(a.healthsystemid) FROM [PriceDisruptions].[IncidentsNdc] a WHERE a.ndc = i.ndc AND a.healthsystemid IS NOT NULL)
		, hsmax = (SELECT MAX(inc_days) FROM [PriceDisruptions].[IncidentsNdc] a WHERE a.ndc = i.ndc AND a.healthsystemid IS NOT NULL)
	FROM [PriceDisruptions].[IncidentsNdc] i
	WHERE healthsystemid IS NULL AND ndc IS NOT NULL
),
CALC_CTE AS (
	SELECT Ndc
	    , HealthSystemId
		, Gpi10
		, GpiName
		, DrugStrength
		, AvgPrice
		, Inc_Days
		, MissingDollars
		, MissingUnits
		, hscount
		, hsmax
	, CAST(inc_days AS DECIMAL(10,2)) / 30 as incperday
	, (CAST(inc_days AS DECIMAL(10,2)) - CAST(hsmax AS DECIMAL(10,2))) / 30 as incperday_notop  --inc/day not incl the top guy
	, 1 - (CAST(hsmax as DECIMAL(10,2)) / CAST(inc_days AS DECIMAL(10,2))) as spread
FROM BASE_CTE
)

SELECT c.[Ndc]
    , c.[HealthSystemId]
    , c.[Gpi10]
    , c.[GpiName]
    , c.[DrugStrength]
    , c.[AvgPrice]
    , c.[Inc_Days]
    , c.[MissingDollars]
    , c.[MissingUnits]
    , c.[HsCount]
    , c.[HsMax]
    , c.[IncPerDay]
    , c.[IncPerDay_NoTop]
    , c.[Spread]

FROM CALC_CTE c
where c.[GpiName] = 'Pantoprazole Sodium'
ORDER BY inc_days DESC;-- gpiname, mfr



select (SUM([NdcsFilled]) ) from 
(select Ndc, sum(TotalUnits) NdcsFilled, sum(QuantityOrdered) NdcsOrdered from 
 NationalPriceDisruptions.RawInvoices where GpiName = 'Pantoprazole Sodium'
 and ndc in ('00378668899','00378668999','13668009690','31722071310','62175061846',
'65162063711','66993006880') group by ndc) a