
WITH BASE_CTE AS (
	SELECT i.[GpiName]
	      , i.[HealthSystemId]
		  , i.[Gpi10]
		  , i.[Inc_Days]
		  , i.[MissingDollars]
		  , i.[MissingUnits]
		, hscount = (SELECT DISTINCT COUNT(a.healthsystemid) FROM [PriceDisruptions].[IncidentsGpi] a WHERE a.gpiname = i.gpiname AND a.healthsystemid IS NOT NULL)
		, hsmax = (SELECT MAX(inc_days) FROM [PriceDisruptions].[IncidentsGpi] a WHERE a.gpiname = i.gpiname AND a.healthsystemid IS NOT NULL)
	FROM [PriceDisruptions].[IncidentsGpi] i
	WHERE healthsystemid IS NULL AND gpiname IS NOT NULL
),
CALC_CTE AS (
	SELECT [GpiName]
	, [HealthSystemId]
	, [Gpi10]
	, [Inc_Days]
	, [MissingDollars]
	, [MissingUnits]
	, hscount
	, hsmax
	, CAST(inc_days AS DECIMAL(10,2)) / 30 as incperday
	, (CAST(inc_days AS DECIMAL(10,2)) - CAST(hsmax AS DECIMAL(10,2))) / 30 as incperday_notop  --inc/day not incl the top guy
	, 1 - (CAST(hsmax as DECIMAL(10,2)) / CAST(inc_days AS DECIMAL(10,2))) as spread
FROM BASE_CTE
)
SELECT c.[GpiName]
    ,c.[HealthSystemId]
    ,c.[Gpi10]
    ,c.[Inc_Days]
    ,c.[MissingDollars]
    ,c.[MissingUnits]
    ,c.[HsCount]
    ,c.[HsMax]
    ,c.[IncPerDay]
    ,c.[IncPerDay_NoTop]
    ,c.[Spread] 
    ,f.filled
    ,cc.contractcount
--	,@ReportedDate
FROM CALC_CTE c
     LEFT JOIN [PriceDisruptions].[FilledUnitsGpi] f 
        ON c.gpiname = f.gpiname
     LEFT JOIN [PriceDisruptions].[ContractCount] cc 
	    ON c.gpiname = cc.gpiname
WHERE inc_days > 300
	AND spread > 0.6
	AND missingdollars >= 10000 --and c.[Gpi10] = '4927007010'
ORDER BY inc_days DESC-- gpiname, mfr;

----FILLED UNITS GPI----
SELECT gpiname
	, MAX(drugid) as gpi10
	, SUM(totalunits) AS filled
FROM [PriceDisruptions].[RawInvoices]
GROUP BY gpiname;
----FILLED UNITS GPI----

select * from PriceDisruptions.IncidentsNdc
SELECT * FROM PriceDisruptions.IncidentsGpi 

SELECT TOP 10 * FROM PriceDisruptions.RawInvoices ri 