SELECT LocationID, LocationName, Address
FROM CogRxDemo.dbo.Locations_testing1;

ALTER TABLE dbo.Locations_testing1 
ADD new_name VARCHAR (255) ;

ALTER TABLE dbo.Locations_testing1 
    ADD 
        [Facility nam1] NVARCHAR (200) ,
		[Facility nam2] VARCHAR (100) ,
        [Facility nam3] VARCHAR (50) ,
		[Facility nam4] VARCHAR (10) ,
		[Facility nam5] VARCHAR (30) ;

ALTER TABLE dbo.Locations_testing1 
    ADD 
        [one] NVARCHAR (255) ,
		[two] NVARCHAR (255) ;
		
	SELECT [Health System], [Health System ID], [Facility Direct Parent], [Facility Direct Parent ID], [Facility Name], [Facility ID], ImportedDate
FROM CogRxDemo.Raw.PremierCustomerList;

ALTER TABLE Raw.PremierCustomerList 
    ADD 
        [Facility AddrLine1] VARCHAR (200) ,
		[Facility AddrLine2] VARCHAR (100) ,
        [Facility City] VARCHAR (50) ,
		[Facility State] VARCHAR (10) ,
		[Facility Zip] VARCHAR (30) ,
		[Facility DEA] NVARCHAR (255);
