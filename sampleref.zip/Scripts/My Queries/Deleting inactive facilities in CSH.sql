SELECT * into customerbkp1130 FROM Customer 
where AccountNumber in  ('CA1267','701534','AZ0121','841206','AB1998','677064')

select * from customerbkp1130 where AccountNumber in  ('CA1267','701534','AZ0121','841206','AB1998','677064')

|CustomerId|CustomerUId                         |ClientId|DataSourceId|AccountNumber|CustomerOrganizationId|OrganizationNumber|OrganizationName             |CustomerName                       |PriceList|AddrLine1                |AddrLine2|City           |State|Zip       |ParentCustomerId|CotId|CustomImportCode|GlDept|Status|DateImported           |DateChanged            |CustomerPatientCareAreaId|CustomerBusinessTypeId|CustomerPurchaseTypeId|CustomerSpecialtyTypeId|CustomerRegionId|DeaLicenseNum|DeaLicenseExpiration|StateLicenseNum|StateLicenseExpiration|HinNum|GlnNum|340bId|340bType|HierarchyNum|HierarchyName|CustomerHrsaNumber|BusinessType|PatientCareArea|ClassOfTrade|BockingData|Notes|SysStartTime           |SysEndTime             |DEA      |Premier_Relation|SPC                 |DivisionName|DivisionId|
|----------|------------------------------------|--------|------------|-------------|----------------------|------------------|-----------------------------|-----------------------------------|---------|-------------------------|---------|---------------|-----|----------|----------------|-----|----------------|------|------|-----------------------|-----------------------|-------------------------|----------------------|----------------------|-----------------------|----------------|-------------|--------------------|---------------|----------------------|------|------|------|--------|------------|-------------|------------------|------------|---------------|------------|-----------|-----|-----------------------|-----------------------|---------|----------------|--------------------|------------|----------|
|154       |0A314D39-CE45-EB11-A607-2818783A85D7|2       |            |677064       |4                     |CO5012            |COMMONSPIRIT HEALTH -  CO5012|MASH URGENT CARE                   |         |                         |         |               |     |          |                |     |                |      |A     |2020-12-24 09:56:00.183|2020-12-24 09:56:00.183|                         |                      |                      |                       |                |             |                    |               |                      |      |      |      |        |            |             |                  |            |               |            |           |     |2021-04-20 08:26:16.000|9999-12-31 23:59:59.000|         |                |                    |            |          |
|286       |8E314D39-CE45-EB11-A607-2818783A85D7|2       |            |701534       |4                     |CO5012            |COMMONSPIRIT HEALTH -  CO5012|SOUTHEASTERN NEPHROLOGY            |         |                         |         |               |     |          |                |     |                |      |A     |2020-12-24 09:56:00.183|2020-12-24 09:56:00.183|                         |                      |                      |                       |                |             |                    |               |                      |      |      |      |        |            |             |                  |            |               |            |           |     |2021-04-20 08:26:16.000|9999-12-31 23:59:59.000|         |                |                    |            |          |
|594       |C2324D39-CE45-EB11-A607-2818783A85D7|2       |            |841206       |4                     |CO5012            |COMMONSPIRIT HEALTH -  CO5012|THE MENKES SURGERY CENTER          |         |                         |         |               |     |          |                |     |                |      |A     |2020-12-24 09:56:00.183|2020-12-24 09:56:00.183|                         |                      |                      |                       |                |             |                    |               |                      |      |      |      |        |            |             |                  |            |               |            |           |     |2021-04-20 08:26:16.000|9999-12-31 23:59:59.000|         |                |                    |            |          |
|1060      |94344D39-CE45-EB11-A607-2818783A85D7|2       |            |AB1998       |25                    |CO5012            |COMMONSPIRIT HEALTH -  CO5012|CHPG UROLOGY CASTLE ROCK           |UNK      |2352 MEADOWS BLVD STE 300|         |CASTLE ROCK    |CO   |80109-8419|                |     |                |      |A     |2020-12-24 09:56:00.183|2021-09-02 10:30:33.547|                         |                      |                      |                       |                |             |                    |               |                      |      |      |      |        |            |             |                  |            |               |            |           |     |2021-09-02 10:30:34.000|9999-12-31 23:59:59.000|FN2316051|OLM             |NON ACUTE - PHARMACY|            |          |
|1398      |E6354D39-CE45-EB11-A607-2818783A85D7|2       |            |AZ0121       |24                    |CO5012            |COMMONSPIRIT HEALTH -  CO5012|NORTHERN ARIZONA ORTHOPAEDICS, LTD.|         |3200 N WINDSONG DR       |         |PRESCOTT VALLEY|AZ   |86314-2255|                |     |                |      |A     |2020-12-24 09:56:00.183|2021-06-07 16:07:47.710|                         |                      |                      |                       |                |             |                    |               |                      |      |      |      |        |            |             |                  |            |               |            |           |     |2021-06-07 16:07:48.000|9999-12-31 23:59:59.000|         |                |                    |            |          |
|1426      |02364D39-CE45-EB11-A607-2818783A85D7|2       |            |CA1267       |24                    |CO5012            |COMMONSPIRIT HEALTH -  CO5012|P V I MANAGEMENT, LLC              |         |                         |         |               |     |          |                |     |                |      |A     |2020-12-24 09:56:00.183|2020-12-24 09:56:00.183|                         |                      |                      |                       |                |             |                    |               |                      |      |      |      |        |            |             |                  |            |               |            |           |     |2021-04-20 08:26:16.000|9999-12-31 23:59:59.000|         |                |                    |            |          |


select * from dbo.Sales where CustomerId in (select customerid FROM Customer 
where AccountNumber in  ('CA1267','701534','AZ0121','841206','AB1998','677064') )

select * from dbo.sales where CustomerId in (154,286,594,1060,1398,1426)

select * from dbo.SalesArchive  where CustomerId in (154,286,594,1060,1398,1426)

---------------------------------------------------------------------------------------------------

delete from dbo.customer where 
AccountNumber in  ('CA1267','701534','AZ0121','841206','AB1998','677064')

--customerpricelist
delete from dbo.CustomerPriceList where  CustomerId in (select customerid FROM Customer 
where AccountNumber in  ('CA1267','701534','AZ0121','841206','AB1998','677064'))

--dbo.CustomerItemPricing

delete from dbo.CustomerItemPricing where  CustomerId in (select customerid FROM Customer 
where AccountNumber in  ('CA1267','701534','AZ0121','841206','AB1998','677064'))



--dbo.CustomerItemPricingHistoryMonthly
delete from dbo.CustomerItemPricingHistoryMonthly where  CustomerId in (select customerid FROM Customer 
where AccountNumber in  ('CA1267','701534','AZ0121','841206','AB1998','677064'))

