select * into customernorthwell from Customer c 

select * from customer

update Customer 
	set DivisionName = bkp.DivisionName
	    DivisionId = bkp.DivisionId
	    from dbo.customer cust join dbo.customernorthwell bkp on cust.AccountNumber = bkp.AccountNumber

	    
select bkp.divisionname,bkp.divisionid,cust.AccountNumber 
	    from dbo.customer cust join dbo.customernorthwell bkp on cust.AccountNumber = bkp.AccountNumber

select * from customernorthwell

NY0024

select * from [Raw].[PremierCustomerList]

select distinct [Health System ID] from [Raw].[PremierCustomerList]




                    SELECT
                        InvoiceDateString as InvoiceDate
                        ,Manufacturer
                        ,FacilityState
                        ,DrugStrength
                        ,SUM(TotalUnits) as TotalUnits
                        ,SUM(QuantityOrdered) as QuantityOrdered
	                    ,CASE
		                    WHEN SUM(QuantityOrdered) = 0 THEN NULL 
		                    ELSE CAST(SUM(TotalUnits) as DECIMAL(8,2))/CAST(SUM(QuantityOrdered) AS DECIMAL(8,2))
	                    END as FillRate
                    FROM NationalPriceDisruptions.RawInvoices
                    WHERE GpiName = 'Indapamide'
                    GROUP BY InvoiceDateString, Manufacturer, FacilityState, DrugStrength
                    ORDER BY InvoiceDateString 
                    
                    select * from NationalPriceDisruptions.filledunitsgpi