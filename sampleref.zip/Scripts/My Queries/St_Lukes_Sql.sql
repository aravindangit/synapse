SELECT GpiName, HealthSystemId, Gpi10, Inc_Days, MissingDollars, MissingUnits, HsCount, HsMax, IncPerDay, IncPerDay_NoTop, Spread, Filled, ContractCount, GeneratedDate, SyncDate
FROM sqldbCogRxProdStLukes.NationalPriceDisruptions.ResultsGpi;


select * from sqldbCogRxProdStLukes.NationalPriceDisruptions.ResultsGpi

                WITH CTE_ASHP AS (
	                SELECT
						 Ndc
						,UpdatedDate
						,AvailableNdcs
						,AddedDateTime
						,Reasons
						,EstimatedResupply
	                FROM dbo.PharmacyItemShortage
	                WHERE isActive = 1 AND Source = 'ASHP' AND Status <> 'R'
                )
                SELECT 
					 r.Ndc
	                ,r.Gpi10
	                ,r.GpiName
	                ,r.Inc_Days
	                ,r.MissingDollars
	                ,r.MissingUnits
	                ,r.HsCount
	                ,pi.Manufacturer
	                ,pi.ItemDescription
	                ,nat.WacPackagePrice as 'Wac'
                    ,r.AvgPrice
	                ,convert(varchar, ashp.UpdatedDate, 23) as 'ShortUpdate'
                    ,convert(varchar, ashp.AddedDateTime, 23) as 'ShortAdded'
                    ,ashp.AvailableNdcs as 'ShortAvailable'
	                ,ashp.Reasons as 'ShortReasons'
	                ,ashp.EstimatedResupply as 'ShortResupply'
            --    FROM ***PREFIX***ResultsNdc r
	              FROM NationalPriceDisruptions.ResultsNdc r
                JOIN dbo.PharmacyItem pi ON r.Ndc = pi.Ndc
                JOIN dbo.NationalPharmacyItemPriceCurrent nat ON r.Ndc = nat.Ndc
                LEFT JOIN CTE_ASHP ashp ON r.Ndc = ashp.Ndc
                WHERE 
	                GpiName = 'Gabapentin'                        --@gpiname
                ORDER BY Inc_Days DESC;


select * from NationalPriceDisruptions.ResultsNdc

[PriceDisruptions].[BuildResultsNdc] from [PriceDisruptions].[IncidentsNdc](loaded from raw invoices - [PriceDisruptions].[RawInvoices]
and the sp is [PriceDisruptions].[BuildIncidentsNdc] from nationalwholes saler database.

next - [PriceDisruptions].[BuildRawInvoices] using [PriceDisruptions].[Transform]
[PriceDisruptions].[AvgPrices] to load rawinvoices

this inturn loaded from premier.WholesalerInvoices with below
tables
premier.wholesalerinvoices
dbo.calendar
dbo.pharmacyitem
dbo.NationalPharmacyItemPriceCurrent
[ItemMaster].[WkGpiDescriptions]
 and sp is [PriceDisruptions].[BuildTransform]



)
