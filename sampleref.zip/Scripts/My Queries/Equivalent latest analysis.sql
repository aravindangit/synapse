DECLARE @CLIENTID INT = 6, @sortColumn VARCHAR(50)='NDC', @sortDirection VARCHAR(5)='asc',
@pageNumber INT=0, @pageSize int = 10, @ndc VARCHAR(11) = '73796027854'

DECLARE @filterToClientCatalog BIT,
                @filterTohas340bPrice BIT,
                @filterToInventory  BIT,
                @filterToChannels BIT,
                @filterToClientActive BIT,
                @filterToClientInactive BIT,
                @filterToShortage BIT
/*                switch (param.EquivalentType)
                {
                    case EquivalentType.Therapeutic:
                        joinColumn = "TherapeuticEqKey";
                        break;
                    case EquivalentType.Pharmaceutical:
                        joinColumn = "PharmaceuticalEqKey";
                        break;
                    case EquivalentType.Bioequivalent:
                        joinColumn = "BioEqKey";
                        break;
                    case EquivalentType.Direct:
                        joinColumn = "DirectEqKey";
                        break;
                }*/
--DROP TABLE #searchResults
            
            select 
                 pie.ItemId
		        ,pie.ItemDescription
		        ,pie.Ndc
		        ,pie.Ndc11
		        ,pie.Manufacturer
		        ,po.LastTimePurchased
                ,CAST(pie.CasePack as varchar(7)) as 'CasePack'
		        ,case when pis.ShortageCount > 0 then 1 else 0 end OnShortage
		        ,cii.QuantityOnHand OnHand
		        ,st.Usage90
		        ,cip340b.Price340b
		        ,cip.MaxPrice
		        ,cip.MinPrice
		        ,cip.ChannelCount
    --        into #searchResults
	        from PharmacyItem pi
		        --join PharmacyItem pie on pie.TherapeuticEqKey = pi.TherapeuticEqKey
	--	        join PharmacyItem pie on pi.TherapeuticEqKey = pie.TherapeuticEqKey
		        join PharmacyItem pie on pi.PharmaceuticalEqKey = pie.PharmaceuticalEqKey
	--	        join PharmacyItem pie on pi.BioEqKey = pie.BioEqKey
	--	        join PharmacyItem pie on pi.DirectEqKey = pie.DirectEqKey
		        left join (
			        select pis.ItemId
				        ,count(1) ShortageCount
			        from PharmacyItemShortage pis
			        where pis.Status = 'S'
			        group by pis.ItemId
		        ) pis on pis.ItemId = pie.ItemId
		        left join (
			        select po.ItemId
                        ,po.ClientId
				        ,max(po.ApprovalDateTime) LastTimePurchased
			        from PurchaseOrder po
			        group by po.ItemId
                        ,po.ClientId
		        ) po on pie.ItemId = po.ItemId
		        left join (
                    select cii.ItemId
	                    ,cii.ClientId
	                    ,sum(cii.QuantityOnHand) QuantityOnHand
                    from CustomerItemInventory cii
                        where cii.InventoryTypeId < 4 --Only include items where inventory type is not other
                    group by cii.ItemId
	                    ,cii.ClientId
                ) cii on cii.ItemId = pie.ItemId
		        left join (
			        select st.ItemId
				        ,st.ClientId
				        ,sum(st.[90DayUsageQty]) Usage90
			        from SalesTotals st
			        group by st.ItemId
				        ,st.ClientId
		        ) st on st.ItemId = pie.ItemId
		        left join (
			        select cip.ClientId
				        ,cip.ItemId
				        ,max(cip.PriceAmount) Price340b
			        from CustomerItemPricing cip
			        where cip.Status = 'A'
				        and cip.PriceListId = 2
			        group by cip.ClientId
				        ,cip.ItemId
		        ) cip340b on cip340b.ItemId = pie.ItemId
		        left join (
			        select cip.ItemId
				        ,cip.ClientId
				        ,max(cip.PriceAmount) MaxPrice
			            ,min(cip.PriceAmount) MinPrice
	                    ,count(case when cip.PriceListId <> 3 then 1 else null end) + 
	                    count(distinct case when cip.PriceListId = 3 then cip.CpSupplierId else null end) ChannelCount
			        from CustomerItemPricing cip
			        where cip.PriceListId = 3
                        and cip.Status = 'A'
			        group by cip.ItemId
				        ,cip.ClientId
		        ) cip on cip.ItemId = pie.ItemId
		        left join CustomerItem ci on ci.ItemId = pie.ItemId
	  --      where pi.Ndc = @ndc --Param
	         where pi.Ndc in (select ndc from pharmacyitem p) --@ndc --Param
		        and pi.Ndc != pie.Ndc
                and (po.ClientId is null or po.ClientId = @clientId) --Param
		        and (cii.ClientId is null or cii.ClientId = @clientId) --Param
		        and (st.ClientId is null or st.ClientId = @clientId) --Param
		        and (cip.ClientId is null or cip.ClientId = @clientId) --Param
		        and (ci.ClientId is null or ci.ClientId = @clientId) --Param
		        
		       order by pi.ndc desc
		        /*and (@filterToClientCatalog = 0 or ci.CustomerItemId is not null) --Param
                and (@filterTohas340bPrice = 0 or cip340b.ItemId is not null) --Param
                and (@filterToInventory = 0 or cii.QuantityOnHand > 0) --Param
                and (@filterToChannels = 0 or cip.ChannelCount > 0) --Param
                and (@filterToClientActive = 0 or ci.ClientItemStatus = 'Active')
                and (@filterToClientInactive = 0 or ci.ClientItemStatus = 'Inactive')
                and (@filterToShortage is null or 
                    (@filterToShortage=1 and pis.ShortageCount > 0) or
                    (@filterToShortage=0 and (pis.ShortageCount = 0 or pis.ShortageCount is null)))
                 ;

		with filteredResults as (
			select fr.ItemId
				 , fr.ItemDescription
				 , fr.Ndc
				 , fr.Ndc11
				 , fr.Manufacturer
				 , fr.LastTimePurchased
				 , fr.CasePack
				 , fr.OnShortage
				 , fr.OnHand
				 , fr.Usage90
				 , fr.Price340b
				 , fr.MaxPrice
				 , fr.MinPrice
				 , fr.ChannelCount
			from (
				select sr.ItemId
					 , sr.ItemDescription
					 , sr.Ndc
					 , sr.Ndc11
					 , sr.Manufacturer
					 , sr.LastTimePurchased
					 , sr.CasePack
					 , sr.OnShortage
					 , sr.OnHand
					 , sr.Usage90
					 , sr.Price340b
					 , sr.MaxPrice
					 , sr.MinPrice
					 , sr.ChannelCount
					 from #searchResults sr
			) fr
			where 1 = 1 
			
		)
		
        select fr.ItemId
			 , fr.ItemDescription
			 , fr.Ndc
			 , fr.Ndc11
			 , fr.Manufacturer
			 , fr.LastTimePurchased
			 , fr.CasePack
			 , fr.OnShortage
			 , fr.OnHand
			 , fr.Usage90
			 , fr.Price340b
			 , fr.MaxPrice
			 , fr.MinPrice
			 , fr.ChannelCount
			 , tc.SearchResultCount
        from filteredResults fr
	        join (select count(1) SearchResultCount from filteredResults) tc on 1 = 1
        order by --Param
	        case when @sortColumn = 'ItemDescription' and @sortDirection = 'asc' then fr.ItemDescription end,
	        case when @sortColumn = 'ItemDescription' and @sortDirection = 'desc' then fr.ItemDescription end desc,
	        case when @sortColumn = 'Ndc' and @sortDirection = 'asc' then fr.Ndc end,
	        case when @sortColumn = 'Ndc' and @sortDirection = 'desc' then fr.Ndc end desc,
	        case when @sortColumn = 'Ndc11' and @sortDirection = 'asc' then fr.Ndc11 end,
	        case when @sortColumn = 'Ndc11' and @sortDirection = 'desc' then fr.Ndc11 end desc,
	        case when @sortColumn = 'Manufacturer' and @sortDirection = 'asc' then fr.Manufacturer end,
	        case when @sortColumn = 'Manufacturer' and @sortDirection = 'desc' then fr.Manufacturer end desc,
	        case when @sortColumn = 'LastTimePurchased' and @sortDirection = 'asc' then fr.LastTimePurchased end,
	        case when @sortColumn = 'LastTimePurchased' and @sortDirection = 'desc' then fr.LastTimePurchased end desc,
	        case when @sortColumn = 'OnShortage' and @sortDirection = 'asc' then fr.OnShortage end,
	        case when @sortColumn = 'OnShortage' and @sortDirection = 'desc' then fr.OnShortage end desc,
	        case when @sortColumn = 'OnHand' and @sortDirection = 'asc' then fr.OnHand end,
	        case when @sortColumn = 'OnHand' and @sortDirection = 'desc' then fr.OnHand end desc,
	        case when @sortColumn = 'Usage90' and @sortDirection = 'asc' then fr.Usage90 end,
	        case when @sortColumn = 'Usage90' and @sortDirection = 'desc' then fr.Usage90 end desc,
	        case when @sortColumn = 'Price340b' and @sortDirection = 'asc' then fr.Price340b end,
	        case when @sortColumn = 'Price340b' and @sortDirection = 'desc' then fr.Price340b end desc,
	        case when @sortColumn = 'MaxPrice' and @sortDirection = 'asc' then fr.MaxPrice end,
	        case when @sortColumn = 'MaxPrice' and @sortDirection = 'desc' then fr.MaxPrice end desc,
	        case when @sortColumn = 'MinPrice' and @sortDirection = 'asc' then fr.MinPrice end,
	        case when @sortColumn = 'MinPrice' and @sortDirection = 'desc' then fr.MinPrice end desc,
	        case when @sortColumn = 'ChannelCount' and @sortDirection = 'asc' then fr.ChannelCount end,
	        case when @sortColumn = 'ChannelCount' and @sortDirection = 'desc' then fr.ChannelCount end desc,
	        case when @sortColumn = 'CasePack' and @sortDirection = 'asc' then fr.CasePack end,
	        case when @sortColumn = 'CasePack' and @sortDirection = 'desc' then fr.CasePack end desc
        offset @pageNumber * @pageSize rows --Param
        fetch next @pageSize rows only --Param ;
            
            select distinct pt.Manufacturer
            from (
	            select sr.Manufacturer
	            from #searchResults sr
	            ) 
	            pt;*/
		        
		        select distinct ndc from pharmacyitem p 