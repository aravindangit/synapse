select ifm.[ClientId],
	   c.[CustomerId],
	   su.SupplierId SupplierId,
	   su.SupplierName SupplierName,
	   pi.ItemId,
       s.[TransactionDate],
       s.[Ndc],
       s.[ItemDescription],
       s.[OrderNumber],
       s.[LineNumber],
       s.[OrderType],
       s.[Qty],
	   s.[QtyOrdered],
       s.[UnitCost],
       s.[UnitPrice],
       s.[UOM],
       s.[InvoiceNumber],
	   s.[WholesalerAccountNumber],
	   s.[ChargeBackContractNumber],
	   s.[Markup/Markdown],
	   ptx.[PriceTypeGroupId],
	   s.[Address1],
	   s.[Address2],
	   s.[City],
	   s.[State],
	   s.[ZipCode],
	   format(ca.FirstDateOfQuarter,'yyyyMMdd') QuarterDate,
       s.[ImportedDate],
	   ifm.[DataSourceId],
	   s.[ProcessPipelineId],
	   case when s.OrderType in ('CPAK Return', 'DOD Order', 'DOD Return', 'Order CPAK') then 1 else 0 end RepackagedFlag
from [Raw].[Sales] s
  inner join [dbo].[ImportFileIDMapping] ifm
     on s.[DataSource] = ifm.[ClientImportCode]
  inner join [dbo].[Customer] c
     on s.[Account] = c.[AccountNumber]
	and ifm.ClientId = c.ClientId
  left join [dbo].[PharmacyItem] pi
     on s.ndc = pi.Ndc
  inner join Calendar ca
     on ifm.[ClientId] = ca.ClientId
	and s.TransactionDate = ca.CalendarDate
  left join Mapping.[PriceTypeGroupXref] ptx
	on c.ClientId = ptx.clientid
	and s.WholesalerAccountAttribute = ptx.[ClientPriceTypeCode]		
  left join [Mapping].[PremierSupplierXref] psx
	on s.Wholesaler = psx.[SupplierCustomerNumber]
    left join supplier su
    on psx.[SupplierId] = su.supplierid
where s.[DataSource] = 'PremierWholesaleInvoice'