SELECT c.fname, c.lname
FROM customers c
WHERE NOT EXISTS (
    SELECT 1 
    FROM sales s 
    WHERE s.cust_id = c.cust_id AND s.date >= DATE_FORMAT(NOW() ,'%Y-01-01')
)

select c.customerid from dbo.customer c where  not exists(
select 1 
from dbo.sales s
where s.customerid = c.customerid and s.TransactionDate >=DATEADD(year,-3,GETDATE()))


select * from dbo.sales where customerid in (3,30,39,67,89)

select DATEADD(year,-1,GETDATE())
select * from Customer where CustomerId in (

select distinct(CustomerId) from dbo.sales 
where (transactiondate not between DATEADD(year,-3,GETDATE()) and GETDATE())
and (transactiondate between DATEADD(year,-3,GETDATE()) and GETDATE())

select distinct(CustomerId) from dbo.sales 
where transactiondate < DATEADD(year,-3,GETDATE()) and GETDATE()
and transactiondate < DATEADD(year,-3,GETDATE()) and GETDATE()
select GETDATE()
select * from dbo.sales where CustomerId in (23
,15
,9
,26
,12
,21
,64
,61
,65
,36
,33
,31
,68
)
select DISTINCT(STRING_AGG(CustomerId),',')) from dbo.sales 
where transactiondate < DATEADD(year,-3,GETDATE())

CONVERT(DATE, HireDate, 103) = CONVERT(DATE, '25-12-2008', 103);
select * from dbo.sales 
where transactiondate > DATEADD(dd, DATEDIFF(dd, 0, dateadd(Month, -37, getdate())), 0)
where TransactionDate,117)  >= convert(date,DATEADD(year,-3,GETDATE()),117)

select cast(TransactionDate as date) from dbo.sales

select cast(DATEADD(year,-3,GETDATE()) as date)

select convert(date,DATEADD(year,-3,GETDATE()),117)

declare @PurgeDate datetime = (select LastDateOfMonth from Calendar where 
clientid is null and CalendarDate = DATEADD(dd, DATEDIFF(dd, 0, dateadd(Month, -37, getdate())), 0));

select @PurgeDate
select * from dbo.sales 
where TransactionDate < @PurgeDate
--DATEADD(dd, DATEDIFF(dd, 0, dateadd(Month, -37, getdate())), 0)
--select DATEADD(dd, DATEDIFF(dd, 0, dateadd(Month, -37, getdate())), 0)

select * from dbo.sales order by TransactionDate ASC  