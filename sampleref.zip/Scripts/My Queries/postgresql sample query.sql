SELECT month_id, provider_class_id, member_key, facility_account_key, bus_partner_id, award_status_key, whsl_purch_type_code, award_status_reported_key, member_top_parent_key, product_key, calc_contract_price, invoice_price, sales_dollars, sales_qty, wac_price, awp_price, year_indicator, current_month_indicator, year_indicator_desc, rx_product_pricing_key, vendor_item_num, last_price_paid, matrix_status_key, qty_ordered, year_id, quarter_id
FROM public.agg_fact_bp_sales_mth;

select    max(a14.member_top_parent_info) AS "Health System",
a14.member_top_parent_id AS "Health System ID",
max(a13.member_direct_parent_info) AS "Facility Direct Parent",
a13.member_direct_parent_id AS "Facility Direct Parent ID",
a12.member_name AS "Facility Name",
a12.member_id AS "Facility ID"
from      agg_fact_bp_sales_mth a11
                join        member_view  a12
                  on         (a11.member_key = a12.member_key)
                join        member_direct_parent_view     a13
                  on         (a12.member_direct_parent_key = a13.member_direct_parent_key)
                join        member_top_parent_view         a14
                  on         (a12.member_top_parent_key = a14.member_top_parent_key)
where (a11.month_id between '2018412' and cast(to_char(date_trunc('month', current_date),'YYYYQMM') as int)
--where   (a11.month_id in
--(select cast(to_char((generate_series('20181201',date_trunc('month', current_date),'1 month')),'YYYYQMM') as int) as month_id)
and (a12.member_top_parent_key in (59815, 53168, 61885, 60971)
or a12.member_direct_parent_key in (12103))
and a12.member_status in ('ACTIVE', 'TERMINATED'))
group by              a12.member_top_parent_key,
                a14.member_top_parent_id,
                a12.member_direct_parent_key,
                a13.member_direct_parent_id,
                a12.member_name,
                a12.member_id limit 500001;


               
select	a12.member_top_parent_key AS member_top_parent_key,		
	max(a15.member_top_parent_info) AS member_top_parent_info,		
	a13.ndc AS ndc,		
	a11.invoice_date AS invoice_date,		
	Sum(case when a11.matrix_status_key in (0,1,2,4,5,6)� then a11.sales_dollars� else 0 end) AS TOTALSPEND,		
	Sum(case when a11.matrix_status_key in (0,1,2,4,5,6)� then a11.qty_ordered� else 0 end) AS QUANTITYORDERED,		
	Sum(case when a11.matrix_status_key in (0,1,2,4,5,6)� then a11.sales_qty� else 0 end) AS TOTALUNITS		
from	fact_bp_sales_detail_view	a11	
	join	member_view	a12
	� on 	(a11.member_key = a12.member_key)	
	join	product_rpt	a13
	� on 	(a11.product_key = a13.product_key)	
	join	bus_partner_source	a14
	� on 	(a11.bp_source_id = a14.bp_source_id)	
	join	member_top_parent_view	a15
	� on 	(a12.member_top_parent_key = a15.member_top_parent_key)	
where	(a11.month_id in (2021206, 2021205, 2021204, 2021103)		
 and a14.bus_partner_id in (11, 1, 12, 4, 8)			
 and a13.ndc in ('63739059110')			
 and a12.member_status in ('ACTIVE', 'TERMINATED'))			
group by	a12.member_top_parent_key,		
	a13.ndc,		
	a11.invoice_date limit 500001       
	
	
	
	
	
	
	
