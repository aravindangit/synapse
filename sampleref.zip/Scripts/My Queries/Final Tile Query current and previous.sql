declare @customerId as int = 44;
with FirstCTE as(select * from --[Year],[Month],[Total Spend],[Total Units] from
(SELECT YEAR(transactiondate) [Year1], 
	     case when year(transactiondate)= year(GETDATE()) then
�����		concat('Currentcost','-',�DATENAME(MONTH, transactiondate)) 
    --     else 
      --  	concat('Previous','-',�DATENAME(MONTH, transactiondate))
         end as [Month],
������   SUM(Qty * UnitCost) as [Total Spend]
--	  sum(Unitcost) as [Total Units] 
	  from dbo.sales s join dbo.customer c on s.customerid = c.customerid
where s.customerid = @customerid and 
YEAR(s.transactiondate) = year(GETDATE()) 
							--	or 
								--YEAR(s.transactiondate)=(YEAR(GETDATE()) - 1)
GROUP BY YEAR(transactiondate), 
������     DATENAME(MONTH, transactiondate)) AS MontlySalesData
PIVOT( SUM([Total Spend])�� 
����FOR [Month] IN (
		[Currentcost-January],
		[Currentcost-February],
		[Currentcost-March],
		[Currentcost-April],
		[Currentcost-May],
����	[Currentcost-June],
		[Currentcost-July],
		[Currentcost-August],
		[Currentcost-September],
		[Currentcost-October],
		[Currentcost-November],
����	[Currentcost-December]))
	--	[Previous-January],
		--[Previous-February]--,
		--[Previous-March],
		--[Previous-April],
		--[Previous-May],
����	--[Previous-June],
		--[Previous-July],
		--[Previous-August],
		--[Previous-September],
		--[Previous-October],
		--[Previous-November],
����	--[Previous-December]))
		 AS pivotname1),
SecondCTE as(select * from --[Year],[Month],[Total Spend],[Total Units] from
(SELECT YEAR(transactiondate) [Year2], 
	case when year(transactiondate)= (year(GETDATE()) -1) then
�����		concat('Previouscost','-',�DATENAME(MONTH, transactiondate)) 
--         else 
  --      	concat('Previous1','-',�DATENAME(MONTH, transactiondate))
         end as [Month],
������SUM(Qty * UnitCost) as [Total Spend]
--	  sum(Unitcost) as [Total Units] 
	  from dbo.sales s join dbo.customer c on s.customerid = c.customerid
where s.customerid = @customerId and 
YEAR(s.transactiondate) = (YEAR(GETDATE()) - 1)
						--		or 
							--	YEAR(s.transactiondate)=(YEAR(GETDATE()) - 1)
GROUP BY YEAR(transactiondate), 
������     DATENAME(MONTH, transactiondate)) AS MontlySalesData
PIVOT( SUM([Total Spend])�� 
����FOR [Month] IN (
	--	[Current1-January],
		--[Current1-February],
		--[Current1-March],
		--[Current1-April],
	--	[Current1-May],
����	--[Current1-June],
		--[Current1-July],
	--	[Current1-August],
		--[Current1-September],
	--	[Current1-October],
		--[Current1-November],
����	--[Current1-December],
		[Previouscost-January],
		[Previouscost-February],
		[Previouscost-March],
		[Previouscost-April],
		[Previouscost-May],
����	[Previouscost-June],
		[Previouscost-July],
		[Previouscost-August],
		[Previouscost-September],
		[Previouscost-October],
		[Previouscost-November],
����	[Previouscost-December])) AS pivotname2),
ThirdCTE as(
select * from FirstCTE  cross join SecondCTE)-- where year1 = 2021 and  year2 = 2020 )
--select * from ThirdCTE
,
FourthCTE as(select * from --[Year],[Month],[Total Spend],[Total Units] from
(SELECT YEAR(transactiondate) [Year3], 
	case when year(transactiondate)= year(GETDATE()) then
�����		concat('Currentunits','-',�DATENAME(MONTH, transactiondate)) 
     --    else 
     --   	concat('Previous2','-',�DATENAME(MONTH, transactiondate))
         end as [Month],
��
  	  sum(Qty) as [Total Units] 
	  from dbo.sales s join dbo.customer c on s.customerid = c.customerid
where s.customerid = @customerId and 
YEAR(s.transactiondate) = year(GETDATE()) 
						--		or 
							--	YEAR(s.transactiondate)=(YEAR(GETDATE()) - 1)
GROUP BY YEAR(transactiondate), 
������     DATENAME(MONTH, transactiondate)) AS MontlySalesData
PIVOT( SUM([Total Units])�� 
����FOR [Month] IN (
		[Currentunits-January],
		[Currentunits-February],
		[Currentunits-March],
		[Currentunits-April],
		[Currentunits-May],
����	[Currentunits-June],
		[Currentunits-July],
		[Currentunits-August],
		[Currentunits-September],
		[Currentunits-October],
		[Currentunits-November],
����	[Currentunits-December]
		--[Previous2-January],
		--[Previous2-February],
		--[Previous2-March],
		--[Previous2-April],
		--[Previous2-May],
����	--[Previous2-June],
		--[Previous2-July],
		--[Previous2-August],
		--[Previous2-September],
		--[Previous2-October],
		--[Previous2-November],
����	--[Previous2-December]
		)) AS pivotname1),
FifthCTE as(select * from --[Year],[Month],[Total Spend],[Total Units] from
(SELECT YEAR(transactiondate) [Year4], 
	case when year(transactiondate)= (year(GETDATE()) -1) then
�����		concat('Previousunits','-',�DATENAME(MONTH, transactiondate)) 
   --      else 
     --   	concat('Previous3','-',�DATENAME(MONTH, transactiondate))
         end as [Month],
��
  	  sum(Qty) as [Total Units] 
	  from dbo.sales s join dbo.customer c on s.customerid = c.customerid
where s.customerid = @customerId and 
YEAR(s.transactiondate) =(YEAR(GETDATE()) - 1)
GROUP BY YEAR(transactiondate), 
������     DATENAME(MONTH, transactiondate)) AS MontlySalesData
PIVOT( SUM([Total Units])�� 
����FOR [Month] IN (
		--[Current3-January],
		--[Current3-February],
		--[Current3-March],
		--[Current3-April],
		--[Current3-May],
����	--[Current3-June],
		--[Current3-July],
		--[Current3-August],
		--[Current3-September],
		--[Current3-October],
		--[Current3-November],
����	--[Current3-December],
		[Previousunits-January],
		[Previousunits-February],
		[Previousunits-March],
		[Previousunits-April],
		[Previousunits-May],
����	[Previousunits-June],
		[Previousunits-July],
		[Previousunits-August],
		[Previousunits-September],
		[Previousunits-October],
		[Previousunits-November],
����	[Previousunits-December])) AS pivotname5),
SixthCTE as(
select * from FourthCTE  cross join FifthCTE),-- where year3 = 2021 and  year4 = 2020 ),
SeventhCTE as(select * from ThirdCTE cross join  SixthCTE),

EighthCTE as (
select 
isnull([Currentcost-January],0)          as          [Currentcost-January],
isnull([Currentcost-February],0)          as          [Currentcost-February],
isnull([Currentcost-March],0)          as          [Currentcost-March],
isnull([Currentcost-April],0)          as          [Currentcost-April],
isnull([Currentcost-May],0)          as          [Currentcost-May],
isnull([Currentcost-June],0)          as          [Currentcost-June],
isnull([Currentcost-July],0)          as          [Currentcost-July],
isnull([Currentcost-August],0)          as          [Currentcost-August],
isnull([Currentcost-September],0)          as          [Currentcost-September],
isnull([Currentcost-October],0)          as          [Currentcost-October],
isnull([Currentcost-November],0)          as          [Currentcost-November],
isnull([Currentcost-December],0)          as          [Currentcost-December],
isnull([Previouscost-January],0)          as          [Previouscost-January],
isnull([Previouscost-February],0)          as          [Previouscost-February],
isnull([Previouscost-March],0)          as          [Previouscost-March],
isnull([Previouscost-April],0)          as          [Previouscost-April],
isnull([Previouscost-May],0)          as          [Previouscost-May],
isnull([Previouscost-June],0)          as          [Previouscost-June],
isnull([Previouscost-July],0)          as          [Previouscost-July],
isnull([Previouscost-August],0)          as          [Previouscost-August],
isnull([Previouscost-September],0)          as          [Previouscost-September],
isnull([Previouscost-October],0)          as          [Previouscost-October],
isnull([Previouscost-November],0)          as          [Previouscost-November],
isnull([Previouscost-December],0)          as          [Previouscost-December],
isnull([Currentunits-January],0)          as          [Currentunits-January],
isnull([Currentunits-February],0)          as          [Currentunits-February],
isnull([Currentunits-March],0)          as          [Currentunits-March],
isnull([Currentunits-April],0)          as          [Currentunits-April],
isnull([Currentunits-May],0)          as          [Currentunits-May],
isnull([Currentunits-June],0)          as          [Currentunits-June],
isnull([Currentunits-July],0)          as          [Currentunits-July],
isnull([Currentunits-August],0)          as          [Currentunits-August],
isnull([Currentunits-September],0)          as          [Currentunits-September],
isnull([Currentunits-October],0)          as          [Currentunits-October],
isnull([Currentunits-November],0)          as          [Currentunits-November],
isnull([Currentunits-December],0)          as          [Currentunits-December],
isnull([Previousunits-January],0)          as          [Previousunits-January],
isnull([Previousunits-February],0)          as          [Previousunits-February],
isnull([Previousunits-March],0)          as          [Previousunits-March],
isnull([Previousunits-April],0)          as          [Previousunits-April],
isnull([Previousunits-May],0)          as          [Previousunits-May],
isnull([Previousunits-June],0)          as          [Previousunits-June],
isnull([Previousunits-July],0)          as          [Previousunits-July],
isnull([Previousunits-August],0)          as          [Previousunits-August],
isnull([Previousunits-September],0)          as          [Previousunits-September],
isnull([Previousunits-October],0)          as          [Previousunits-October],
isnull([Previousunits-November],0)          as          [Previousunits-November],
isnull([Previousunits-December],0)          as          [Previousunits-December],
( isnull([Currentcost-January],0)+
isnull([Currentcost-February],0)+
isnull([Currentcost-March],0)+
isnull([Currentcost-April],0)+
isnull([Currentcost-May],0)+
isnull([Currentcost-June],0)+
isnull([Currentcost-July],0)+
isnull([Currentcost-August],0)+
isnull([Currentcost-September],0)+
isnull([Currentcost-October],0)+
isnull([Currentcost-November],0)+
isnull([Currentcost-December],0)) as [CurrentyearCost],
(isnull([Previouscost-January],0)+
isnull([Previouscost-February],0)+
isnull([Previouscost-March],0)+
isnull([Previouscost-April],0)+
isnull([Previouscost-May],0)+
isnull([Previouscost-June],0)+
isnull([Previouscost-July],0)+
isnull([Previouscost-August],0)+
isnull([Previouscost-September],0)+
isnull([Previouscost-October],0)+
isnull([Previouscost-November],0)+
isnull([Previouscost-December],0)) as [PreviousyearCost],
(isnull([Currentunits-January],0)+
isnull([Currentunits-February],0)+
isnull([Currentunits-March],0)+
isnull([Currentunits-April],0)+
isnull([Currentunits-May],0)+
isnull([Currentunits-June],0)+
isnull([Currentunits-July],0)+
isnull([Currentunits-August],0)+
isnull([Currentunits-September],0)+
isnull([Currentunits-October],0)+
isnull([Currentunits-November],0)+
isnull([Currentunits-December],0)) as [currentyearunits],
(isnull([Previousunits-January],0)+
isnull([Previousunits-February],0)+
isnull([Previousunits-March],0)+
isnull([Previousunits-April],0)+
isnull([Previousunits-May],0)+
isnull([Previousunits-June],0)+
isnull([Previousunits-July],0)+
isnull([Previousunits-August],0)+
isnull([Previousunits-September],0)+
isnull([Previousunits-October],0)+
isnull([Previousunits-November],0)+
isnull([Previousunits-December],0)) as [previousyearunits],
(isnull([Currentcost-January],0)+
isnull([Currentcost-February],0)+
isnull([Currentcost-March],0)+
isnull([Currentcost-April],0)+
isnull([Currentcost-May],0)+
isnull([Currentcost-June],0)+
isnull([Currentcost-July],0)+
isnull([Currentcost-August],0)+
isnull([Currentcost-September],0)+
isnull([Currentcost-October],0)+
isnull([Currentcost-November],0)+
isnull([Currentcost-December],0)) -
(isnull([Previouscost-January],0)+
isnull([Previouscost-February],0)+
isnull([Previouscost-March],0)+
isnull([Previouscost-April],0)+
isnull([Previouscost-May],0)+
isnull([Previouscost-June],0)+
isnull([Previouscost-July],0)+
isnull([Previouscost-August],0)+
isnull([Previouscost-September],0)+
isnull([Previouscost-October],0)+
isnull([Previouscost-November],0)+
isnull([Previouscost-December],0)) as [costdifferencebetweenyear],
(isnull([Currentunits-January],0)+
isnull([Currentunits-February],0)+
isnull([Currentunits-March],0)+
isnull([Currentunits-April],0)+
isnull([Currentunits-May],0)+
isnull([Currentunits-June],0)+
isnull([Currentunits-July],0)+
isnull([Currentunits-August],0)+
isnull([Currentunits-September],0)+
isnull([Currentunits-October],0)+
isnull([Currentunits-November],0)+
isnull([Currentunits-December],0)) -
(isnull([Previousunits-January],0)+
isnull([Previousunits-February],0)+
isnull([Previousunits-March],0)+
isnull([Previousunits-April],0)+
isnull([Previousunits-May],0)+
isnull([Previousunits-June],0)+
isnull([Previousunits-July],0)+
isnull([Previousunits-August],0)+
isnull([Previousunits-September],0)+
isnull([Previousunits-October],0)+
isnull([Previousunits-November],0)+
isnull([Previousunits-December],0)) as [unitsdifferencebetweenyear],
(((isnull([Currentcost-January],0)+
isnull([Currentcost-February],0)+
isnull([Currentcost-March],0)+
isnull([Currentcost-April],0)+
isnull([Currentcost-May],0)+
isnull([Currentcost-June],0)+
isnull([Currentcost-July],0)+
isnull([Currentcost-August],0)+
isnull([Currentcost-September],0)+
isnull([Currentcost-October],0)+
isnull([Currentcost-November],0)+
isnull([Currentcost-December],0)) -
(isnull([Previouscost-January],0)+
isnull([Previouscost-February],0)+
isnull([Previouscost-March],0)+
isnull([Previouscost-April],0)+
isnull([Previouscost-May],0)+
isnull([Previouscost-June],0)+
isnull([Previouscost-July],0)+
isnull([Previouscost-August],0)+
isnull([Previouscost-September],0)+
isnull([Previouscost-October],0)+
isnull([Previouscost-November],0)+
isnull([Previouscost-December],0)))/
(isnull([Previouscost-January],0)+
isnull([Previouscost-February],0)+
isnull([Previouscost-March],0)+
isnull([Previouscost-April],0)+
isnull([Previouscost-May],0)+
isnull([Previouscost-June],0)+
isnull([Previouscost-July],0)+
isnull([Previouscost-August],0)+
isnull([Previouscost-September],0)+
isnull([Previouscost-October],0)+
isnull([Previouscost-November],0)+
isnull([Previouscost-December],0)))* 100 as Costincrease,
((((isnull([Currentunits-January],0)+
isnull([Currentunits-February],0)+
isnull([Currentunits-March],0)+
isnull([Currentunits-April],0)+
isnull([Currentunits-May],0)+
isnull([Currentunits-June],0)+
isnull([Currentunits-July],0)+
isnull([Currentunits-August],0)+
isnull([Currentunits-September],0)+
isnull([Currentunits-October],0)+
isnull([Currentunits-November],0)+
isnull([Currentunits-December],0)) -
(isnull([Previousunits-January],0)+
isnull([Previousunits-February],0)+
isnull([Previousunits-March],0)+
isnull([Previousunits-April],0)+
isnull([Previousunits-May],0)+
isnull([Previousunits-June],0)+
isnull([Previousunits-July],0)+
isnull([Previousunits-August],0)+
isnull([Previousunits-September],0)+
isnull([Previousunits-October],0)+
isnull([Previousunits-November],0)+
isnull([Previousunits-December],0)))/ 
(isnull([Previousunits-January],0)+
isnull([Previousunits-February],0)+
isnull([Previousunits-March],0)+
isnull([Previousunits-April],0)+
isnull([Previousunits-May],0)+
isnull([Previousunits-June],0)+
isnull([Previousunits-July],0)+
isnull([Previousunits-August],0)+
isnull([Previousunits-September],0)+
isnull([Previousunits-October],0)+
isnull([Previousunits-November],0)+
isnull([Previousunits-December],0))) * 100) as unitsincrease
from SeventhCTE)
 
/* select cast((((CurrentyearCost - PreviousyearCost)/PreviousyearCost)*100) as FLOAT) as costincrease,
 		cast((((currentyearunits - previousyearunits)/(previousyearunits))*100) as Float) as Unitsincrease
 from EighthCTE*/
 --select * from EighthCTE
/*  select (((CurrentyearCost - PreviousyearCost)/(PreviousyearCost))*100) as costincrease,
 		(((currentyearunits - previousyearunits)/(previousyearunits),100) as Unitsincrease,
 		(CurrentyearCost * PreviousyearCost),
 		(CurrentyearCost * PreviousyearCost),**/
 		
select (((CurrentyearCost - PreviousyearCost)/(PreviousyearCost))*100) as costincrease, 
cast((((cast(currentyearunits as float)) -(cast(previousyearunits as float))) 
/cast(previousyearunits as float))*100.00 as float) as unitsincrease
 ,* from EighthCTE
 
