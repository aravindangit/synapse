declare @clientId AS int = (select ClientId from client) ;
select
    ifm.ClientId
                    , dft.Name ImportType
                    , ifm.ClientImportCode FileName
                    , dfl.ImportedDate ImportDate
                    , ifft.Description FrequencyDescription
                    , dfl.BeginDate DataStart
                    , dfl.EndDate DataEnd
                    , case when datediff(d, dfl.ImportedDate, getdate()) >= ifft.WarningDayThreshold then 1 else 0 end RaiseWarning
                    , ifft.WarningDayThreshold
from DataFeedLog dfl
    join ImportFileIDMapping ifm on dfl.ImportFileMapId = ifm.ImportFileMapId
    join ImportFileFrequencyType ifft on ifm.ImportFileFrequencyTypeId = ifft.ImportFileFrequencyTypeId
    join DataFeedType dft on dfl.DataFeedTypeId = dft.DataFeedTypeId
    join (
	                select ifm.ClientImportCode,
        max(dfl.ImportedDate) ImportedDate
    from DataFeedLog dfl
        join ImportFileIDMapping ifm on dfl.ImportFileMapId = ifm.ImportFileMapId
    where ifm.ClientId is null or ifm.ClientId = @clientId
    --Param
    group by ifm.ClientImportCode
	                ) gdfl on gdfl.ClientImportCode = ifm.ClientImportCode and gdfl.ImportedDate = dfl.ImportedDate
order by dfl.ImportedDate desc


select * from [dbo].[ImportFileIDMapping]


--dependencies of the stored procedure

select * from sys.dm_sql_referencing_entities('dbo.DataFeedLog','object')
--sp_depends 'pass stored procedure'
select * from sys.dm_sql_referenced_entities('dbo.DataFeedLog','object')