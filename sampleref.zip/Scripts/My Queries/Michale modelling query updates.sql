
 ------Tweaking-----------------------------------------------------------
declare @clientId as int = (
select
	ClientId
from
	client);

declare @jCode as varchar(10) = 'J0135';

SELECT
	JCode ,
	ClientId ,
	QuarterDate,
	PriceList ,
	CustomerId ,
	SUM(SalesQty) AS 'SalesQty' ,
	SUM(Cost) AS 'Cost' ,
	SUM(DispQty) AS 'DispQty'
FROM
	(
	SELECT
		ptg.PriceTypeGroupDescription AS 'PriceList' ,
		c.ClientId ,
		asp.QuarterDate ,
		c.CustomerId ,
		s.Qty AS 'SalesQty' ,
		s.Qty*s.UnitPrice AS 'Cost' ,
		asp.HcpcsCode AS 'JCode' ,
		asp.BillableUnitsPer11DigitNDC*s.Qty AS 'DispQty'
	FROM
		Sales s
	JOIN Customer c ON
		s.CustomerId = c.CustomerId
		AND s.ClientId = c.ClientId
		--If we ignore QuarterDate and join to CurrentRecord instead, we will always get sales data, but the price may not be as accurate as historical prices
		--first       JOIN AspPriceAndLimits asp ON asp.Ndc = s.Ndc  AND asp.QuarterDate = s.QuarterDate
		--              or (AspPriceAndLimits asp ON asp.Ndc = s.Ndc  AND asp.IsCurrentRecords = 1)
	JOIN AspPriceAndLimits asp ON
		CASE
			WHEN (asp.Ndc = s.Ndc) AND (asp.QuarterDate = s.QuarterDate) THEN 1
			WHEN (asp.Ndc = s.Ndc) AND (asp.IsCurrentRecords = 1) THEN 1
		END = 1
		--        JOIN AspPriceAndLimits asp ON asp.Ndc = s.Ndc  AND 							
		--				(CASE WHEN asp.QuarterDate = s.QuarterDate THEN 
		--				  WHEN asp.aIsCurrentRecords = 1 THEN
		--		END)
	JOIN PriceTypeGroup ptg ON
		ptg.PriceTypeGroupId = s.PriceTypeGroupId
	WHERE
		s.ClientId = @clientId
		and asp.HcpcsCode = @jCode ) TOTALS
GROUP BY
	JCode ,
	ClientId ,
	QuarterDate ,
	PriceList ,
	CustomerId
                        
