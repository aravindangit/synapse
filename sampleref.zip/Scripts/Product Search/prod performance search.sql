
declare @clientId int = (select clientid from Client ),@pageNumber int = 0,@pageSize int = 500,@filterToClientCatalog bit= 'false',@sortColumn varchar(20) = 'ItemDescription',@sortDirection varchar(20) ='asc',
@genericDrugFilter bit = null,@filterTohas340bPrice bit= 'false',@filterToInventory bit= 'false',@filterToChannels bit= 'false',@filterToClientActive bit= 'false',@filterToClientInactive bit= 'false',
@filterToShortage varchar(20) = null,@searchTerm_0 varchar(20) = 'infliximab',@PremierRelation_0 varchar(20) = '';
drop table if exists #searchresults;
            select
                 pi.ItemId Id
	            ,pi.ItemUId
	            ,pi.Manufacturer
	            ,pi.ItemDescription
	            ,pi.PackageDescription PkgDescription
                ,pi.PackageSize
	            ,pi.DrugName BrandName
                ,ob.OrangeBookCode
                ,ahfs.AhfsCode
	            ,pi.Ingredients GenericName
	            ,pi.Ndc
	            ,pi.PricingKey
	            ,cis.Supplier
	            ,cii.QuantityOnHand Inventory
	            ,ci.ClientItemStatus Status
                ,ci.Formulary FormularyStatus
	            ,pis.Shortage ShortageStatus
                ,pi.DrugStrength + pi.DrugStrengthUOM as DrugStrength
	            ,df.DosageFormAbbreviation as DosageForm
                ,asp.HcpcsCode
                ,cst.CatalogStatusTypeId [CatalogStatus]
				,case when st.Purchased is not null then st.Purchased else 'Not Purchased' end as 'Purchased'
				,c.Premier_Relation 'PremierRelation'
				,c.SPC as ServiceProviderClass
         --   into #searchResults
            from dbo.PharmacyItem pi
                left join ItemMaster.DosageForm df ON pi.dosageFormId = df.dosageFormId
	            inner join CustomerItem ci on ci.ItemId = pi.ItemId and ci.ClientId = ci.ClientId
				left join Customer c on c.ClientId = ci.ClientId
                left join CatalogStatusType cst on ci.ClientItemStatus = cst.Description
	            left join CustomerItemSupplier cis on cis.ClientId = ci.ClientId and cis.ItemId = pi.ItemId
                left join AspPriceAndLimits asp on pi.ItemId = asp.ItemId and asp.IsCurrentRecords = 1
                left join ItemMaster.OrangeBook ob on ob.OrangeBookId = pi.OrangeBookId
                left join PharmacyItemAhfs pia on pia.ItemId = pi.ItemId
                    and pia.Status = 'A'
                left join ItemMaster.AHFS ahfs on ahfs.AhfsId = pia.AhfsId
	            left join (select cii.ItemId
	                    ,cii.ClientId
	                    ,sum(cii.QuantityOnHand) QuantityOnHand
                    from CustomerItemInventory cii
                    where cii.InventoryTypeId < 4 --Only include items where inventory type is not other
                    group by cii.ItemId
	                    ,cii.ClientId
	            ) cii on cii.ItemId = pi.ItemId and cii.ClientId = ci.ClientId
	            left join (select pisg.ItemId
					            ,stuff(
						            (select N', ' + pis.Source
						            from PharmacyItemShortage pis
						            where pis.ItemId = pisg.ItemId
						            for xml path(N''), type).value(N'.[1]', N'nvarchar(max)'), 1, 1, N''
					            ) Shortage
				            from PharmacyItemShortage pisg
				            where pisg.ItemId is not null
					            and pisg.Status != 'R'
				            group by pisg.ItemId
	            ) pis on pis.ItemId = pi.ItemId
				left join
				 ( select distinct st.Ndc,st.ItemId
                            ,case when sum(st.[1YearQtyOrdered]) != 0 then 'Purchased' else 'Not Purchased' end as Purchased
                    from SalesTotals st group by st.Ndc,st.ItemId
                    ) st on st.Ndc = pi.Ndc and st.ItemId = pi.ItemId
	            left join (select cip.ItemId
				            from CustomerItemPricing cip
				            where cip.PriceListId = 2 --340B
					            and cip.Status = 'A'
					            and cip.ClientId = @clientId --Param
				            group by cip.ItemId
	            ) cip on cip.ItemId = pi.ItemId
                --WHAT IS THE PURPOSE HERE?
	            left join (select pi2.itemid, count(*) as channels
			            from customeritempricing cip2
			            join pharmacyitem pi2 ON cip2.itemid = pi2.itemid
			            where cip2.cpsupplierid <> 2 and cip2.pricelistid = 11 and cip2.status = 'A' and cip2.ClientId = @clientId
			            group by pi2.itemid
	            ) as chn ON pi.itemid = chn.itemid
            where (ci.clientId is null or ci.clientId = @clientId) --Param
	            and pi.Manufacturer is not null--TODO: Removing all items with no mfg. Is this ok???
	            and (@filterToClientCatalog = 0 or ci.CustomerItemId is not null) --Param
                and (@genericDrugFilter is null or pi.IsGenericDrug = @genericDrugFilter) --Param
	            and (@filterTohas340bPrice = 0 or cip.ItemId is not null) --Param
                and (@filterToInventory = 0 or cii.QuantityOnHand > 0) --Param
                and (@filterToChannels = 0 or chn.channels > 1) --Param
                and (@filterToClientActive = 0 or ci.ClientItemStatus = 'Active')
                and (@filterToClientInactive = 0 or ci.ClientItemStatus = 'Inactive')
                and (
                    @filterToShortage is null or 
                    (@filterToShortage=1 and pis.Shortage IS NOT NULL) or
                    (@filterToShortage=0 and pis.Shortage IS NULL))
                and (contains ((pi.Ndc, pi.DrugName, pi.Ingredients, pi.ItemDescription, pi.Manufacturer, pi.Ndc10, pi.Ndc11, pi.GpiDrugName), @searchTerm_0) or contains ((asp.HcpcsCode), @searchTerm_0))

            ;with filteredResults as (
	            select distinct pt.Id
                    ,pt.ItemUId
		            ,pt.Manufacturer
		            ,pt.ItemDescription
		            ,pt.PkgDescription
		            ,pt.BrandName
                    ,pt.OrangeBookCode
		            ,pt.GenericName
		            ,pt.Ndc
		            ,pt.PricingKey
		            ,pt.Supplier
		            ,pt.Inventory
		            ,pt.Status
		            ,pt.ShortageStatus
		            ,pt.FormularyStatus
		            ,pt.DrugStrength
		            ,pt.DosageForm
		            ,pt.PackageSize
                    ,pt.CatalogStatus
					,pt.Purchased
					,pt.PremierRelation
					,pt.ServiceProviderClass
	            from (
		            select sr.Id
                        ,sr.ItemUId
			            ,sr.Manufacturer
			            ,sr.ItemDescription
			            ,sr.PkgDescription
			            ,sr.BrandName
                        ,sr.OrangeBookCode
                        ,sr.AhfsCode
			            ,sr.GenericName
			            ,sr.Ndc
			            ,sr.PricingKey
			            ,sr.Supplier
			            ,sr.Inventory
			            ,sr.Status
			            ,sr.ShortageStatus
			            ,sr.FormularyStatus
			            ,sr.DrugStrength
			            ,sr.DosageForm
			            ,sr.PackageSize
                        ,sr.CatalogStatus
						,sr.Purchased
						,sr.PremierRelation
						,sr.ServiceProviderClass
			            ,eat.Description
			            ,eav.Value
		            from #searchResults sr
			            left join EntityAttributeValue eav on sr.ItemUId = eav.EntityId
			            left join EntityAttributeType eat on eav.EntityAttributeTypeId = eat.EntityAttributeTypeId
	            )
                
                pt
	            where 1 = 1
		            
                    
            )

            select sr.Id
                ,sr.ItemUId
	            ,sr.Manufacturer
	            ,sr.ItemDescription
	            ,sr.PkgDescription
	            ,sr.BrandName
                ,sr.OrangeBookCode
	            ,sr.GenericName
	            ,sr.Ndc
	            ,sr.PricingKey
	            ,sr.Supplier
	            ,sr.Inventory
	            ,sr.Status
	            ,sr.ShortageStatus
                ,sr.FormularyStatus
                ,sr.CatalogStatus
	            ,src.SearchResultCount
				,sr.Purchased
				,sr.PremierRelation
				,sr.ServiceProviderClass
            from filteredResults sr
	            join (select count(1) SearchResultCount from filteredResults) src on 1 = 1
            order by 
	            case when @sortColumn = 'Id' and @sortDirection = 'asc' then sr.Id end,
	            case when @sortColumn = 'Id' and @sortDirection = 'desc' then sr.Id end desc,
	            case when @sortColumn = 'Manufacturer' and @sortDirection = 'asc' then sr.Manufacturer end,
	            case when @sortColumn = 'Manufacturer' and @sortDirection = 'desc' then sr.Manufacturer end desc,
	            case when @sortColumn = 'ItemDescription' and @sortDirection = 'asc' then sr.ItemDescription end,
	            case when @sortColumn = 'ItemDescription' and @sortDirection = 'desc' then sr.ItemDescription end desc,
	            case when @sortColumn = 'PkgDescription' and @sortDirection = 'asc' then sr.PkgDescription end,
	            case when @sortColumn = 'PkgDescription' and @sortDirection = 'desc' then sr.PkgDescription end desc,
	            case when @sortColumn = 'BrandName' and @sortDirection = 'asc' then sr.BrandName end,
	            case when @sortColumn = 'BrandName' and @sortDirection = 'desc' then sr.BrandName end desc,
	            case when @sortColumn = 'OrangeBookCode' and @sortDirection = 'asc' then sr.OrangeBookCode end,
	            case when @sortColumn = 'OrangeBookCode' and @sortDirection = 'desc' then sr.OrangeBookCode end desc,
	            case when @sortColumn = 'GenericName' and @sortDirection = 'asc' then sr.GenericName end,
	            case when @sortColumn = 'GenericName' and @sortDirection = 'desc' then sr.GenericName end desc,
	            case when @sortColumn = 'Ndc' and @sortDirection = 'asc' then sr.Ndc end,
	            case when @sortColumn = 'Ndc' and @sortDirection = 'desc' then sr.Ndc end desc,
	            case when @sortColumn = 'PricingKey' and @sortDirection = 'asc' then sr.PricingKey end,
	            case when @sortColumn = 'PricingKey' and @sortDirection = 'desc' then sr.PricingKey end desc,
	            case when @sortColumn = 'Supplier' and @sortDirection = 'asc' then sr.Supplier end,
	            case when @sortColumn = 'Supplier' and @sortDirection = 'desc' then sr.Supplier end desc,
	            case when @sortColumn = 'Inventory' and @sortDirection = 'asc' then sr.Inventory end,
	            case when @sortColumn = 'Inventory' and @sortDirection = 'desc' then sr.Inventory end desc,
	            case when @sortColumn = 'Status' and @sortDirection = 'asc' then sr.Status end,
	            case when @sortColumn = 'Status' and @sortDirection = 'desc' then sr.Status end desc,
	            case when @sortColumn = 'ShortageStatus' and @sortDirection = 'asc' then sr.ShortageStatus end,
	            case when @sortColumn = 'ShortageStatus' and @sortDirection = 'desc' then sr.ShortageStatus end desc,
                case when @sortColumn = 'FormularyStatus' and @sortDirection = 'asc' then sr.FormularyStatus end,
	            case when @sortColumn = 'FormularyStatus' and @sortDirection = 'desc' then sr.FormularyStatus end desc,
                case when @sortColumn = 'CatalogStatus' and @sortDirection = 'asc' then sr.CatalogStatus end,
	            case when @sortColumn = 'CatalogStatus' and @sortDirection = 'desc' then sr.CatalogStatus end desc
            offset @pageNumber * @pageSize rows --Param
            fetch next @pageSize rows only; select distinct pt.DrugStrength
                ,pt.Manufacturer
                ,pt.BrandName
                ,pt.OrangeBookCode
                ,pt.AhfsCode
                ,pt.Ingredient
                ,pt.PkgDescription
                ,pt.PackageSize
                ,pt.DosageForm
				,pt.Purchased
				,pt.PremierRelation
				,pt.ServiceProviderClass
	            
            from (
	            select sr.DrugStrength
		            ,sr.Manufacturer
		            ,sr.BrandName
                    ,sr.OrangeBookCode
                    ,sr.AhfsCode
		            ,ni.IngredientDrugName as Ingredient
		            ,sr.PkgDescription
		            ,sr.PackageSize
		            ,sr.DosageForm
					,sr.Purchased
					,sr.PremierRelation
					,sr.ServiceProviderClass
		            ,eat.Description
		            ,eav.Value
	            from #searchResults sr
		            left join EntityAttributeValue eav on sr.ItemUId = eav.EntityId
		            left join EntityAttributeType eat on eav.EntityAttributeTypeId = eat.EntityAttributeTypeId
                    left join ItemMaster.NdcIngredients ni on sr.Id = ni.ItemId
	            ) 
                
	            pt;