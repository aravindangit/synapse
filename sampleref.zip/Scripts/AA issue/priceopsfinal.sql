

CREATE PROCEDURE [dbo].[CreatePriceOpps_Premier]
(
	@rundate DATETIME,
	@cogmult DECIMAL(10,4),
	@defaultSupplierId int
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON

DECLARE @wacid as int = 99999999;
DECLARE @apexus as int = 88888888;

DROP TABLE IF EXISTS cjm_margin_clientprices;
DROP TABLE IF EXISTS cjm_margin_0;
DROP TABLE IF EXISTS cjm_margin_1;
DROP TABLE IF EXISTS cjm_margin_2;
DROP TABLE IF EXISTS cjm_margin_3;
DROP TABLE IF EXISTS cjm_margin_4;
DROP TABLE IF EXISTS cjm_margin_5;
DROP TABLE IF EXISTS cjm_margin_6;

DROP TABLE IF EXISTS cjm_margin_3C;
DROP TABLE IF EXISTS cjm_margin_5C;
DROP TABLE IF EXISTS cjm_margin_6C;


SELECT
	cip.itemid
	, cip.ndc
	, cip.pricelistid
	, MAX(cip.priceamount) as price
	, MIN(cip.customeritempriceid) as cipid
--INTO dbo.cjm_margin_clientprices
FROM customeritempricing cip
JOIN (
	SELECT
		itemid
		, ndc
		, pricelistid
		, MAX(priceamount) as maxprice
	FROM customeritempricing
	GROUP BY
		itemid
		, ndc
		, pricelistid
) a ON  cip.priceamount = a.maxprice AND cip.pricelistid = a.pricelistid AND cip.itemid = a.itemid
GROUP BY
	cip.itemid
	, cip.ndc
	, cip.pricelistid;

SELECT
	s.itemid
	, c.customerid
	, wk.gpiname as drugname
	, pi.isgenericdrug as generic
	, CASE s.pricetypegroupid
		WHEN 1 THEN 4
		WHEN 2 THEN 2
		ELSE 3
	 END as pricelistid
	, pi.mfrid
	, pi.packagesize
	, pi.casepack
	, pi.pricingkey
	, s.ndc
	, pi.itemdescription
	, s.qty
	, s.unitprice
	, s.suppliername
	--, s.supplierid
	, s.supplierid as supp_0
--INTO dbo.cjm_margin_0
FROM sales s
	JOIN customer c on s.customerid = c.customerid
	JOIN pharmacyitem pi on s.itemid = pi.itemid
	JOIN [ItemMaster].[WkGpiDescriptions] wk ON LEFT(pi.gpi, 10) = wk.gpicodesegment
WHERE s.transactiondate > '2022-10-01 00:00:00.000' (SELECT MAX(rundate) FROM mv.priceoppsfinal);
SELECT MAX(rundate) FROM mv.priceoppsfinal

SELECT MAX(rundate) FROM mv.priceoppsfinal

select distinct rundate from mv.PriceOppsFinal

select max(transactiondate) from dbo.sales

SELECT
	s.itemid
	, s.customerid
	, s.supp_0
	, s.generic
	, s.pricelistid
	, MAX(s.drugname) as drugname
	, MAX(s.mfrid) as mfrid
	, MAX(s.packagesize) as packsize
	, MAX(s.casepack) as casepack
	, MAX(s.pricingkey) as pricingkey
	, MAX(s.ndc) as ndc
	, MAX(s.itemdescription) as itemdescription
	, SUM(s.qty) AS qty
	, CASE WHEN SUM(s.qty) = 0 THEN 0 ELSE SUM(s.unitprice * s.qty) / SUM(s.qty) END as avgprice
	, MAX(s.unitprice) as maxprice
--INTO dbo.cjm_margin_1
FROM cjm_margin_0 s
GROUP BY
	s.itemid
	, s.customerid
	, s.supp_0
	, s.generic
	, s.pricelistid

--get original catalog entry from cip for the item from sales
SELECT
	m.*
	, cip.itemid as 'item_0'
	, cip.customeritempriceid as 'cipid_0'
	, cip.pricelistid as 'pl_0'
	, cip.priceamount as 'listprice_0'
INTO dbo.cjm_margin_2
FROM cjm_margin_1 m
	LEFT JOIN customeritempricing cip ON 
		(
			(m.itemid = cip.itemid) 
			AND (m.pricelistid = cip.pricelistid) 
			AND (m.customerid = cip.customerid)
			--AND (m.maxprice = cip.priceamount) --temp fix until anthony fixes his mapping
			AND (m.supp_0 = cip.[CpSupplierId]) --this is the real line
		) 
WHERE 
	(cip.status = 'A' OR cip.status IS NULL)
ORDER BY m.itemid;

--IN THEORY, we should have less NULLs to clean up in Premier data than HCPharm data
--pricelist 4 comes from the national table
UPDATE m
SET 
	m.item_0 = m.itemid
	, m.cipid_0 = @wacid
	, pl_0 = 4
	, listprice_0 = nat.wacpackageprice * @cogmult
FROM cjm_margin_2 m
	JOIN nationalpharmacyitempricecurrent nat ON m.itemid = nat.itemid
WHERE (m.pricelistid = 4)
	AND cipid_0 IS NULL;


	--we are assuming 0 prices from mck are just the price in the sales file
UPDATE cjm_margin_2
SET listprice_0 = avgprice
WHERE listprice_0 = 0;


-- find all equivalents 
SELECT
	m.*
	, pi.itemid as 'item_1'
	, pi.ndc as 'ndc_1'
	, pi.mfrid as 'mfrid_1'
	, pi.packagesize as 'packsize_1'
	, pi.casepack as 'casepack_1'
	, pi.itemdescription as 'itemdescription_1'
INTO dbo.cjm_margin_3
FROM cjm_margin_2 m
	LEFT JOIN pharmacyitem pi ON (
		m.pricingkey = pi.pricingkey 
		AND m.ndc <> pi.ndc -- I don't want channel switches here
		AND m.generic = pi.isgenericdrug
		AND (pi.packagesizeuomid <> 3 OR (m.packsize = pi.packagesize))
	)
WHERE
	m.item_0 IS NOT NULL ;


-- join back to the customeritemprice table to get all the prices for all the equiv
SELECT
	m.*
	, cip.customeritempriceid as 'cipid_1'
	, m.supp_0 as 'supp_1'
	, cip.pricelistid as 'pl_1'
	, cip.priceamount as 'listprice_1'
	, ((packsize*casepack) / (packsize_1*casepack_1)) as 'equratio_1'
	, ((packsize*casepack) / (packsize_1*casepack_1)) * cip.priceamount as 'equprice_1'
INTO dbo.cjm_margin_4
FROM cjm_margin_3 m
	LEFT JOIN customeritempricing cip ON 
		(
			m.item_1 = cip.itemid 
			AND m.pricelistid = cip.pricelistid
			AND (m.customerid = cip.customerid OR cip.customerid IS NULL)
		) 
WHERE 
	(cip.status = 'A' OR cip.status IS NULL)
	AND (cip.priceamount > 0 OR cip.priceamount IS NULL); -- I can't do anything with 0 prices


--DECLARE @cogmult DECIMAL(10,4) = 0.9477;
--pl 4 comes from nat table
UPDATE m
SET 
	m.cipid_1 = @wacid
	, pl_1 = 4
	, listprice_1 = nat.wacpackageprice * @cogmult
	, equprice_1 = nat.wacpackageprice * @cogmult * equratio_1
FROM cjm_margin_4 m
	JOIN nationalpharmacyitempricecurrent nat ON m.item_1 = nat.itemid
WHERE (m.pricelistid = 4)
	AND cipid_1 IS NULL
	AND nat.wacpackageprice IS NOT NULL;


--Because the catalog is built off the past sales. We don't often have
--prices for equivalents for the specific customer. So instead, we are
--going to join to a table of max prices for a given ndc/pricelist
UPDATE m
SET
	m.cipid_1 = p.cipid
	, m.pl_1 = p.pricelistid
	, listprice_1 = p.price
	, equprice_1 = p.price * equratio_1
FROM cjm_margin_4 m
	JOIN cjm_margin_clientprices p ON m.item_1 = p.itemid AND m.pricelistid = p.pricelistid
WHERE
	m.cipid_1 IS NULL

--There are 0 prices in WAC and Mck data. Unmatch these
UPDATE cjm_margin_4
SET cipid_1 = NULL
	--, supp_1 = NULL
	, pl_1 = NULL
	, listprice_1 = NULL
	, equprice_1 = NULL
WHERE listprice_1 = 0;

--these are records matched back to the exact same record.
--THIS WILL DELETE DATA TAKEN FROM WAC/APEXIS???
DELETE FROM cjm_margin_4 
WHERE 
	cipid_0 <> @wacid AND 
	cipid_1 <> @wacid AND
	cipid_0 <> @apexus AND
	cipid_1 <> @apexus AND
	cipid_0 = cipid_1;

--for now delete unmatched records at the end of the process
DELETE FROM cjm_margin_4 WHERE cipid_1 IS NULL;
DELETE FROM cjm_margin_4 WHERE ndc=ndc_1;


SELECT m.*
	, s0.suppliername as 'sname_0'
	, s1.suppliername as 'sname_1'
	, mfr0.mfrname as 'mname_0'
	, mfr1.mfrname as 'mname_1'
	, listprice_0 - equprice_1 as 'pricediff'
	, (listprice_0 - equprice_1) * qty as 'opp'
INTO dbo.cjm_margin_5
FROM cjm_margin_4 m
	JOIN supplier s0 on m.supp_0 = s0.supplierid
	JOIN supplier s1 ON m.supp_1 = s1.supplierid
	JOIN manufacturer mfr0 ON m.mfrid = mfr0.mfrid
	JOIN manufacturer mfr1 ON m.mfrid_1 = mfr1.mfrid;

	
SELECT
	customerid
	, ndc
	, ndc_1
	, MAX(drugname) as 'drugname'
	, generic as 'generic'
	, MAX(itemdescription) as 'desc'
	, MAX(itemdescription_1) as desc_1
	, MAX(supp_0) as supp_0
	, MAX(supp_1) as supp_1
	, MAX(sname_0) as sname_0
	, MAX(sname_1) as sname_1
	, MAX(mname_0) as mname_0
	, MAX(mname_1) as mname_1
	, pricelistid
	, SUM(qty) as qty
	, AVG(listprice_0) as listprice_0
	, AVG(equprice_1) as equprice_1
	, AVG(pricediff) as pricediff
	, SUM(opp) as opp
	, MAX(cipid_0) as 'cipid_0'
	, MAX(cipid_1) as 'cipid_1'
INTO dbo.cjm_margin_6
FROM
	cjm_margin_5
GROUP BY
	customerid
	, ndc
	, item_0
	, ndc_1
	, item_1
	, generic
	, pricelistid
ORDER BY SUM(opp) DESC;


SELECT
	m.*
	, m.item_0 as 'item_1'
	, m.ndc as 'ndc_1'
	, m.mfrid as 'mfrid_1'
	, m.packsize as 'packsize_1'
	, m.casepack as 'casepack_1'
	, m.itemdescription as 'itemdescription_1'
	, cip.customeritempriceid as 'cipid_1'
	, COALESCE(cip.[CpSupplierId], @defaultSupplierId) as 'supp_1' --MCK
	, m.pl_0 as 'pl_1'
	, cip.priceamount as 'listprice_1'
	, 1.00 as 'equratio_1'
	, cip.priceamount as 'equprice_1'
INTO dbo.cjm_margin_3C
FROM cjm_margin_2 m
	LEFT JOIN customeritempricing cip ON m.item_0 = cip.itemid 
		AND m.pl_0 = cip.pricelistid
		AND (m.customerid = cip.customerid OR cip.customerid IS NULL)
WHERE
	cip.[CpSupplierId] IS NOT NULL
	AND m.supp_0 <> cip.[CpSupplierId];


SELECT m.*
	, s0.suppliername as 'sname_0'
	, s1.suppliername as 'sname_1'
	, mfr.mfrname as 'mname_0'
	, mfr.mfrname as 'mname_1'
	, listprice_0 - equprice_1 as 'pricediff'
	, (listprice_0 - equprice_1) * qty as 'opp'
INTO dbo.cjm_margin_5C
FROM cjm_margin_3C m
	JOIN supplier s0 ON m.supp_0 = s0.supplierid
	JOIN supplier s1 ON m.supp_1 = s1.supplierid
	JOIN manufacturer mfr ON m.mfrid = mfr.mfrid


SELECT
	customerid
	, ndc
	, ndc_1
	, MAX(drugname) as 'drugname'
	, generic as 'generic'
	, MAX(itemdescription) as 'desc'
	, MAX(itemdescription_1) as desc_1
	, MAX(supp_0) as supp_0
	, MAX(supp_1) as supp_1
	, MAX(sname_0) as sname_0
	, MAX(sname_1) as sname_1
	, MAX(mname_0) as mname_0
	, MAX(mname_1) as mname_1
	, pricelistid
	, SUM(qty) as qty
	, AVG(listprice_0) as listprice_0
	, AVG(equprice_1) as equprice_1
	, AVG(pricediff) as pricediff
	, SUM(opp) as opp
	, MAX(cipid_0) as cipid_0
	, MAX(cipid_1) as cipid_1
INTO dbo.cjm_margin_6C
FROM
	cjm_margin_5C
GROUP BY
	customerid
	, ndc
	, ndc_1
	, generic
	, pricelistid
ORDER BY SUM(opp) DESC;


--DROP TABLE MV.PriceOppsDetail;
INSERT INTO MV.PriceOppsDetail
SELECT *
--INTO MV.PriceOppsDetail
FROM
	(SELECT *, CAST(@rundate as DATETIME) as 'insertdate', 0 as 'equ_or_switch', ndc + '/' + ndc_1 + '/X/X' as tkey FROM cjm_margin_6
	UNION
	SELECT *, CAST(@rundate as DATETIME) as 'insertdate', 1 as 'equ_or_switch', ndc + '/' + ndc_1 + '/' + CAST(supp_0 AS varchar) + '/' + CAST(supp_1 AS varchar) as tkey FROM cjm_margin_6C) a


--DROP TABLE MV.PriceOppsFinal;
INSERT INTO MV.PriceOppsFinal
SELECT * 
--INTO MV.PriceOppsFinal
FROM 
(
SELECT 
	*
	, COALESCE([2], 0) as '340b'
    , COALESCE([4], 0) as 'wac'
	, COALESCE([3], 0) + COALESCE([6], 0) +  COALESCE([7], 0) as 'gpo'
	, COALESCE([2], 0) + COALESCE([3], 0) + COALESCE([4], 0) + COALESCE([6], 0) + COALESCE([7], 0) as 'total' 
FROM (
	SELECT 
		ndc
		, ndc_1
		, pricelistid
		, MAX(drugname) as drugname
		, generic
		, MAX([desc]) as 'desc'
		, MAX(desc_1) as 'desc_1'
		, MAX(supp_0) as 'supp_0'
		, MAX(supp_1) as 'supp_1'
		, MAX(sname_0) as 'sname_0'
		, MAX(sname_1) as 'sname_1'
		, MAX(mname_0) as 'mname_0'
		, MAX(mname_1) as 'mname_1'
		, SUM(opp) as 'opp'
		, equ_or_switch as 'equ_or_switch'
		, tkey as 'tkey'
		, MAX(@rundate) as 'rundate'
	FROM MV.PriceOppsDetail
	WHERE insertdate = @rundate
	GROUP BY
		ndc
		, ndc_1
		, pricelistid
		, generic
		, equ_or_switch
		, tkey
) d
PIVOT (
	SUM(opp) 
	FOR pricelistid IN ([2], [3], [4], [6], [7])
) as pvt
) x;


-- adding drop temp tables to keep db clean
DROP TABLE IF EXISTS cjm_margin_clientprices;
DROP TABLE IF EXISTS cjm_margin_0;
DROP TABLE IF EXISTS cjm_margin_1;
DROP TABLE IF EXISTS cjm_margin_2;
DROP TABLE IF EXISTS cjm_margin_3;
DROP TABLE IF EXISTS cjm_margin_4;
DROP TABLE IF EXISTS cjm_margin_5;
DROP TABLE IF EXISTS cjm_margin_6;

DROP TABLE IF EXISTS cjm_margin_3C;
DROP TABLE IF EXISTS cjm_margin_5C;
DROP TABLE IF EXISTS cjm_margin_6C;

END

select * from mv.priceoppsfinal



DECLARE @RC int

DECLARE @begin datetime

DECLARE @end datetime

DECLARE @cogmult decimal(10,4)

DECLARE @defaultSupplierId int



-- TODO: Set parameter values here.
SET @begin = '2022-07-01';
--set @end = '2022-07-02';
SET @end = Getdate();
SET @cogmult = .9477;
SET @defaultSupplierId = 1;

EXECUTE @RC = [dbo].[CreatePriceOpps_Premier_MultiDay] @begin,@end, @cogmult, @defaultSupplierId
GO

select * from mv.PriceOppsFinal


