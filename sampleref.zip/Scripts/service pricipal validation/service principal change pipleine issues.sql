
DELETE FROM   dbo.Sales
DELETE FROM   dbo.SalesArchive
DELETE FROM   Contract.SubContractItem
DELETE FROM   ItemMaster.FdaProductApplications
DELETE FROM   ItemMaster.FdaProductExclusivity
DELETE FROM   ItemMaster.FdaProductPatent
DELETE FROM   ItemMaster.NdcIngredients
DELETE FROM   dbo.PharmacyItemAttributes
DELETE FROM   dbo.PharmacyItemShortage


select * from dbo.pharmacyitem

select * from itemmaster.NdcIngredientsdebugissue


select ni.ItemUId, im.ItemId, ni.[Ndc], ni.IngredientDrugName, ni.IngredientStrengthValue, ni.IngredientStengthUom
from itemmaster.NdcIngredientsdebugissue ni 
   join [dbo].[ItemMaster] im 
     on ni.ItemUId = im.ItemUId 
     order by im.itemid DESC
   --  and im.itemid not in (select itemid from dbo.pharmacyitem)

     select * from dbo.pharmacyitem

     select * from  itemmaster.NdcIngredientsdebugissue
     
     with newcte as ( 
     select pi.ItemUId, im.itemid, pi.ItemId ItemMasterItemId, pi.ItemDescription, pi.ItemShortDescription, pi.Gtin, pi.Ndc, pi.Ndc10, pi.Ndc11,  pi.Ndc9, pi.NdcFormatCode, pi.PreviousNdc,
	            pi.ReplacedByNdc, pi.CasePack, pi.PackageSize, pi.PackageDescription, pi.DrugStrength, pi.DrugStrengthUom, pi.IsGenericDrug, pi.DrugName, pi.Ingredients,
	            pi.BrandNameTypeId, pi.UnitDoseId, pi.DosageFormId, pi.IsItemMultiSourced, pi.StorageConditionId, pi.RxNormNumber, pi.IsItemRepackaged, pi.IsItemHazardouMaterial,
	            pi.LabelerId, m.MfrId, pi.DeaClassId, pi.OrangeBookId, pi.PackageSizeUomId, pi.UnitOfMeasureId, pi.PurpleBookId, pi.GPI, pi.TypeOfBrandDesciption,
	            pi.DrugDescriptorId, pi.BioEquivalenceId, pi.DateAdded, pi.DateChanged, pi.DataSourceId, m.[MfrName] 'Manufacturer', pi.[isDiscontinued], pi.[GPIDrugNameCode], pi.[GpiDrugName]
	   from dbo.PharmacyItemdebugissue pi  inner join [dbo].[ItemMaster] im on pi.ItemUId = im.ItemUId
	       left join [dbo].[Manufacturer] m on pi.MfrId = m.[ItemMasterMfrId]),
           newcte1 as (
               select * from dbo.pharmacyitem
           )
           select n.*
           from newcte n join newcte1 n1 on n.ItemUId = n1.itemuid

           select * from pharmacyitem


           truncate table [dbo].[ItemMaster]
           delete from dbo.itemmaster
           select * from dbo.itemmaster

           

 delete from dbo.itemmaster
DBCC CHECKIDENT ('dbo.itemmaster', RESEED,0)




   select pi.ItemUId, im.itemid, pi.ItemId ItemMasterItemId, pi.ItemDescription, pi.ItemShortDescription, pi.Gtin, pi.Ndc, pi.Ndc10, pi.Ndc11,  pi.Ndc9, pi.NdcFormatCode, pi.PreviousNdc,
	            pi.ReplacedByNdc, pi.CasePack, pi.PackageSize, pi.PackageDescription, pi.DrugStrength, pi.DrugStrengthUom, pi.IsGenericDrug, pi.DrugName, pi.Ingredients,
	            pi.BrandNameTypeId, pi.UnitDoseId, pi.DosageFormId, pi.IsItemMultiSourced, pi.StorageConditionId, pi.RxNormNumber, pi.IsItemRepackaged, pi.IsItemHazardouMaterial,
	            pi.LabelerId, m.MfrId, pi.DeaClassId, pi.OrangeBookId, pi.PackageSizeUomId, pi.UnitOfMeasureId, pi.PurpleBookId, pi.GPI, pi.TypeOfBrandDesciption,
	            pi.DrugDescriptorId, pi.BioEquivalenceId, pi.DateAdded, pi.DateChanged, pi.DataSourceId, m.[MfrName] 'Manufacturer', pi.[isDiscontinued], pi.[GPIDrugNameCode], pi.[GpiDrugName]
	   from dbo.PharmacyItemdebugissue pi  inner join [dbo].[ItemMaster] im on pi.ItemUId = im.ItemUId
	       left join [dbo].[Manufacturer] m on pi.MfrId = m.[ItemMasterMfrId]
           order by im.itemid asc

           delete * from dbo.itemmaster

           select * from select * from dbo.ItemMaster im