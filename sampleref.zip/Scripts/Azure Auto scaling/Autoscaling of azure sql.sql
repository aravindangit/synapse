---ALTER DATABASE [DatabaseName] MODIFY (EDITION = �edition�, SERVICE_OBJECTIVE = �service objective�);



SELECT 
  DATABASEPROPERTYEX(db_name(),'edition') 
    AS ServiceTier,
  DATABASEPROPERTYEX(db_name(),'serviceobjective') 
    AS ComputeSize,
 
    
    DATABASEPROPERTYEX('NationalWholeSaler', 'MaxSizeInBytes') AS MaxSizeInBytes;
    
    
CREATE PROCEDURE [schema].[name procedure] AS 

ALTER DATABASE [DatabaseName] MODIFY (EDITION = 'Standard',  SERVICE_OBJECTIVE = 'S4');

select d.name,
       slo.*
       from sys.databases d 
       join sys.database_service_objectives slo
       on d.database_id = slo.database_id ;
      
      select d.name,
       slo.*
       from sys.databases d 
       join sys.database_service_objectives slo
       on d.database_id = slo.database_id ;
      
      
      
CREATE PROCEDURE [Premier].[Scaleup] AS 
ALTER DATABASE [NationalWholeSaler] MODIFY (EDITION = 'GeneralPurpose',  SERVICE_OBJECTIVE = 'GP_Gen5_6',
MAXSIZE=400GB);
--ALTER DATABASE MyDatabase MODIFY (EDITION='WEB', MAXSIZE=5GB)

select * from sys.database_service_objectives


select * from sys.databases



SELECT max_db_size_in_gb = 
    CASE WHEN serverproperty('EngineEdition') = 4 THEN
        CASE WHEN SERVERPROPERTY('productversion') between '10.50' and '5' THEN 10 ELSE 4 END
    ELSE -1 
    END

  ---cogrxdemo autoscaling
  ALTER DATABASE [CogRxDemo] MODIFY (EDITION = 'Standard',  SERVICE_OBJECTIVE = 'S4');     
      