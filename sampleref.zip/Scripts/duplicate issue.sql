select * from DELETE FROM table_name WHERE condition;

DELETE FROM dbo.Customer where CustomerId in (66,67,68)

delete from dbo.SalesTotals where CustomerId in (66,67,68)

delete from dbo.CustomerItemPricing where CustomerId in (66,67,68)

delete from dbo.SalesTotalMonthly where CustomerId in (66,67,68)

delete from CustomerItemPricingHistoryMonthly  where CustomerId in (66,67,68)


select * from dbo.



delete from dbo.CustomerPriceList where CustomerId in (66,67,68)


select * from dbo.ROI_Tracking

select * from dbo.PurchaseOrderHistory


select top 3 * from dbo.ROI_Tracking

select top 3  * from dbo.ROI_information

actual quanity

update raw.drug_shortage_alerts
set Date_Scored = getdate()
select * from raw.drug_shortage_alerts

ndc,division,facility,wholesaler,wholesaleraccountnumber,ROI_Track_Date,start, end
estimated,
actual roi

actual quanity ??

