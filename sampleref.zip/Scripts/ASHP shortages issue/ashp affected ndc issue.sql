/*
Investigation details
step 1 - processing of the following stored procedure - [RawASHP].[UpdateRawASHPShortageIds]

        impacted tables
        ===============
            [RawASHP].[ASHPShortageAffectedProduct]
            [RawASHP].[ASHPShortageAlternativeAgent]  
            [RawASHP].[ASHPShortageAlternativeAgentTable]   
            [RawASHP].[ASHPShortageAuthor]   
            [RawASHP].[ASHPShortageAvailableProduct]  
            [RawASHP].[ASHPShortageNoAvailableProductsNote] 
            [RawASHP].[ASHPShortagePatientCareImplications] 
            [RawASHP].[ASHPShortageReason] 
            [RawASHP].[ASHPShortageReference] 
            [RawASHP].[ASHPShortageResupplyEstimateNote] 
            [RawASHP].[ASHPShortageSafetyNote] 
step 2 - [RawASHP].[ImportRawASHPShortages]
        impacted tables
        =================
            [dbo].[ASHPShortage]
            [dbo].[ASHPShortage] 
            [dbo].[ASHPShortageAffectedProduct] 
            [dbo].[ASHPShortageAlternativeAgent] 
            [dbo].[ASHPShortageAlternativeAgentTable] 
            [dbo].[ASHPShortageAuthor] 
            [dbo].[ASHPShortageAvailableProduct] 
            [dbo].[ASHPShortageNoAvailableProductsNote] 
            [dbo].[ASHPShortagePatientCareImplications] 
            [dbo].[ASHPShortageReason] 
            [dbo].[ASHPShortageReference] 
            [dbo].[ASHPShortageResupplyEstimateNote] 
            [dbo].[ASHPShortageSafetyNote] 
          
step 3 - [dbo].[ImportASHPShortages]
step 4 - [dbo].[UpdateDiscontinuedPharmacyItems]
*/

declare @ndc varchar(20) ='63323049405';
            SELECT pis.Id
                 , pis.ItemId
                 , pis.Ndc
                 , pis.Source
                 , pis.STATUS
                 , pi.ItemDescription
                 , pis.UpdatedDate
                 --, affectedNdcs.Ndcs AvailableNdcs
                 --, availableNdcs.AvailableNdcs AffectedNdcs
                  , affectedNdcs.Ndcs AffectedNdcs
                 , availableNdcs.AvailableNdcs
                 , pis.ExternalLink
                 , pis.Reasons
                 , pis.EstimatedResupply
            FROM PharmacyItemShortage pis
                 JOIN PharmacyItem pi ON pis.ItemId = pi.ItemId
                 LEFT JOIN (
                    SELECT pisg.ExternalId
                         , STUFF(
                            (
                                --split each NDC by pipe, with optional description after tilda
                                SELECT N'|' + CASE
                                                  WHEN pii.ItemId IS NOT NULL
                                                  THEN dbo.FormatNdc(pisi.Ndc) + '~' + pii.ItemDescription
                                                  ELSE dbo.FormatNdc(pisi.Ndc)
                                              END Ndc
                                FROM PharmacyItemShortage pisi
                                --CROSS APPLY STRING_SPLIT(pisi.Ndcs, ',') AS pppa
                                     LEFT JOIN PharmacyItem pii ON pisi.Ndc = pii.Ndc
                                WHERE pisi.ExternalId = pisg.ExternalId
                                ORDER BY pii.ItemDescription FOR XML PATH(N''), TYPE
                            ).value(N'.[1]', N'nvarchar(max)'), 1, 1, N'') Ndcs
                    FROM PharmacyItemShortage pisg 
                    GROUP BY pisg.ExternalId
                ) affectedNdcs ON pis.ExternalId = affectedNdcs.ExternalId AND  pis.isActive = 1
                 LEFT JOIN (
                    SELECT pisg.Ndc
                         , STUFF((
                        --split each NDC by pipe, with optional description after tilda
                        SELECT N'|' + CASE
                                          WHEN pia.ItemId IS NOT NULL
                                          THEN dbo.FormatNdc(pissa.Value) + '~' + pia.ItemDescription
                                          ELSE dbo.FormatNdc(pissa.Value)
                                      END Ndc
                        FROM PharmacyItemShortage pisa
                             CROSS APPLY STRING_SPLIT(pisa.AvailableNdcs, ',') AS pissa
                             LEFT JOIN PharmacyItem pia ON pia.Ndc = dbo.FormatNdc(pissa.Value)
                        WHERE pisg.Ndc = pisa.Ndc AND pisa.isActive = 1
                        ORDER BY pia.ItemDescription FOR XML PATH(N''), TYPE
                    ).value(N'.[1]', N'nvarchar(max)'), 1, 1, N'') AvailableNdcs
                    FROM PharmacyItemShortage pisg where pisg.isActive = 1
                    GROUP BY pisg.Ndc
                ) availableNdcs ON pis.Ndc = availableNdcs.Ndc AND  pis.isActive = 1
            WHERE pis.Ndc = @ndc --ALTER TABLE and pis.isActive = 1; --Param




SELECT pisg.ExternalId
                         , STUFF(
                            (
                                --split each NDC by pipe, with optional description after tilda
                                SELECT N'|' + CASE
                                                  WHEN pii.ItemId IS NOT NULL
                                                  THEN dbo.FormatNdc(pisi.Ndc) + '~' + pii.ItemDescription
                                                  ELSE dbo.FormatNdc(pisi.Ndc)
                                              END Ndc
                                FROM PharmacyItemShortage pisi
                                --CROSS APPLY STRING_SPLIT(pisi.Ndcs, ',') AS pppa
                                     LEFT JOIN PharmacyItem pii ON pisi.Ndc = pii.Ndc
                                WHERE pisi.ExternalId = pisg.ExternalId
                                ORDER BY pii.ItemDescription FOR XML PATH(N''), TYPE
                            ).value(N'.[1]', N'nvarchar(max)'), 1, 1, N'') Ndcs
                    FROM PharmacyItemShortage pisg
                    GROUP BY pisg.ExternalId


                    select * from PharmacyItemShortage

                    select * from dbo.pharmacyitemshortage where ndc = '67457049215'





    select * from [Fda].[FDAShortage] where Genericname is null


    select * from dbo.PharmacyItemShortage where source = 'ASHP' and ExternalId IS null

SELECT * FROM DBO.PharmacyItem

    with FdaItems AS
(select  [dbo].[FormatNdc](ndc) 'NDC',
		 GenericName,
		 [DateofUpdate],
		 [RelatedInfoLink],
		 [DateDiscontinued],
		 [Status],
		 [ReasonforShortage],
		 [AvailabilityInformation],
		 [FDAShortageUID],
		 [InitialPostingDate],
		 [AddedDateTime]
 from [Fda].[FDAShortage] 
),
RankedFdaItems as 
(select NDC,
		GenericName,
		[DateofUpdate],
		[RelatedInfoLink],
		[DateDiscontinued],
		[Status],
		[ReasonforShortage],
		[AvailabilityInformation],
		[FDAShortageUID],
		[InitialPostingDate],
		[AddedDateTime],
		rank() over (partition by [InitialPostingDate], NDC   order by [AddedDateTime]  desc, [FDAShortageUID]) rnk
 from FdaItems
 where NDC is not null
)select * from RankedFdaItems where Genericname is null


select * from [dbo].[ASHPShortage]

select * from pharmacyitemshortage where source = 'ASHP'

select * from dbo.pharmacyitemshortage where ndc  = '63323049405'


SELECT *
FROM PharmacyItemShortage pisa
                             CROSS APPLY STRING_SPLIT(pisa.AvailableNdcs, ',') AS pissa
                             WHERE PISA.NDC = '63323049405'


===============================================================================================
select (case when item.[Ndc] is not null then item.[Ndc] else replace(AffectedProduct.[affectedProductNDC], '-','') end) as NDC,
					item.ItemId,
					itemMaster.[ItemUId],
				--	AffectedProduct.[affectedProducttextDescription] as ExternalId1,
					cast(shortage.[ASHPId] as varchar(2000)) as ExternalId,
					'ASHP' as Source,
					shortage.[lastRevisedDate] as [UpdatedDate],
					'' as [ExternalLink],
					(case when AffectedProduct.[affectedProductdiscontinued] = 'true'
											then 'D' 
											else (case when shortage.[shortageStatus] = 'Active' 
														then 'S' 
														else (case when shortage.[shortageStatus] in ('No Commercially Available Preparations',
																					'No Longer Available',
																					'Resolved')
																	then 'R' 
																	else ''
															end) 
													end) 
											end) as STATUS,
					(
								SELECT ', "'+[AvailableProductNDC] + '"'
								FROM [dbo].[ASHPShortageAvailableProduct] available
								WHERE available.[ASHPShortageId] = shortage.[ASHPShortageId]
								FOR XML PATH ('')
							) as [AvailableNdcs] ,
							(
								SELECT CONCAT('"' , [Reason1]
										, '", "' ,[Reason2]
										, '", "' ,[Reason3]
										, '", "' ,[Reason4]
										, '", "' ,[Reason5]
										, '", "' ,[Reason6]
										, '", "' ,[Reason7]
										, '", "' ,[Reason8]
										, '", "' ,[Reason9]
										, '", "' ,[Reason10]
										, '", "' ,[Reason11]
										, '", "' ,[Reason12]
										, '", "' ,[Reason13]
										, '", "' ,[Reason14]
										, '", "' ,[Reason15] , '"')
								FROM [dbo].[ASHPShortageReason] reason
								WHERE reason.[ASHPShortageId] = shortage.[ASHPShortageId]
							) as [Reasons],
							(SELECT CONCAT('"' , [ResupplyEstimateNote1]
								  , '", "' ,[ResupplyEstimateNote2]
								  , '", "' ,[ResupplyEstimateNote3]
								  , '", "' ,[ResupplyEstimateNote4]
								  , '", "' ,[ResupplyEstimateNote5]
								  , '", "' ,[ResupplyEstimateNote6]
								  , '", "' ,[ResupplyEstimateNote7]
								  , '", "' ,[ResupplyEstimateNote8]
								  , '", "' ,[ResupplyEstimateNote9]
								  , '", "' ,[ResupplyEstimateNote10] , '"')
							  FROM [dbo].[ASHPShortageResupplyEstimateNote] resupply
							  WHERE resupply.[ASHPShortageId] = shortage.[ASHPShortageId]) as  [EstimatedResupply],
							  (case when AffectedProduct.[affectedProductdiscontinued] = 'true'
											then 1
											else 0 end) as [isDiscontinued],
					0 as [isToBeDiscontinued],
					shortage.[shortageCreateDate] as InitialPostingDate,
					shortage.[ASHPShortageUID]
					from [dbo].[ASHPShortage] shortage 
					inner join [dbo].[ASHPShortageAffectedProduct] AffectedProduct on AffectedProduct.[ASHPShortageId] = shortage.[ASHPShortageId]
					left join [dbo].[PharmacyItem] item on item.[Ndc] = AffectedProduct.[affectedProductNDC] 
															or item.[Ndc10] = AffectedProduct.[affectedProductNDC]
															or item.[Ndc11] = AffectedProduct.[affectedProductNDC]
					left join dbo.ItemMaster itemMaster ON itemMaster.ItemId = item.ItemId 



select * from [dbo].[ASHPShortageAffectedProduct]  where ndc = '67457049215'