select count(*),clientid from CustomerItemPricing
--WHERE --PriceStartDate -- > '2019-09-01'
group by ClientId 

SELECT * FROM CustomerItemPricing WHERE ClientId = 5

  and tar.clientid in (select clientid from [dbo].[ImportFileIDMapping] where ClientImportCode = 'PremierWholesaleInvoice')
		  and tar.CpSupplierID in (select CpSupplierID from [dbo].[ImportFileIDMapping] where ClientImportCode = 'PremierWholesaleInvoice')
		  and tar.[CustomerId] in (select [CustomerId] from [dbo].[ImportFileIDMapping] where ClientImportCode = 'PremierWholesaleInvoice')
		  and tar.PriceListId in (select PriceListId from [dbo].[ImportFileIDMapping] where ClientImportCode = 'PremierWholesaleInvoice')
		  and tar.DataSourceId in (select DataSourceId from [dbo].[ImportFileIDMapping] where ClientImportCode = 'PremierWholesaleInvoice')
		  
		  
		  select count(*) from CustomerItemPricing where status = 'I'
		  
		  select * from [dbo].[ImportFileIDMapping]