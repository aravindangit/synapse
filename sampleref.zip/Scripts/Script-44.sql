WITH LatestPuchaseDate
                    AS (
                        SELECT customerid
                            , WholesalerAccountNumber  --00000000000000622942
                            , Ndc
                            , FORMAT(Max(TransactionDate), 'MM/dd/yyyy') AS Latestpurchasedate
							, PriceTypeGroupId
                        FROM dbo.Sales
                        WHERE qty > 0
                        --    AND ndc = '64764030020'
                        GROUP BY customerid
                            , WholesalerAccountNumber
                            , Ndc
							, PriceTypeGroupId
                        ),
                    custWan
                    AS (
                        SELECT l.customerid
                            , l.ndc
                            , l.wholesaleraccountnumber
                            , l.Latestpurchasedate
                            , s.qty
                            , s.unitprice
                            , s.InvoiceNumber
							, pl.PriceTypeGroupDescription
                           , ROW_NUMBER() OVER(partition by s.customerid,s.ndc,s.WholesalerAccountNumber,s.PriceTypeGroupId
                              ORDER BY InvoiceNumber desc,qty desc) AS rowlines
                        FROM LatestPuchaseDate l

                        JOIN sales s
                            ON s.CustomerId = l.CustomerId
                                AND s.WholesalerAccountNumber = l.WholesalerAccountNumber
                                AND s.ndc = l.Ndc
                                AND s.transactiondate = l.Latestpurchasedate
								AND s.PriceTypeGroupId = l.PriceTypeGroupId
								--join PriceList pl on pl.PriceListId = s.PriceTypeGroupId
								join PriceTypeGroup pl on pl.PriceTypeGroupId = s.PriceTypeGroupId
                                where s.qty > 0  
                        ),



                    WanAgg AS (
                            SELECT a.customerid
                                , a.ndc
								, a.PriceTypeGroupDescription
                                , STRING_AGG(a.Latestpurchasedate, ',') WITHIN
                            GROUP (
                                    ORDER BY a.customerid ASC
                                    ) AS Latestpurchasedate
                                , STRING_AGG(a.wholesaleraccountnumber, ',') WITHIN
                            GROUP (
                                    ORDER BY a.customerid ASC
                                    ) AS wholesaleraccountnumber
                                , STRING_AGG(a.qty, ',') WITHIN
                            GROUP (
                                    ORDER BY a.customerid ASC
                                    ) AS quantity
                                , STRING_AGG(a.unitprice, ',') WITHIN
                            GROUP (
                                    ORDER BY a.customerid ASC
                                    ) AS unitprice
                            FROM custWan a
                            where a.rowlines = 1
                            GROUP BY a.customerid
                                , a.ndc
								,a.PriceTypeGroupDescription
                            )
                            INSERT INTO DBO.salesWanAgg 
                            (customerid,NDC,PriceTypeGroupDescription
                            ,Latestpurchasedate,wholesaleraccountnumber
                            ,quantity,unitprice
                            ) SELECT customerid,NDC,PriceTypeGroupDescription
                            ,Latestpurchasedate,wholesaleraccountnumber
                            ,quantity,unitprice FROM WANAGG
  -- CogRxDemo.dbo.salesWanAgg definition

-- Drop table

-- DROP TABLE CogRxDemo.dbo.salesWanAgg;

CREATE TABLE CogRxDemo.dbo.salesWanAgg (
	customerid int NOT NULL,
	ndc varchar(11) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	PriceTypeGroupDescription varchar(30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Latestpurchasedate nvarchar(4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	wholesaleraccountnumber varchar(8000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	quantity nvarchar(4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	unitprice nvarchar(4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
);
 CREATE NONCLUSTERED INDEX salesWanAgg_customerid_IDX ON dbo.salesWanAgg (  customerid ASC  , ndc ASC  , PriceTypeGroupDescription ASC  )  
	 WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
	 ON [PRIMARY ] ;                              

                select 
                   ROW_NUMBER() OVER (
                   ORDER BY npp.[NationalPricePredictionGuid]
                   ) NPPId
                 , npp.[NationalPricePredictionId]
                 , npp.[NationalPricePredictionGuid]
                 , npp.[RecordSyncDate]
                 , npp.[IsActive]
                 , case when pis.IsShort is not null then pis.IsShort else 0 end as 'IsShort'
                 , npp.[Ndc]
                 , phi.ItemId
                 , phi.ItemDescription
                 , npp.[PriceDate]
                 , npp.[RunDate]
                 , npp.[TrainDate]
                 , npp.[WacUnitPrice]
                 , npp.[PeriodFirstIdentified]
                 --facility price info
                 , cip.CpSupplierID 'CpSupplierId'
                 , s.SupplierName 'Wholesaler'
                 , c.ClientId
                 , c.CustomerId
                 , c.Premier_Relation as PremierRelation
                 , dbo.fn_FacilityName(c.CustomerName, c.AccountNumber, c.Dea) 'FacilityName'
                 , dbo.fn_DivisionName(c.DivisionName, c.DivisionId) 'Division'
                 , cip.PriceAmount 'UnitPrice'
                 , ptg.PriceTypeGroupDescription 'AccountType'
                 , sum(isNull(st.[1YearUsageQty], 0)) 'YearQty'
                 , cast(sum(isnull(st.[1YearUsageQty], 0))as decimal (18,2))/4  'QuarterQty'
                 , cast(sum(isnull(st.[1YearUsageQty], 0))as decimal (18,2))/4 * cip.PriceAmount 'QuarterCost'
                 , sc.StorageConditionDescription
                 , gpid.GpiCodeSegment + ' - ' + replace(gpid.GpiName,'*','') 'GpiDrugGroup'
                -- , case when IPD.[Brand Drug Name] is null then 0 else 1 end as 'Potential_Generic'
                 -- verification current month
                 , npp.[Month0ProbabilityOfIncrease]
                 , npp.[Month0PredictedWacUnitPrice]
                 
                 -- month 1
                 , npp.[Month1ProbabilityOfIncrease]
                 , npp.[Month1PredictedWacUnitPrice]
                 , npp.[Month1PercentIncrease]
                 , npp.[Month1Period]
                 , dbo.fn_IncreaseMoneyByPercent(cip.PriceAmount, npp.Month1PercentIncrease) 'Month1PredictedUnitPrice'
                 , cast(sum(isnull(st.[1YearUsageQty], 0))as decimal (18,2))/4 * cast((cip.PriceAmount + (cip.PriceAmount * npp.Month1PercentIncrease)) as decimal(18, 2)) 'Month1PredictedQuarterCost'
                 , cast(sum(isnull(st.[1YearUsageQty], 0))as decimal (18,2))/4 * (cast((cip.PriceAmount + (cip.PriceAmount * npp.Month1PercentIncrease)) as decimal(18, 2)) - cip.PriceAmount) 'Month1PredictedQuarterSavings'
                 
                 --month 2
                 , npp.[Month2ProbabilityOfIncrease]
                 , npp.[Month2PredictedWacUnitPrice]
                 , npp.[Month2PercentIncrease]
                 , npp.[Month2Period]
                 , dbo.fn_IncreaseMoneyByPercent(cip.PriceAmount, npp.Month2PercentIncrease) 'Month2PredictedUnitPrice'
                 , cast(sum(isnull(st.[1YearUsageQty], 0))as decimal (18,2))/4 * cast((cip.PriceAmount + (cip.PriceAmount * npp.Month2PercentIncrease)) as decimal(18, 2)) 'Month2PredictedQuarterCost'
                 , cast(sum(isnull(st.[1YearUsageQty], 0))as decimal (18,2))/4 * (cast((cip.PriceAmount + (cip.PriceAmount * npp.Month2PercentIncrease)) as decimal(18, 2)) - cip.PriceAmount) 'Month2PredictedQuarterSavings'
                 
                 --month 3
                 , npp.[Month3ProbabilityOfIncrease]
                 , npp.[Month3PredictedWacUnitPrice]
                 , npp.[Month3PercentIncrease]
                 , npp.[Month3Period]
                 , dbo.fn_IncreaseMoneyByPercent(cip.PriceAmount, npp.Month3PercentIncrease) 'Month3PredictedUnitPrice'
                 , cast(sum(isnull(st.[1YearUsageQty], 0))as decimal (18,2))/4 * cast((cip.PriceAmount + (cip.PriceAmount * npp.Month3PercentIncrease)) as decimal(18, 2)) 'Month3PredictedQuarterCost'
                 , cast(sum(isnull(st.[1YearUsageQty], 0))as decimal (18,2))/4 * (cast((cip.PriceAmount + (cip.PriceAmount * npp.Month3PercentIncrease)) as decimal(18, 2)) - cip.PriceAmount) 'Month3PredictedQuarterSavings'                 
                 , wa.wholesalerAccountNumber
                 , c.DivisionId 
                 , ISNULL(BR.STATUS,'Not Reviewed') AS BRSTATUS
                 , wa.Latestpurchasedate
                 , wa.quantity
				 , wa.unitprice AS UtPrice                

                from [Predictive].[NationalPricePrediction] npp
                join PharmacyItem phi on phi.Ndc = npp.Ndc
                join CustomerItem ci on npp.Ndc = ci.Ndc
                join CustomerItemPricing cip on ci.Ndc = cip.Ndc
                                                and ci.ClientId = cip.ClientId
                join Supplier s on cip.CpSupplierID = s.SupplierId
                join Customer c on c.CustomerId = cip.CustomerId
                                   and c.ClientId = cip.ClientId                
                -- join to PriceList and PriceTypeGroup to use description to link purchases and prices  
                join PriceList pl on pl.PriceListId = cip.PriceListId				
                join PriceTypeGroup ptg on ptg.PriceTypeGroupDescription = pl.PriceListDescription
				join salesWanAgg wa on c.customerid = wa.customerid and wa.ndc = phi.ndc AND wa.PriceTypeGroupDescription = pl.PriceListDescription
                join SalesTotals st on npp.NDC = st.ndc
                                       and st.ClientId = ci.ClientId
                                       and st.CustomerId = cip.CustomerId
                                       and st.PriceTypeGroupId = ptg.PriceTypeGroupId
                                       and st.SupplierId = cip.CpSupplierID
                join ItemMaster.WkGpiDescriptions gpid on substring(phi.GPI, 1, 2) = substring(gpid.GpiCodeSegment, 1, 2)
               -- left join [dbo].[IPD_Patent] IPD on phi.DrugName = IPD.[Brand Drug Name]
                left join App.BuyInResolved BR on BR.Ndc = npp.Ndc and BR.CustomerId = C.CustomerID --and BR.DivisionId = C.DivisionId
				AND BR.WHOLESALERSUPPLIERID = ST.SUPPLIERID AND BR.AccountType = pl.PriceListDescription
              --  AND BR.USERADDEDID=@userId
                -- left join to PharmacyItemShortage to determine if Ndc has shortages
                left join
                (   select pisg.Ndc
                            , case when pisg.Ndc is null then 0 else 1 end as IsShort
                    from PharmacyItemShortage pisg
                    where pisg.Ndc is not null
                            and pisg.Status != 'R'
                    group by pisg.Ndc) pis on pis.Ndc = npp.Ndc
                    join ItemMaster.StorageCondition sc on sc.storageConditionId = phi.storageConditionId
            where npp.IsActive = 1
                and c.status = 'A'
                and st.[1YearUsageQty] > 0
                and c.ClientId = 6
                and gpid.GPIRecordTypeId > 0
				and gpid.Status = 'A'
                and substring(phi.GPI, 1, 2) = gpid.GpiCodeSegment
                -- todo: We should evaluate how we handle BuyInExclusions
                and not exists 
                (   select bie.ItemId
                    from App.BuyInExclusion bie
                    where bie.ItemId = phi.ItemId
                          and (bie.CustomerId is null or bie.CustomerId = c.customerid)
                          and bie.ClientId = c.ClientId
                          and (bie.ExclusionEndDate > getdate() or bie.ExclusionEndDate is null))
            -- we need to group because SalesTotals groups by WAN, and that will cause duplicates since WAN is not 
            -- everything is going to be included in the grouping *except* for sales total 1 year usage, which will be summed
            group by npp.ndc
                    , st.PriceTypeGroupId
                    , st.SupplierId
                    , cip.CpSupplierID
                    , s.SupplierName
                    , c.ClientId
                    , c.CustomerId
                    , npp.NationalPricePredictionGuid
                    , npp.[NationalPricePredictionId]
                    , npp.[RecordSyncDate]
                    , npp.[IsActive]
                    , pis.IsShort
                    , phi.ItemId
                    , phi.ItemDescription
                    , npp.[PriceDate]
                    , npp.[RunDate]
                    , npp.[TrainDate]
                    , npp.[WacUnitPrice]
                    , npp.[PeriodFirstIdentified]
                    , c.Premier_Relation
                    , c.CustomerName
                    , c.AccountNumber
                    , c.Dea
                    , c.DivisionName
                    , c.DivisionId
                    , cip.PriceAmount
                    , ptg.PriceTypeGroupDescription 
                    , sc.StorageConditionDescription
                    , npp.[Month0ProbabilityOfIncrease]
                    , npp.[Month0PredictedWacUnitPrice]
                    , npp.[Month1ProbabilityOfIncrease]
                    , npp.[Month1PredictedWacUnitPrice]
                    , npp.[Month1PercentIncrease]
                    , npp.[Month1Period]
                    , npp.[Month2ProbabilityOfIncrease]
                    , npp.[Month2PredictedWacUnitPrice]
                    , npp.[Month2PercentIncrease]
                    , npp.[Month2Period]
                    , npp.[Month3ProbabilityOfIncrease]
                    , npp.[Month3PredictedWacUnitPrice]
                    , npp.[Month3PercentIncrease]
                    , npp.[Month3Period]
                    , gpid.GpiCodeSegment + ' - ' + replace(gpid.GpiName,'*','')
                    , c.DivisionId
                    , wa.wholesalerAccountNumber
                    ,c.DivisionId
                    , BR.STATUS
                    , wa.Latestpurchasedate 
                    , wa.quantity
				    , wa.unitprice 
                  --  , IPD.[Brand Drug Name]

				---  having  wa.wholesalerAccountNumber like '%FCA01277A%'

            order by Ndc
            
            select  * from [Sync].[vw_GetNdcWithIngredients]
            
            select * from dbo.ndcingredientsdebugsep
            
            
            select * from dbo.Customer c 
            select * from raw.PremierCustomerList pcl 
            where pcl.[Facility Direct Parent ID] in ('AD4719','AB1648')
            
            
            
            
select ifm.clientimportcode as clientimportcode, 
ifm.ImportFileMapUId as ImportFileMapUId, ds.DataSourceUID as DataSourceUID, ifft.ImportFileFrequencyTypeUId as ImportFileFrequencyTypeUId
from ImportFileIDMapping ifm
   inner join DataSource ds
     on ifm.DataSourceId = ds.DataSourceId
   inner join ImportFileFrequencyType ifft
   
   select * from dbo.DataSource
   
   truncate table dbo.DataSource 
   
   
   
   
     on ifm.ImportFileFrequencyTypeId = ifft.ImportFileFrequencyTypeId
     
     
     select * from [dbo].[ImportFileIDMapping]
     
     
     select count(*) from dbo.sales
     group by clientid
     
     select count(*) from raw.Sales s 
     
     
     
      select top 1000 s.[ClientId],
        c.[CustomerId],
        su.SupplierId SupplierId,
        su.SupplierName SupplierName,
        pi.ItemId,
        s.[TransactionDate],
        s.[Ndc],
        s.[ItemDescription],
        s.[OrderNumber],
        s.[LineNumber],
        s.[OrderType],
        s.[Qty],
        s.[QtyOrdered],
        s.[UnitCost],
        s.[UnitPrice],
        s.[UOM],
        s.[InvoiceNumber],
        s.[WholesalerAccountNumber],
        s.[ChargeBackContractNumber],
        s.[Markup/Markdown],
        ptx.[PriceTypeGroupId],
        s.[Address1],
        s.[Address2],
        s.[City],
        s.[State],
        s.[ZipCode],
       -- format(ca.FirstDateOfQuarter,'yyyyMMdd') QuarterDate,
        FORMAT(DATEADD(qq, DATEDIFF(qq, 0, s.TransactionDate), 0),'yyyyMMdd') QuarterDate,
        s.[ImportedDate],
        ifm.DataSourceId  as [DataSourceId],
        s.[ProcessPipelineId],
        case when s.OrderType in ('CPAK Return', 'DOD Order', 'DOD Return', 'Order CPAK') then 1 else 0 end RepackagedFlag,
        s.[OrderDate],
        s.[ReasonCodeDesc]
    from [Raw].[Sales] s
        inner join [dbo].[ImportFileIDMapping] ifm
        on s.[DataSource] = ifm.[ClientImportCode]
        inner join [dbo].[Customer] c
        on s.[Account] = c.[AccountNumber]
            and s.ClientId = c.ClientId
        left join [dbo].[PharmacyItem] pi
        on s.ndc = pi.Ndc
      /*  inner join Calendar ca
        on ifm.[ClientId] = ca.ClientId
            and s.TransactionDate = ca.CalendarDate   */
        left join Mapping.[PriceTypeGroupXref] ptx
       -- on c.ClientId = ptx.clientid
            on s.WholesalerAccountAttribute = ptx.[ClientPriceTypeCode]
        left join supplier su
        on s.Wholesaler = su.SupplierName
    where su.SupplierTypeId= 2 and su.MfrId is null and s.[DataSource] = 'PremierWholesaleInvoice'
    
    select top 1000 * from raw.Sales s 
    
    select count(*), clientid
    from raw.sales 
	group by ClientId  
	
	select * from dbo.ImportFileIDMapping ifi where ifi.ImportFileMapId in (1,2,3)
	
	
	
	INSERT INTO dbo.ImportFileIDMapping (ClientImportCode,Description,ClientId,ClientSupplierId,CpSupplierID,CustomerId,PriceListId,DataSourceId,PayerId,ReimbursementTypeId,ImportFileFrequencyTypeId,ImportFileMapUId,MPBFlag) VALUES
	 (N'PremierWholesaleInvoice',N'PremierWholesaleInvoice',5,NULL,1,NULL,NULL,17,NULL,NULL,1,N'689D401B-1A92-45EC-90E4-90031E29BC4F',NULL),
	 (N'PremierWholesalePO',N'PremierWholesalePO',5,NULL,1,NULL,NULL,17,NULL,NULL,1,N'B818CBD9-FBF5-4264-AF09-F5A35CD3EE30',NULL),
	 (N'PA0023',N'Premier Health System Id',5,NULL,NULL,NULL,NULL,17,NULL,NULL,NULL,N'69285D47-47BF-45EC-B9C2-4803A3B0C968',NULL);

     
     select top 10 * from dbo.Sales s 
 select distinct customerid from dbo.sales
 
 where TransactionDate >= DATEADD(year,-3, GETDATE()) and Clientid = 2
 
 select DATEADD(year,-3, GETDATE())
 
 
declare @clientid int = (select clientid from [ImportFileIDMapping] 
where [ClientImportCode] = 'PremierWholesaleInvoice');
select @clientid
declare @DataSourceId int = (select DataSourceId from [ImportFileIDMapping] 
where [ClientImportCode] = 'PremierWholesaleInvoice');
select @DataSourceId

select top 10 * from dbo.CustomerItemPricing
select top 10 * from dbo.CustomerItemPricingHistory

truncate table [dbo].[CustomerItemPricing]
truncate table [dbo].[CustomerItemPricingHistory]

     
update c set c.DivisionName =  a.DivisionName, c.DivisionId = a.DivisionId 
from customer c join customerapr2022 a on c.AccountNumber = a.AccountNumber
select * from customerapr2022

select count(*) from raw.sales where PremierContractNumber is not null

select  * from dbo.Sales where PremierContractNumber is not null
			select count(*) from premier.WholesalerInvoices where PremierContractNumber is not null
			
			
			
			
			select top 100 * from sales
			
			select * from client
			
			se