select
				  a.DivisionId
				, a.Division
                , a.CustomerId
				, a.CustomerName
				, TotalCost30Day
				, TotalCost60Day
				, TotalCost90Day
				, TotalCost
			from
				(select c.DivisionId
				    , dbo.fn_DivisionName(c.DivisionName, c.DivisionId) 'Division'
					, c.CustomerId 
					, c.CustomerName 
					, sum([30DayUsageExtPrice]) as TotalCost30Day
					, sum([60DayUsageExtPrice]) as TotalCost60Day
					, sum([90DayUsageExtPrice]) as TotalCost90Day
					, sum([1YearUsageExtPrice]) as TotalCost
				from dbo.SalesTotals st
				join dbo.Customer c on c.CustomerId = st.CustomerId and c.ClientId = st.ClientId
				where st.ClientId = 7
                    and OrganizationName = 'ADVOCATE AURORA HEALTH -  WI0013' --Param
                    and c.customerid = 
				group by c.CustomerId, c.CustomerName, c.DivisionName, c.DivisionId) a
			join dbo.Customer cn on cn.CustomerId = a.CustomerId
			order by CustomerName 
			
	/*	select * from CustomerOrganization co 
		
		select * from Customer c */
		
		
		
--wan spend chart at facility level. sales totals is used
declare @id as int =347;
declare @clientid as int =7;
select 
					 st.WholesalerAccountNumber as WAN
					,s.SupplierName as Wholesaler 
					,sum([30DayUsageExtPrice]) as TotalCost30Day
					,sum([60DayUsageExtPrice]) as TotalCost60Day
					,sum([90DayUsageExtPrice]) as TotalCost90Day
					,sum([1YearUsageExtPrice]) as TotalCost					
				from dbo.SalesTotals st
				 join dbo.Supplier s on s.SupplierId = st.SupplierId
				where st.Customerid = @id and 
				st.ClientId = @clientId
				group by st.WholesalerAccountNumber, s.SupplierName 
				
				
-----purchase history utilization-------------------
--@ndc varchar(20) = '67457015309',				
declare @clientId int = 7,@customerId int = 347, @from varchar(20) = '2/25/2021', @to varchar(20) = '2/25/2022 ',@pageNumber int = 0,

@pageSize int = 10000000,@sortDirection varchar(20) = '',@sortColumn varchar(20) = '';

            with 
            utilization as (
	            select pi.Ndc
                        ,pi.ItemDescription as 'Description'
                        ,s.CustomerId
			            ,s.TransactionDate
			            ,s.Qty
			            ,s.UnitCost
			            --, isnull(sum(ROUND((qty * unitprice),0)), 0) as "30DayUsageExtPrice"
			            ,ROUND(s.UnitCost * Qty,0) as 'TotalCost'
						,s.WholesalerAccountNumber
						,s.OrderType
						,s.WholesalerCBID						
						,s.InvoiceNumber
						,s.SupplierName
						, ptg.PriceTypeGroupDescription as 'AccountType'
						, pi.DrugName as BrandName
						, pi.GpiDrugName as GenericName						
						, df.DosageFormDescription as DosageForm
						, pi.DrugStrength + pi.DrugStrengthUom as Strength
						, dose.UnitDoseCode -- ask if we should include
						, dose.UnitDoseDescription -- ask if we should include
						, pi.PackageSize as PackageSize
						, pi.CasePack as PackageQuantity
						, pi.PackageDescription as PackagingDescription
						, packageUom.PackageSizeUomCode as Uom
						, packageUom.PackageSizeUomDescription as UomDescription

		            from PharmacyItem pi 
                        join Sales s on s.itemid = pi.itemid
			            join Customer c on s.CustomerId = c.CustomerId and s.ClientId = c.ClientId
						join PriceTypeGroup ptg ON s.PriceTypeGroupId = ptg.PriceTypeGroupId

						left join ItemMaster.BrandNameTypes bnt on bnt.BrandNameTypeId = pi.BrandNameTypeId
						left join ItemMaster.DosageForm df on df.DosageFormId = pi.DosageFormId
						left join ItemMaster.PackageSizeUom packageUom on packageUom.PackageSizeUomId = pi.PackageSizeUomId
						left join ItemMaster.UnitDose dose on dose.UnitDoseId = pi.UnitDoseId

		            where s.ClientId = @clientId -- Param
			            and c.CustomerId = @customerId and c.ClientId = s.ClientId -- Param
			            and s.WholesalerAccountNumber = '870292'
			            
						
            ) select * from utilization ,
       --     select dateadd(dd, -30, getdate())
            utilizationTotals as (
	            select sum(case when u.TransactionDate >= dateadd(dd, -30, getdate()) then u.Qty else 0 end) Usage30
		            ,sum(case when u.TransactionDate >= dateadd(dd, -60, getdate()) then u.Qty else 0 end) Usage60
		            ,sum(case when u.TransactionDate >= dateadd(dd, -90, getdate()) then u.Qty else 0 end) Usage90
		            ,sum(case when u.TransactionDate >= dateadd(dd, -30, getdate()) then u.TotalCost else 0 end) Cost30
		            ,sum(case when u.TransactionDate >= dateadd(dd, -60, getdate()) then u.TotalCost else 0 end) Cost60
		            ,sum(case when u.TransactionDate >= dateadd(dd, -90, getdate()) then u.TotalCost else 0 end) Cost90
		            ,sum(u.Qty) TotalUsage
		            ,sum(u.UnitCost) TotalUnitCost
		            ,sum(u.TotalCost) TotalTotalCost
	            from utilization u
            ),
            utilizationDetail as (
	            select tu.Ndc
						,tu.Description
                        ,tu.CustomerId			            
			            ,tu.TransactionDate
			            ,tu.Qty
			            ,tu.UnitCost
			            ,tu.UnitCost * Qty as 'TotalCost'
						,tu.WholesalerAccountNumber
						,tu.OrderType
						,tu.WholesalerCBID	
						,tu.AccountType
						,tu.InvoiceNumber
						,tu.SupplierName


						, tu.BrandName
						, tu.GenericName						
						, tu.DosageForm
						, tu.Strength
						, tu.UnitDoseCode 
						, tu.UnitDoseDescription 
						, tu.PackageSize
						, tu.PackageQuantity
						, tu.PackagingDescription
						, tu.Uom
						, tu.UomDescription

		            from utilization tu
		            where tu.TransactionDate >= @from
			            and tu.TransactionDate < dateadd(day, 1, @to)
            )

            select 
                s.Ndc
                ,s.Description
                ,s.CustomerId	            
	            ,s.TransactionDate
	            ,s.Qty
                ,s.UnitCost
                ,s.TotalCost
				,s.WholesalerAccountNumber
				,s.OrderType
				,s.WholesalerCBID
				,s.AccountType
				,s.InvoiceNumber
				,s.SupplierName
	            ,totals.TotalCount as SearchResultCount
                ,totals.SearchResultTotalUnitCost
	            ,totals.SearchResultTotalCost
	            ,totals.SearchResultTotalQty
	            ,totalUsage.Usage30 AS SearchResultUsage30
	            ,totalUsage.Usage60 AS SearchResultUsage60
	            ,totalUsage.Usage90 AS SearchResultUsage90
	            ,totalUsage.Cost30 AS SearchResultCost30
	            ,totalUsage.Cost60 AS SearchResultCost60
	            ,totalUsage.Cost90 AS SearchResultCost90
	            ,totalUsage.TotalUsage
	            ,totalUsage.TotalUnitCost
	            ,totalUsage.TotalTotalCost

				, s.BrandName
				, s.GenericName				
				, s.DosageForm
				, s.Strength
				, s.UnitDoseCode 
				, s.UnitDoseDescription 
				, s.PackageSize
				, s.PackageQuantity
				, s.PackagingDescription
				, s.Uom
				, s.UomDescription

            from utilizationDetail s
	            join (select count(1) as TotalCount
                            ,sum(u.UnitCost) as SearchResultTotalUnitCost
				            ,sum(u.TotalCost) as SearchResultTotalCost
				            ,sum(u.Qty) as SearchResultTotalQty
			            from utilizationDetail u) totals on 1 = 1
	            join (select ut.Usage30
			            ,ut.Usage60
			            ,ut.Usage90
			            ,ut.Cost30
			            ,ut.Cost60
			            ,ut.Cost90
			            ,ut.TotalUsage
			            ,ut.TotalUnitCost
			            ,ut.TotalTotalCost
		              from utilizationTotals ut) totalUsage on 1 = 1
            order by
	            case when @sortColumn = 'Ndc' and @sortDirection = 'asc' then s.Ndc end,
	            case when @sortColumn = 'Ndc' and @sortDirection = 'desc' then s.Ndc end desc,
	            case when @sortColumn = 'Description' and @sortDirection = 'asc' then s.Description end,
	            case when @sortColumn = 'Description' and @sortDirection = 'desc' then s.Description end desc,
				case when @sortColumn = 'WholesalerAccountNumber' and @sortDirection = 'asc' then s.WholesalerAccountNumber end,
	            case when @sortColumn = 'WholesalerAccountNumber' and @sortDirection = 'desc' then s.WholesalerAccountNumber end desc,
				case when @sortColumn = 'OrderType' and @sortDirection = 'asc' then s.OrderType end,
	            case when @sortColumn = 'OrderType' and @sortDirection = 'desc' then s.OrderType end desc,
				case when @sortColumn = 'WholesalerCBID' and @sortDirection = 'asc' then s.WholesalerCBID end,
	            case when @sortColumn = 'WholesalerCBID' and @sortDirection = 'desc' then s.WholesalerCBID end desc,	
				case when @sortColumn = 'AccountType' and @sortDirection = 'asc' then s.AccountType end,
	            case when @sortColumn = 'AccountType' and @sortDirection = 'desc' then s.AccountType end desc,
				case when @sortColumn = 'InvoiceNumber' and @sortDirection = 'asc' then s.InvoiceNumber end,
	            case when @sortColumn = 'InvoiceNumber' and @sortDirection = 'desc' then s.InvoiceNumber end desc,
				case when @sortColumn = 'SupplierName' and @sortDirection = 'asc' then s.SupplierName end,
				case when @sortColumn = 'SupplierName' and @sortDirection = 'desc' then s.SupplierName end desc,
	            case when @sortColumn = 'TransactionDate' and @sortDirection = 'asc' then s.TransactionDate end,
	            case when @sortColumn = 'TransactionDate' and @sortDirection = 'desc' then s.TransactionDate end desc,
	            case when @sortColumn = 'Qty' and @sortDirection = 'asc' then s.Qty end,
	            case when @sortColumn = 'Qty' and @sortDirection = 'desc' then s.Qty end desc,
	            case when @sortColumn = 'UnitCost' and @sortDirection = 'asc' then s.UnitCost end,
	            case when @sortColumn = 'UnitCost' and @sortDirection = 'desc' then s.UnitCost end desc,
				case when @sortColumn = 'TotalCost' and @sortDirection = 'asc' then s.TotalCost end,
	            case when @sortColumn = 'TotalCost' and @sortDirection = 'desc' then s.TotalCost end desc
            offset @pageNumber * @pageSize rows --Param
            fetch next @pageSize rows only

			select 
			DISTINCT 
			s.SupplierName AS 'Wholesaler',
			s.OrderType AS 'OrderType',
			s.WholesalerAccountNumber AS 'WholesalerAccountNumber',
			ptg.PriceTypeGroupDescription as 'AccountType'
		from Sales s
			join PharmacyItem pi on s.ItemId = pi.ItemId and s.ClientId = @clientId
			join Customer c on s.CustomerId = c.CustomerId and s.ClientId = c.ClientId
			join PriceTypeGroup ptg ON s.PriceTypeGroupId = ptg.PriceTypeGroupId
			join (
				select st.Ndc
						, sum([30DayUsageQty])		 [Usage30]	
						, sum([60DayUsageQty])		 [Usage60]	
						, sum([90DayUsageQty])		 [Usage90]	
						, sum([30DayUsageExtPrice]) [Cost30]	
						, sum([60DayUsageExtPrice]) [Cost60]	
						, sum([90DayUsageExtPrice]) [Cost90]	
				from SalesTotals st
				join PharmacyItem pi on st.itemid  = pi.itemid  and st.ClientId = @clientId
				group by st.Ndc) st on st.Ndc = pi.Ndc
		where c.CustomerId = @customerId  and s.TransactionDate >= @from
			and s.TransactionDate < dateadd(day, 1, @to)
			
			select * from customer where customerid = 347
			
			select * from SalesTotals st where st.WholesalerAccountNumber = '870292'
			
			
			---salestotals
			
declare @today date = getdate();
    declare @Past30 date = dateadd(day, -30, @today);			
select clientid
             , CustomerId
             , ndc
             , PriceTypeGroupId
             , SupplierId
             , WholesalerAccountNumber 
             , max(itemid) itemid
             , isnull(sum(qty), 0) as "30DayUsageQty"
             , isnull(sum(ROUND((qty * unitprice),0)), 0) as "30DayUsageExtPrice"
             , isnull(sum(QtyOrdered), 0) as "30DayQtyOrdered"
             , count(1) as "30DayUsageTransactionCount"
             , @Past30 as "30DayAsOfDate"
        from dbo.Sales
        where transactiondate >= @Past30
              and [RepackagedFlag] = 0 and WholesalerAccountNumber = '870292'
        group by clientid
               , CustomerId
               , ndc
               , PriceTypeGroupId
               , SupplierId
               , WholesalerAccountNumber