


-----purchase history utilization-------------------
--@ndc varchar(20) = '67457015309',				
declare @clientId int = 7,@WholesalerId int = 1, @from varchar(20) = '12/15/2021', @to varchar(20) = '03/15/2022 ',@pageNumber int = 0,

@pageSize int = 10000000,@sortDirection varchar(20) = '',@sortColumn varchar(20) = '';


		 with utilization as (
	            select pi.Ndc
			            ,pi.ItemDescription as 'Description'
			            ,c.OrganizationName as 'Organization'
						,[dbo].[fn_DivisionName](c.DivisionName, c.DivisionId) as 'Division'
						,[dbo].[fn_FacilityName](c.CustomerName,c.AccountNumber,c.DEA)  AS 'Facility'
			            ,c.CustomerName as 'Account'
			            ,s.TransactionDate
			            ,s.Qty
			            ,s.UnitCost
			            ,s.UnitCost * Qty as 'TotalCost'
						,s.WholesalerAccountNumber
						,s.WholesalerCBID
						,s.CostofDistribution
						,s.InvoiceNumber
						,s.SupplierName as 'WholesalerName'
						,s.OrderType as 'WholesalerPurchaseType'
						,sup.SupplierName
						,ptg.PriceTypeGroupDescription as 'AccountType'
						,st.Usage30
			            ,st.Usage60
			            ,st.Usage90
			            ,st.Cost30
			            ,st.Cost60
			            ,st.Cost90
						, pi.DrugName as BrandName
						, pi.GpiDrugName as GenericName						
						, df.DosageFormDescription as DosageForm
						, pi.DrugStrength + pi.DrugStrengthUom as Strength
						, dose.UnitDoseCode -- ask if we should include
						, dose.UnitDoseDescription -- ask if we should include
						, pi.PackageSize as PackageSize
						, pi.CasePack as PackageQuantity
						, pi.PackageDescription as PackagingDescription
						, packageUom.PackageSizeUomCode as Uom
						, packageUom.PackageSizeUomDescription as UomDescription
		            from Sales s
			            join PharmacyItem pi on s.ItemId = pi.ItemId and s.ClientId = @clientId
						join Supplier sup on pi.MfrId = sup.MfrId and s.SupplierId = @WholesalerId
			            join Customer c on s.CustomerId = c.CustomerId and s.ClientId = c.ClientId
						join PriceTypeGroup ptg ON s.PriceTypeGroupId = ptg.PriceTypeGroupId
						join (
				            select st.Ndc
						            , sum([30DayUsageQty])		 [Usage30]	
						            , sum([60DayUsageQty])		 [Usage60]	
						            , sum([90DayUsageQty])		 [Usage90]	
						            , sum([30DayUsageExtPrice]) [Cost30]	
						            , sum([60DayUsageExtPrice]) [Cost60]	
						            , sum([90DayUsageExtPrice]) [Cost90]	
				            from SalesTotals st
				            join PharmacyItem pi on st.ItemId = pi.ItemId and st.ClientId = @clientId and st.SupplierId = @WholesalerId
				            join Supplier sup on pi.MfrId = sup.MfrId and st.SupplierId = @WholesalerId
				            group by st.Ndc) st on st.Ndc = pi.Ndc
					left join ItemMaster.BrandNameTypes bnt on bnt.BrandNameTypeId = pi.BrandNameTypeId
					left join ItemMaster.DosageForm df on df.DosageFormId = pi.DosageFormId
					left join ItemMaster.PackageSizeUom packageUom on packageUom.PackageSizeUomId = pi.PackageSizeUomId
					left join ItemMaster.UnitDose dose on dose.UnitDoseId = pi.UnitDoseId
		            where s.TransactionDate >= @from
			            and s.TransactionDate < dateadd(day, 1, @to) and c.status = 'A' and s.SupplierId=@WholesalerId
                        
						
            ),
            utilizationTotals as (
				            SELECT
							sum(case when u.TransactionDate >= dateadd(dd, -30, getdate()) then u.Qty else 0 end) Usage30
							,sum(case when u.TransactionDate >= dateadd(dd, -60, getdate()) then u.Qty else 0 end) Usage60
							,sum(case when u.TransactionDate >= dateadd(dd, -90, getdate()) then u.Qty else 0 end) Usage90
							,sum(case when u.TransactionDate >= dateadd(dd, -30, getdate()) then u.TotalCost else 0 end) Cost30
							,sum(case when u.TransactionDate >= dateadd(dd, -60, getdate()) then u.TotalCost else 0 end) Cost60
							,sum(case when u.TransactionDate >= dateadd(dd, -90, getdate()) then u.TotalCost else 0 end) Cost90
								 , sum(u.Qty) SearchResultTotalQty
		                         , sum(u.UnitCost) SearchResultTotalUnitCost
		                         , sum(u.TotalCost) SearchResultTotalCost
	                        from utilization u
                        )

            select 
                            u.Ndc
                            ,u.Description
							,u.Division
							,u.Facility
				            ,u.Organization
				            ,u.Account            
	                        ,u.TransactionDate
	                        ,u.Qty
                            ,u.UnitCost
                            ,u.TotalCost
							,u.WholesalerAccountNumber
							,u.WholesalerCBID
							,u.CostofDistribution
							,u.InvoiceNumber
							,u.WholesalerName
							,u.SupplierName
							,u.AccountType
							,u.WholesalerPurchaseType
	                        ,u.Usage30
				            ,u.Usage60
				            ,u.Usage90
				            ,u.Cost30
				            ,u.Cost60
				            ,u.Cost90
	                        ,src.SearchResultCount
                            ,ut.SearchResultTotalUnitCost
	                        ,ut.SearchResultTotalCost
	                        ,ut.SearchResultTotalQty
				            ,ut.Usage30 AS SearchResultUsage30
	                        ,ut.Usage60 AS SearchResultUsage60
	                        ,ut.Usage90 AS SearchResultUsage90
	                        ,ut.Cost30 AS SearchResultCost30
	                        ,ut.Cost60 AS SearchResultCost60
	                        ,ut.Cost90 AS SearchResultCost90
							, u.BrandName
							, u.GenericName						
							, u.DosageForm
							, u.Strength
							, u.UnitDoseCode 
							, u.UnitDoseDescription 
							, u.PackageSize
							, u.PackageQuantity
							, u.PackagingDescription
							, u.Uom
							, u.UomDescription
                        from utilization u
				            join utilizationTotals ut on 1 = 1
	                        join (select count(1) SearchResultCount from utilization                                 
								 ) src on 1 = 1
                        order by
	                        case when @sortColumn = 'Ndc' and @sortDirection = 'asc' then u.Ndc end,
	                        case when @sortColumn = 'Ndc' and @sortDirection = 'desc' then u.Ndc end desc,
	                        case when @sortColumn = 'Description' and @sortDirection = 'asc' then u.Description end,
	                        case when @sortColumn = 'Description' and @sortDirection = 'desc' then u.Description end desc,
							case when @sortColumn = 'WholesalerAccountNumber' and @sortDirection = 'asc' then u.WholesalerAccountNumber end,
							case when @sortColumn = 'WholesalerAccountNumber' and @sortDirection = 'desc' then u.WholesalerAccountNumber end desc,
							case when @sortColumn = 'WholesalerCBID' and @sortDirection = 'asc' then u.WholesalerCBID end,
							case when @sortColumn = 'WholesalerCBID' and @sortDirection = 'desc' then u.WholesalerCBID end desc,
							case when @sortColumn = 'CostofDistribution' and @sortDirection = 'asc' then u.CostofDistribution end,
							case when @sortColumn = 'CostofDistribution' and @sortDirection = 'desc' then u.CostofDistribution end desc,
							case when @sortColumn = 'InvoiceNumber' and @sortDirection = 'asc' then u.InvoiceNumber end,
							case when @sortColumn = 'InvoiceNumber' and @sortDirection = 'desc' then u.InvoiceNumber end desc,
				            case when @sortColumn = 'Organization' and @sortDirection = 'asc' then u.Organization end,
	                        case when @sortColumn = 'Organization' and @sortDirection = 'desc' then u.Organization end desc,
				            case when @sortColumn = 'Account' and @sortDirection = 'asc' then u.Account end,
							case when @sortColumn = 'SupplierName' and @sortDirection = 'asc' then u.SupplierName end,
							case when @sortColumn = 'SupplierName' and @sortDirection = 'desc' then u.SupplierName end desc,
							case when @sortColumn = 'AccountType' and @sortDirection = 'asc' then u.AccountType end,
							case when @sortColumn = 'AccountType' and @sortDirection = 'desc' then u.AccountType end desc,
							case when @sortColumn = 'WholesalerPurchaseType' and @sortDirection = 'asc' then u.WholesalerPurchaseType end,
							case when @sortColumn = 'WholesalerPurchaseType' and @sortDirection = 'desc' then u.WholesalerPurchaseType end desc,
	                        case when @sortColumn = 'Account' and @sortDirection = 'desc' then u.Account end desc,
	                        case when @sortColumn = 'TransactionDate' and @sortDirection = 'asc' then u.TransactionDate end,
	                        case when @sortColumn = 'TransactionDate' and @sortDirection = 'desc' then u.TransactionDate end desc,
	                        case when @sortColumn = 'Qty' and @sortDirection = 'asc' then u.Qty end,
	                        case when @sortColumn = 'Qty' and @sortDirection = 'desc' then u.Qty end desc,
	                        case when @sortColumn = 'UnitCost' and @sortDirection = 'asc' then u.UnitCost end,
	                        case when @sortColumn = 'UnitCost' and @sortDirection = 'desc' then u.UnitCost end desc,
				            case when @sortColumn = 'TotalCost' and @sortDirection = 'asc' then u.TotalCost end,
	                        case when @sortColumn = 'TotalCost' and @sortDirection = 'desc' then u.TotalCost end desc
                        offset @pageNumber * @pageSize rows --Param
                        fetch next @pageSize rows only;
						
						select 
			            DISTINCT 
						[dbo].[fn_DivisionName](c.DivisionName, c.DivisionId) as 'Division',
						[dbo].[fn_FacilityName](c.CustomerName,c.AccountNumber,c.DEA)  AS 'Facility',
						s.WholesalerAccountNumber AS 'WholesalerAccountNumber',
						s.OrderType AS 'WholesalerPurchaseType',	
						sup.SupplierName as 'Supplier',
						ptg.PriceTypeGroupDescription as 'AccountType'
		            from Sales s
			            join PharmacyItem pi on s.ItemId = pi.ItemId and s.ClientId = @clientId and s.SupplierId = @WholesalerId
						join Supplier sup on pi.MfrId = sup.MfrId and s.SupplierId = @WholesalerId
			            join Customer c on s.CustomerId = c.CustomerId and s.ClientId = c.ClientId	
						join PriceTypeGroup ptg ON s.PriceTypeGroupId = ptg.PriceTypeGroupId
		            where s.SupplierId = @WholesalerId and s.TransactionDate >= @from
			            and s.TransactionDate < dateadd(day, 1, @to) and c.status = 'A'
		

		
	               