/*select clientid,max(transactiondate), min(transactiondate) from dbo.sales    
group by ClientId 


select * 

select distinct PriceTypeGroupId  from dbo.sales where WholesalerAccountNumber = '100170010'


-- dbo.IPD_Patent definition

-- Drop table

-- DROP TABLE dbo.IPD_Patent;

CREATE TABLE dbo.IPD_Patent (
	[Brand Drug Name] nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Generic Name] nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Brand Company] nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Therapeutic Area] nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[US Brand Sales ($bln)] nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Orange Book Patents] nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Pediatric Exclusivity] nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Patent Comments] nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Related Litigation Comments] nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Paragraph IV Certification] nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[First ANDA Filer(s)] nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Other ANDA Filer(s)] nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[DMF Filers] nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Litigation Status] nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[30-Month Stay Expirations] nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Earliest Possible Generic Entrants(s)] nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Triggering Event] nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Earliest Possible Launch] nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Earliest Launch Probability] nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Expected Outlook for Generic Entry] nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Comments on Generic Entry] nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Estimated LOE] nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Load_date datetime DEFAULT getdate() NULL
);
CREATE TABLE dbo.Drug_shortage_alerts (
	DrugName varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Route varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ShortageSource varchar(30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Rank] float NULL,
	Date_Scored datetime NULL,
	isInjectable int NULL,
	Last_Updated_Data datetime DEFAULT getdate() NULL
);
-- dbo.ROI_Information definition

-- Drop table

-- DROP TABLE dbo.ROI_Information;

CREATE TABLE dbo.ROI_Information (
	Ndc varchar(11) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	ROI_Start_Date datetime NULL,
	ROI_End_Date datetime NULL,
	ROI_Check_Date datetime NULL,
	Actual_Percentage_Increase float NULL
);

-- sqldbCogRxProdNorthwell.dbo.ROI_Tracking definition

-- Drop table

-- DROP TABLE sqldbCogRxProdNorthwell.dbo.ROI_Tracking;

CREATE TABLE dbo.ROI_Tracking (
	Ndc varchar(11) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	Division varchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Facility varchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Wholesaler varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	WholesalerAccountNumber varchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ROI_Track_Date datetime NULL,
	ROI_Start_Date datetime NULL,
	ROI_End_Date datetime NULL,
	Status varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Estimated_Advance_Purchase_Units int NOT NULL,
	Actual_Quantity int NULL,
	Units_to_Count_for_ROI int NULL,
	Actual_ROI money NULL,
	Clientid int NOT NULL,
	IsActive int NOT NULL,
	Roi_Track_Id int IDENTITY(1,1) NOT NULL,
	Current_Price money NULL,
	Reason_ROI varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Actual_Percentage_Increase float NULL
);*/


select top 10 * from dbo.sales 

alter table dbo.sales
add PremierContractNumber varchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL;

alter table raw.sales
add PremierContractNumber varchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL;

SELECT * FROM CUSTOMER WHERE CLIENTID = 9


select * from dbo.customer where DivisionName is NULL 

select * from dbo.PharmacyItemShortage order by UpdatedDate desc

select * from dbo.clientidlookup

SELECT DISTINCT CLIENTID FROM DBO.CUSTOMER 

WHERE ClientId  = 9


select * from dbo.SalesTotalMonthly stm 




SELECT CLIENTID ,COUNT(*),min(transactiondate), max(transactiondate) FROM DBO.SALES GROUP BY CLIENTID







CREATE PROCEDURE DailyMaintinance.RebuildDeletionofJeffersonFacility
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

delete from dbo.SalesArchive 
where CustomerId not in 
(select CustomerId  from dbo.Customer c 
WHERE accountnumber  IN ('PA5036','NJ5062','809162','NJ5061','809161',
'655027','NU2044','PA2196','781393','PA2586','743695','PA5025','730437',
'PA1151','PA1152','742292','PA2033','691507','PA0025',
--'PA2108',
'619908') and clientid = 9 ) and clientid = 9

delete from dbo.SalesTotalMonthly 
where CustomerId not in 
(select CustomerId  from dbo.Customer c 
WHERE accountnumber  IN ('PA5036','NJ5062','809162','NJ5061','809161',
'655027','NU2044','PA2196','781393','PA2586','743695','PA5025','730437',
'PA1151','PA1152','742292','PA2033','691507','PA0025',
--'PA2108',
'619908') and clientid = 9 ) and clientid = 9;

--select top 1000 * from dbo.SalesTotalMonthly stm where stm.ClientId = 9
delete from dbo.SalesTotals 
where CustomerId not in 
(select CustomerId  from dbo.Customer c 
WHERE accountnumber  IN ('PA5036','NJ5062','809162','NJ5061','809161',
'655027','NU2044','PA2196','781393','PA2586','743695','PA5025','730437',
'PA1151','PA1152','742292','PA2033','691507','PA0025',
--'PA2108',
'619908') and clientid = 9) and  clientid = 9;
delete from dbo.CustomerItemPricing 
where CustomerId not in 
(select CustomerId  from dbo.Customer c 
WHERE accountnumber  IN ('PA5036','NJ5062','809162','NJ5061','809161',
'655027','NU2044','PA2196','781393','PA2586','743695','PA5025','730437',
'PA1151','PA1152','742292','PA2033','691507','PA0025',
--'PA2108',
'619908') and clientid = 9) and  clientid = 9;
delete from dbo.CustomerItemPricingHistoryMonthly 
where CustomerId not in 
(select CustomerId  from dbo.Customer c 
WHERE accountnumber  IN ('PA5036','NJ5062','809162','NJ5061','809161',
'655027','NU2044','PA2196','781393','PA2586','743695','PA5025','730437',
'PA1151','PA1152','742292','PA2033','691507','PA0025',
--'PA2108',
'619908')and clientid = 9) and  clientid = 9;
delete from dbo.CustomerPriceList 
where CustomerId not in 
(select CustomerId  from dbo.Customer c 
WHERE accountnumber  IN ('PA5036','NJ5062','809162','NJ5061','809161',
'655027','NU2044','PA2196','781393','PA2586','743695','PA5025','730437',
'PA1151','PA1152','742292','PA2033','691507','PA0025',
--'PA2108',
'619908') and clientid = 9) and  clientid = 9;

delete from dbo.Sales  
where CustomerId not in 
(select CustomerId  from dbo.Customer c 
WHERE accountnumber  IN ('PA5036','NJ5062','809162','NJ5061','809161',
'655027','NU2044','PA2196','781393','PA2586','743695','PA5025','730437',
'PA1151','PA1152','742292','PA2033','691507','PA0025',
--'PA2108',
'619908') and clientid = 9) and  clientid = 9;

delete from dbo.customer 
WHERE accountnumber  not IN ('PA5036','NJ5062','809162','NJ5061','809161',
'655027','NU2044','PA2196','781393','PA2586','743695','PA5025','730437',
'PA1151','PA1152','742292','PA2033','691507','PA0025',
--'PA2108',
'619908') and  clientid = 9;
End


select  * from raw.PremierCustomerList pcl where [Health System ID] = 'PA5036'


select distinct pcl.ClientId 'clientid', 
					pcl.[Facility ID] 'AccountNumber', 
					pcl.[Facility Name] 'CustomerName', 
					pcl.[Facility AddrLine1] 'Address1', 
					pcl.[Facility AddrLine2] 'Address2', 
 					pcl.[Facility City]      'City',
					pcl.[Facility State]     'State', 
					pcl.[Facility Zip]       'Zip',
					pcl.[Facility DEA]       'DEA',
					pcl.[Premier_Relation]       'Premier_Relation',
					pcl.[SPC]       'SPC',
					pcl.[Division Name]       'Division Name',
					pcl.[DivisionId]       'DivisionId',
					co.CustomerOrganizationId 'CustomerOrganizationId', 
                    CASE 
						WHEN pcl.Clientid IN (8,4,1) then
                            pcl.[Facility Direct Parent ID]
						ELSE
							pcl.[Health System ID]
						END AS 'OrganizationNumber', 
					CASE 
						WHEN pcl.clientid IN (8,4,1) then
							pcl.[Facility Direct Parent]
						ELSE
							pcl.[Health System]
						END AS 'OrganizationName'
					from [Raw].[PremierCustomerList] pcl
						inner join CustomerOrganization co
							on pcl.[Facility Direct Parent ID] = co.[OrganizationNumber]
                            and pcl.Clientid = co.clientid
                            
       SELECT * FROM RAW.PremierCustomerList pcl                     
                            
      select * from raw.PremierCustomerList pcl                      
                            
select distinct pcl.ClientId, 
                       [Facility Direct Parent ID] 'OrganizationNumber', 
					   [Facility Direct Parent] 'OrganizationName' ,
					   1 'IsActive'
		from [Raw].[PremierCustomerList] pcl
		--	inner join [dbo].[ImportFileIDMapping] fm
			--	on pcl.[Health System ID] = fm.ClientImportCode
		where [Health System ID] is not null and [Facility Direct Parent ID] <> '0'
		
		select * from dbo.CustomerOrganization where OrganizationNumber =  'PA5036'
		
		
		
		SELECT * FROM DBO.Customer c 
		
		SELECT * FROM DBO.BuyinsAggregation ba 
		
	select * from dbo.salesmaskbkp



CREATE PROCEDURE DailyMaintinance.RebuildSalesWanAgg
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

truncate table dbo.salesWanAgg;

WITH LatestPuchaseDate
AS (
    SELECT customerid
        , WholesalerAccountNumber --00000000000000622942
        , Ndc
        , FORMAT(Max(TransactionDate), 'MM/dd/yyyy') AS Latestpurchasedate
        , PriceTypeGroupId
    FROM dbo.Sales
    WHERE qty > 0
    --    AND ndc = '64764030020'
    GROUP BY customerid
        , WholesalerAccountNumber
        , Ndc
        , PriceTypeGroupId
    )
    , custWan
AS (
    SELECT l.customerid
        , l.ndc
        , l.wholesaleraccountnumber
        , l.Latestpurchasedate
        , s.qty
        , s.unitprice
        , s.InvoiceNumber
        , pl.PriceTypeGroupDescription
        , ROW_NUMBER() OVER (
            PARTITION BY s.customerid
            , s.ndc
            , s.WholesalerAccountNumber
            , s.PriceTypeGroupId ORDER BY InvoiceNumber DESC
                , qty DESC
            ) AS rowlines
    FROM LatestPuchaseDate l
    JOIN sales s
        ON s.CustomerId = l.CustomerId
            AND s.WholesalerAccountNumber = l.WholesalerAccountNumber
            AND s.ndc = l.Ndc
            AND s.transactiondate = l.Latestpurchasedate
            AND s.PriceTypeGroupId = l.PriceTypeGroupId
    --join PriceList pl on pl.PriceListId = s.PriceTypeGroupId
    JOIN PriceTypeGroup pl
        ON pl.PriceTypeGroupId = s.PriceTypeGroupId
    WHERE s.qty > 0
    )
    , WanAgg
AS (
    SELECT a.customerid
        , a.ndc
        , a.PriceTypeGroupDescription
        , STRING_AGG(a.Latestpurchasedate, ',') WITHIN
    GROUP (
            ORDER BY a.customerid ASC
            ) AS Latestpurchasedate
        , STRING_AGG(a.wholesaleraccountnumber, ',') WITHIN
    GROUP (
            ORDER BY a.customerid ASC
            ) AS wholesaleraccountnumber
        , STRING_AGG(a.qty, ',') WITHIN
    GROUP (
            ORDER BY a.customerid ASC
            ) AS quantity
        , STRING_AGG(a.unitprice, ',') WITHIN
    GROUP (
            ORDER BY a.customerid ASC
            ) AS unitprice
    FROM custWan a
    WHERE a.rowlines = 1
    GROUP BY a.customerid
        , a.ndc
        , a.PriceTypeGroupDescription
    )
INSERT INTO dbo.salesWanAgg (
    customerid
    , NDC
    , PriceTypeGroupDescription
    , Latestpurchasedate
    , wholesaleraccountnumber
    , quantity
    , unitprice
    , last_updated_date
    )
SELECT customerid
    , NDC
    , PriceTypeGroupDescription
    , Latestpurchasedate
    , wholesaleraccountnumber
    , quantity
    , unitprice
    , getdate()
FROM WanAgg

END


-- CogRxDemo.dbo.salesWanAgg definition

-- Drop table

-- DROP TABLE CogRxDemo.dbo.salesWanAgg;

CREATE TABLE dbo.salesWanAgg (
	customerid int NOT NULL,
	ndc varchar(11) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	PriceTypeGroupDescription varchar(30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Latestpurchasedate nvarchar(4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	wholesaleraccountnumber varchar(8000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	quantity nvarchar(4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	unitprice nvarchar(4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Last_updated_date datetime NULL,
	clientid int not null
);
 CREATE NONCLUSTERED INDEX salesWanAgg_customerid_IDX ON dbo.salesWanAgg (  clientid ASC ,customerid ASC  , ndc ASC  , PriceTypeGroupDescription ASC  )  
	 WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
	 ON [PRIMARY ] ;

	 exec DailyMaintinance.RebuildSalesWanAgg


select distinct clientid from salesWanAgg


-- CogRxDemo.App.BuyInResolved definition

-- Drop table

-- DROP TABLE CogRxDemo.App.BuyInResolved;

CREATE TABLE App.BuyInResolved (
	BuyInResolvedId int IDENTITY(1,1) NOT NULL,
	ClientId int NOT NULL,
	Ndc char(11) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	WholesalerSupplierId int NOT NULL,
	CustomerId int NOT NULL,
	UserAddedId int NOT NULL,
	DateAdded datetime NOT NULL,
	DivisionID varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Status varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	AccountType varchar(3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_BuyInResolved PRIMARY KEY (BuyInResolvedId)
);

|healthsystem|clientid|Description     |
|------------|--------|----------------|
|838509      |8       |CENTURA         |
|WI0013      |7       |ADVOCATE AURORA |
|CO5012      |2       |COMMONSPIRIT    |
|NC9999      |1       |PROD DEMO       |
|NY0024      |4       |NORTHWELL       |
|PA0023      |5       |ST LUKES        |
|MN2013      |3       |FAIRVIEW        |
|743692      |6       |UPMC            |
|PA5036      |9       |JEFFERSON HEALTH|

select distinct customerid from dbo.sales where clientid = 5
select distinct customerid from dbo.sales 

select clientid,count(*)
from dbo.sales
group by clientid
select count(*),a.clientid from
(select distinct clientid,customerid from dbo.sales) a
group by a.clientid

select c.customerid
from dbo.customer c left join dbo.sales s
on c.customerid = s.customerid

CREATE PROCEDURE DailyMaintinance.RebuildFacilityStatus

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
--inactivating
with inactivecte as (
select
	c.customerid
from
	dbo.customer c
where
	not exists (
	select
		1
	from
		dbo.sales s
	where
		s.customerid = c.customerid
		and s.TransactionDate >= DATEADD(year,-3, GETDATE())))
		select * from inactivecte
update
	dbo.customer
set
	status = 'I',
	DateChanged = GETDATE()
where
	CustomerId in (
	select
		customerid
	from
		inactivecte);
--activating

select count(*) from dbo.customer
with activecte as (
select
	c.customerid
from
	dbo.customer c
where
	 exists (
	select
		1
	from
		dbo.sales s
	where
		s.customerid = c.customerid
		and s.TransactionDate <= DATEADD(year,-3, GETDATE())))
		select * from activecte
update
	dbo.customer
set
	status = 'A',
	DateChanged = GETDATE()
where
	CustomerId in (
	select
		customerid
	from
		activecte);
select count(*) from dbo.customer
select distinct customerid as customerid into #tempactivecustomer from dbo.sales

select c.customerid --set c.status = 'A' ,  DateChanged = GETDATE()
from dbo.customer c join #tempactivecustomer t on c.customerid = t.customerid
update customer set
with activecustomer as 
(select distinct customerid as customerid from dbo.sales)
update c set status = 'A' from customer c
where c.customerid in ( select customerid from activecustomer)
		select max(transactiondate),min(transactiondate) from dbo.sales
		
END
select status,count(*) from dbo.customer group by status
update dbo.customer set status = 'I',DateChanged = GETDATE();
with activecustomer as (
	select distinct clientid,customerid from dbo.sales
)
update c set c.status = 'A' ,  DateChanged = GETDATE()
from dbo.customer c join activecustomer a on c.customerid = a.customerid and c.clientid = a.clientid

update dbo.customer set status = 'I' where clientid = 3
with activecustomer as (
	select distinct clientid,customerid from dbo.sales where clientid = 3
)
update c set c.status = 'A' ,  DateChanged = GETDATE()
from dbo.customer c join activecustomer a on c.customerid = a.customerid and c.clientid = a.clientid

select * from dbo.customer

select clientid from dbo.client

select * into dbo.customerbkp1001 from dbo.customer
select * from customer where clientid = 4


select * from dbo.customer where clientid = 5 and status = 'A'

select * from dbo.sales where customerid = 315


select * from dbo.Drug_shortage_alerts dsa 

truncate table dbo.Drug_shortage_alerts 


select * from dbo.GxImport gi 


exec Integrations.UpdatePharmacyItemUsingGxImport


select top 10000  * from dbo.PharmacyItem pi2 

|PremierCustomerSyncId|DataFactory                 |HealthSystemID|FacilityDirectParentID|Secret                         |DatasetInvoiceCode     |DatasetPoCode     |Status|
|---------------------|----------------------------|--------------|----------------------|-------------------------------|-----------------------|------------------|------|
|1                    |adf-Premier-DataReceive-prod|CO5012        |                      |Secret-CogRX-DB-CommonSpirit   |PremierWholesaleInvoice|PremierWholesalePO|A     |
|2                    |adf-Premier-DataReceive-prod|PA0023        |                      |Secret-CogRX-DB-stluke         |PremierWholesaleInvoice|PremierWholesalePO|A     |
|3                    |adf-Premier-DataReceive-prod|NY5011        |NY0024                |Secret-CogRX-DB-northwell      |PremierWholesaleInvoice|PremierWholesalePO|A     |
|4                    |adf-Premier-DataReceive-prod|MN2013        |                      |Secret-CogRX-DB-Fairview       |PremierWholesaleInvoice|PremierWholesalePO|A     |
|5                    |adf-Premier-DataReceive-prod|743692        |                      |Secret-CogRX-DB-upmc           |PremierWholesaleInvoice|PremierWholesalePO|A     |
|6                    |adf-Premier-DataReceive-prod|NY5011        |NY5073                |Secret-CogRX-DB-Demo           |PremierWholesaleInvoice|PremierWholesalePO|I     |
|7                    |adf-Premier-DataReceive-prod|WI0013        |                      |Secret-CogRX-DB-AdvocateAurora |PremierWholesaleInvoice|PremierWholesalePO|A     |
|8                    |adf-Premier-DataReceive-prod|CO5012        |838509                |Secret-CogRX-DB-Centura        |PremierWholesaleInvoice|PremierWholesalePO|A     |
|9                    |adf-Premier-DataReceive-prod|PA5036        |                      |Secret-CogRX-DB-JeffersonHealth|PremierWholesaleInvoice|PremierWholesalePO|A     |


exec [MonthlyMaintinance].[ArchiveSalesData]