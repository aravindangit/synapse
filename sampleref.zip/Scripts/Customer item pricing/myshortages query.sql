DECLARE @CLIENTID INT = 5

--select dbo.fn_DivisionName(cm.DivisionName, cm.DivisionId) 'Division' from dbo.customer as cm
--select * from CustomerDrugShortage
DROP TABLE
IF EXISTS #shortages


/* select * from [Watch].[ShortageWatchReason] 
select * from Watch.ShortageWatch*/

    SELECT DISTINCT sw.ShortageWatchId
        ,  pi.Ndc
        , pi.ItemDescription
        , pi.Manufacturer 
        , sw.ProbabilityPercentage
        , swpt.Description [ProbabilityDescription]
        , sw.ProbabilityChange
        , sw.IsNew
        , sw.PeriodStartDate
        , sw.PeriodEndDate
        , sw.IsActive
         , df.DosageFormAbbreviation AS DosageForm
          , CASE 
            WHEN cds.CustomerDrugShortageId IS NOT NULL
                THEN 1
            ELSE 0
            END AS IsManaged 
         , CASE pi.IsGenericDrug
            WHEN 0
                THEN 'Brand'
            ELSE 'Generic'
            END IsGeneric  
        , st.Days30Qty
        , st.Days30QtyOrdered
        , swr.Sources
         , cds.CustomerDrugShortageId
          , CASE 
            WHEN CHARINDEX('Unknown - ', cm.CustomerName) > 0
                THEN cm.CustomerName
            WHEN cm.DEA IS NULL
                THEN cm.CustomerName + ' - ' + cm.AccountNumber
            ELSE cm.CustomerName + ' - ' + cm.AccountNumber + ' - ' + cm.DEA
            END AS Facility  
        , cm.CustomerId 
        ,CASE 
            WHEN pi.Gx_Indicator = 'Y'
                THEN 'Yes'
            ELSE 'No'
            END AS ProvideGx 
		, CONCAT_WS('-',cm.DivisionName, cm.DivisionId) 'Division' 
    --	dbo.fn_DivisionName(cm.DivisionName, cm.DivisionId) 'Division'
    INTO #shortages
    FROM Watch.ShortageWatch sw
    LEFT OUTER JOIN (
        SELECT swr.ShortageWatchId
            , swr.IsActive
            , replace(string_agg((swrt.Description), ', ') WITHIN GROUP (
                    ORDER BY swrt.Description ASC
                    ), ' Shortage', '') AS Sources
        FROM Watch.ShortageWatchReason AS swr
        LEFT JOIN watch.ShortageWatchReasonType swrt
            ON swrt.ShortageWatchReasonTypeId = swr.ShortageWatchReasonTypeId
        GROUP BY swr.ShortageWatchId
            , swr.IsActive
        ) AS swr
        ON sw.ShortageWatchId = swr.ShortageWatchId
            AND swr.IsActive = 1
    JOIN Watch.ShortageWatchProbabilityRange swpr
        ON sw.ClientId = swpr.ClientId
    JOIN Watch.ShortageWatchProbabilityType swpt
        ON swpr.ShortageWatchProbabilityTypeId = swpt.ShortageWatchProbabilityTypeId
    JOIN dbo.PharmacyItem pi
        ON sw.ItemId = pi.ItemId
    LEFT JOIN ItemMaster.DosageForm df
        ON pi.dosageFormId = df.dosageFormId
    LEFT OUTER JOIN CustomerDrugShortage AS cds
        ON cds.Ndc = pi.Ndc
            AND cds.ShortageStatusId = 1
    LEFT OUTER JOIN dbo.CustomerItemPricing AS cip
        ON cip.ItemId = pi.ItemId and  cip.clientid = @clientId
    LEFT OUTER JOIN dbo.Customer AS cm
        ON cm.CustomerId = cip.CustomerId and cm.clientid = @clientId
     LEFT OUTER JOIN (
        SELECT st.ClientId
            , st.Ndc
            , st.ItemId
            , st.CustomerId
            , sum(st.[30DayUsageQty]) AS Days30Qty
            , sum(st.[30DayQtyOrdered]) AS Days30QtyOrdered
        FROM SalesTotals AS st
        WHERE st.ClientId = @clientId
        GROUP BY st.Ndc
            , st.ItemId
            , st.ClientId
            , st.CustomerId
        ) AS st
        ON st.Ndc = sw.Ndc
            AND st.ClientId = sw.ClientId
            AND st.CustomerId = cm.CustomerId 
    WHERE sw.ClientId = @clientId
        AND sw.IsActive = 1
        AND cm.STATUS = 'A'
        AND sw.ProbabilityPercentage > swpr.ProbabilityLow
        AND sw.ProbabilityPercentage <= swpr.ProbabilityHigh
        AND NOT EXISTS (
            SELECT 1
            FROM dbo.CustomerDrugShortage cds
            WHERE cds.Ndc = pi.Ndc
                AND cds.ShortageStatusId = 1
                AND cds.ClientId = @clientId
            ); 

select distinct ndc from #shortages
/* WITH filteredResults
AS (
    SELECT s.ShortageWatchId
        , s.Ndc
        , s.ItemDescription
        , s.ProbabilityPercentage
        , s.ProbabilityDescription
        , s.ProbabilityChange
        , s.IsNew
        , s.PeriodStartDate
        , s.PeriodEndDate
        , s.IsActive
        , s.IsManaged
        , s.IsGeneric
        , s.Days30Qty
        , s.Days30QtyOrdered
        , s.Days30Qty AS QtyPurchased
        , s.Days30QtyOrdered AS QtyOrdered
        , CASE 
            WHEN s.Days30QtyOrdered <> 0
                THEN CAST(((CAST(s.Days30Qty AS DECIMAL(10, 0)) / CAST(s.Days30QtyOrdered AS DECIMAL(10, 0))) * 100) AS DECIMAL(10, 0))
            ELSE s.Days30QtyOrdered
            END AS FillRate
        , s.Sources
        , s.CustomerDrugShortageId
        , s.Facility
        , s.Manufacturer
        , s.CustomerId
        , s.ProvideGx
        , s.Division
        , s.DosageForm
    FROM #shortages AS s
    WHERE 1 = 1
        AND (s.Days30Qty <> 0)
    )
SELECT s.ShortageWatchId
    , s.Ndc
    , s.ItemDescription
    , s.ProbabilityPercentage
    , s.ProbabilityDescription
    , s.ProbabilityChange
    , s.IsNew
    , s.PeriodStartDate
    , s.PeriodEndDate
    , s.IsActive
    , s.IsManaged
    , s.IsGeneric
    , s.QtyOrdered
    , s.QtyPurchased
    , s.FillRate
    , s.Sources
    , s.CustomerDrugShortageId
    , sc.TotalCount SearchResultCount
    , s.Facility AS Facility
    , s.Manufacturer
    , s.CustomerId
    , s.ProvideGx
    , s.Division
    , s.DosageForm
FROM filteredResults s
JOIN (
    SELECT count(1) TotalCount
    FROM filteredResults
    WHERE QtyOrdered > 0
        AND QtyPurchased >= 0
    ) sc
    ON 1 = 1
WHERE QtyOrdered > 0
    AND QtyPurchased >= 0

--        ORDER BY				
--            CASE WHEN @sortColumn = 'IsNew' and @sortDirection = 'asc' THEN s.IsNew end,
--         CASE WHEN @sortColumn = 'IsNew' and @sortDirection = 'desc' THEN s.IsNew end desc,
--         CASE WHEN @sortColumn = 'Ndc' and @sortDirection = 'asc' THEN s.Ndc end,
--         CASE WHEN @sortColumn = 'Ndc' and @sortDirection = 'desc' THEN s.Ndc end desc,
--         CASE WHEN @sortColumn = 'ItemDescription' and @sortDirection = 'asc' THEN s.ItemDescription end,
--         CASE WHEN @sortColumn = 'ItemDescription' and @sortDirection = 'desc' THEN s.ItemDescription end desc,
--CASE WHEN @sortColumn = 'ProvideGx' and @sortDirection = 'asc' THEN s.ProvideGx end,
--         CASE WHEN @sortColumn = 'ProvideGx' and @sortDirection = 'desc' THEN s.ProvideGx end desc,
--CASE WHEN @sortColumn = 'Facility' and @sortDirection = 'asc' THEN s.Facility end,
--         CASE WHEN @sortColumn = 'Facility' and @sortDirection = 'desc' THEN s.Facility end desc,
--         CASE WHEN @sortColumn = 'ProbabilityPercentage' and @sortDirection = 'asc' THEN s.ProbabilityPercentage end,
--         CASE WHEN @sortColumn = 'ProbabilityPercentage' and @sortDirection = 'desc' THEN s.ProbabilityPercentage end desc,
--            CASE WHEN @sortColumn = 'ProbabilityChange' and @sortDirection = 'asc' THEN s.ProbabilityChange end,
--         CASE WHEN @sortColumn = 'ProbabilityChange' and @sortDirection = 'desc' THEN s.ProbabilityChange end desc,
--         CASE WHEN @sortColumn = 'PeriodStartDate' and @sortDirection = 'asc' THEN s.PeriodStartDate end,
--         CASE WHEN @sortColumn = 'PeriodStartDate' and @sortDirection = 'desc' THEN s.PeriodStartDate end desc,
--         CASE WHEN @sortColumn = 'PeriodEndDate' and @sortDirection = 'asc' THEN s.PeriodEndDate end,
--         CASE WHEN @sortColumn = 'PeriodEndDate' and @sortDirection = 'desc' THEN s.PeriodEndDate end desc,
--         CASE WHEN @sortColumn = 'IsGeneric' and @sortDirection = 'asc' THEN s.IsGeneric end,
--         CASE WHEN @sortColumn = 'IsGeneric' and @sortDirection = 'desc' THEN s.IsGeneric end desc,
--CASE WHEN @sortColumn = 'FillRate' and @sortDirection = 'asc' THEN s.FillRate end,
--CASE WHEN @sortColumn = 'FillRate' and @sortDirection = 'desc' THEN s.FillRate end desc,
--CASE WHEN @sortColumn = 'Division' and @sortDirection = 'asc' THEN s.Division end,
--CASE WHEN @sortColumn = 'Division' and @sortDirection = 'desc' THEN s.Division end desc,
--CASE WHEN @sortColumn = 'QtyOrdered' and @sortDirection = 'asc' THEN s.Days30QtyOrdered end, CASE WHEN @sortColumn = 'QtyOrdered' and @sortDirection = 'desc' THEN s.Days30QtyOrdered end desc,
--CASE WHEN @sortColumn = 'QtyPurchased' and @sortDirection = 'asc' THEN s.Days30Qty end, CASE WHEN @sortColumn = 'QtyPurchased' and @sortDirection = 'desc' THEN s.Days30Qty end desc,
--         CASE WHEN @sortColumn = 'Sources' and @sortDirection = 'asc' THEN s.Sources end,
--         CASE WHEN @sortColumn = 'Sources' and @sortDirection = 'desc' THEN s.Sources end desc
--        OFFSET @pageNumber * @pageSize rows
--        FETCH NEXT @pageSize rows only;
SELECT s.Manufacturer
    , s.ProbabilityDescription
    , s.Division
    , s.Facility
    , trim(value) AS ReasonDescription
    , s.ProvideGx
    , s.DosageForm
FROM #shortages AS s
CROSS APPLY STRING_SPLIT(CASE 
            WHEN s.Sources IS NULL
                THEN ''
            ELSE s.Sources
            END, ',')
WHERE 1 = 1
    AND (s.Days30Qty <> 0)
 */


select * from Watch.ShortageWatch where clientid = 5

select count(*)
from watch.ShortageWatch
where clientid = 5
group by isactive

select clientid,count(*)  
from [dbo].[CustomerItem]
group by clientid


select * from customeritem where clientid = 5
order by datechanged DESC


select max(datechanged),min(datechanged) from customeritem


select max(periodstartdate) as maxstart ,
min(periodstartdate) as minstart,
max(periodstartdate) as maxend,
min(periodstartdate) as minend,
max(addeddate) as maxadded,
min(addeddate) as minadded  from [Watch].[NationalShortageWatchReason]


select max(SysStartTime),min(SysStartTime),max(UpdatedDate),min(UpdatedDate) from [dbo].[PharmacyItemShortage]

select * from  [Watch].[NationalShortageWatchReason]


select * from watch.ShortageWatch where clientid = 5 and isactive = 1


select max(periodstartdate) as maxstart ,
min(periodstartdate) as minstart,
max(periodstartdate) as maxend,
min(periodstartdate) as minend,
max(datechanged) as maxadded,
min(datechanged) as minadded,
count(*) as totalcount  from [Watch].[ShortageWatch] where clientid = 5

