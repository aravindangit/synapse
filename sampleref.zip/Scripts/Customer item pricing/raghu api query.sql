DECLARE @CLIENTID INT = 5


--select * from Watch.ShortageWatch where clientid = 5

drop table if exists #shortages

	        SELECT distinct sw.ShortageWatchId,
		      --      pi.Ndc,
		       --     pi.ItemDescription,
               --     pi.Manufacturer, 
		            sw.ProbabilityPercentage,
				--	swpt.Description [ProbabilityDescription],
                    sw.ProbabilityChange,
                    sw.IsNew,
		            sw.PeriodStartDate,
		            sw.PeriodEndDate,
                    sw.IsActive
					--df.DosageFormAbbreviation as DosageForm,
		        --    CASE WHEN cds.CustomerDrugShortageId IS NOT NULL THEN 1 ELSE 0 END AS IsManaged
				--     CASE pi.IsGenericDrug WHEN 0 THEN 'Brand' ELSE 'Generic' END IsGeneric
					--, st.Days30Qty, st.Days30QtyOrdered
					, swr.Sources
				--	, cds.CustomerDrugShortageId,
				/*	, CASE
					    WHEN CHARINDEX('Unknown - ',cm.CustomerName) > 0 THEN cm.CustomerName
						WHEN cm.DEA IS NULL THEN cm.CustomerName + ' - ' + cm.AccountNumber
						ELSE cm.CustomerName + ' - ' + cm.AccountNumber + ' - ' + cm.DEA 
					END AS Facility,
					cm.CustomerId,*/
              --      CASE WHEN pi.Gx_Indicator = 'Y' THEN 'Yes'
			--	    ELSE 'No' END AS ProvideGx
		--			dbo.fn_DivisionName(cm.DivisionName, cm.DivisionId) 'Division'
           INTO #shortages
	        FROM Watch.ShortageWatch sw
				LEFT OUTER JOIN (
					SELECT swr.ShortageWatchId
						, swr.IsActive
						, replace(string_agg((swrt.Description),', ') 
						WITHIN GROUP (ORDER BY swrt.Description ASC), ' Shortage','') as Sources
					FROM Watch.ShortageWatchReason AS swr
					left join watch.ShortageWatchReasonType swrt 
					on swrt.ShortageWatchReasonTypeId=swr.ShortageWatchReasonTypeId
					GROUP BY swr.ShortageWatchId, swr.IsActive) AS swr ON sw.ShortageWatchId = swr.ShortageWatchId 
					AND swr.IsActive = 1
				JOIN Watch.ShortageWatchProbabilityRange swpr ON sw.ClientId = swpr.ClientId
				JOIN Watch.ShortageWatchProbabilityType swpt ON swpr.ShortageWatchProbabilityTypeId = swpt.ShortageWatchProbabilityTypeId
		        JOIN dbo.PharmacyItem pi ON sw.ItemId = pi.ItemId
				left join ItemMaster.DosageForm df ON pi.dosageFormId = df.dosageFormId
				LEFT OUTER JOIN CustomerDrugShortage AS cds ON cds.Ndc = pi.Ndc AND cds.ShortageStatusId = 1
                LEFT OUTER JOIN dbo.CustomerItemPricing AS cip ON cip.ItemId = pi.ItemId and cip.ClientId = @clientId
				LEFT OUTER JOIN dbo.Customer AS cm ON cm.CustomerId = cip.CustomerId and cm.ClientId = @clientId
				LEFT OUTER JOIN (
					SELECT st.ClientId
						, st.Ndc
						, st.ItemId
						, st.CustomerId
						, sum(st.[30DayUsageQty]) as Days30Qty, sum(st.[30DayQtyOrdered]) as Days30QtyOrdered
						FROM SalesTotals AS st 
						WHERE st.ClientId = @clientId
						GROUP BY st.Ndc, st.ItemId, st.ClientId, st.CustomerId) AS st ON st.Ndc = sw.Ndc
						AND st.ClientId = sw.ClientId and st.CustomerId=cm.CustomerId
	        WHERE sw.ClientId = @clientId
		        AND sw.IsActive = 1 AND cm.status = 'A'
				AND sw.ProbabilityPercentage > swpr.ProbabilityLow AND sw.ProbabilityPercentage <= swpr.ProbabilityHigh
		        and not exists (select 1 from dbo.CustomerDrugShortage cds where cds.Ndc = pi.Ndc and cds.ShortageStatusId = 1 and cds.ClientId = @clientId)
		      select count(*) from #shortages;  

            ;with filteredResults as (
                SELECT s.ShortageWatchId
		            , s.Ndc
		            , s.ItemDescription
		            , s.ProbabilityPercentage
					, s.ProbabilityDescription
                    , s.ProbabilityChange
                    , s.IsNew
		            , s.PeriodStartDate
		            , s.PeriodEndDate
                    , s.IsActive
		            , s.IsManaged
					, s.IsGeneric
					, s.Days30Qty, s.Days30QtyOrdered
					, s.Days30Qty as QtyPurchased, s.Days30QtyOrdered as QtyOrdered, CASE WHEN s.Days30QtyOrdered <> 0 THEN  CAST(((CAST(s.Days30Qty AS DECIMAL(10,0)) / CAST(s.Days30QtyOrdered  AS DECIMAL(10,0))) * 100) AS DECIMAL(10,0)) ELSE s.Days30QtyOrdered end AS FillRate
					, s.Sources
					, s.CustomerDrugShortageId
					, s.Facility
                    , s.Manufacturer
					, s.CustomerId	
				    , s.ProvideGx
				--	, s.Division
					, s.DosageForm
                FROM #shortages AS s
                WHERE 1 = 1
				AND (s.Days30Qty <> 0)
                
            )

           

            SELECT s.ShortageWatchId,
	               s.Ndc,
	               s.ItemDescription,
	               s.ProbabilityPercentage,
				   s.ProbabilityDescription,
                   s.ProbabilityChange,
                   s.IsNew,
	               s.PeriodStartDate,
	               s.PeriodEndDate,
                   s.IsActive,
                   s.IsManaged,
				   s.IsGeneric,
				   s.QtyOrdered,
				   s.QtyPurchased,
				   s.FillRate,
				   s.Sources,
				   s.CustomerDrugShortageId,
	               sc.TotalCount SearchResultCount,
				   s.Facility AS Facility,
				   s.Manufacturer,
				   s.CustomerId,
				   s.ProvideGx,
			--	   s.Division,
				   s.DosageForm
            
            FROM filteredResults s
	            JOIN (select count(1) TotalCount from filteredResults WHERE QtyOrdered > 0 and QtyPurchased >= 0) sc on 1=1
			WHERE QtyOrdered > 0 and QtyPurchased >= 0
    --        ORDER BY				
    --            CASE WHEN @sortColumn = 'IsNew' and @sortDirection = 'asc' THEN s.IsNew end,
	   --         CASE WHEN @sortColumn = 'IsNew' and @sortDirection = 'desc' THEN s.IsNew end desc,
	   --         CASE WHEN @sortColumn = 'Ndc' and @sortDirection = 'asc' THEN s.Ndc end,
	   --         CASE WHEN @sortColumn = 'Ndc' and @sortDirection = 'desc' THEN s.Ndc end desc,
	   --         CASE WHEN @sortColumn = 'ItemDescription' and @sortDirection = 'asc' THEN s.ItemDescription end,
	   --         CASE WHEN @sortColumn = 'ItemDescription' and @sortDirection = 'desc' THEN s.ItemDescription end desc,
				--CASE WHEN @sortColumn = 'ProvideGx' and @sortDirection = 'asc' THEN s.ProvideGx end,
	   --         CASE WHEN @sortColumn = 'ProvideGx' and @sortDirection = 'desc' THEN s.ProvideGx end desc,
				--CASE WHEN @sortColumn = 'Facility' and @sortDirection = 'asc' THEN s.Facility end,
	   --         CASE WHEN @sortColumn = 'Facility' and @sortDirection = 'desc' THEN s.Facility end desc,
	   --         CASE WHEN @sortColumn = 'ProbabilityPercentage' and @sortDirection = 'asc' THEN s.ProbabilityPercentage end,
	   --         CASE WHEN @sortColumn = 'ProbabilityPercentage' and @sortDirection = 'desc' THEN s.ProbabilityPercentage end desc,
    --            CASE WHEN @sortColumn = 'ProbabilityChange' and @sortDirection = 'asc' THEN s.ProbabilityChange end,
	   --         CASE WHEN @sortColumn = 'ProbabilityChange' and @sortDirection = 'desc' THEN s.ProbabilityChange end desc,
	   --         CASE WHEN @sortColumn = 'PeriodStartDate' and @sortDirection = 'asc' THEN s.PeriodStartDate end,
	   --         CASE WHEN @sortColumn = 'PeriodStartDate' and @sortDirection = 'desc' THEN s.PeriodStartDate end desc,
	   --         CASE WHEN @sortColumn = 'PeriodEndDate' and @sortDirection = 'asc' THEN s.PeriodEndDate end,
	   --         CASE WHEN @sortColumn = 'PeriodEndDate' and @sortDirection = 'desc' THEN s.PeriodEndDate end desc,
	   --         CASE WHEN @sortColumn = 'IsGeneric' and @sortDirection = 'asc' THEN s.IsGeneric end,
	   --         CASE WHEN @sortColumn = 'IsGeneric' and @sortDirection = 'desc' THEN s.IsGeneric end desc,
				--CASE WHEN @sortColumn = 'FillRate' and @sortDirection = 'asc' THEN s.FillRate end,
				--CASE WHEN @sortColumn = 'FillRate' and @sortDirection = 'desc' THEN s.FillRate end desc,
				--CASE WHEN @sortColumn = 'Division' and @sortDirection = 'asc' THEN s.Division end,
				--CASE WHEN @sortColumn = 'Division' and @sortDirection = 'desc' THEN s.Division end desc,
				--CASE WHEN @sortColumn = 'QtyOrdered' and @sortDirection = 'asc' THEN s.Days30QtyOrdered end, CASE WHEN @sortColumn = 'QtyOrdered' and @sortDirection = 'desc' THEN s.Days30QtyOrdered end desc,
				--CASE WHEN @sortColumn = 'QtyPurchased' and @sortDirection = 'asc' THEN s.Days30Qty end, CASE WHEN @sortColumn = 'QtyPurchased' and @sortDirection = 'desc' THEN s.Days30Qty end desc,
	   --         CASE WHEN @sortColumn = 'Sources' and @sortDirection = 'asc' THEN s.Sources end,
	   --         CASE WHEN @sortColumn = 'Sources' and @sortDirection = 'desc' THEN s.Sources end desc
    --        OFFSET @pageNumber * @pageSize rows
    --        FETCH NEXT @pageSize rows only;

			SELECT s.Manufacturer
                , s.ProbabilityDescription
			--	, s.Division
                , s.Facility
				, trim(value) as ReasonDescription
				, s.ProvideGx
				, s.DosageForm
            FROM #shortages AS s
			CROSS APPLY  STRING_SPLIT(case when s.Sources IS NULL then '' else s.Sources end, ',')
            WHERE 1 = 1
				AND (s.Days30Qty <> 0)    
        
			select * from Watch.ShortageWatch
			
			
		select * from Watch.ShortageWatchReason	
		select * from watch.ShortageWatchReasonType
			
			SELECT swr.ShortageWatchId
						, swr.IsActive
						, replace(string_agg((swrt.Description),', ') 
						WITHIN GROUP (ORDER BY swrt.Description ASC), ' Shortage','') as Sources
					FROM Watch.ShortageWatchReason AS swr
					left join watch.ShortageWatchReasonType swrt 
					on swrt.ShortageWatchReasonTypeId=swr.ShortageWatchReasonTypeId
					GROUP BY swr.ShortageWatchId, swr.IsActive
					
					
					
					
					
					

declare @Today datetime = DATEADD(dd, DATEDIFF(dd, 0, getdate()), 0);

Drop table if exists #tbl;

create table #tbl(ID int Identity(1,1), 
				  clientid int,
                  Ndc varchar(11), 
				  itemid int, 
                  ProbabilityPercentage float, 
				  PeriodStartDate datetime, 
				  PeriodEndDate datetime, 
				  IsActive bit, 
				  IsNew bit, 
				  ProbabilityChange int, 
				  CreatedDate datetime,
				  ShortageWatchReasonTypeId int,
				  SourceKey int);

insert into #tbl
(clientid, Ndc, itemid, ProbabilityPercentage, PeriodStartDate, PeriodEndDate, IsActive, IsNew, ProbabilityChange, CreatedDate, ShortageWatchReasonTypeId, SourceKey)
select ci.clientid, nsw.ndc,  nsw.itemid, nsw.ProbabilityPercentage, nsw.PeriodStartDate, nsw.PeriodEndDate, nsw.IsActive, nsw.IsNew, nsw.ProbabilityChange, nsw.CreatedDate, nswr.ShortageWatchReasonTypeId, nswr.SourceKey
from [Watch].[NationalShortageWatch] nsw
	inner join [dbo].[CustomerItem] ci
		on nsw.ndc = ci.ndc --and ci.clientid = nsw.clientid
	inner join [Watch].[NationalShortageWatchReason] nswr
		on nsw.NationalShortageWatchId = nswr.NationalShortageWatchId
where nsw.IsActive = 1


create clustered index idx_tmp on #tbl(ID) WITH FILLFACTOR = 100;
select count(*) from #tbl where clientid = 5


delete t
from #tbl t
	inner join [dbo].[CustomerDrugShortage] cds
		on t.clientid = cds.clientid
		and t.ndc = cds.ndc


  MERGE [Watch].[ShortageWatch] AS tar
  USING (select distinct clientid, 
                         Ndc, 
						 itemid, 
						 ProbabilityPercentage, 
						 PeriodStartDate, 
						 PeriodEndDate, 
						 IsActive, 
						 IsNew, 
						 ProbabilityChange, 
						 CreatedDate
		 from #tbl
		 where itemid is not null) AS src
	ON tar.clientid = src.clientid
	and tar.itemid = src.itemid
  WHEN MATCHED 
      AND (tar.ProbabilityPercentage != src.ProbabilityPercentage
   			   or (src.ProbabilityPercentage is null and tar.ProbabilityPercentage is not null)
			   or (src.ProbabilityPercentage is not null and tar.ProbabilityPercentage is null)
		       or tar.PeriodStartDate != src.PeriodStartDate
   			   or (src.PeriodStartDate is null and tar.PeriodStartDate is not null)
			   or (src.PeriodStartDate is not null and tar.PeriodStartDate is null)
			   or tar.PeriodEndDate != src.PeriodEndDate
   			   or (src.PeriodEndDate is null and tar.PeriodEndDate is not null)
			   or (src.PeriodEndDate is not null and tar.PeriodEndDate is null)
			   or tar.IsActive != src.IsActive
   			   or (src.IsActive is null and tar.IsActive is not null)
			   or (src.IsActive is not null and tar.IsActive is null)
			   or tar.IsNew != src.IsNew
   			   or (src.IsNew is null and tar.IsNew is not null)
			   or (src.IsNew is not null and tar.IsNew is null)
			   or tar.ProbabilityChange != src.ProbabilityChange
   			   or (src.ProbabilityChange is null and tar.ProbabilityChange is not null)
			   or (src.ProbabilityChange is not null and tar.ProbabilityChange is null)
			   or tar.CreatedDate != src.CreatedDate
   			   or (src.CreatedDate is null and tar.CreatedDate is not null)
			   or (src.CreatedDate is not null and tar.CreatedDate is null))
		and (tar.IsActive = 1 or (tar.IsActive = 0 and src.IsActive = 1 and DATEADD(dd, DATEDIFF(dd, 0, tar.PeriodEndDate), 60) <= @Today )) then
			   --or tar.IsActive = 0) THEN
      UPDATE SET  tar.ProbabilityPercentage = src.ProbabilityPercentage, 
					tar.PeriodStartDate = src.PeriodStartDate,
					tar.PeriodEndDate = src.PeriodEndDate,
					tar.IsActive = src.IsActive,
					tar.IsNew = src.IsNew,
					tar.ProbabilityChange = src.ProbabilityChange,
					tar.CreatedDate = src.CreatedDate,
					tar.DateChanged = getdate()
  WHEN NOT MATCHED THEN
      INSERT (clientid, Ndc, itemid, ProbabilityPercentage, PeriodStartDate, PeriodEndDate, IsActive, IsNew, ProbabilityChange, CreatedDate, temp)
      VALUES (src.clientid, src.Ndc, src.itemid, src.ProbabilityPercentage, src.PeriodStartDate, src.PeriodEndDate, src.IsActive, src.IsNew, src.ProbabilityChange, src.CreatedDate, 'Y');


MERGE [Watch].[ShortageWatchReason] AS tar
  USING (select sw.ShortageWatchId, t.ShortageWatchReasonTypeId, t.SourceKey, t.PeriodStartDate, t.PeriodEndDate, t.IsActive
		 from [Watch].[ShortageWatch] sw
			inner join #tbl t 
				on t.clientid = sw.ClientId
			   and t.itemid = sw.itemid) AS src
	ON tar.ShortageWatchId = src.ShortageWatchId
	and tar.ShortageWatchReasonTypeId = src.ShortageWatchReasonTypeId
  WHEN MATCHED 
      AND (tar.SourceKey != src.SourceKey
   			   or (src.SourceKey is null and tar.SourceKey is not null)
			   or (src.SourceKey is not null and tar.SourceKey is null)
			   or tar.PeriodStartDate != src.PeriodStartDate
   			   or (src.PeriodStartDate is null and tar.PeriodStartDate is not null)
			   or (src.PeriodStartDate is not null and tar.PeriodStartDate is null)
			   or tar.PeriodEndDate != src.PeriodEndDate
   			   or (src.PeriodEndDate is null and tar.PeriodEndDate is not null)
			   or (src.PeriodEndDate is not null and tar.PeriodEndDate is null)
			   or tar.IsActive != src.IsActive
   			   or (src.IsActive is null and tar.IsActive is not null)
		       or (src.IsActive is not null and tar.IsActive is null))
		and (tar.IsActive = 1 or (tar.IsActive = 0 and src.IsActive = 1 and DATEADD(dd, DATEDIFF(dd, 0, tar.PeriodEndDate), 60) <= @Today )) then
			   --or tar.IsActive = 0) THEN
      UPDATE SET  tar.SourceKey = src.SourceKey,
				  tar.PeriodStartDate = src.PeriodStartDate,
				  tar.PeriodEndDate = src.PeriodEndDate,
				  tar.IsActive = src.IsActive,
	              tar.DateChanged = getdate()
  WHEN NOT MATCHED THEN
      INSERT ([ShortageWatchId], [ShortageWatchReasonTypeId],[SourceKey],[PeriodStartDate],[PeriodEndDate],[IsActive], temp)
      VALUES (src.ShortageWatchId, src.ShortageWatchReasonTypeId,src.SourceKey,src.PeriodStartDate,src.PeriodEndDate,src.IsActive, 'Y');


End
