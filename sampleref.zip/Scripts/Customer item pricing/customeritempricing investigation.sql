--[Integrations].[MergeAquisitionCost_Premier] 'PremierWholesaleInvoice'

CREATE PROCEDURE [Integrations].[MergeAquisitionCost_Premier] @DataSource varchar(50)
AS
BEGIN
	
	SELECT TOP 100 * FROM CustomerItemPricing cip 
	SELECT MAX(PriceStartDate),MIN(PriceStartDate) FROM CustomerItemPricing
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

declare @clientid int = (select clientid from [ImportFileIDMapping] where [ClientImportCode] = @DataSource);
declare @DataSourceId int = (select DataSourceId from [ImportFileIDMapping] where [ClientImportCode] = @DataSource);

Drop table if exists #temp_Premier_Pricing;

with Prices AS 
(
  Select --wi.Cliendid ,
  FacilityID, 
        Wholesaler, 
		WholesalerPurchaseType, 
		su.[SupplierId] 'SupplierId', 
		--CASE WholesalerPurchaseType  
		--	WHEN 'Premier Contract' THEN 3  
		--	WHEN 'Wholesaler Contract' THEN 3  
		--	WHEN 'Other Contract' THEN 3  
		--	WHEN 'Private Contract' THEN 3  
		--	WHEN 'Non Contract' THEN 3  
		--	WHEN 'DSH' THEN 2  
		--	WHEN '340B' THEN 2  
		--	WHEN 'WAC' THEN 11  	
		--	ELSE null
		--END 'PriceListId',
		p.PriceListId as PriceListId,
		Ndc, 
		InvoiceDate, 
		InvoicePrice, 
		wi.Wholesaler 'DistributorAccountNo'
from [Premier].[WholesalerInvoices] wi
		inner join supplier su
	on wi.Wholesaler = su.SupplierName
			left join PriceList p on p.PriceListDescription=coalesce(wi.WholesalerAccountAttribute,'UNK')
 where su.SupplierTypeId= 2 and su.MfrId is null and ndc != '0'),-- and wi.cliendid = 5),
PriceRank AS (
select--Cliendid,
FacilityID, 
        Wholesaler, 
		SupplierId,
		WholesalerPurchaseType, 
		Ndc, 
		InvoiceDate, 
		InvoicePrice,
		PriceListId,
		rank() over (partition by FacilityID, SupplierId, PriceListId, Ndc order by InvoiceDate desc) rnk,
		DistributorAccountNo
from Prices),
PriceCodes as ( 
select FacilityID, 
       Wholesaler,
	   SupplierId,
	   WholesalerPurchaseType,
	   Ndc,
	   InvoiceDate,
	   InvoicePrice,
	   PriceListId,
	   ROW_NUMBER() over (partition by SupplierId, FacilityID, Ndc, PriceListId order by InvoiceDate desc) Seq,
	   DistributorAccountNo
from PriceRank
where rnk = 1)
select '5' 'clientid', 
	   SupplierId 'CpSupplierID',
	   c.CustomerId 'CustomerId',	    
	   pc.Ndc 'NDC',
	   pi.itemid 'ItemId',
	   pc.InvoicePrice 'PriceAmount',
	   InvoiceDate 'PriceStartDate',
	   PriceListId,
	 --  @DataSourceId 'DataSourceId',
	   DistributorAccountNo
--into #temp_Premier_Pricing
from PriceCodes pc
	inner join customer c
		on c.ClientId = 5
		and pc.FacilityID = c.AccountNumber
	inner join [dbo].[PharmacyItem] pi
		on pc.ndc = pi.ndc
where seq = 1;


Insert into [dbo].[CustomerItemPricingHistory]
	(ActionType,
	 CustomerItemPriceId,
	 ClientId,
	 CpSupplierID,
	 ItemId,
	 PriceAmount,
	 PriceStartDate,
	 CustomerId,
	 PriceListId,
	 DataSourceId,
	 DateChanged,
	 [Status],
	 PriceChangeDate, 
	 OldPrice, 
	 PercentageChange,
	 DistributorAccountNo
)
select m.ActionType,
	   m.CustomerItemPriceId,
	   m.ClientId,
	   m.CpSupplierID,
	   m.ItemId,
	   m.PriceAmount,
	   m.PriceStartDate,
	   m.CustomerId,
	   m.PriceListId,
	   m.DataSourceId,
	   m.DateChanged,
	   m.[Status],
	   m.PriceChangeDate, 
	   m.OldPrice, 
	   m.PercentageChange,
	   m.DistributorAccountNo
From
	(MERGE [dbo].[CustomerItemPricing] AS tar
		USING (select clientid,
					   CpSupplierID,
					   CustomerId,
					   Ndc,
					   ItemId,
					   PriceAmount,
					   PriceStartDate,
					   PriceListId,
					   DataSourceId,
					   DistributorAccountNo
				from #temp_Premier_Pricing) AS src
		ON tar.[ClientId] = src.[ClientId]
		and tar.[CpSupplierID] = src.[CpSupplierID] 
		and tar.[ItemId] = src.[ItemId]
		and tar.[CustomerId] = src.[CustomerId]
		and tar.[PriceListId] = src.[PriceListId]
		and tar.[DataSourceId] = src.[DataSourceId]
		WHEN MATCHED 
		     AND (tar.PriceAmount != src.PriceAmount
		       or tar.PriceStartDate != src.PriceStartDate
			   or tar.DistributorAccountNo != src.DistributorAccountNo
  			   or (src.DistributorAccountNo is null and tar.DistributorAccountNo is not null)
			   or (src.DistributorAccountNo is not null and tar.DistributorAccountNo is null)
			   or tar.[status] = 'I')
		    THEN
		   UPDATE SET
			  tar.PriceChangeDate = case when tar.PriceAmount != src.PriceAmount then GetDate() else tar.PriceChangeDate end,
			  tar.OldPrice = case when tar.PriceAmount != src.PriceAmount then tar.PriceAmount else tar.OldPrice end,
			  tar.PercentageChange = case when (tar.PriceAmount != src.PriceAmount) and (tar.PriceAmount != 0) then [Integrations].[CalculatePriceChangePercentage](src.PriceAmount,tar.PriceAmount)  else tar.PercentageChange end,
			  tar.PriceAmount = src.PriceAmount,
			  tar.PriceStartDate = src.PriceStartDate,
			  tar.DateChanged = getdate(),
			  tar.[Status] = 'A',
			  tar.DistributorAccountNo = src.DistributorAccountNo
		WHEN NOT MATCHED THEN
		   INSERT
		   (
				ClientId, 
				CpSupplierID,
				ItemId,
				PriceAmount,
				PriceStartDate,
				CustomerId,
				PriceListId, 
				DataSourceId,
				[Status],
				ndc,
				DistributorAccountNo
		   )
		   VALUES
		   (
				src.ClientId, 
				src.CpSupplierID,
				src.ItemId,
				src.PriceAmount,
				src.PriceStartDate,
				src.CustomerId,
				src.PriceListId, 
				src.DataSourceId,
				'A',
				src.ndc,
				src.DistributorAccountNo
		   )
		WHEN NOT MATCHED BY SOURCE
		  and tar.clientid in (select clientid from [dbo].[ImportFileIDMapping] where ClientImportCode = @DataSource)
		  and tar.CpSupplierID in (select CpSupplierID from [dbo].[ImportFileIDMapping] where ClientImportCode = @DataSource)
		  and tar.[CustomerId] in (select [CustomerId] from [dbo].[ImportFileIDMapping] where ClientImportCode = @DataSource)
		  and tar.PriceListId in (select PriceListId from [dbo].[ImportFileIDMapping] where ClientImportCode = @DataSource)
		  and tar.DataSourceId in (select DataSourceId from [dbo].[ImportFileIDMapping] where ClientImportCode = @DataSource)
   	      AND tar.[status] = 'A' THEN
		UPDATE SET
			  tar.[status] = 'I'
		OUTPUT
		   CASE WHEN deleted.[status] = 'A' and inserted.[status] = 'I' Then 'DELETED' 
		        WHEN deleted.[status] = 'I' and inserted.[status] = 'A' Then 'REACTIVATED'
				WHEN $action = 'UPDATE' Then 'UPDATED'
				WHEN $action = 'INSERT' Then 'INSERTED'
		        ELSE $action End as ActionType,
		   CASE WHEN $action = 'INSERT' then null else deleted.CustomerItemPriceId End as CustomerItemPriceId,
		   CASE WHEN $action = 'INSERT' then inserted.ClientId else deleted.ClientId End as ClientId,
		   CASE WHEN $action = 'INSERT' then inserted.CpSupplierID else deleted.CpSupplierID End as CpSupplierID,
		   CASE WHEN $action = 'INSERT' then inserted.ItemId else deleted.ItemId End as ItemId,
		   CASE WHEN $action = 'INSERT' then inserted.PriceAmount else deleted.PriceAmount End as PriceAmount,
		   CASE WHEN $action = 'INSERT' then inserted.PriceStartDate else deleted.PriceStartDate End as PriceStartDate,
		   CASE WHEN $action = 'INSERT' then inserted.CustomerId else deleted.CustomerId End as CustomerId,
		   CASE WHEN $action = 'INSERT' then inserted.PriceListId else deleted.PriceListId End as PriceListId,
		   CASE WHEN $action = 'INSERT' then inserted.DataSourceId else deleted.DataSourceId End as DataSourceId,
		   CASE WHEN $action = 'INSERT' then inserted.DateChanged else deleted.DateChanged End as DateChanged,
		   CASE WHEN $action = 'INSERT' then inserted.Status else deleted.Status End as [Status],
		   CASE WHEN $action = 'INSERT' then inserted.PriceChangeDate else deleted.PriceChangeDate End as PriceChangeDate,
		   CASE WHEN $action = 'INSERT' then inserted.OldPrice else deleted.OldPrice End as OldPrice,
		   CASE WHEN $action = 'INSERT' then inserted.PercentageChange else deleted.PercentageChange End as PercentageChange,
		   CASE WHEN $action = 'INSERT' then inserted.DistributorAccountNo else deleted.DistributorAccountNo End as DistributorAccountNo
	) as M; 

	if @@error = 0
	begin
		--Log data activity
		declare @BeginDate datetime
		declare @EndData datetime

		select @BeginDate = min([BeginDate]), @EndData = max([EndDate])
		from [Raw].[AcquisitionCost]
		where [DataSource] = @DataSource

		exec [Integrations].[LogDataFeed] @DataSource, 'PriceList', @BeginDate, @EndData;
	end

END
