drop table if EXISTS #potempsource
select 
a.* into #potempsource from (SELECT  ifim.clientid clientid
    , ifim.DataSourceId DataSourceId
    , max(po.ApprovalDateTime) ApprovalDateTime
    , po.Ndc Ndc
    , pi.ItemId ItemId
    , po.PurchaseOrderNumber PurchaseOrderNumber
    , po.LineNumber LineNumber
    , po.Buyer Buyer
    , po.PriceList PriceList
    , po.PurchaseOrderStatus PurchaseOrderStatus
    , po.LineStatus LineStatus
    , po.SupplierId SupplierId
    , po.SupplierName SupplierName
    , po.SupplierSite SupplierSite
    , po.Routing Routing
    , po.ReceiptNumber ReceiptNumber
    , cs.CustomerSupplierId CustomerSupplierId
    , max(po.ReceivedDateTime) ReceivedDateTime
    , max(po.ClosedDateTime) ClosedDateTime
    , Max(po.UnitPrice) UnitPrice
    , max(po.ExtendedPrice) ExtendedPrice
    , Max(po.CurrentQuantityOrdered) CurrentQuantityOrdered
    , Max(po.OriginalQuantityOrdered) OriginalQuantityOrdered
    , Sum(po.QuantityReceived) QuantityReceived
    , Max(po.QuantityOutstanding) QuantityOutstanding
    , Max(po.QuantityCancelled) QuantityCancelled
    , Max(po.TotalQuantityBilled) TotalQuantityBilled
    , count(*) ReceiptTransactionCount
    , ptgx.[PriceTypeGroupId] [PriceTypeGroupId]
    , CASE 
        WHEN ptgx.[PriceTypeGroupId] IN (1, 2)
            THEN 1
        ELSE 0
        END 'Is340B'
FROM [Raw].[PurchaseOrders] po
INNER JOIN [dbo].[ImportFileIDMapping] ifim
    ON po.DataSource = ifim.ClientImportCode
LEFT JOIN PharmacyItem pi
    ON po.Ndc = pi.Ndc
INNER JOIN [dbo].[CustomerSupplier] cs
    ON po.SupplierId = cs.ClientSupplierRefId
        AND ifim.clientid = cs.clientid
LEFT JOIN [Mapping].[PriceTypeGroupXref] ptgx
    ON po.PriceList = ptgx.ClientPriceTypeCode
        AND ifim.clientid = ptgx.ClientId
WHERE po.DataSource = 'PremierWholesalePO' 
GROUP BY ifim.clientid
    , ifim.DataSourceId
    , po.Ndc
    , pi.ItemId
    , po.PurchaseOrderNumber
    , po.LineNumber
    , po.Buyer
    , po.PriceList
    , po.PurchaseOrderStatus
    , po.LineStatus
    , po.SupplierId
    , po.SupplierName
    , po.SupplierSite
    , po.Routing
    , po.ReceiptNumber
    , cs.CustomerSupplierId
    , PriceTypeGroupId) a  
    select count(*) from #potempsource  --no disitinct 1408261   -- distinct 1408182
    select 1408261 - 1408182
     --710038
     710054

select count(*) from ( 
    select  a.[ClientId],a.NDC,a.PurchaseOrderNumber,a.LineNumber,a.ReceiptNumber,a.Routing from #potempsource a ) b

--order by rownum desc
select b.* from
(select a.[ClientId],a.NDC,a.PurchaseOrderNumber,a.LineNumber,a.ReceiptNumber,a.Routing ,
rank() OVER ( PARTITION BY a.[ClientId],a.NDC,a.LineNumber,a.PurchaseOrderNumber,a.ReceiptNumber,a.Routing 
ORDER BY a.[ClientId],a.NDC,a.LineNumber,a.ReceiptNumber,a.Routing) row_num
from #potemptable as a) b
where b.row_num > 1

select count(*) from #potempsource


select b.* from
(select a.[ClientId],a.NDC,a.PurchaseOrderNumber,a.LineNumber,a.ReceiptNumber,a.Routing ,
rank() OVER ( PARTITION BY a.[ClientId],a.NDC,a.LineNumber,a.PurchaseOrderNumber,a.ReceiptNumber,a.Routing 
ORDER BY a.[ClientId],a.NDC,a.LineNumber,a.ReceiptNumber,a.Routing) row_num
from #potemptable as a) b
where b.row_num > 1

select b.* from
(select a.[ClientId],a.NDC,a.PurchaseOrderNumber,a.LineNumber,a.ReceiptNumber,a.Routing ,
rank() OVER ( PARTITION BY a.[ClientId],a.NDC,a.LineNumber,a.PurchaseOrderNumber,a.ReceiptNumber,a.Routing 
ORDER BY a.[ClientId],a.NDC,a.LineNumber,a.ReceiptNumber,a.Routing) row_num
from dbo.PurchaseOrder as a) b
where b.row_num > 1

select count(*) from dbo.PurchaseOrder
select count(*) from dbo.sales



select a.[ClientId],a.NDC,a.PurchaseOrderNumber,a.LineNumber,a.ReceiptNumber,a.Routing,
--b.[ClientId],b.NDC,b.PurchaseOrderNumber,b.LineNumber,b.ReceiptNumber,b.Routing,
rank() OVER ( PARTITION BY a.[ClientId],a.NDC,a.LineNumber,a.PurchaseOrderNumber,a.ReceiptNumber,a.Routing
--b.[ClientId],b.NDC,b.PurchaseOrderNumber,b.LineNumber,b.ReceiptNumber,b.Routing
ORDER BY a.[ClientId],a.NDC,a.PurchaseOrderNumber,a.LineNumber,a.ReceiptNumber,a.Routing
--b.[ClientId],b.NDC,b.PurchaseOrderNumber,b.LineNumber,b.ReceiptNumber,b.Routing
) row_num
from #potempsource a join dbo.PurchaseOrder b on
	a.[ClientId] = b.[ClientId]
		 and a.NDC = b.NDC
		 and a.PurchaseOrderNumber = b.PurchaseOrderNumber
		 and a.LineNumber = b.LineNumber
		 and (a.ReceiptNumber = b.ReceiptNumber or (a.ReceiptNumber is null and b.ReceiptNumber is null))
		 and (a.Routing = b.Routing or (a.Routing is null and b.Routing is null))

select b.* from 
		 (select a.[ClientId],a.NDC,a.PurchaseOrderNumber,a.LineNumber,a.ReceiptNumber,a.Routing,
		 ROW_NUMBER() OVER (PARTITION BY a.[ClientId],a.NDC,a.LineNumber,a.PurchaseOrderNumber,a.ReceiptNumber,a.Routing
		 ORDER BY a.NDC) row_num
			from #potempsource a) b 
			where b.row_num > 1 a.ndc = '49281040565'
		 and a.PurchaseOrderNumber = 0

select * from RAW.PurchaseOrders where PurchaseOrderNumber =  '0'

		 select * from dbo.PurchaseOrder a
		 where a.[ClientId] = 4 and
		 a.NDC = '49281040565' and
		 a.PurchaseOrderNumber = 0 and
		 a.LineNumber = 2 and
		 a.ReceiptNumber is null  and
		 a.Routing is null


		 select * from dbo.PurchaseOrder

         select top 10000  * from [dbo].[PurchaseOrderHistory] order by DateChanged desc
drop table if EXISTS #temppoanalysis
select c.[ClientId],c.NDC,c.PurchaseOrderNumber,c.LineNumber,c.ReceiptNumber,c.Routing,c.details,
ROW_NUMBER() OVER 
( PARTITION BY c.[ClientId],c.NDC,c.PurchaseOrderNumber,c.LineNumber,c.ReceiptNumber,c.Routing
ORDER BY c.[ClientId],c.NDC,c.PurchaseOrderNumber,c.LineNumber,c.ReceiptNumber,c.Routing
) as newrownumber
into #temppoanalysis from 
(select  a.[ClientId],a.NDC,a.PurchaseOrderNumber,a.LineNumber,a.ReceiptNumber,a.Routing,'Source' as details
from #potempsource a
union all 
select b.[ClientId],b.NDC,b.PurchaseOrderNumber,b.LineNumber,b.ReceiptNumber,b.Routing,'target' as details
from dbo.PurchaseOrder b) as c
--where c.newrownumber > 2
order by c.[ClientId],c.NDC,c.PurchaseOrderNumber,c.LineNumber,c.ReceiptNumber,c.Routing

select * from #temppoanalysis where  newrownumber > 2
select * from #temppoanalysis where ndc in ('49281040565','49281041950') and purchaseordernumber = '0'
order by ndc,details,newrownumber asc
where details = 'target' and  newrownumber > 
 where ndc = '49281041950' and PurchaseOrderNumber = 0
order by ndc,details,newrownumber

select a.[ClientId],a.NDC,a.PurchaseOrderNumber,a.LineNumber,a.ReceiptNumber,a.Routing,
--b.[ClientId],b.NDC,b.PurchaseOrderNumber,b.LineNumber,b.ReceiptNumber,b.Routing,
rank() OVER ( PARTITION BY a.[ClientId],a.NDC,a.LineNumber,a.PurchaseOrderNumber,a.ReceiptNumber,a.Routing
--b.[ClientId],b.NDC,b.PurchaseOrderNumber,b.LineNumber,b.ReceiptNumber,b.Routing
ORDER BY a.[ClientId],a.NDC,a.PurchaseOrderNumber,a.LineNumber,a.ReceiptNumber,a.Routing
--b.[ClientId],b.NDC,b.PurchaseOrderNumber,b.LineNumber,b.ReceiptNumber,b.Routing
) row_num
from #potempsource a join dbo.PurchaseOrder b on
	a.[ClientId] = b.[ClientId]
		 and a.NDC = b.NDC
		 and a.PurchaseOrderNumber = b.PurchaseOrderNumber
		 and a.LineNumber = b.LineNumber
		 and (a.ReceiptNumber = b.ReceiptNumber or (a.ReceiptNumber is null and b.ReceiptNumber is null))
		 and (a.Routing = b.Routing or (a.Routing is null and b.Routing is null))


         select * from dbo.sales where ndc in ('49281040565','49281041950') order by TransactionDate desc

           select ndc,max(TransactionDate) as maxdate, min(TransactionDate) as mindate 
            from dbo.sales where ndc in ('49281040565','49281041950')
            group by ndc
            where ndc in ('49281040565','49281041950') order by TransactionDate desc



sp_helptext '[Integrations].[MergePurchaseOrderRecords]'

exec [Integrations].[MergePurchaseOrderRecords] 'PremierWholesalePO'

select * from client

select * from Predictive.NationalPricePrediction

select * from raw.roi_information

select * from dbo.roi_information

exec [Integrations].[MergeAquisitionCost_Premier] 'PremierWholesaleInvoice'



|clientid|         |
|--------|---------|
|1       |103,233  |
|3       |1,455,708|
|5       |250,713  |
|9       |137,086  |
|2       |2,793,041|
|8       |387,253  |
|6       |591,630  |
|7       |1,901,680|

|clientid|         |
|--------|---------|
|1       |103,233  |
|3       |1,455,708|
|4       |482,116  |
|5       |250,713  |
|9       |137,086  |
|2       |2,793,041|
|8       |387,253  |
|6       |591,630  |
|7       |1,901,680|

|clientid|         |
|--------|---------|
|1       |103,233  |
|4       |482,116  |
|3       |1,455,708|
|5       |250,713  |
|9       |137,086  |
|2       |2,793,041|
|8       |387,253  |
|6       |591,630  |
|7       |1,901,680|


|clientid|         |
|--------|---------|
|3       |1,455,708|
|4       |482,116  |
|9       |137,086  |
|2       |2,793,041|
|6       |591,630  |
|7       |1,901,680|
|8       |387,253  |
|1       |103,233  |
|5       |250,713  |

select cliendid,max(invoicedate),min(invoicedate) from premier.wholesalerinvoices
group by cliendid

select top 1000 * from premier.wholesalerinvoices