-- CogRxDemo.dbo.Sales definition

-- Drop table

-- DROP TABLE CogRxDemo.dbo.Sales;


alter TABLE raw.Sales 
ADD PremierContractNumber varchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL

alter TABLE dbo.Sales 
ADD PremierContractNumber varchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL

	