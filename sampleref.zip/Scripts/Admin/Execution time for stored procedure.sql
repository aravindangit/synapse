SELECT
    --   DB_NAME(database_id) [database],
    OBJECT_NAME(object_id) [stored_procedure]
    , cached_time
    , last_execution_time
    , execution_count
    , total_elapsed_time / execution_count [avg_elapsed_time]
--  [type_desc]
FROM sys.dm_exec_procedure_stats
--WHERE OBJECT_NAME(object_id) IN ('SP1','SP2','SP3','SP4','SP5')
ORDER BY avg_elapsed_time DESC;

SELECT DB_NAME(database_id) [database]
    , OBJECT_NAME(object_id) [stored_procedure]
    , cached_time
    , last_execution_time
    , execution_count
    , total_elapsed_time AS overalltime
    , (total_elapsed_time / execution_count) / 60000000 [avg_elapsed_time]
    , -- converting to minutes from milli seconds
    last_elapsed_time / 60000000 AS lastrunmin
    ,
    -- total_elapsed_time/60000000 [avg_elapsed_time], -- converting to minutes from milli seconds
    -- (total_elapsed_time/execution_count)/60000000) [avg_disruption_elapsed_time], -- converting to minutes from milli seconds
    [type_desc]
FROM sys.dm_exec_procedure_stats
WHERE OBJECT_NAME(object_id) LIKE ('Build%')
ORDER BY avg_elapsed_time DESC

SELECT *
FROM sys.dm_exec_procedure_stats

--top ten stored procedures
SELECT TOP 10 d.object_id
    , d.database_id
    , OBJECT_NAME(object_id, database_id) 'proc name'
    , d.cached_time
    , d.last_execution_time
    , d.total_elapsed_time
    , d.total_elapsed_time / d.execution_count AS [avg_elapsed_time]
    , d.last_elapsed_time
    , d.execution_count
FROM sys.dm_exec_procedure_stats AS d
ORDER BY [total_worker_time] DESC;

PRINT convert(VARCHAR, getdate(), 21)

EXEC PROC SP1

PRINT convert(VARCHAR, getdate(), 21)

SELECT *
FROM sys.schemas s

SELECT *
FROM sys.tables t

SELECT T.name TableName
    , i.Rows NumberOfRows
FROM sys.tables T
JOIN sys.sysindexes I
    ON T.OBJECT_ID = I.ID
WHERE indid IN (0, 1)
    AND T.schema_id = 20
ORDER BY i.Rows DESC
    , T.name
