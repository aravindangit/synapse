-- Local Temporary Stored Procedure
CREATE PROC #HarshaTest
AS
DECLARE @Table TABLE ( col1 INT );
INSERT INTO @Table
 ( col1 )
VALUES ( 1),(2),(3),(4);
SELECT * FROM @Table
RETURN 0
GO
-- Global Temporary Stored Procedure
CREATE PROC ##HarshaTest
AS
DECLARE @Table TABLE ( col1 INT );
INSERT INTO @Table
 ( col1 )
 VALUES ( 1),(2),(3),(4);
SELECT * FROM @Table
RETURN 0
GO

USE tempdb
GO
-- Stored procedure in tempdb
CREATE PROC dbo.HarshaTest
AS
DECLARE @Table TABLE ( col1 INT );
INSERT INTO @Table
 ( col1 )
VALUES ( 1),(2),(3),(4);
SELECT * FROM @Table
RETURN 0
GO

-- Local Temporary Stored Procedure
CREATE PROC ##cogrxspend(@mfid int)
AS
BEGIN 
--select sum([90DayUsageExtPrice]) from (
select clientid, 
		CustomerId, 
		ndc, 
		PriceTypeGroupId, 
		Max(itemid) itemid, 
		sum(qty) '90DayUsageQty', 
		sum(qty * unitprice) '90DayUsageExtPrice',
		sum(QtyOrdered) '90DayQtyOrdered',
		count(*) '90DayUsageTransactionCount'
	--	@Past90 '90DayAsOfDate'
       from dbo.sales
       where (transactiondate >= '2021-01-01' and transactiondate <='2021-03-30')
         and [RepackagedFlag] = 0
         and itemid in (select distinct itemid from PharmacyItem where MfrId=@mfid)
       group by clientid, CustomerId, ndc, PriceTypeGroupId--) a
       
       --MfrId=971	, 924
END

Exec ##cogrxspend 971;