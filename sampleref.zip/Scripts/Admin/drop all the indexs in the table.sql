
BEGIN TRAN
declare @qry nvarchar(max);
select @qry = 
(SELECT  'DROP INDEX ' + quotename(ix.name) + ' ON ' + quotename(object_schema_name(object_id)) + '.' + quotename(OBJECT_NAME(object_id)) + '; '
FROM  sys.indexes ix
WHERE   ix.Name IS NOT null and ix.Name like '%rawinvoices%'
for xml path(''));
exec sp_executesql @qry;
COMMIT TRAN

CREATE NONCLUSTERED INDEX IX_NationalPriceDisruptions_RawInvoices_DrugStrength_GpiName ON NationalPriceDisruptions.RawInvoices (GpiName,DrugStrength) INCLUDE (QuantityOrdered, TotalUnits, InvoiceDateString);
CREATE NONCLUSTERED INDEX IX_NationalPriceDisruptions_RawInvoices_FILL_FacilityState_GpiName ON NationalPriceDisruptions.RawInvoices (GpiName,FacilityState) INCLUDE (TotalUnits, QuantityOrdered, Manufacturer, InvoiceDateString);
CREATE NONCLUSTERED INDEX IX_NationalPriceDisruptions_RawInvoices_GpiName ON NationalPriceDisruptions.RawInvoices (GpiName) INCLUDE (TotalUnits, QuantityOrdered, InvoiceDateString);
CREATE NONCLUSTERED INDEX IX_NationalPriceDisruptions_RawInvoices_Manufacturer_GpiName ON NationalPriceDisruptions.RawInvoices (GpiName,Manufacturer) INCLUDE (TotalUnits, QuantityOrdered, InvoiceDateString);

COMMIT TRAN;
==============================================
select is_disabled,* from sys.indexes
where object_id = (select top 1 object_id from sys.objects where name = 'rawinvoices')

DECLARE @indexName VARCHAR(128)
DECLARE @tableName VARCHAR(128)

DECLARE [indexes] CURSOR FOR

        SELECT          [sysindexes].[name] AS [Index],
                        [sysobjects].[name] AS [Table]

        FROM            [sysindexes]

        INNER JOIN      [sysobjects]
        ON              [sysindexes].[id] = [sysobjects].[id]

        WHERE           [sysindexes].[name] IS NOT NULL 
        AND             [sysobjects].[type] = 'U'
        --AND               [sysindexes].[indid] > 1

OPEN [indexes]

FETCH NEXT FROM [indexes] INTO @indexName, @tableName

WHILE @@FETCH_STATUS = 0
BEGIN
        --PRINT 'DROP INDEX [' + @indexName + '] ON [' + @tableName + ']'
        Exec ('DROP INDEX [' + @indexName + '] ON [' + @tableName + ']')

        FETCH NEXT FROM [indexes] INTO @indexName, @tableName
END

CLOSE           [indexes]
DEALLOCATE      [indexes]

GO