
select distinct o.name, o.type_desc, dep.is_updated
FROM sys.sql_modules   m 
INNER JOIN sys.objects o ON m.object_id=o.object_id
INNER JOIN sys.sql_dependencies dep ON m.object_id = dep.object_id
INNER JOIN sys.columns col ON dep.referenced_major_id = col.object_id
INNER JOIN sys.tables tab ON tab.object_id = col.object_id
WHERE tab.name = 'transform'
and is_updated = 1
ORDER BY O.name
===================================================================

EXECUTE [PriceDisruptions].[BuildWacPricekey]
========================================================
use [CSharpCornerDB]  
GO  
GRANT VIEW DEFINITION ON SCHEMA :: Person TO [CogRxUser]  
GO  



==========================================================
select name, 
    has_perms_by_name(name, 'OBJECT', 'EXECUTE') as has_execute,
    has_perms_by_name(name, 'OBJECT', 'VIEW DEFINITION') as has_view_definition
from sys.procedures
==============================================================================
SELECT 
  ROUTINE_SCHEMA,
  ROUTINE_NAME
FROM INFORMATION_SCHEMA.ROUTINES
WHERE ROUTINE_TYPE = 'PROCEDURE';
==========================================================
select * from sys.objects


select * from i
select * from sys.tables where name = 'CustomerItemPricing'

SELECT DISTINCT(WholesalerAccountAttribute)  FROM RAW.SALES

SELECT COUNT(*) FROM RAW.SALES WHERE WholesalerAccountAttribute = 'UNK'