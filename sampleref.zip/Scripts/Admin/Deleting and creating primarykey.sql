
 
-- Return the name of primary key.  
SELECT name  
FROM sys.key_constraints  
WHERE type = 'PK' AND OBJECT_NAME(parent_object_id) = N'SalesTotals';  
  
-- Delete the primary key constraint.  
ALTER TABLE dbo.SalesTotals  
DROP CONSTRAINT PK_SalesTotals; 

select * from dbo.sales where WholesalerAccountNumber is NULL 

update dbo.salestotals set WholesalerAccountNumber = 0

--Adding new primary key constraint
ALTER TABLE dbo.SalesTotals 
   ADD CONSTRAINT PK_SalesTotals PRIMARY KEY (ClientId,CustomerId,Ndc,PriceTypeGroupId,
                                              SupplierId,WholesalerAccountNumber);

                                             
 select top 100 * from dbo.SalesTotals st 