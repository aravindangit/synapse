BEGIN TRY  
    WHILE @rownum > 1
    BEGIN
        INSERT INTO dbo.bestsellers (id, name, datastring, country)
        VALUES (@id, @name, @datastring, @country)
    END
END TRY  
BEGIN CATCH  

    PRINT '================================================';  
    PRINT 'ERROR: @rownum=' + cast(@rownum as varchar) +  ' @name=' + @name + ' @datastring=' + @datastring  + ' @country=' + @country;
    PRINT '================================================';  
    THROW

END CATCH; 