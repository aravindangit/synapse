
--sp lookup inside all other sp

DECLARE @Search varchar(255)
SET @Search = 'DataFeedLog'

; WITH CTE AS 
(
    SELECT DISTINCT o.name AS Object_Name, o.type_desc
    FROM sys.sql_modules m 
    INNER JOIN sys.objects o ON m.object_id = o.object_id
    WHERE m.definition LIKE '%' + @Search + '%'

    UNION ALL

    SELECT o.name AS Object_Name, o.type_desc
    FROM sys.sql_modules m 
    INNER JOIN sys.objects o ON m.object_id = o.object_id
    , cte AS c
    WHERE m.definition LIKE '%' + c.Object_Name + '%'
      AND o.name <> c.Object_Name
)
SELECT * 
FROM Cte 
;