with Gx_Indicator as
                        (select distinct GPIDrugNameCode,Gx_Indicator from pharmacyitem where Gx_Indicator is not null)

                    SELECT
                         REPLACE(GpiName, '-', ' - ') as GpiName
                        ,HealthSystemId
                        ,Gpi10
                        ,Inc_Days
                        ,MissingDollars
                        ,MissingUnits
                        ,HsCount
                        ,HsMax
                        ,IncPerDay
                        ,IncPerDay_NoTop
                        ,Spread
                        ,Filled
                        ,ContractCount
                        ,HasShortage
                        ,gx.Gx_Indicator as PGxIndicator
                    FROM NationalPriceDisruptions.[ResultsGpi] rgpi
                    LEFT JOIN Gx_Indicator gx on rgpi.Gpi10=gx.GPIDrugNameCode
                    ORDER BY Inc_Days DESC