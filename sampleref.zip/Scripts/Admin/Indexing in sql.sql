To disable an index, you use the ALTER INDEX statement as follows:

ALTER INDEX index_name
ON table_name
DISABLE;



To disable all indexes of a table, you use the following form of the ALTER INDEX statement:

ALTER INDEX ALL ON table_name
DISABLE;


ALTER INDEX ix_cust_city 
ON sales.customers 
DISABLE;


SELECT    
    first_name, 
    last_name, 
    city
FROM    
    sales.customers
WHERE 
    city = 'San Jose';

   
   This statement disables all indexes of the sales.customers table:

ALTER INDEX ALL ON sales.customers
DISABLE;
Code language: SQL (Structured Query Language) (sql)
Hence, you cannot access data in the table anymore.

SELECT * FROM sales.customers;


Enable index using ALTER INDEX and CREATE INDEX statements
This statement uses the ALTER INDEX statement to �enable� or rebuild an index on a table:

ALTER INDEX index_name 
ON table_name  
REBUILD;
Code language: SQL (Structured Query Language) (sql)
This statement uses the CREATE INDEX statement to enable the disabled index and recreate it:

CREATE INDEX index_name 
ON table_name(column_list)
WITH(DROP_EXISTING=ON)
Code language: SQL (Structured Query Language) (sql)
The following statement uses the ALTER INDEX statement to enable all disabled indexes on a table:

ALTER INDEX ALL ON table_name
REBUILD;
Code language: SQL (Structured Query Language) (sql)
Enable indexes using DBCC DBREINDEX statement
This statement uses the DBCC DBREINDEX to enable an index on a table:

DBCC DBREINDEX (table_name, index_name);
Code language: SQL (Structured Query Language) (sql)
This statement uses the DBCC DBREINDEX to enable all indexes on a table:

DBCC DBREINDEX (table_name, " ");  
Code language: SQL (Structured Query Language) (sql)
Enable indexes example
The following example uses the ALTER INDEX statement to enable all indexes on the sales.customers table from the sample database:

ALTER INDEX ALL ON sales.customers
REBUILD;
Code language: SQL (Structured Query Language) (sql)
In this tutorial, you have learned various statements including ALTER INDEX, CREATE INDEX, and DBCC DBREINDEX to enable one or all indexes on a table.