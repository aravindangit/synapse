with cte as (
SELECT
         JCode
        ,Dosage
        ,ClientId
        ,QuarterDate
        ,PriceList                        
        ,'ASP - 22.5%' as 'Reimbursement Rule'                            
        , CAST(ISNULL(SUM(Cost) / NULLIF(Sum(DispQty),0),0) AS DECIMAL(10, 2)) as '340bcost'
        ,SUM(DispQty)* 4 as 'TotalUnits'
        ,CAST(CurrentASP AS DECIMAL(10, 2)) as CurrentASP
    FROM
    (
        SELECT
            ptg.PriceTypeGroupDescription AS 'PriceList'
            ,c.ClientId
            ,s.QuarterDate
            ,c.CustomerId
            ,s.Qty AS 'SalesQty'
            ,s.Qty*s.UnitPrice AS 'Cost'
            ,asp.HcpcsCode AS 'JCode'
            ,asp.HcpcsCodeDosage as 'Dosage'
            ,asp.BillableUnitsPer11DigitNDC*s.Qty AS 'DispQty'
            ,asp.AspUnitPrice as CurrentASP
        FROM Sales s
            JOIN Customer c ON s.CustomerId = c.CustomerId AND s.ClientId = c.ClientId
            JOIN AspPriceAndLimits asp ON asp.Ndc = s.Ndc AND asp.IsCurrentRecords = 1
            JOIN PriceTypeGroup ptg ON ptg.PriceTypeGroupId = s.PriceTypeGroupId
            WHERE --s.ClientId = 6 --(select ClientId from Client)
            --and asp.HcpcsCode = 'j0153'
      --      and ptg.PriceTypeGroupDescription <> 'UNK' and 
            --and s.QuarterDate='20220101' and 
            ptg.PriceTypeGroupDescription='340b'
    ) TOTALS
    GROUP BY
        JCode
        ,Dosage
        ,ClientId
        ,QuarterDate
        ,PriceList
        --,CustomerId                        
        ,CurrentASP
    )
    select
    JCode as HCPCSCode
    ,PriceList as AccountType
    ,QuarterDate
    ,[Reimbursement Rule]
    ,CAST(TotalUnits AS int) as AnnualizedVolume
    ,CEILING(CAST(([340bcost] * TotalUnits) AS DECIMAL(10,2))) as Expenses
    ,CEILING(CAST((CurrentASP * TotalUnits) AS DECIMAL(10,2)) - CAST(( CurrentASP * TotalUnits * 0.225) AS DECIMAL(10,2))) AS Revenue
    ,CEILING(CAST((CurrentASP * TotalUnits) AS DECIMAL(10,2)) - CAST(( CurrentASP * TotalUnits * 0.225) AS DECIMAL(10,2)) - CAST(([340bcost] * TotalUnits) AS DECIMAL(10,2))) as Margin
    from cte
    ORDER BY JCode